#!/usr/bin/env python3
"""Resolve explicit portable aliases. Never recursively load history or source assets."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
def resolve_reference(paper_id, reference, allow_candidate=False):
    index=json.loads((ROOT/'active_index.json').read_text())
    row=next((r for r in index['records'] if r['paper_id']==paper_id),None)
    if row is None: raise KeyError('Paper is not selected in this release')
    if not row.get('default_eligible', False) and not allow_candidate: raise KeyError('Candidate is not yet eligible; review mode must be explicit')
    selection=json.loads((ROOT/row['version_selection']).read_text())
    if selection.get('workbook_representation_bindings'):
        import workbook_reference_resolver as wr
        wr.ROOT=ROOT
        wr.guard_ordinary_reference(paper_id, reference, allow_candidate)
    result=selection['active_reference_aliases'].get(reference)
    if result is None: raise KeyError('Reference is external, historical, or unrecognized; not active')
    allowed={f['path'] for f in selection['active_scientific_files']+selection.get('required_supporting_files',[])}
    if result not in allowed or not (ROOT/result).is_file(): raise ValueError('Alias target is not an active delivered file')
    return result

# Reviewed-candidate extension staged separately; do not modify frozen prior resolver.
def resolve_json_pointer(paper_id, reference, pointer, allow_candidate=False):
    """Resolve a JSON document reference and its explicit pointer, including proven subtree relocation."""
    result = resolve_reference(paper_id, reference, allow_candidate=allow_candidate)
    index = json.loads((ROOT/'active_index.json').read_text())
    row = next(r for r in index['records'] if r['paper_id'] == paper_id)
    selection = json.loads((ROOT/row['version_selection']).read_text())
    if pointer != '' and not pointer.startswith('/'):
        raise ValueError('A JSON pointer must be empty or begin with /')
    projections = [p for p in selection.get('subdocument_alias_projections', []) if p['reference'] == reference]
    if len(projections) > 1:
        raise ValueError('Ambiguous subdocument projection')
    if projections:
        p = projections[0]
        if p['target'] != result:
            raise ValueError('Subdocument target differs from selected alias')
        prefix = p['source_pointer_prefix']
        if not (pointer == prefix or pointer.startswith(prefix + '/')):
            raise ValueError('Pointer is outside the proven source subtree')
        pointer = p['target_pointer_prefix'] + pointer[len(prefix):]
    successors = [p for p in selection.get('accepted_successor_aliases', []) if p['reference'] == reference]
    if len(successors) > 1:
        raise ValueError('Ambiguous accepted successor')
    if successors:
        successor = successors[0]
        if successor['target'] != result:
            raise ValueError('Accepted successor target differs from selected alias')
        if pointer:
            relocated = False
            for relocation in successor['historical_metadata_relocations']:
                prefix = relocation['old_pointer']
                if pointer == prefix or pointer.startswith(prefix + '/'):
                    pointer = relocation['current_pointer'] + pointer[len(prefix):]
                    relocated = True
                    break
            if not relocated:
                if pointer not in successor['pointer_mapping']:
                    raise ValueError('Old-version pointer has no verified successor mapping')
                pointer = successor['pointer_mapping'][pointer]
    value = json.loads((ROOT/result).read_text())
    if pointer:
        for token in pointer[1:].split('/'):
            token = token.replace('~1', '/').replace('~0', '~')
            value = value[int(token)] if isinstance(value, list) else value[token]
    return result, pointer

def resolve_reference_occurrence(paper_id, source_file, json_pointer, reference=None, allow_candidate=False):
    """Resolve only a reviewed, exact contextual acceptance reference. Never fall back to a global filename."""
    import hashlib
    index = json.loads((ROOT / 'active_index.json').read_text())
    row = next((r for r in index['records'] if r['paper_id'] == paper_id), None)
    if row is None:
        raise KeyError('Paper is not selected')
    if not row.get('default_eligible', False) and not allow_candidate:
        raise KeyError('Candidate review mode must be explicit')
    selection = json.loads((ROOT / row['version_selection']).read_text())
    selected = {f['path'] for f in selection['active_scientific_files'] + selection.get('required_supporting_files', [])}
    support = {f['path'] for f in selection.get('required_supporting_files', [])}
    science = {f['path'] for f in selection['active_scientific_files']}
    entries = [b for b in selection.get('occurrence_scoped_reference_bindings', []) if b['source_file'] == source_file and b['json_pointer'] == json_pointer]
    if len(entries) != 1:
        raise KeyError('Unknown, missing or ambiguous contextual reference; no global fallback')
    b = entries[0]
    target = b['target']
    if source_file not in selected or target not in support or target in science:
        raise ValueError('Contextual acceptance target must be a selected nonactive supporting snapshot')
    if not source_file.startswith('full/' + paper_id + '/') or not target.startswith('full/' + paper_id + '/'):
        raise ValueError('Cross-paper contextual reference')
    manifests = {f['path']: f for f in json.loads((ROOT / 'source_file_manifest.json').read_text()) + json.loads((ROOT / 'supporting_file_manifest.json').read_text())}
    def checked(path, chain):
        f = manifests[path]
        data = (ROOT / path).read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        if chain['path'] != path or chain['current_sha256'] != actual or f['sha256'] != actual or chain['original_sha256'] != f.get('source_sha256') or chain['baseline_sha256'] != f.get('baseline_delivered_sha256'):
            raise ValueError('Contextual source/target hash chain mismatch')
        return data
    source = json.loads(checked(source_file, b['source_hash_chain']))
    checked(target, b['target_hash_chain'])
    def pointer(obj, ptr):
        if not ptr.startswith('/'):
            raise ValueError('A concrete source pointer is required')
        for token in ptr[1:].split('/'):
            token = token.replace('~1', '/').replace('~0', '~')
            obj = obj[int(token)] if isinstance(obj, list) else obj[token]
        return obj
    observed = pointer(source, json_pointer)
    if observed != b['reference'] or not isinstance(observed, str) or hashlib.sha256(observed.encode()).hexdigest() != b['source_value_sha256'] or (reference is not None and reference != observed):
        raise ValueError('Contextual reference value mismatch')
    declared = pointer(source, b['declared_target_hash_pointer'])
    if declared != b['declared_target_hash_value'] or declared not in [b['target_hash_chain']['original_sha256'], b['target_hash_chain']['baseline_sha256']]:
        raise ValueError('Declared acceptance hash does not identify the selected snapshot')
    if b['role'] != 'nonactive_acceptance_snapshot' or b['automatic_loading'] is not False or b['global_alias_unchanged'] is not True:
        raise ValueError('Contextual binding is not a nonactive acceptance snapshot')
    return target
# Isolated batch10 source-scoped runtime APIs.
BATCH10_RUNTIME_PROOF_DIGESTS = {'R017': {'occurrence_scoped_subdocument_projections': '2a677ea99454f26914948ece376f7ee222df437fca91ccadd55c6f05822839bb', 'mandatory_local_companion_identity_bindings': '11dddbfb5dd8e82a962190be637c496891b8f395e72f0fac09c49fed4d908f6b', 'required_runtime_pointer_bindings': 'b77626158fee5765234dc39d05cf533cd88052e9096776a5d1dc23e3445b3ab1', 'occurrence_scoped_reference_bindings': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945'}, 'R006': {'occurrence_scoped_subdocument_projections': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'mandatory_local_companion_identity_bindings': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'required_runtime_pointer_bindings': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'occurrence_scoped_reference_bindings': 'c62840e598d13d0efff156ca3d7168e3c587fb1cff4463f30be1286cf7f8b5a7'}, 'R023': {'occurrence_scoped_subdocument_projections': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'mandatory_local_companion_identity_bindings': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'required_runtime_pointer_bindings': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'occurrence_scoped_reference_bindings': 'dcc0d4a42444205cd62eb6363816bf99396de225003e878857207230fe55ce19'}}

# Isolated batch10 resolvers. Caller provides identity, never a mutable selection.
def _batch10_runtime_context(paper_id, allow_candidate=False):
    import hashlib, json
    if paper_id not in BATCH10_RUNTIME_PROOF_DIGESTS:
        raise KeyError('No batch10 source-scoped runtime projection for this paper')
    def canonical(value):
        return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    def load(path):
        p = ROOT / path
        if not p.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('Path escapes release')
        return json.loads(p.read_bytes())
    index = load('active_index.json')
    rows = [r for r in index['records'] if r['paper_id'] == paper_id]
    if len(rows) != 1:
        raise KeyError('Paper is not uniquely selected')
    row = rows[0]
    if not row.get('default_eligible', False) and not allow_candidate:
        raise KeyError('Candidate is not eligible; review mode must be explicit')
    if row['version_selection'] != 'full/' + paper_id + '/version_selection.json':
        raise ValueError('Selection location is not canonical')
    s = load(row['version_selection'])
    if s['paper_id'] != paper_id or s.get('default_eligible') != row.get('default_eligible'):
        raise ValueError('Selection identity or eligibility differs from index')
    for field in ['active_scientific_files', 'required_supporting_files']:
        if s[field] != row[field]:
            raise ValueError('Selection closure differs from index')
    for field, expected in BATCH10_RUNTIME_PROOF_DIGESTS[paper_id].items():
        if canonical(s.get(field)) != expected:
            raise ValueError('Frozen source-scoped proof set missing or modified')
    selected = {f['path'] for f in s['active_scientific_files'] + s['required_supporting_files']}
    support = {f['path'] for f in s['required_supporting_files']}
    science = {f['path'] for f in s['active_scientific_files']}
    manifests = {f['path']: f for f in load('source_file_manifest.json') + load('supporting_file_manifest.json')}
    def checked(path, chain):
        if path not in selected or not path.startswith('full/' + paper_id + '/'):
            raise ValueError('Cross-paper or unselected source/target')
        p = ROOT / path
        if not p.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('Path escapes release')
        data = p.read_bytes(); f = manifests[path]; actual = hashlib.sha256(data).hexdigest()
        if chain['path'] != path or chain['current_sha256'] != actual or f['sha256'] != actual or chain['original_sha256'] != f.get('source_sha256') or chain['baseline_sha256'] != f.get('baseline_delivered_sha256'):
            raise ValueError('Source/target byte identity differs from frozen proof')
        return json.loads(data)
    def pointer(value, q):
        if q and not q.startswith('/'):
            raise ValueError('Invalid JSON pointer')
        for token in q[1:].split('/') if q else []:
            token = token.replace('~1', '/').replace('~0', '~')
            value = value[int(token)] if isinstance(value, list) else value[token]
        return value
    companions = s['mandatory_local_companion_identity_bindings']
    if len(companions) != (5 if paper_id == 'R017' else 0):
        raise ValueError('All five exact manifest-bound companions are required')
    for b in companions:
        if b['target'] not in support or b['target'] in science:
            raise ValueError('Mandatory companion missing or promoted to root')
        checked(b['target'], b['target_hash_chain'])
    return s, support, science, canonical, checked, pointer


def resolve_batch10_subdocument_reference(paper_id, source_file, reference_json_pointer, reference, original_ancestor_sha256, original_json_pointer, allow_candidate=False):
    """Resolve one pinned source occurrence into the current root, without loading its ancestor."""
    s, support, science, canonical, checked, pointer = _batch10_runtime_context(paper_id, allow_candidate)
    rows = [b for b in s['occurrence_scoped_subdocument_projections'] if b['source_file'] == source_file and b['source_reference_pointer'] == reference_json_pointer]
    if len(rows) != 1:
        raise KeyError('Unknown source occurrence; no global or basename fallback')
    b = rows[0]
    if reference != b['reference'] or original_ancestor_sha256 != b['original_ancestor_identity']['sha256']:
        raise ValueError('Reference or original ancestor identity mismatch')
    if b['target'] not in science or source_file not in support:
        raise ValueError('Projection must join required support to the sole current root')
    source = checked(source_file, b['source_hash_chain'])
    if pointer(source, reference_json_pointer) != reference or pointer(source, b['source_pointer_declaration']) != b['source_pointer_prefix']:
        raise ValueError('Source occurrence or declared subtree differs')
    prefix = b['source_pointer_prefix']
    if prefix != '/current_evidence_view' or not (original_json_pointer == prefix or original_json_pointer.startswith(prefix + '/')):
        raise ValueError('Requested fragment is outside the exact proven current subtree')
    target_pointer = b['target_pointer_prefix'] + original_json_pointer[len(prefix):]
    current = checked(b['target'], b['target_hash_chain'])
    if canonical(current) != b['target_current_value_canonical_sha256']:
        raise ValueError('Current projected root differs from frozen proof')
    pointer(current, target_pointer)
    return b['target'], target_pointer


def resolve_batch10_support_fragment(paper_id, source_file, source_json_pointer, reference=None, allow_candidate=False):
    """Resolve an exact pinned file-plus-fragment occurrence into required support."""
    s, support, science, canonical, checked, pointer = _batch10_runtime_context(paper_id, allow_candidate)
    rows = [b for b in s['required_runtime_pointer_bindings'] if b['source_file'] == source_file and b['source_json_pointer'] == source_json_pointer and b['binding_kind'] == 'explicit_file_fragment_reference']
    if len(rows) != 1:
        raise KeyError('Unknown source fragment occurrence; no fallback')
    b = rows[0]
    if b['target'] not in support or b['target'] in science:
        raise ValueError('Fragment target is not mandatory same-paper support')
    source = checked(source_file, b['source_hash_chain']); observed = pointer(source, source_json_pointer)
    if observed != 'inherited_status.json#' + b['target_json_pointer'] or (reference is not None and reference != observed) or canonical(observed) != b['current_source_value_canonical_sha256']:
        raise ValueError('Source fragment value differs from frozen proof')
    target = checked(b['target'], b['target_hash_chain']); value = pointer(target, b['target_json_pointer'])
    if canonical(value) != b['target_current_value_canonical_sha256']:
        raise ValueError('Actual support fragment value differs from frozen proof')
    return b['target'], b['target_json_pointer']


def resolve_batch10_reference_occurrence(paper_id, source_file, json_pointer, reference=None, allow_candidate=False):
    """Resolve a pinned nonactive supporting occurrence, keeping snapshot/finalization roles distinct."""
    s, support, science, canonical, checked, pointer = _batch10_runtime_context(paper_id, allow_candidate)
    if paper_id not in ['R006', 'R023']:
        raise KeyError('No batch10 nonactive support occurrence for this paper')
    rows = [b for b in s['occurrence_scoped_reference_bindings'] if b['source_file'] == source_file and b['json_pointer'] == json_pointer]
    if len(rows) != 1:
        raise KeyError('Unknown nonactive support occurrence; no global fallback')
    b = rows[0]
    required_role = 'nonactive_acceptance_snapshot' if paper_id == 'R006' else 'nonactive_finalization_review_support'
    if b['role'] != required_role or b['target'] not in support or b['target'] in science or b['automatic_loading'] is not False or b['global_alias_unchanged'] is not True:
        raise ValueError('Incorrect nonactive supporting role or selected target')
    source = checked(source_file, b['source_hash_chain']); observed = pointer(source, json_pointer)
    import hashlib
    if observed != b['reference'] or (reference is not None and reference != observed) or hashlib.sha256(observed.encode()).hexdigest() != b['source_value_sha256']:
        raise ValueError('Source occurrence value differs from frozen proof')
    declared = pointer(source, b['declared_target_hash_pointer'])
    if declared != b['declared_target_hash_value'] or declared not in [b['target_hash_chain']['original_sha256'], b['target_hash_chain']['baseline_sha256']]:
        raise ValueError('Declared target hash does not identify the nonactive support')
    if s['active_reference_aliases'][observed] != b['rejected_current_alias_target'] or s['active_reference_aliases'][observed] == b['target']:
        raise ValueError('Global current alias was changed')
    checked(b['target'], b['target_hash_chain'])
    return b['target']
