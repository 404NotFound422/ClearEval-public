# SOLID / SOLID-DL：整篇技术证据拆解

论文：Zhu等，Nature Communications，2024-09-27。DOI：10.1038/s41467-024-52560-7；PMC11436996。

本包是可追溯的文献证据整理，不是实验执行日志。旧库未改写。范围从已制备组织及既有荧光标签开始，覆盖离体标记、透明、成像和结果；不列动物模型构建、病毒注射、活体操作或试剂采购/制造流程。

## 核心结论与正确读法

- SOLID通过低浓度1,2-HxD的脱脂/暂时膨胀补偿后续脱水收缩。优化后的终末脱水使用HxD-TBN，折射率匹配使用BBPN。Fig1C–D开发实验最后用DBE，不能视为最终SOLID全流程。
- 主文仅给出“整鼠脑等大样本”的例示五阶段：1、0.5、0.5、0.5、1天，30°C轻摇。3.5天是这五个脱脂/脱水阶段的算术和；随后BBPN至完全透明，未给固定时长。不能回答“3.5天完成全部透明”，也不能移植到1-mm切片、猪脑或整身。
- SOLID-DL的3天TO-PRO-3、12天IBA1和18天anti-GFP是各自标记实验时间。12天IBA1渗透不等于全部脑组织均匀穿透。抗体通用协议的一抗1–20天、二抗1–20天是两个独立阶段，不能当全部标记流程。
- S3D及S5C的“sample size”是顶视投影面积比。SOLID整脑面积后/前均值0.967899，样本SD 0.029020，n=6 samples。S4B是另一实验的micro-CT逐轴线性比，L–R、A–P、V–D分别约0.939055、0.934565、0.934356，n=3。不得把面积写成线性/体积，或把作者“无明显变化”强化成严格零变化。
- S6为1-mm脑片、表面50μm MIP的荧光兼容试验。GFAP取海马，其余取皮层。relative SBR是透明后SBR/透明前SBR，不是总荧光保留率，也不是同一神经元配对。SOLID的DAPI约0.662、GFP约1.187；大于1不等于荧光蛋白数量增加。源表“-”按图标quenched保留，不能补0。
- 高透明与小形变的结论限定本研究条件。SOLID与iDISCO+透明度比较p=0.9643，并非“显著优于所有方法”。猪半脑、P60整身宏观透明图也不能证明其全部标签兼容或相同处理时长。

以上均值/SD由公开Source Data按原分组重算。定位、指标维度、样本和条件列在quantitative_results.csv。SD采用样本标准差；未新增显著性检验。

## 文件与检索

- record.json：完整主记录，包含样本、实验、协议分支、操作、时间、荧光证据、源冲突和缺项。
- branches.csv / operations.csv / time_metrics.csv / flow_structure.json：20条分支和125个阶段操作。B01只带整脑例示时间；B18是其他样本的通用SOLID框架，不带该时间。B08/B09是免疫对照；B19/B20是核染对照。互斥对照不能串成一条流程。
- samples.csv / experiments.csv：9组输入样本、19个实验的条件绑定。没有逐图明确的年龄、器官或尺寸保持未知。
- quantitative_results.csv：1177条技术条件汇总；其中Dice保留每个命名Brain内部的重复值分组，不能当1177个独立实验。
- dice_brain_mean_summaries.csv：240组描述性汇总，先在每个Brain内部求均值，再对4个Brain均值求均值/SD。它们不是作者箱线图统计的复制，也不是新的p值。
- application_statistics.csv：1303条神经血管、投射和AD应用的派生统计、分区变化或排序。与透明性能分开；细胞/血管参数不当形变指标。原始图像未重分析。
- fluorescence_compatibility.csv / antibodies.csv / imaging.csv / metric_definitions.csv：标签类别、标记与成像条件、指标解释。
- source_documents.csv / source_spans.csv / reading_log.csv / query_log.csv：实际来源、文件hash、章节/面板/单元格定位及成功或失败的获取记录。源数据各表覆盖见sheet_coverage.csv。
- source_conflicts.csv / unresolved_items.csv：无法凭现有证据消除的冲突及缺项，不以常识填值。

## 阅读覆盖与边界

已读主文Results、Discussion、Methods全段及所有6张主图；补充信息17页、15图和表1均实际查看。全部25个Source Data工作表已核读结构并建立技术或应用派生记录；S2B仅按原曲线读取，不人为划分像素区间求均值。6部影片各抽12个时间点并实际核看，共72帧；未声称连续播放或逐帧观看。审稿文件为独立审阅者定向核读，reporting summary的年龄信息亦经图像页核验。

任务范围内的科学字段已完成四轮核查：scoped_scientific_four_rounds_complete=true；主文、方法、补图和25表无已知未闭合科学字段遗漏。全部材料穷尽阅读exhaustive_all_materials_read=false：影片是抽帧核读，审稿是定向核读，未重分析TB级原图。旧总字段full_text_decomposition_complete仍为false，沿用较宽的全材料口径，不代表科学字段未完成或只读摘要。所有未报告流程参数与未确认样本独立性仍保留。原文称TB级图像需向作者申请，本次未联系作者，也未声称复现原图定量。

## 必须保留的来源问题

1. HxD-TBN段落在90%HxD/10%TB后又写添加2%胺及dH2O，水量与体积基准不清。没有强行归一为100%。
2. Animals及reporting summary写5xFAD/YFP为12/56周；结果图按3M/8M分组。没有擅改56周。
3. 原文Equation2（包括原公式图像）将Michelson分式写成“和/差”，与通常定义互逆。原数据按出版结果保留，不替作者改公式。
4. 正文“其他溶剂法深度<4500μm”是概述；Source Data有PEGASOS单一样本4566μm，不当作严格上限。
5. Par18对3M/8M胞体受侵方向的句子与随病程增加的解释/图示不一致。
6. iDISCO+透明图示有漂白步骤，Par41未写；Par35免疫流程另有漂白。两协议分开。
7. S3C图注uDISCO的p项重复，不作为新增实验。
8. S4D图注称relative SBR但坐标/源表写SBR且缺少before归一说明，区别S6。
9. S5C的heart与stomach在EZClear/F-CUBIC/SHIELD三组共九个原值逐项相同，标为源数据重复疑点，不自行修改。

SOLID最终pH数字、BBPN实测RI、透明后长期荧光稳定时长未报告。任何未知都不能从其他方法移植。

## 审阅与交付

R1冻结后由独立审阅者进行R2逐项校对、R3协议/时间/荧光专项和R4实际查询；独立验收已完成，审查结论及所绑定科学版本hash见review/final_acceptance.json。初始R2/R3文件保留当时的revisions_required状态作为历史；最终验收确认必要修订关闭。科学字段在验收后未改写。

最终轻量包仅含派生JSON/CSV、中文说明和审阅/校验结果，不含原文XML、PDF、原图、源XLSX、视频或渲染副本。完整源文件仅供工作区溯源。
