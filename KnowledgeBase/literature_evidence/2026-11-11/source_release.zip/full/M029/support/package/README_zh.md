# M029 · OPTIClear / next-generation histology

论文：Lai 等，2018，Next generation histology methods for three-dimensional imaging of fresh and archival human brain tissues。DOI：[10.1038/s41467-018-03359-w](https://doi.org/10.1038/s41467-018-03359-w)。

## 当前版本与审核状态

**本包已通过独立四轮审阅，最终状态为 accepted_scope_complete。** `record_R2.json` 的 11 项返修全部回核通过；25 张当前 CSV、嵌套平表和来源/采样引用共 397 项检查全部通过。正式验收见 `review/final_acceptance.json`，逐项返修核验见 `review/revision_verification_R2.json`。

R1、R2 及两版关联协议均冻结未改写。R2 文件内部及作者生成的 `review_rounds.csv`、`revision_change_log` 保留冻结时的待核验状态，作为版本历史；**当前验收状态以最终验收 sidecar 为准**。初版审阅及 R1 结构检查也作为历史保留，不能代替修订后验收。

- R2 SHA256：`a724ec9282d2dcbc8d27e6ee20188382c11f5ab551e569936a03978fb456d917`
- R1 SHA256：`60e7c02ddb58e37d082f2e51d624e73265540809dceb48bf0d15ea8c7ebcff78`
- 修订关联协议附录 SHA256：`0ed157598bdcdc1b107379d20f728c27834f3379a5b45a2dd0059d788e76c034`

本轮覆盖主文全部科学正文、6 图、1 表，补充 PDF 全部 33 页、16 图、4 表及补充方法，电影说明、正式勘误，以及后发作者协议全文 11 页与两图。补充电影 185.22 秒全时段按 1 Hz 抽取的 185 张画面已全部目视检查，科学场景已被独立复核；音轨及原始连续 25 fps 运动未检查。scope-complete 仅指上述已识别的科学材料与场景范围，不表示逐帧/音轨、所有引用文献或公开网页附件目录均重新穷举检查。

## 数据范围

- 23 证据组、46 样本描述、152 条件、128 方法定义
- **332 方法记录行，其中 8 行是外引方法未恢复的占位行**；不能称为 332 个已确认执行或可直接执行的步骤
- 44 结果、41 组织成像条目、3 非组织检测条目、58 印刷数值/量化条目、70 标记条目
- 27 主文/补充图表清单项、17 来源差异、4 个正式勘误字段
- 主文 Table 1 全部 11 行抗体定义；补充 Table 1 的 5 种方法 × 5 个流程位置及 3 条脚注
- 后发作者协议另记 10 项试剂/配液定义、34 步骤、2 图、10 项来源差异；新增实验数为 0

样本描述、条件和 ROI 数量不是独立供体或动物数。只涉及固定离体组织的清透、染色、成像及相关物理/染料试验。fresh 指新取得后进行固定的人组织，不按活体或未经固定组织理解。物种、组织、保存史、尺度和图像结果逐项绑定；年龄、性别、死后间隔及独立生物学 n 未报告时为 null。

## 返修要点与解释边界

1. P110–P117 的可能重复 PBST 洗涤改为原文条款，不能串成已确认的重复执行流程。EGFP/YFP 的 SBC 前处理仅为通用方法候选，实际执行未知。
2. SF10b 与 SF10c 的不同批次分开样本键；c 中从 b 继承的 SDS 1 天、55 °C 仅为共同图注语境候选。SF16 宏观照片的实际测量波段为 null，不继承通用共焦 CV 波段。
3. 正式 [Author Correction](https://www.nature.com/articles/s41467-018-05089-5) 更正 SDS 缓冲体系、PBST Triton、PBST sodium azide、OPTIClear pH 四字段。SDS 当前作者正式更正值为 **0.2 M boric acid**；缓存更正 PDF 残余文字仍为 0.2 M sodium borate，两者来源链保留。旧值由正式勘误回溯，未直接读取历史未更正 PDF。更正不是新实验。
4. 组织厚度、Z 栈/投影跨度、抗体穿透、DiI 扩散距离、神经突长度是不同量。Fig4 局部全厚显示不证明整块均匀抗体穿透。电影人小脑 NF 的 1500 µm MIP 已连至相应成像采样，不混同主图详细区的 546 µm。Fig4/SF14 的 10 组印刷 xyz 是相对胞体的最长路径终点坐标，不是原始图像真实世界配准坐标。
5. SF4 的信号/背景直方图交叠百分比不是荧光保留率；3 周图像重新优化成像设置。SF9 的 740/645/582 天为不同鼠脑标记的终点，不是人脑或统一无衰减曲线。SF12 的 DiO 在 3 周几乎消失，不能笼统称所有亲脂示踪剂长期稳定。
6. Fig5 主图的 3528 个与 SF15 总数及 ROI 求和的 3582 个不一致；另列 excluded 105 的关系未交代。没有自行选择总数或减去 105。其余样本厚度、固定史、标记名称和时长来源差异均保留。
7. Table 1 抗体宿主、克隆性、IgG 亚类、免疫原和货号完整保留；ST1 是假想样本的五法流程比较，不是新进行的性能试验。SF11 十个 CV 候选、ST2 十九个蛋清候选和 ST4 全部 22 项均保留。失败抗体不等于靶抗原不存在。
8. 原派生 Protocol.xlsx 的 ZO-1 货号 339100 已依主文 Table 1 修为 40-2300。这是派生数据纠错，不是论文勘误。
9. 通用方法建议独立成表，包括可选 DAPI 1 µg/ml、GFAP 补充方案、SDS 时间范围、约 5 mm 取块、长期存放建议和完整物镜型号；没有回填成未知逐图实操。E14 的三个 sampling 引用明确指向非组织光谱检测，E23 的视频投影结果明确指向对应成像采样。

## 文件与关联

- `record_R2.json`：本轮当前修订记录，包含关联作者协议；`record_R1.json` 是历史冻结版本。
- 当前目录的 25 张 CSV 均与 **R2** 同步。`review/final_review_rounds.csv` 是最终验收轮次摘要。当前包文件及 SHA256 清单为 `delivery_manifest.json`；作者旧交付清单不作为本包清单。
- `protocols.csv`：方法记录行，protocol_id 对应一个方法定义；须结合 row_kind、条款顺序角色、候选状态及占位标记解释。
- `samples.csv`、`experimental_arms.csv`、`markers.csv`、`results.csv`、`imaging_rows.csv`、`measurement_rows.csv`、`quantitative_results.csv`：对应平表。样本键在 record_id 内唯一。嵌套对象以 JSON 单元格保留。
- `antibody_table1.csv`、`supplementary_table1.csv`、`supplementary_table1_footnotes.csv`、`main_method_recommendations.csv`：参考定义与作者通用建议，不增加实验。
- `figures.csv`、`sources.csv`、`source_locator_index.json`、`reading_log.csv`：逐项来源定位与阅读范围。
- `source_conflicts.csv`、`version_corrections.csv`、`missing_fields.csv`：来源差异、版本及未知项。
- `movie_scenes.csv`：13 个近似场景区间；电影秒数不是实验处理时长。
- `revision_change_log.json` / `.csv`：11 项返修的实施位置与冻结时待核验状态；最终逐项通过记录见 `review/revision_verification_R2.json`。
- `structure_check.json`：引用、采样链接和结构检查已通过，不替代独立科学核验。
- `review/R2_revision_manifest.json`、`review_rounds.csv`：修订冻结当时的待审状态；原 R1 冻结记录保留。最终状态另见 `review/final_acceptance.json`。

CSV 空单元格对应 JSON null，具体原因见相邻说明。通用物镜清单不应全部映射到每张图。复制旧结构化证据时重新核对本轮原始来源，没有继承旧审阅状态。原资料库保持只读。

## 后发作者协议

[Methods for next generation three-dimensional histology for human neural tissues](https://doi.org/10.1038/protex.2018.087)，2018-08-13 发布，11 页。完整正文及两幅改编图已独立阅读。修订版为 `author_protocol_addendum_R2.json`，另有三份对应 CSV。后发协议的 60 °C Nissl 直接 RI、终稀释、存放建议、流程图时间范围等均独立版本化。DiI 货号在该协议为 D3911，主文为 D282，保留来源特定值，不合并产品，也不回填成主文已执行条件。

原 `author_protocol_addendum.json` SHA256 为 `a24411ec43c8fa23c0411e075c6a4432552595205db4b8c6ba9fc3d6e34ea80b`，保持不变。原作者协议独立阅读意见为历史审阅；修订关联协议现已纳入本包最终独立验收。

## 分发边界

派生成果包仅包含 JSON、CSV 和 README。原 PDF、视频、页面图、全文提取文本、下载缓存和生成脚本不分发。主论文标示 CC BY 4.0；本包为重新整理的派生证据，不是原文副本。

## 审阅记录更正

初版 REV11 与 R4-Q09 曾称 E14 没有检测定义，此说法过强：R1 已有三个 `measurement_sampling` 条目，最初检查器只搜索了 `imaging_sampling`。实际需要修复的是显式集合链接、独立检测平表及不适用的组织物镜说明；R2 已修复并通过回核。这是审阅者的集合查找误判，不是论文错误或新增实验。

所有原始资产均排除；包内只含派生 JSON、CSV 与本文说明。包本身尚未发送给最终接收者，交付由上级汇总。
