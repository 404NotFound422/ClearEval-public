# A124｜SCN–OVLT血管连接与SCN分区血管结构

版本：0.1.2-source-reviewed。用途：2021年论文的非操作性证据阅读与检索。

Identification of the suprachiasmatic nucleus venous portal system in the mammalian brain

Yao等，Nature Communications 12:5643 (2021)。DOI：[10.1038/s41467-021-25793-z](https://www.nature.com/articles/s41467-021-25793-z)。

## 结论与证据边界

固定小鼠脑三维图像支持SCN rostrum至OVLT腹侧浅层血管丛的连续连接。SCN shell的分支节点密度高于core，公开Source Data支持其配对统计。2021年本文没有证明血流方向，也未直接证明AVP或其他昼夜信号经此通路运输。

## 研究问题

### A124-GQ01｜研究适用的材料与分母

本文的物种、材料状态与分析分母怎样限制推论？

直接材料为10–14周龄雄性C57BL/6NJ小鼠固定脑。27个透明化脑中14个用于连接观察、13个用于方法开发；定量从28个可用SCN随机选择6个作配对，动物和侧别映射仍未明确。

范围：不把SCN数、节点数、光学切片数当独立小鼠数。

### A124-GQ02｜透明成像的证据作用

完整组织三维成像支持了何种此前难以追踪的关系？

支持SCN至OVLT中线血管的空间连续性与区域定位。透明化用于解剖应用，不是本文对透明化性能的全面基准比较。

范围：不提取操作参数，不将引用的11%收缩视为本文测量。

### A124-GQ03｜连接的终点

SCN血管是否与OVLT血管床形成可追踪的解剖连接？

图像及描迹显示SCN rostrum附近血管连至OVLT腹侧浅层血管丛。

范围：固定组织拓扑证据；不同方向是同一标本再表达。

### A124-GQ04｜连接的路径与尺度

血管沿何处连接，双侧SCN又有什么关系？

双侧SCN血管床存在吻合，中线通路沿第三脑室底、视交叉上方至OVLT。作者估计两区域相距约385 µm。

范围：385 µm缺群体分布；冠状切片标注50/100 µm冲突保留。

### A124-GQ05｜core/shell密度差

SCN shell是否具有更高的毛细血管分支节点密度？

6个SCN配对中，shell为(8.7 ± 0.7)×10⁻⁶，core为(4.6 ± 1.8)×10⁻⁶ nodes/µm³，mean ± SD；配对t(5)=7.81，p=0.00055。

范围：AVP定义区域；n=6 SCN；不是血流测量。

### A124-GQ06｜跨研究一致性

整SCN密度与既有图谱的比较能否作为独立验证？

作者报告本研究0.132 ± 0.008与Kirst研究0.138 ± 0.029接近，公开回复补充25 µm voxel参照。本轮在明确立方体假设下重组公开6行数表得到0.1240 ± 0.0142，未复得作者整SCN值；不能将这一比较视为已独立验证的等效性。

范围：25 µm voxel参照部分明确；整SCN计算范围、差异来源及外部Kirst原始资料仍未决。core/shell配对结果另已复得。

### A124-GQ07｜方向、分子与功能

解剖连接是否已经证明SCN向OVLT传输AVP或昼夜信号？

2021年本文没有证明。作者保留方向不确定，AVP是候选；本文未直接测量经该通路的血流、分子运输或生理效应。2024年另有方向性研究，单列文献关联，不并入本记录。

范围：AVP定位和血管连续性不足以证明AVP运输。

### A124-GQ08｜新颖性与推广

第二门脉通路主张能推广至哪些物种与脑区？

作者据小鼠材料提出新的SCN–OVLT门脉解剖通路；其他哺乳动物和其他脑室周围器官仍待直接验证。

范围：标题范围不扩大直接证据范围。

## 证据记录

### A124-E01｜固定小鼠脑材料与面板分母

分析层级：脑、小鼠、SCN核团、同核团的core/shell、分支节点是不同层级

- A124-E01-O01：材料为雄性C57BL/6NJ小鼠；主文说购入时8周龄，研究前至少适应2周，Reporting Summary补充实际动物年龄为10–14周。27个透明化脑中，8个双标记和6个三标记脑用于SCN–OVLT连接观察，13个额外脑用于前期方法开发；另有3个生物学独立脑用于共聚焦。不是每个结果均有27个独立重复。

  来源：[Methods: Animals](https://www.nature.com/articles/s41467-021-25793-z#Sec11)；[Reporting Summary PDF page 2, study design](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)；[Reporting Summary PDF page 3, Animals](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)

- A124-E01-O02：Fig. 2及Supplementary Fig. 3标N=8 mice；Fig. 3和Supplementary Fig. 4标N=6 mice；Fig. 4a标N=6 mice；Fig. 4biii明确N=6 SCN。Supplementary Fig. 5c说明5个重建核团加Fig. 4bii的1个核团构成这6个SCN。

  来源：[Fig. 2a–e and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig2)；[Fig. 3a–c and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig3)；[Fig. 4a–biii and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig4)；[Supplementary Information PDF pages 7–8, Fig. 5a–c](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)；[Reporting Summary PDF page 2, study design](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)；[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)

- A124-E01-O03：材料取自开灯后5小时这一报告时点；本文没有给出多个昼夜相位的血管或血流时间序列。

  来源：[Methods: Animals](https://www.nature.com/articles/s41467-021-25793-z#Sec11)

- A124-E01-O04：Reporting Summary说从28个可用SCN中随机选择6个作分支密度分析，比较为同核团core/shell配对；Source Data仅以SCN1–SCN6标识，没有动物或左右侧映射。作者还报告双标记2次、三标记3次独立重复，所有复验成功；两名独立研究者的描迹结果一致，但没有给出量化一致性指标或明确盲法细节。“无数据排除”是作者的数据集声明，不能消除Methods对血管段直径的分析纳入规则。

  来源：[Reporting Summary PDF page 2, study design](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)；[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)

- 限制：不同图面的n不能相加；同一资料的不同方向、投影或描迹不增加独立样本数。

- 限制：已读Reporting Summary、Source Data与定向Peer Review内容，6个SCN至动物/左右侧映射仍未找到。

### A124-E02｜三维标记定位支持SCN与OVLT血管连续性

分析层级：已固定完整脑组织中的血管拓扑

- A124-E02-O01：本文实际应用iDISCO组织透明化、免疫标记与光片显微成像研究小鼠脑血管。AVP信号用于界定SCN及其富AVP的shell；collagen用于血管定位；SMA用于动脉定位。SCN和OVLT在同一扫描区域内呈现。 Reporting Summary明确包含双标记和三标记材料，不把所有8只或6只图示动物都自动视为同一标记方案。

  来源：[Results: Identification and visualization of the SCN, OVLT, and capillaries; Methods: Image processing](https://www.nature.com/articles/s41467-021-25793-z#Sec3)；[Supplementary Information PDF page 2, Fig. 1](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)；[Reporting Summary PDF page 2, study design](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)；[Methods: Antibodies; Immunostaining; Light-sheet microscopy, signal identities only](https://www.nature.com/articles/s41467-021-25793-z#Sec14)

- A124-E02-O02：Fig. 2及Supplementary Fig. 3在同一标本的矢状及水平展示中，可见血管由SCN前端rostrum附近沿中线连接至OVLT腹侧浅层毛细血管丛；三维图、最大强度投影和配套描迹给出相互对应的解剖连续性。

  来源：[Fig. 2a–e and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig2)；[Supplementary Information PDF pages 4–5, Fig. 3a–e](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)；[Methods: Light-sheet microscopy (Fig. 2/Supplementary Fig. 3 same sample)](https://www.nature.com/articles/s41467-021-25793-z#Sec16)

- 限制：投影和描迹是同一组织的表示方式，不是新增动物复验。

- 限制：胶原与SMA的组织信号支持血管身份/空间关系，不构成活体灌流方向或运输量的直接测量。

### A124-E03｜中线通路、双侧SCN吻合与相邻结构

分析层级：血管路径及区域间几何关系

- A124-E03-O01：Fig. 3和Supplementary Fig. 4显示双侧SCN血管床在第三脑室底部相连，并在SCN rostrum形成吻合；连接OVLT的血管沿第三脑室底、视交叉上方的近中线路径延续。更外侧的动脉与非该通路静脉不属于作者所描绘的中线连接。

  来源：[Fig. 3a–c and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig3)；[Supplementary Information PDF page 6, Fig. 4a–b and legend](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)

- A124-E03-O02：作者报告SCN与OVLT之间约385 µm的间距，Fig. 3a亦标出385 µm。该数值为图示/作者报告的近似几何距离，没有群体均值、误差或样本分布；不能直接当作活体运输距离或动力学参数。

  来源：[Fig. 3a–c and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig3)；[Results: final paragraph of Identification and visualization; Discussion opening](https://www.nature.com/articles/s41467-021-25793-z#Sec3)

- A124-E03-O03：Supplementary Fig. 4的冠状光学切片厚度存在来源内部不一致：主文Results/Methods和图4a示意标100 µm，补图4图注标50 µm。本稿并列保留，未自行决定实际值。

  来源：[Supplementary Information PDF page 6, Fig. 4a–b and legend](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)；[Results: continuity paragraph; Methods: Vascular tracing and optic slicing](https://www.nature.com/articles/s41467-021-25793-z#Sec18)

- 限制：该不一致影响图像取样元数据复用；不自动推翻已有血管解剖连接图像。

### A124-E04｜同一SCN内shell与core的血管分支节点密度

分析层级：6个SCN的核团内配对区域

- A124-E04-O01：固定透明组织图像提示富AVP的shell血管网络比core更密集复杂；独立的固定切片共聚焦图使用AVP及tomato lectin显示一致的定性区域差异。共聚焦图为N=3 mice，不是再增加3个定量SCN。

  来源：[Fig. 4a–biii and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig4)；[Supplementary Information PDF pages 7–8, Fig. 5a–c](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)；[Reporting Summary pages 2–3, confocal signal identities only](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)

- A124-E04-O02：对6个SCN的配对分析显示，core分支节点密度为(4.6 ± 1.8) ×10⁻⁶ nodes/µm³，shell为(8.7 ± 0.7) ×10⁻⁶ nodes/µm³，±为SD。作者报告双侧配对t检验t(5)=7.81，p=0.00055。

  来源：[Fig. 4a–biii and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig4)；[Methods: Statistical analysis](https://www.nature.com/articles/s41467-021-25793-z#Sec20)；[Supplementary Information PDF pages 7–8, Fig. 5a–c](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM1_ESM.pdf)；[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)

- A124-E04-O03：分支节点定义为有至少3条分支的节点；分析排除直径大于10 µm的血管段。密度分母是各自core或shell体积；不是单纯节点总数，也不是荧光亮度或血流量。作者对配对密度差做Shapiro–Wilk检验(p=0.91)。

  来源：[Methods: Statistical analysis](https://www.nature.com/articles/s41467-021-25793-z#Sec20)；[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)

- A124-E04-O04：作者报告shell体积(1.53×10⁷ ± 1.39×10⁶) µm³，core体积(3.66×10⁶ ± 9.16×10⁴) µm³，均为mean ± SD。Fig. 4biii箱体显示中位数与四分位数，须线为1.5×IQR；连接线表示同一SCN配对，不能把箱图中位数误当文中均值。

  来源：[Fig. 4a–biii and legend](https://www.nature.com/articles/s41467-021-25793-z#Fig4)；[Methods: Statistical analysis](https://www.nature.com/articles/s41467-021-25793-z#Sec20)；[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)

- A124-E04-O05：本轮按Source Data的节点数、区域体积及原表公式作只读复算，得到core 4.6145 ± 1.8050、shell 8.7373 ± 0.7352 nodes/10⁶ µm³；配对t=7.8118，双侧p=0.0005510，差值Shapiro–Wilk p=0.90586，均与正文舍入值一致。此为公开数表的汇总算术核验，不是重新描迹或独立生物学复验。

  来源：[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)

- 限制：6个SCN究竟来自多少只动物及左右核团对应关系在当前读取来源中未明确。

- 限制：不从图形反推原始重复值，不从SD或p值反推新的动物样本数。

### A124-E05｜整SCN与外部血管图谱的作者比较

分析层级：不同研究的整SCN汇总值

- A124-E05-O01：作者将自身整SCN分支密度0.132 ± 0.008 per unit volume与Kirst等的0.138 ± 0.029作描述性比较。公开同行评审回复第7页补充其单位参照为25 µm voxel；这部分解决单位说明缺项，但外部Kirst原始数据与两研究可比性尚未在本轮独立核验。

  来源：[Results: Comparison of SCN shell and core vasculature, paragraph following Fig. 4](https://www.nature.com/articles/s41467-021-25793-z#Sec4)；[Peer Review File PDF page 7, author response on branch density](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM2_ESM.pdf)

- A124-E05-O02：限定的复核尝试：若把25 µm voxel解释为25×25×25 µm³，并对Source Data中6个SCN按(core节点+shell节点)/whole volume换算，所得mean ± SD约为0.1240 ± 0.0142 nodes/voxel，不能复得作者整SCN的0.132 ± 0.008。作者没有给出该整SCN比较的逐项独立数表或完整计算说明；可能使用了不同的取样/计算范围，因此保留为未决对账差异，不据此改写原报告值。

  来源：[Source Data, sheet Fig 4biii, A1:H7](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM6_ESM.xlsx)；[Peer Review File PDF page 7, author response on branch density](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM2_ESM.pdf)

- 限制：25 µm voxel的补充说明来自作者公开回复；不是对外部Kirst原始数据的独立验证。

- 限制：整SCN比较未能用当前六行Source Data与明确假设完全重现，不自动影响已复得的core/shell配对结果。

## 作者主张及解释边界

### A124-A01｜SCN–OVLT门脉通路的新颖性

作者：作者将此解剖连接称为哺乳动物脑内继垂体门脉之后的第二个门脉通路。

边界：直接材料为雄性小鼠固定脑。标题中的mammalian brain不等于已在人类或全部哺乳动物中验证。

来源：[Abstract; Introduction; Discussion](https://www.nature.com/articles/s41467-021-25793-z#Sec6)

### A124-A02｜血流方向与功能输出仍未证明

作者：作者认为既有功能背景提示SCN至OVLT的通信方向，但明确说尚未证明。

边界：解剖连续性不能推出血流方向、流量、浓度增益、昼夜信号传递或生理效应；本文没有相应动态/干预证据。

来源：[Discussion: SCN-OVLT communication; Neurosecretions](https://www.nature.com/articles/s41467-021-25793-z#Sec6)

### A124-A03｜经通路运输的神经分泌信号尚待确定

作者：作者讨论AVP是候选输出信号，同时强调SCN还有多种潜在分泌物。

边界：AVP在本研究中是解剖定位标记；本文没有直接测量AVP或其他分子经过该血管通路运输。

来源：[Discussion: SCN-OVLT communication; Neurosecretions](https://www.nature.com/articles/s41467-021-25793-z#Sec6)

### A124-A04｜组织透明化的作用及收缩引文边界

作者：作者认为完整组织成像有助于保存物理切片时易受损的中线血管，并引用约11%的iDISCO收缩幅度解释几何观察。

边界：未见本研究对所有材料逐标本测得11%收缩；这是引用既往方法研究的背景，不是本文的新收缩测量或已验证的活体尺寸校正。

来源：[Results: Identification and visualization of the SCN, OVLT, and capillaries; Methods: Image processing](https://www.nature.com/articles/s41467-021-25793-z#Sec3)

### A124-A05｜其他脑区或物种的推广

作者：作者提出其他脑室周围器官附近可能存在类似门脉，且小鼠发现可能见于其他哺乳动物。

边界：这是待验证推广；本文未对这些器官或其他物种建立同类连接。

来源：[Discussion: Question of additional brain portal systems](https://www.nature.com/articles/s41467-021-25793-z#Sec9)

### A124-A06｜标记完整性与描迹一致性的范围

作者：在公开审稿回复中作者承认不能排除漏标部分血管；Reporting Summary报告两名研究者描迹一致。

边界：存在连接的证据不等于全血管覆盖率已验证；两人结果一致的文字声明不等于已量化准确度、盲法或重复性。

来源：[Peer Review File PDF pages 6–7, author response about potentially missed vessels](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM2_ESM.pdf)；[Reporting Summary PDF page 2, study design](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-021-25793-z/MediaObjects/41467_2021_25793_MOESM5_ESM.pdf)

## 未决事项

- A124-U01：随机选取的6个SCN至动物/左右侧映射未明确；Source Data仅列SCN标签。不能自行写成6只独立小鼠。

- A124-U02：Supplementary Fig. 4图注50 µm与图示及主文100 µm不一致。

- A124-U03：2021年本文没有直接证明血流方向及特定分子的通路运输/生理作用。另有2024年方向性研究，不能并入本记录。

- A124-U04：作者回复补充25 µm voxel单位参照，但按明确立方体假设重组6行数据得0.1240 ± 0.0142，未复得0.132 ± 0.008；具体计算/取样范围和外部Kirst数表未独立确认。

- A124-U06：可能漏标血管仍被作者保留；两名研究者一致没有量化准确性或盲法证明。

## 已解决的来源缺项

- A124-U05：初稿时未读的Source Data、Reporting Summary与相关Peer Review内容已在初稿后取得并按所声明范围核读；原ID保留。

## 文献时间边界

后续另有2024年原始研究[Blood flows from the SCN toward the OVLT within a new brain vascular portal pathway](https://doi.org/10.1126/sciadv.adn8350)。这里只使用已核验的书目信息与标题，将它作为独立的后续方向性研究提示。本稿没有把2024年的实验纳入2021年的观测记录，也不据此增加本次论文计数。

## 覆盖与核验

已视觉核读主图1–5、补充材料8页；读取Reporting Summary并核对第2–3页；完整只读核验Source Data唯一工作表A1:H7。公开同行评审文件只做相关议题定向核读。补充视频说明已读；视频本体长175.5754秒，按每15秒取样的12帧全时段缩略联系表已核读，呈现固定组织三维图像与描迹，未作逐帧或像素级审计。初稿后定向查找更正与缺失证据，未找到对应更正条目，但该阴性检索不证明不存在更正。

core/shell数表算术核验不等于重新分割、重新描迹或实验复现。整SCN比较的未决对账问题与已核实的分区配对结果分别保存。

本稿只提供公开汇总结果及出处，不含生物实验配方、透明化参数、操作优化或逐个样本原始数表。
