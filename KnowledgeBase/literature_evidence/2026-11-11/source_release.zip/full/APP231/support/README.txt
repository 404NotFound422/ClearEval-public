APP231 单篇证据完成轻包｜2026-10-19

先读逐篇证据说明.txt。evidence_record.json为主记录；9个CSV为对应平表；来源链接.txt列出独立公开来源。review/independent_review.json及审查说明为独立审查，validation为机器一致性检查，二者不能互相替代。

四轮完成不代表无缺值。原文非孕/孕措辞冲突、PI最终浓度、每图样本数及成像细节保留为unknown；功能作用仅假说。视频为全时长抽帧核验，非逐帧人工播放。

本包只含派生数据、中文说明、审查与验证，不含原全文XML/PDF、图片或视频。来源文件仅在工作目录存档，记录中的cache_path是核查出处，不保证轻包内存在。原库未改。validate_record.py仅需本包Python标准库，可复核结构一致性。
