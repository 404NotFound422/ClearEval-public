# A121 当前方法记录

保留稳定P/step/case标识；来源继承和本轮范围见REVIEW.md。未报告不是空白许可；候选分支不得合并执行。

## A121-P001 人肝新鲜块/活检改良CLARITY与ECM标记
- record_type: partially_reported_workflow
- purpose: 记录本文透明化、染色和观察，来源缺项/冲突不补造。
- applicability: {"fresh_human":"nonfibrotic/resected/explant/biopsy;monomersbymaterial","not_automatically_inherited":"mouseincubationtime,FFPEdeparaffinization,2Dhistology"}
- start_state: 来源人肝组织，样本类型区分。
- end_state: 染色、核染并RIM保存待装管组织。
- provenance: {"source":"institutionaloriginal11-pagePDF+officialSupplementDOCX","original_protocol_workbook":null}
- materials: ["RPMI1640;FBS;antibiotic-antimycotic","Acrylamide;PFA;VA044;PBS;saponin;optionalbis","Sunfloweroil;boricacid;SDS;glycerol","CollagenI/Elastinantibodies;CY3secondary;goatserum;Hoechst","Nycodenz;phosphatebuffer;lowmeltingagarose"]
- preparation_and_warnings: ["作者源核候选；不代表实验重现、临床可用性或Pro接受。"]
- reported_precedence: [{"before":"A121-P001-S01","after":"A121-P001-S03","scope":"tissuehistory"},{"before":"A121-P001-S02","after":"A121-P001-S03","scope":"reagentpreparation"},{"before":"A121-P001-S03","after":"A121-P001-S04","scope":"humanroute"},{"before":"A121-P001-S04","after":"A121-P001-S05","scope":"humanroute"},{"before":"A121-P001-S05","after":"A121-P001-S06","scope":"humanroute"},{"before":"A121-P001-S06","after":"A121-P001-S07","scope":"glycerol-to-staintransitiondetailmissing"},{"before":"A121-P001-S07","after":"A121-P001-S08","scope":"staining"},{"before":"A121-P001-S08","after":"A121-P001-S09","scope":"staining"},{"before":"A121-P001-S10","after":"A121-P001-S09","scope":"RIMcompositionpreparedseparately,notaftertissueprocessing"}]
- missing_information: []
- source_conflicts: []
- review_status: source_read_author_revision;independent integration pending

### A121-P001-SEC01 HM与清除

#### A121-P001-S01 转运与材料范围
- action: 新鲜人肝组织置RPMI1640加20%FBS、1%penicillin-streptomycin-amphotericinB转运液。主要染色选长>10mm的样本；不把典型1.4mm×2cm活检尺寸当所有切块实测。
- parameters: {"transfer":"RPMI1640+20%FBS+1%penicillin-streptomycin-amphotericinB","selection":"liversamplesover10mmlength","typical_biopsy_context":"diameter1.4mm,length2cm inResults"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph12, starts: Liver tissues were put into transfer media","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Clarifying","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp3: Wholecorebiopsies","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["转运时间/温度与各组尺寸分布未报；临床病因只是来源状态，不恢复任何病毒实验。"]
- legacy_rows: []

#### A121-P001-S02 HM配方：组织类型分支
- action: 改良HM含1%acrylamide、4%PFA、0.25%VA044、1×PBS、0.05%saponin和水。移植/切除块不加bisacrylamide；活检变体加0.025%bisacrylamide。40%acrylamide、16%PFA和2%bis为stock，不能当最终浓度。
- parameters: {"common_final":{"acrylamide":"1%from40%stock","PFA":"4%from16%stock","VA044":"0.25%","PBS":"1×","saponin":"0.05%","water":"distilled"},"explant_variant":"no bisacrylamide","biopsy_variant":"0.025%bisacrylamide from2%stock"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph4, starts: Modified Hydrogel Monomer Solution:","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_TABLE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"TableS4,all4rows;originaltablevisuallyinspectedinrenderedDOCXPDF","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["未给百分比基准和配制总量/stock加液量；原CLARITY表列4%acrylamide/0.05%bis是参考，不与新配方连续执行。新鲜组织单独PFA预固定时程未明确，不加一次额外固定。"]
- legacy_rows: []

#### A121-P001-S03 人肝HM浸入
- action: 组织在适用HM中4°C摇动3–7天，使单体扩散。
- parameters: {"solution":"P001-S02appropriatecase","temperature":"4°C","duration":"3–7days","agitation":"shaker"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph12, starts: Liver tissues were put into transfer media","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["摇速、体积、各样本取3或7天的选择规则未报；不以鼠清除图的周数替代该时程。"]
- legacy_rows: []

#### A121-P001-S04 油层替代除氧与聚合
- action: 补充方法描述在HM表面加入sunfloweroil层代替原始degassingchamber，并于37°C聚合3h。原除气腔是替代路线背景，不再叠加执行。
- parameters: {"oxygen_control":"sunfloweroil layerontopofHM,alternative tooriginaldegassingchamber","polymerization":"37°C,3h"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph12, starts: Liver tissues were put into transfer media","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["油层厚度/体积及容器封闭方式未报；旧除气法详细条件未读，不补造。"]
- legacy_rows: []

#### A121-P001-S05 透明液配方及被动清除
- action: 透明液由200nM硼酸、4%SDS和水组成，调pH8.5，室温保存。聚合后转此液，每日加以更新直到透明。正文及补充都写200nM，照录并标单位疑点。
- parameters: {"boric_acid_as_reported":"200nM","SDS":"4%","vehicle":"distilledwater","pH":8.5,"buffer_storage":"RT","tissue_clearing":"passiveCLARITY,solutionrefresheddailyuntiltransparent","biopsy_clearing_temperature_from_S5A":"37°C,core-biopsy schematic only"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph5, starts: Clearing Solution:","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph12, starts: Liver tissues were put into transfer media","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Clarifying","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_FIGURE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"FigS5A originalembeddedimage;renderedPDF forinspection","mode":"visual","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["200nM未独立核定，不改成常见配方200mM；SDS基准、非活检材料的清除温度、总体积/终点判据未报，RT仅透明液保存，不自动当处理温度。"]
- legacy_rows: []

#### A121-P001-S06 去SDS及透明组织保存
- action: PBS过夜孵育去SDS残留，随后透明人肝保存于86–89%glycerol。
- parameters: {"PBS":"overnight","storage_medium":"86–89%glycerol"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph12, starts: Liver tissues were put into transfer media","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["PBS温度、洗次数/液量、glycerol基准/保存温度/时长和之后转染色的过渡洗法未报。"]
- legacy_rows: []

### A121-P001-SEC02 染色及匹配

#### A121-P001-S07 人肝一抗标记分支
- action: 用anti-CollagenI或anti-Elastin分别作ECM标记；补充写or，不能据正文and认定同一样本混合共染。1:2500一抗置0.1%v/vTween20PBS、0.01%w/vazide中4°C轻摇。
- parameters: {"branches":["CollagenI,Abcam,1:2500","Elastin,MerckMillipore,1:2500"],"buffer":"PBS+0.1%(v/v)Tween20+0.01%(w/v)SodiumAzide","temperature":"4°C","motion":"gentleagitation","TableS5_identity":{"CollagenI":"Abcamab90395,COL-1","Elastin":"Sigma-AldrichMAB2503,clone10B8;main/supptextMerckMillipore"}}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph19, starts: Cleared liver tissues were stained with anti-Collagen","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Stainingofclearedhumanliver","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_TABLE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"TableS5,antibodies/reagentidentityrows;originaltablevisuallyinspectedinrenderedDOCXPDF","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["一抗孵育时长和每样本单/双标对应未报；不从鼠1:100替换人1:2500。"]
- legacy_rows: []

#### A121-P001-S08 洗涤、封闭及人肝二抗
- action: 一抗后PBSTw洗，5%normalgoatserum封闭，再CY3二抗1:500于4°C。正文洗涤写0.01%Tween20，补充只称PBSTw且前定义0.1%，两来源并列。
- parameters: {"wash_main":"PBSTw0.01%(v/v)Tween20","wash_supplement":"PBSTw withoutnewconcentration","block":"5%normalgoatserum","secondary":"CY3-conjugated,1:500,JacksonImmunoResearch,4°C","TableS5_identity":{"secondary_table":"CY3AffiniPureGoatAnti-MouseIgG(H+L),Jackson115-165-003"}}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph19, starts: Cleared liver tissues were stained with anti-Collagen","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Staining","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_TABLE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"TableS5,antibodies/reagentidentityrows;originaltablevisuallyinspectedinrenderedDOCXPDF","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["封闭/二抗时间、各洗次数及温度未报；wash0.01/0.1%未决，不任选。"]
- legacy_rows: []

#### A121-P001-S09 核染与染后RI匹配
- action: Hoechst1:1000/PBS核染，正文明确过夜。洗去多余液后置RIMs，补充给4°C保存到成像。详细染色段与S5均为先染后RIM，与正文总述把RI列在标记前的顺序并列说明。
- parameters: {"nuclear":"Hoechst1:1000 inPBS,overnightpermain","afterwash":"washoffexcess,detailsunreported","poststain":"RIMs,4°C untilimaging","RIM_role":"afterimmunostaining,notextrabefore+afterduplicatedstage","TableS5_identity":{"nuclear_table":"Hoechst33342,InvitrogenH1399"}}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph19, starts: Cleared liver tissues were stained with anti-Collagen","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Staining","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph56, starts: Supplementary Figure S5.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_TABLE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"TableS5,antibodies/reagentidentityrows;originaltablevisuallyinspectedinrenderedDOCXPDF","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["Hoechst孵育温度、末洗条件和RIM平衡时长未报；正文总述的RI-before-labeling不强行再加一次匹配。"]
- legacy_rows: []

### A121-P001-SEC03 独立溶液配制

#### A121-P001-S10 RIM与装管基质独立配制
- action: RIM：40gNycodenz溶于30ml0.02Mphosphatebuffer，37°C溶解、pH7.5，约RI1.45，4°C保存。装管基质：200mg低熔点agarose加10mlRIM，水浴75°C溶解，测RI，4°C存。
- parameters: {"RIM":"40gNycodenz per30ml0.02Mphosphatebuffer;37°C;pH7.5;RI~1.45;store4°C","mounting":"200mg lowmeltingagarose in10mlRIM;75°Cwaterbath;measureRIwithLOYKArefractometer;store4°C"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph7, starts: Refractive Index Matching Solution (RIMs):","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph9, starts: Mounting Media Solution:","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["Nycodenz分母是源缓冲液体积，不假定最终体积或换成最终g/ml。75°C是无组织基质配制，不把组织置75°C；装管时基质工作温度未给。"]
- legacy_rows: []

## A121-P002 FFPE脱蜡及部分清除支线
- record_type: partially_reported_workflow
- purpose: 记录本文透明化、染色和观察，来源缺项/冲突不补造。
- applicability: {}
- start_state: 原有formalin-fixed/paraffin-embedded肝组织。
- end_state: 已报告透明化的档案组织及ECM读出。
- provenance: {"source":"institutionaloriginal11-pagePDF+officialSupplementDOCX","original_protocol_workbook":null}
- materials: ["xylene;ethanol;studyCLARITYreagentsasapplicable"]
- preparation_and_warnings: ["作者源核候选；不代表实验重现、临床可用性或Pro接受。"]
- reported_precedence: [{"before":"A121-P002-S01","after":"A121-P002-S02","scope":"FFPEroute"}]
- missing_information: []
- source_conflicts: []
- review_status: source_read_author_revision;independent integration pending

### A121-P002-SEC01 FFPE处理

#### A121-P002-S01 FFPE脱蜡独立起点
- action: 档案FFPE肝组织用加热及xylene/ethanol处理脱蜡；来源只给这一级操作，不补齐梯度。
- parameters: {"source_state":"formalin-fixedparaffin-embedded","operations":["heating","xylene/ethanolapplication"],"sample_context":"10FFPEspecimens,nonfibroticandadvancedMASLD"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: ClarifyingFFPE","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp5: FFPEresults","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["温度/时长/次数/乙醇梯度、块尺寸和亚组n未报。"]
- legacy_rows: []

#### A121-P002-S02 FFPE后续清除与读出范围
- action: 脱蜡后按来源所述被动清除达到透明，开展ECM成像与EPV描述；不把新鲜转运、完整HM时程视为已确认的FFPE特有方案。
- parameters: {"clearing":"passiveclarification reported","method_link":"modifiedCLARITY study route,exactFFPE-specificembeddingparametersnotseparatelygiven","readout":"EPV range description;nonfibroticandcirrhoticexamples"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp5: FFPEresults","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Clarifying","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["FFPE专属HM/聚合/染色时程分配未给；需要时引用P001所列组成而非默认执行全部前缀。"]
- legacy_rows: []

## A121-P003 整鼠肝清除、胶原标记和阶段观察
- record_type: partially_reported_workflow
- purpose: 记录本文透明化、染色和观察，来源缺项/冲突不补造。
- applicability: {}
- start_state: 来源模型终点整肝。
- end_state: 染色/RIM保存鼠肝；另有S7清除阶段照片。
- provenance: {"source":"institutionaloriginal11-pagePDF+officialSupplementDOCX","original_protocol_workbook":null}
- materials: ["HM;clearingbuffer;glycerol","Bio-RadCollagenIprimary;488secondary;goatserum;Hoechst;RIM"]
- preparation_and_warnings: ["作者源核候选；不代表实验重现、临床可用性或Pro接受。"]
- reported_precedence: [{"before":"A121-P003-S01","after":"A121-P003-S02","scope":"mousemethodsequence;S7glycerolphoto separatelyscoped"},{"before":"A121-P003-S02","after":"A121-P003-S03","scope":"mousemethodsequence;S7glycerolphoto separatelyscoped"},{"before":"A121-P003-S03","after":"A121-P003-S04","scope":"mousemethodsequence;S7glycerolphoto separatelyscoped"},{"before":"A121-P003-S04","after":"A121-P003-S05","scope":"mousemethodsequence;S7glycerolphoto separatelyscoped"}]
- missing_information: []
- source_conflicts: []
- review_status: source_read_author_revision;independent integration pending

### A121-P003-SEC01 鼠肝专属处理

#### A121-P003-S01 既有终点离体鼠肝与队列背景
- action: 本文观察既有终点离体整鼠肝。来源总体为48只雄性C57Bl6/J，模型与对照分组及6、9、12周终点仅为已有样本背景；后续固定组织读出按各自来源限定，不包含动物准备、造模或取材实施。
- parameters: {"sample_history":"48maleC57Bl6/J;HFHS+CCl4orHFHS+oliveoil;6/9/12weekendpoints","clearing_entry":"Existing endpoint ex vivo whole-liver specimens; animal preparation, model establishment and collection operations are outside the release scope.","HM_definition":"P001-S02compositiononly,notexecutehumantransfer/prefix"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp8: Animalmaterials","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: continuedAnimalmaterials","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph16, starts: Mice were anaesthetised with isoflurane.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["鼠离体组织的HM孵育时间和温度未报告，不从人组织条件外推；动物准备与取材实施不在交付范围。"]
- legacy_rows: []

#### A121-P003-S02 鼠肝聚合和被动透明
- action: HM浸泡后37°C3h聚合，转透明液被动CLARITY；补图S7分别显示清除前及2/4/7/9周照片，完全透明后以glycerol匹配RI。
- parameters: {"polymerization":"37°C,3h","clearing":"passiveCLARITY withreportedclearing solution","S7_photo_times":["before","2weeks","4weeks","7weeks","9weeks"],"S7_RI":"glycerol aftercompletetransparency"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph16, starts: Mice were anaesthetised with isoflurane.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph63, starts: Supplementary Figure S7.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["鼠肝清除温度、换液周期、glycerol具体该图浓度未报告；9周照片不是每个鼠样本必需固定9周程序。"]
- legacy_rows: []

#### A121-P003-S03 鼠肝胶原一抗
- action: anti-CollagenI(Bio-Rad)1:100于PBSTw0.1%v/vTween20、4°C轻摇孵育。
- parameters: {"primary":"anti-CollagenI,Bio-Rad,1:100","buffer":"PBS+0.1%(v/v)Tween20","temperature":"4°C","motion":"gentleagitation","TableS5_identity":{"listed_matching_table_entry":"Rabbitanti-MouseCollagenI,Bio-Rad2150-1410;tablealsohasothercollagenantibodies,notsilentlyassigned"}}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph22, starts: Cleared mouse liver tissues were stained with anti-Collagen","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_TABLE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"TableS5,antibodies/reagentidentityrows;originaltablevisuallyinspectedinrenderedDOCXPDF","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["时长未报，鼠段未列azide，不从人段默认加入。"]
- legacy_rows: []

#### A121-P003-S04 鼠肝洗涤、封闭和488二抗
- action: 一抗后PBSTw洗，5%normalgoatserum封闭，再488-conjugated二抗1:200、4°C。
- parameters: {"wash":"PBSTw","block":"5%normalgoatserum","secondary":"488-conjugated,Invitrogen,1:200,4°C","TableS5_identity":{"secondary_table":"AlexaFluor488GoatAnti-RabbitIgG(H+L),InvitrogenA11008"}}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph22, starts: Cleared mouse liver tissues were stained with anti-Collagen","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_TABLE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"TableS5,antibodies/reagentidentityrows;originaltablevisuallyinspectedinrenderedDOCXPDF","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["各时间/洗次数未报；不套人CY3/1:500。"]
- legacy_rows: []

#### A121-P003-S05 鼠核染及RIM保存
- action: Hoechst1:1000/PBS核染，随后RIM于4°C保存到成像。
- parameters: {"nuclear":"Hoechst1:1000 inPBS","storage":"RIM,4°Cuntilimaging"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph22, starts: Cleared mouse liver tissues were stained with anti-Collagen","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["鼠核染时间/温度未独立写出，不沿用人核染overnight。"]
- legacy_rows: []

## A121-P004 装管、光片采集及显示
- record_type: independent_readout_and_analysis
- purpose: 保存论文实际采集与分析，维持步骤、显示尺度和方法适用范围。
- applicability: {}
- start_state: P001/P003染色RIM组织；FFPE以其报告的匹配状态为限。
- end_state: 原始TIFF、拼接图和展示重建。
- provenance: {"source":"primaryPDF+originalSupplementDOCX"}
- materials: ["agarose/RIM;borosilicatetube;glycerolcage","customOpenSPIM-derivedLSM;ORCAFlash4.0v3","ImageJ;LASX;ImarisViewer"]
- preparation_and_warnings: ["不把宏观阶段照片、统计图、光学示意图与显微图当同一采集步骤。"]
- reported_precedence: [{"before":"A121-P004-S01","after":"A121-P004-S03","scope":"samplemountbeforeacquisition"},{"before":"A121-P004-S03","after":"A121-P004-S05","scope":"acquirethenstitch/reconstruct"}]
- missing_information: []
- source_conflicts: []
- review_status: source_read_author_revision;independent integration pending

### A121-P004-SEC01 装管、光片采集及显示

#### A121-P004-S01 组织装管与成像介质
- action: 6cm硼硅管先半填agarose/RIM基质，放入已染色组织后完全填满，避免气泡。放入customholder并水平浸于glycerol-filledsamplecage。
- parameters: {"tube":"6cmborosilicate","fill_order":["halffillmountingmedium","placetissue","completefill avoidingbubbles"],"mounting_medium":"P001-S10compositiononly","orientation":"horizontal","cage_medium":"glycerol","RI_target":"matchingclearedtissue,about1.45"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph30, starts: Stained liver tissues were embedded in a borosilicate","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: LSMimaging","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_FIGURE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"FigS5B originalembeddedimage;renderedPDF forinspection","mode":"visual","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["管径、工作基质温度/凝固时间、glycerol此腔浓度未报；不把配基质75°C直接作用于组织。"]
- legacy_rows: []

#### A121-P004-S02 双侧静态光片系统配置
- action: 来源自建OpenSPIM衍生系统用柱面镜生静态光片，四镜扩束后PBS分为两路相向照明，半波片调各侧强度，机械slit整形并经三镜relay到样本；浸液物镜垂直收光至CMOS。
- parameters: {"illumination":"dualopposedstaticlightsheet,cylindricallens","opticalpath":"four-lensbeamexpander→polarizingbeamsplitter→mechanicalslit→cylindricallens→three-lensrelay","sources_from_S6A":"405,488,525nm asprinted","objective_from_S6A":"10×objective","total_magnification_main":"7.5×","control":"mechanicalshutters/stepmotors;Arduinodriver;filterwheelsynchronized;Thorlabs3-axisstage"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph26, starts: The light sheet microscope used for imaging","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: LSMimaging","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_FIGURE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"FigS6A originalembeddedimage;renderedPDF forinspection","mode":"visual","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["光路距离/透镜焦距、laserpower、曝光/检测带宽未报；10×物镜与7.5×系统总倍率分层，不推导未报告relay倍率。补充文字称滤轮换excitationfilters但图标EmissionFilterWheel，两来源并列。"]
- legacy_rows: []

#### A121-P004-S03 图块、步长与原始采集
- action: 自建控制软件同步串口Arduino快门/滤轮、样本位移及相机API触发，指定tile数，重叠25%，Z-step2–10µm。ORCAFlash4.0v3采16bit灰度无损TIFF。
- parameters: {"tile_overlap":"25%","z_step":"2–10µm","camera":"HamamatsuORCA-Flash4.0v3CMOS","format":"16bitgrayscale,losslessTIFF","software":"customLSMcontroller,serialArduinoandcameraAPI"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph30, starts: Stained liver tissues were embedded in a borosilicate","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph33, starts: Captured images were acquired from the ORCA","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: LSMimaging","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["每样本tile数、具体z-step和曝光未逐例给；2µm采样不等于2µm轴向分辨率。"]
- legacy_rows: []

#### A121-P004-S04 PSF/分辨率报告的边界
- action: 以补图S6C荧光珠图及XY/Z剖面记录系统PSF检查。正文给轴FWHM23µm、横向3.5µm；图横剖面用pixels坐标，不自行换算或把采样间隔当PSF。
- parameters: {"test_object":"fluorescentbeadimage","main_FWHM":"Z23µm;XY3.5µm","S6C_plot":"axialdistanceµm;lateralaxisdistancepixels,FWHM4pixels asfigure","scope":"instrumenttest,notallbiopsysample-specificresolution"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: LSMimaging","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_FIGURE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"FigS6C originalembeddedimage;renderedPDF forinspection","mode":"visual","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["珠尺寸/产品、介质、重复/拟合步骤及pixel-size转换未报。"]
- legacy_rows: []

#### A121-P004-S05 拼接、3D重建与展示
- action: ImageJmacro自动拼接。展示在LASX导入拼图、合并通道和裁剪，分别调强度/gamma/opacity，用movieeditor输出图和视频。图4/S3另列ImarisViewer10.1.0。
- parameters: {"stitch":"ImageJmacro","ImageJ":"1.52q perS1caption","LasX":"LeicaApplicationSuiteX3.5.5.19976 forFig1–3/movielegends","display_operations":["mergechannels","crop","setintensity/gamma/opacityperchannel","movieeditor"],"other_display":"ImarisViewer10.1.0,Fig4/S3"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph33, starts: Captured images were acquired from the ORCA","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph36, starts: 3D reconstructions were built on LasX","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp3: Fig1caption","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp7: Fig4caption","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph48, starts: Supplementary Figure S1.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph53, starts: Supplementary Figure S3.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["拼接算法/参数、显示gamma/透明度具体值未报；显示调整不等于定量阈值步骤，也不算原图强度校准。原MOV本轮未复读。"]
- legacy_rows: []

### A121-P004-C01 宏观照片与示意排除
- parameters: {"Fig1B_C_D":"progressiveclearingphotos;exacttimepointsnotgiven","S7":"before/2/4/7/9weekphotosandRI-matchedphoto","exclude_from_LSM":["Fig1B–D","S7macro","Fig1A/E","S5schematic","S6A/Bsetupview"]}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp3: Fig1","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph63, starts: Supplementary Figure S7.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- warning: 这些观察不继承LSM7.5×/2–10µm/相机设置。

### A121-P004-C02 图2/3局部倍率及显示厚度
- parameters: {"Fig2_3_caption":"left-bottom images40×,notwhole3Ddefault","Fig1F":"displayedreconstructionextent400µm","S2A":"displayedreconstructionextent1100µm"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp3: Fig1Fimage","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp4: Fig2caption","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp5: Fig3caption","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_FIGURE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"FigS2A originalembeddedimage;renderedPDF forinspection","mode":"visual","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- warning: 40×的caption局部标注不覆盖通用LSM总倍率；与右侧组织学inset的精确绑定未在文字中进一步明示。400/1100µm是例图范围，不是z-step。

## A121-P005 CPA/EPA、截面均值及异质性分析
- record_type: independent_readout_and_analysis
- purpose: 保存论文实际采集与分析，维持步骤、显示尺度和方法适用范围。
- applicability: {}
- start_state: P004拼接的标记图像与对应核通道。
- end_state: CPA/EPA逐层值、作者定义CPV/EPV及研究内分类统计。
- provenance: {"source":"primaryPDF+originalSupplementDOCX"}
- materials: ["ImageJmacro;Otsu;Huang","MATLABR2021b"]
- preparation_and_warnings: ["不把宏观阶段照片、统计图、光学示意图与显微图当同一采集步骤。"]
- reported_precedence: [{"before":"A121-P005-S01","after":"A121-P005-S02","scope":"persectiontomean"},{"before":"A121-P005-S02","after":"A121-P005-S03","scope":"heterogeneitybranch"},{"before":"A121-P005-S02","after":"A121-P005-S04","scope":"ROCbranch"}]
- missing_information: []
- source_conflicts: []
- review_status: source_read_author_revision;independent integration pending

### A121-P005-SEC01 CPA/EPA、截面均值及异质性分析

#### A121-P005-S01 定量图预处理及两个阈值分支
- action: 拼接原图以ImageJmacro增强对比，再二值化/阈值和量面积。Otsu取胶原阳性区；对应核染层面以Huang取组织总面积，最后作ECM/总组织面积比例。
- parameters: {"processing":"contrastenhancement→binarization/threshold→area measurement","positive_region":"Otsu,collagenchannel","total_tissue_region":"Huang,correspondingnuclear-stainedopticalsection","CPA":"collagenpositivearea / total tissuearea×100%","EPA":"sameanalysis applied toelastin"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp3: ECMquantification","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph33, starts: Captured images were acquired from the ORCA","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX_FIGURE","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"FigS1 originalembeddedimage;renderedPDF forinspection","mode":"visual","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["对比增强及阈值具体参数/ROI处理未报；补充文字“divides fibrosisarea into totalarea”语序不清，图S1明确Otsu/Huang及正文ECM/total方向，保留公式来源。"]
- legacy_rows: []

#### A121-P005-S02 截面均值定义CPV/EPV
- action: 每标本所有采集光学截面分别量CPA/EPA，再取平均为CPV/EPV。详细结果给100–400层、197±99（SD），与摘要每份>200的说法并列。
- parameters: {"CPV":"mean ofper-sectionCPA","EPV":"mean ofper-sectionEPA","source_sections":"100–400/sample;197±99,SD inResults","abstract_wording":"over200sections/sample"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp3: ECMquantification","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp4: CPVdefinition","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Imageanalysis","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph33, starts: Captured images were acquired from the ORCA","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["没有说明面积/体素加权；不能改成所有阳性体积/总组织体积，也不当真实体积分数未经验证的等价。各标本样本层级/数量映射未全给。"]
- legacy_rows: []

#### A121-P005-S03 IQR和CV类别
- action: 按标本截面分布描述变异：来源称以CPV/EPV及slice间SD算百分比CV。按F1–2或F3–4组的CV均值±组CVSD切为low/intermediate/high。
- parameters: {"CV_source_description":"usingCPV/EPVandstandarddeviationbetweenslices,expressedaspercentage","groups":["F1–2","F3–4"],"low":"CV%<groupCVmean−groupCVSD","intermediate":"groupCVmean−groupCVSD<CV%<groupCVmean+groupCVSD","high":"CV%>groupCVmean+groupCVSD","IQR":"reporteddistributionmeasure foreachfibrosisstage"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph34, starts: To designate the level of variations","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp7: Fig5caption","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Statisticalanalysis","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["恰等阈值边界未定义；不擅自改≤。组CV分类不是按临床固定阈值个体判病。IQR/箱须的全部展示规则未报。"]
- legacy_rows: []

#### A121-P005-S04 研究内ROC/Youden阈值及光学层再分类
- action: 以AUROC和Youdenindex选择CPA/CPV/EPV阶段阈值，来源额外写Youden≥50%。再用这些阈值形成光学层分布的3Dhistogram，MATLABR2021b。
- parameters: {"selection":"AUROC,Youdenindex(bestfit;source≥50%)","CPA_cutoffs":{"F1":"2.3≤value≤7.7","F2":"7.7<value≤13.2","F3":"13.2<value≤23.7","F4":"value>23.7"},"CPV_cutoffs":{"F1":"4.3≤value≤8.7","F2":"8.7<value≤17.7","F3":"17.7<value≤24.7","F4":"value>24.7"},"EPV_cutoffs":{"F1":"5.4≤value≤9.8","F2":"9.8<value≤16.6","F3":"16.6<value≤26.9","F4":"value>26.9"},"units":"percent source readout","histogram":"MATLABR2021b;percentageofslices perwholebiopsy sample"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp4: ResultsROCcutoffs","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp7: Fig5C/FtablesandG/H","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Statisticalanalysis","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph35, starts: The cut-off values of CPA, CPV, and EPV","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["F0边界和逐例分类/加权汇总细节不全；研究内拟合阈值尚需外部验证，不作为临床诊断建议。若干AUROCCI超0–1范围旧冲突保留，不重算。"]
- legacy_rows: []

#### A121-P005-S05 分比较统计范围
- action: 来源显著性门槛0.05；S4A/C的CV类别比较为Chi-square，CPV比较p0.48、EPV比较p0.002。其余p值未给具体检验的地方保持unknown。
- parameters: {"threshold":"p≤0.05;**≤0.01;***≤0.001","S4_CV_comparison":"Chi-square;CPVp=0.48,EPVp=0.002","scope":"MASLDversusviral-relatedfibrosis F3–4categoricalCVcomparison"}
- source_refs: [{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp9: Statisticalanalysis","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph55, starts: Supplementary Figure S4.","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["不能因Chi-square已在S4给出而赋给所有连续量/ROC/IQR；比较独立性/多重比较和完整有效n未报。"]
- legacy_rows: []

## A121-P006 独立二维组织病理及参照CPA
- record_type: partially_reported_workflow
- purpose: 保存论文实际采集与分析，维持步骤、显示尺度和方法适用范围。
- applicability: {}
- start_state: 固定/石蜡包埋的人肝组织。
- end_state: 二维染色、限定ROI的CPA与病理分期。
- provenance: {"source":"primaryPDF+originalSupplementDOCX"}
- materials: ["formalin;paraffin;PicroSiriusRed;H&E","Zeisslightmicroscope"]
- preparation_and_warnings: ["不把宏观阶段照片、统计图、光学示意图与显微图当同一采集步骤。"]
- reported_precedence: [{"before":"A121-P006-S01","after":"A121-P006-S02","scope":"2DCPAroute"},{"before":"A121-P006-S01","after":"A121-P006-S03","scope":"histologicalgradingroute"}]
- missing_information: []
- source_conflicts: []
- review_status: source_read_author_revision;independent integration pending

### A121-P006-SEC01 独立二维组织病理及参照CPA

#### A121-P006-S01 独立二维病理切片与染色
- action: 人肝另作formalin固定、石蜡包埋，活检切2µm、移植肝切4µm。PicroSiriusRed和H&E用于纤维化分期/半定量病理，不经过透明化整块路线。
- parameters: {"fixation":"formalin","embedding":"paraffin","thickness":"biopsy2µm;transplant4µm","stains":["PicroSiriusRed","haematoxylin/eosin"]}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph39, starts: Liver tissues were formalin-fixed, paraffin-embedded","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["固定/脱水/染色具体时间、配方和配对取材映射未给；不从表S5材料清单补出染色操作。"]
- legacy_rows: []

#### A121-P006-S02 二维CPA十视野测量
- action: Zeiss光学显微镜10×拍十个不同感兴趣区作CPA。总面积排除portaltracts、lumens及vascularcollagen，再计算纤维化区/总区百分比。
- parameters: {"fields":"10differentareasofinterest","microscope":"Zeisslightmicroscope,10×","exclusions":["portaltracts","lumens","vascularcollagen"],"CPA":"fibrosisarea/totalarea,percent"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph39, starts: Liver tissues were formalin-fixed, paraffin-embedded","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["视野挑选/盲法和每样本全十区均值方式未完全说明；这些ROI排除是2D段，不能自动应用到3D核通道总面积。"]
- legacy_rows: []

#### A121-P006-S03 来源病理分期定义
- action: 保存原Kleiner分类：F0无纤维化；F1为perisinusoidal或portal/periportal；F2两者兼有；F3bridging；F4cirrhosis。Fig4A另由病理专家在同标本不同光学面评阶段。
- parameters: {"Kleiner_stages":{"F0":"absence","F1":"perisinusoidal ORportal/periportal","F2":"perisinusoidal ANDportal/periportal","F3":"bridging","F4":"cirrhosis"},"Fig4A":"expertpathologist gradesdifferentopticalsections"}
- source_refs: [{"source_id":"SUPPLEMENT_DOCX","path":"protocol_content_revision_20261008/recent/A121/sources/41598_2025_98680_MOESM9_ESM.docx","locator":"OriginalDOCXparagraph39, starts: Liver tissues were formalin-fixed, paraffin-embedded","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"},{"source_id":"PRIMARY_PDF","path":"protocol_content_revision_20261008/recent/A121/sources/Main_institutional_repository.pdf","locator":"PDFp7: Fig4Acaption","checked_in_prior_source_revision":true,"prior_source_revision":"2026-10-08; see original snapshot/history"}]
- missing_information: ["评分者数、盲法、一致性与临床应用验证未报；同一个人/同标本多层不是独立临床重复。"]
- legacy_rows: []

## P/E/G/O映射
{"old_protocol_rows":[],"reason":"No baselineProtocolworkbook;sourceMethods/Supplementread.","evidence_bindings":[{"evidence_id":"A121-E01","observation_ids":["A121-E01-O01"],"group_ids":["A121-E01-G01"],"record_ids":["A121-P001","A121-P004","A121-P006"],"step_ids":["A121-P001-S01","A121-P001-S02","A121-P001-S03","A121-P001-S04","A121-P001-S05","A121-P001-S06","A121-P001-S07","A121-P001-S08","A121-P001-S09","A121-P001-S10","A121-P004-S01","A121-P004-S02","A121-P004-S03","A121-P004-S05","A121-P006-S01","A121-P006-S03"],"scope":"HumanECM3Dandcorresponding2Dhistology;Fig1macro/settingsandlocal40×exceptionsretained;humanCY3pseudogreen/yellowdoesnotmake488secondary.","original_core_modified":false},{"evidence_id":"A121-E02","observation_ids":["A121-E02-O01"],"group_ids":["A121-E02-G01","A121-E02-G02","A121-E02-G03","A121-E02-G04","A121-E02-G05"],"record_ids":["A121-P001","A121-P004","A121-P005"],"step_ids":["A121-P004-S03","A121-P004-S05","A121-P005-S01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","original_core_modified":false},{"evidence_id":"A121-E03","observation_ids":["A121-E03-O01"],"group_ids":["A121-E03-G01","A121-E03-G02"],"record_ids":["A121-P005"],"step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S03"],"scope":"CPV/EPVmeanofsectionalproportionsandCVclassification,notrawtotalvolumeratio.","original_core_modified":false},{"evidence_id":"A121-E04","observation_ids":["A121-E04-O01"],"group_ids":["A121-E04-G01","A121-E04-G02","A121-E04-G03"],"record_ids":["A121-P005"],"step_ids":["A121-P005-S04"],"scope":"ROCcutoffs forCPA/CPV/EPV;CPAcutoffinput originnotuniquelyassignedto2Dhistologyoropticalsectionsbythereadtext,thereforenoP006ten-fieldacquisitionasserted.OriginalCIanomaliesremain.","original_core_modified":false},{"evidence_id":"A121-E05","observation_ids":["A121-E05-O01"],"group_ids":["A121-E05-G01","A121-E05-G02"],"record_ids":["A121-P005"],"step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S04"],"scope":"OpticalsectionclassificationusingresearchderivedCPV/EPVcutoffs;notindependentpatient-levelrepeateddiagnosis.","original_core_modified":false},{"evidence_id":"A121-E06","observation_ids":["A121-E06-O01"],"group_ids":["A121-E06-G01"],"record_ids":["A121-P001","A121-P004","A121-P005"],"step_ids":["A121-P001-S02","A121-P001-S03","A121-P001-S04","A121-P001-S05","A121-P001-S06","A121-P001-S07","A121-P001-S08","A121-P001-S09","A121-P004-S01","A121-P004-S02","A121-P004-S03","A121-P004-S05","A121-P005-S01","A121-P005-S02"],"scope":"Transplantexplantvariant,no-bis;aggregateof6caseswithin56cohort;EPVgroupmean/thresholdtensionnotresolved.","original_core_modified":false},{"evidence_id":"A121-E07","observation_ids":["A121-E07-O01"],"group_ids":["A121-E07-G01","A121-E07-G02"],"record_ids":["A121-P001","A121-P005"],"step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S03","A121-P005-S05"],"scope":"Clinicalfixedliveretiologycomparisononly;nopathogenhandling/engineeringprocedureadded;Chi-squareonlyCVcategorypanels.","original_core_modified":false},{"evidence_id":"A121-E08","observation_ids":["A121-E08-O01"],"group_ids":["A121-E08-G01","A121-E08-G02"],"record_ids":["A121-P002","A121-P004","A121-P005"],"step_ids":["A121-P002-S01","A121-P002-S02","A121-P004-S01","A121-P004-S03","A121-P005-S01","A121-P005-S02"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","original_core_modified":false},{"evidence_id":"A121-E09","observation_ids":["A121-E09-O01"],"group_ids":["A121-E09-G01"],"record_ids":["A121-P003","A121-P004","A121-P005"],"step_ids":["A121-P003-S01","A121-P003-S02","A121-P003-S03","A121-P003-S04","A121-P003-S05","A121-P004-S01","A121-P004-S02","A121-P004-S03","A121-P004-S05","A121-P005-S01","A121-P005-S02"],"scope":"MouseCollagenI1:100/488secondary1:200,not humanCY3.Elastin/humanCVROCnotinherited;S7stagephotosdonotinheritLSMsettings.","original_core_modified":false}]}

## 源内冲突
[{"conflict_id":"A121-CF01","field":"boricacidunit","sources":[{"locator":"mainp9andSupplementClearingSolution","value":"200nM"}],"resolution":"两处一致但需单位核实；原样保存，未改200mM、未以引用补救。"},{"conflict_id":"A121-CF02","field":"humanPBSTwwashconcentration","sources":[{"locator":"mainp9primary/wash","value":"primary0.1%v/vTween20;wash0.01%v/v"},{"locator":"Supplementstaining","value":"PBSTwdefined0.1%,washPBSTwwithoutrestatedconcentration"}],"resolution":"保留来源包，具体wash值未决。"},{"conflict_id":"A121-CF03","field":"RIandlabellingorder","sources":[{"locator":"mainp9briefenumeration","value":"RIhomogenization listedbefore molecularlabelling"},{"locator":"mainp9detailedstaining,Fig1A,FigS5","value":"label thenRImatching"}],"resolution":"详细染色/图示步骤有明确poststainRIM；不再额外插入一次prelabelRIM，早期RI是否另执行未核。"},{"conflict_id":"A121-CF04","field":"filterwheelrole","sources":[{"locator":"SupplementLSMdevelopment","value":"filterwheelchangesexcitationfilters"},{"locator":"FigS6A","value":"EmissionFilterWheel;separateExcitationFilterslabel"}],"resolution":"原角色说明并列；未复建设备或猜纠错。"},{"conflict_id":"A121-CF05","field":"localmagnificationbinding","sources":[{"locator":"Fig2/3captions","value":"left-bottomimages40×"},{"locator":"mainLSMMethods","value":"total7.5×"},{"locator":"FigS6A","value":"10×objective"}],"resolution":"系统总倍率/物镜和局部40×分层；40×具体inset文字绑定不完整，绝不套用全部3D图。"}]

## 尚未核或原未报
["Boricacid200nMrequiresverification;humanwashTween0.01/0.1%,RIenumerationorderandfilterwheelrole remainunresolved.","FFPEdeparaffinizationandFFPE-specificembeddingparameters,humanantibodydurations,mouseHMtime/clearingsettingsandmouseHoechsttime aremissing.","Wholeimage-to-samplezstep/tiles,40×localcaptionbinding,PSFbeadspecs/calibrationandmacroparametersnotfullygiven.","CPV/EPVreportedasarithmeticmeanofsectionproportions;volume-weightedestimatewasnotreported.ROCcutoffsnotexternallyvalidated;oldcount/CI/mediaissuesremain.","CPA cutoff input origin (conventional2Dversusoptical-sectionCPA) notuniquelyreported;P006ten-fieldanalysis isnotautomaticallyboundtoE04."]
