# A121 科学范围与同步审阅

主论文 DOI：10.1038/s41598-025-98680-y。身份字段来自 /document/doi，完整路径与哈希在 scientific_coverage.json。

## 本轮结论
声明的证据层科学范围已覆盖：完整当前 P/E/G/O/问题副本、方法分支与来源缺项同步。使用历史实读继承和本轮明确列出的定向原源核读；不要求已核来源无理由重读。
当前共 P=6、步骤=30、E=9、G=19、O=9、GQ=13；P/E/G/O关系=9。

## 可解决漏项与变更
- 恢复inventory遗漏的完整E/G/O和问题对象，并连接已存在的当前P；不再把None路径误作内容缺失。
- 将当前P已核的人CY3和鼠Alexa488检测链补入G，保留逐样本/面板分配未明及CPA-ROC来源分支未决。

## 已核范围与历史继承
当前 P 所有动作/参数/缺项与 cases，以及全部 E/G/O 和全部问题关系已逐记录核对。原 source_read_this_round、媒体核验及源状态是对应历史版本的阅读记录；本轮新增原源核读仅见如下清单。
- 本轮无新增全篇/图像/媒体重读；按带哈希历史科学范围继承，逐记录审阅当前关系。

历史完整审阅和字段范围存于 history/ 及 accepted_semantics_inheritance.json。A122–A124的既有独立接受只对原哈希与原范围有效，不自动接受改变后的当前包；A120/A121不新声称取得完整独立接受。

## 同类检查与保护反例
- CPA/EPA截面比例与CPV/EPV截面均值分开；不转换成体积加权值。
- Fig5 CPA ROC来源未唯一确定，不给它P006十视野实体组织学绑定。
- 人CY3、鼠488及图中伪彩分开；FFPE前处理缺项不由新鲜路线填补。
- S7周数属于观察时点；基质75°C不是组织处理；原AUROC CI与人数/截面数差异并列。

## 原未报、源冲突和具体尚未核
原未报告/实际值未明逐项定位在 scientific_coverage.json 的 precisely_reported_limits；各P步骤也保留同样缺项。源内冲突保留原ID和值；修复结构或描述不等于解决科学冲突。
所有 current source_conflicts：A121-U01, A121-U02, A121-U03, A121-U04, A121-U05, A121-CF01, A121-CF02, A121-CF03, A121-CF04, A121-CF05
历史未读/未复核范围：["OriginalMOV1–8notnewlyread;priorvideofile-to-legendmappingambiguityinherited","SupplementS3captionreadbutcompleteoriginalS3figurepixelrereviewnotclaimed","RawImageJmacro,rawstacks,per-specimenvaluesandexternallycitedmethodsnotretrieved/run","Modelinductionnotrestoredasnewexperimentalprotocol;onlymaterialhistoryandclearingentryreported"]
原P剩余限制：["Boricacid200nMrequiresverification;humanwashTween0.01/0.1%,RIenumerationorderandfilterwheelrole remainunresolved.","FFPEdeparaffinizationandFFPE-specificembeddingparameters,humanantibodydurations,mouseHMtime/clearingsettingsandmouseHoechsttime aremissing.","Wholeimage-to-samplezstep/tiles,40×localcaptionbinding,PSFbeadspecs/calibrationandmacroparametersnotfullygiven.","CPV/EPVreportedasarithmeticmeanofsectionproportions;volume-weightedestimatewasnotreported.ROCcutoffsnotexternallyvalidated;oldcount/CI/mediaissuesremain.","CPA cutoff input origin (conventional2Dversusoptical-sectionCPA) notuniquelyreported;P006ten-fieldanalysis isnotautomaticallyboundtoE04."]
A121主文PDF/SI DOCX独立源文件未在当前本地恢复；保留2026-10-08/10明确原源实读记录及带哈希底稿中的原文摘录。此项限制本轮“重新读全部原件”的主张，不把已完成历史源审阅抹成未读。

## 科学完成与接受状态分开
科学证据层当前可解决范围完成；源冲突/原未报已具体保留。当前修订包仍为 candidate，尚未获得本版独立整包接受或 Pro 审阅；未进行实验实施、模型实验、原始图像重测或临床验证。

## 结构检查
{"status":"pass","errors":[],"warnings":[],"checks":["all current files parse","stable E/G/O/P/GQ IDs retained","P record/step/case targets resolve","O/G membership","GQ E/O/G targets","bidirectional question index regenerated","embedded P equals standalone P","original quantitative result/statistical fields unchanged","contextual or null-P scope does not become blanket execution"],"no_procedure_bindings":[]}

## 结束条件
当前范围内没有仍可由已读来源解决但未处理的遗漏。没有修改授权目录外文件，没有push。

## 附加实际校验
O/GQ来源ID、全部问题答案与MD、全部P步骤ID与方法MD、文件哈希均再次实测通过。首次脚本的A类引用误报及结构化摘录哈希中断已记录于validation_run_history.json；修正的是验证器，不改科学数据让测试通过。

旧nonoperational范围与冻结接受状态已移入历史字段。当前版本身份标为evidence-layer-current-20261012.1，P/E/G/O和问题明确同步，改变后的包仍为candidate。
