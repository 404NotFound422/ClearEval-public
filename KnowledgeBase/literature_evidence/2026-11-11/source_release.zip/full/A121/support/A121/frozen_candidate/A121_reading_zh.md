# A121 当前证据阅读稿

Investigating hepatic fibrosis heterogeneity by three-dimensional imaging in metabolic dysfunction-associated steatotic liver disease

本稿将历史已有来源审阅与当前方法副本同步。历史实读范围可继承；本轮未将旧媒体/图像核验改称重新实读。candidate、独立接受和Pro状态见REVIEW.md。

## 科学问题
{"id":"A121-SQ01","question":"透明化肝组织的三维ECM观察能否揭示常规单截面分期遗漏的空间异质性，其临床解释边界是什么？"}

## A121-E01 人肝实际透明化后显示不同分期的胶原I和弹性蛋白空间模式
- record_id: A121-E01
- title: 人肝实际透明化后显示不同分期的胶原I和弹性蛋白空间模式
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_masld","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"肝实质及细胞外基质","form":"穿刺活检、切除和移植离体标本；个体与用途映射未完全报告","initial_state":"临床取得的离体组织；新鲜来源与FFPE扩展分别记录","biological_n":57,"n_level":"patients","n_status":"reported","stage_counts":{"F0":1,"F1":21,"F2":5,"F3":11,"F4":19},"source_refs":["F02","F17"]},{"sample_key":"human_control","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"无实质性肝病的非纤维化肝组织","form":"良性或恶性疾病切除时取得的非病变肝组织","initial_state":"离体组织","biological_n":12,"n_level":"patients","n_status":"reported","source_refs":["F02","F18"],"qualification":"摘要称healthy；不推断为无其他疾病的健康志愿者。"}]
- limitations: ["代表性图像不等于临床诊断准确率；没有统一荧光强度倍数。","完整活检组织的三维观察不能消除活检位置相对于整个肝脏的取样误差。"]
- independence_note: 与同队列其他ECM分析相关；重复引用本记录或多个光学截面不增加独立患者数。

### A121-E01-G01 MASLD F0–F4与非纤维化参考组织
- sample_keys: ["human_masld","human_control"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P001","step_ids":["A121-P001-S01","A121-P001-S02","A121-P001-S03","A121-P001-S04","A121-P001-S05","A121-P001-S06","A121-P001-S07","A121-P001-S08","A121-P001-S09","A121-P001-S10"],"binding_id":"A121-B001","observation_ids":["A121-E01-O01"],"scope":"HumanECM3Dandcorresponding2Dhistology;Fig1macro/settingsandlocal40×exceptionsretained;humanCY3pseudogreen/yellowdoesnotmake488secondary.","all_steps_asserted":false},{"protocol_id":"A121-P004","step_ids":["A121-P004-S01","A121-P004-S02","A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B001","observation_ids":["A121-E01-O01"],"scope":"HumanECM3Dandcorresponding2Dhistology;Fig1macro/settingsandlocal40×exceptionsretained;humanCY3pseudogreen/yellowdoesnotmake488secondary.","all_steps_asserted":false},{"protocol_id":"A121-P006","step_ids":["A121-P006-S01","A121-P006-S03"],"binding_id":"A121-B001","observation_ids":["A121-E01-O01"],"scope":"HumanECM3Dandcorresponding2Dhistology;Fig1macro/settingsandlocal40×exceptionsretained;humanCY3pseudogreen/yellowdoesnotmake488secondary.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F01","F02","F03","F20","F22"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B001"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E01-O01
- arm_ids: ["A121-E01-G01"]
- sample_keys: ["human_masld","human_control"]
- metric: ECM三维可视化及分布形态
- result: 作者确实将临床肝组织透明化后成像。图1B–D展示非纤维化、活检和肝硬化标本透明度变化；图2–3显示随分期较重，窦周、门管区、桥接和结节周ECM图像更明显。
- values: [{"metric":"actual_tissue_clearing","value":true},{"metric":"examined_histological_stages","value":["F0","F1","F2","F3","F4"]}]
- statistics: {"test":null,"p_value":null,"status":"not_reported_for_this_endpoint"}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F01","F02","F03","F20","F22"]
- evidence_kind: direct_report
- limits: ["代表性图像不等于临床诊断准确率；没有统一荧光强度倍数。","完整活检组织的三维观察不能消除活检位置相对于整个肝脏的取样误差。","视频动画帧不是光学截面；133/134解码帧不能用于验证100–400截面/标本。"]
- supplement_visual_review: {"reviewer_observation":"八段原始MOV的抽样帧均显示旋转三维组织块及空间不均匀的绿色或黄色纤维信号和蓝色背景；这只是展示形式核对。图例前四条均标S1，文件序号不能可靠对应具体分期/靶点，故不按颜色重新分配生物身份。","scope":"8段均取得；每段14个抽样帧，共112帧；非全帧检查","new_independent_experiment":false,"quantitative_reanalysis":false}
- protocol_binding_ids: ["A121-B001"]

来源：["F01","F02","F03","F20","F22"]

## A121-E02 人肝同一标本内光学截面显示ECM比例与分期差异
- record_id: A121-E02
- title: 人肝同一标本内光学截面显示ECM比例与分期差异
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_masld","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"肝实质及细胞外基质","form":"穿刺活检、切除和移植离体标本；个体与用途映射未完全报告","initial_state":"临床取得的离体组织；新鲜来源与FFPE扩展分别记录","biological_n":57,"n_level":"patients","n_status":"reported","stage_counts":{"F0":1,"F1":21,"F2":5,"F3":11,"F4":19},"source_refs":["F02","F17"]},{"sample_key":"human_control","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"无实质性肝病的非纤维化肝组织","form":"良性或恶性疾病切除时取得的非病变肝组织","initial_state":"离体组织","biological_n":12,"n_level":"patients","n_status":"reported","source_refs":["F02","F18"],"qualification":"摘要称healthy；不推断为无其他疾病的健康志愿者。"}]
- limitations: ["摘要over200与Results范围/均值有表述张力；不能说每份标本都超过200个截面。","光学截面是嵌套观测，不是独立患者；图4A为示例，不是全队列盲法重分期研究。"]
- independence_note: 与同队列其他ECM分析相关；重复引用本记录或多个光学截面不增加独立患者数。

### A121-E02-G01 F0
- sample_keys: []
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P004","step_ids":["A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F15"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- candidate_sample_keys: ["human_masld","human_control"]
- sample_binding_status: F0图示究竟属于MASLD F0还是非纤维化对照未明确，不强行绑定
- protocol_binding_ids: ["A121-B002"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E02-G02 F1
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P004","step_ids":["A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F15"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B002"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E02-G03 F2
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P004","step_ids":["A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F15"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B002"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E02-G04 F3
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P004","step_ids":["A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F15"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B002"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E02-G05 F4
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P004","step_ids":["A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01"],"binding_id":"A121-B002","observation_ids":["A121-E02-O01"],"scope":"SectionalCPA/EPA distributionsfromwholebiopsies;noareaweightingorall>200layersassumed.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F15"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B002"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E02-O01
- arm_ids: ["A121-E02-G01","A121-E02-G02","A121-E02-G03","A121-E02-G04","A121-E02-G05"]
- sample_keys: ["human_masld","human_control"]
- metric: 截面CPA/EPA分布与同标本分期异质性
- result: 图4A的同一活检三个光学截面被病理专家分别判为F2、F3、F4。各分期内CPA/EPA分布较宽，F3与F4重叠。CPA为胶原阳性面积/截面组织面积；EPA对应弹性蛋白。
- values: [{"metric":"sections_per_specimen","range":[100,400],"mean":197,"error":99,"error_type":"SD","unit":"optical sections","status":"Results_exact_report"},{"metric":"CPA_peak_ranges_by_stage","value":{"F0":[0,4],"F1":[0,12],"F2":[6,15],"F3":[10,25],"F4":[15,30]},"unit":"%","status":"author_reported_clusters_not_full_ranges"},{"metric":"EPA_peak_ranges_by_stage","value":{"F0":[0,6],"F1":[0,10],"F2":[0,20],"F3":[15,25],"F4":[15,30]},"unit":"%","status":"author_reported_clusters_not_full_ranges"}]
- statistics: {"test":null,"p_value":null,"status":"not_reported_for_this_endpoint"}
- sampling: {"unit_hierarchy":["patient","specimen","optical section"],"individual_specimen_section_counts":"not_publicly_reported"}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F04","F15"]
- evidence_kind: direct_report
- limits: ["摘要over200与Results范围/均值有表述张力；不能说每份标本都超过200个截面。","光学截面是嵌套观测，不是独立患者；图4A为示例，不是全队列盲法重分期研究。"]
- protocol_binding_ids: ["A121-B002"]

来源：["F04","F15"]

## A121-E03 人肝CPV和EPV随分期改变并报告明显截面变异
- record_id: A121-E03
- title: 人肝CPV和EPV随分期改变并报告明显截面变异
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_masld","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"肝实质及细胞外基质","form":"穿刺活检、切除和移植离体标本；个体与用途映射未完全报告","initial_state":"临床取得的离体组织；新鲜来源与FFPE扩展分别记录","biological_n":57,"n_level":"patients","n_status":"reported","stage_counts":{"F0":1,"F1":21,"F2":5,"F3":11,"F4":19},"source_refs":["F02","F17"]}]
- limitations: ["均值面积比例不自动等于体积加权的ECM体积分数。","约85%来自按组均值±SD划定的相对类别，不是跨样本统一绝对异质性阈值。","IQR箱图描述分期组内标本均值分布，不能与同标本截面CV混成同一变异层级。","缺逐标本配对数据及明确检验名称，无法复算组差异。"]
- independence_note: 与同队列其他ECM分析相关；重复引用本记录或多个光学截面不增加独立患者数。

### A121-E03-G01 F1–F2
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S03"],"binding_id":"A121-B003","observation_ids":["A121-E03-O01"],"scope":"CPV/EPVmeanofsectionalproportionsandCVclassification,notrawtotalvolumeratio.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F05","F11","F12"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B003"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E03-G02 F3–F4
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S03"],"binding_id":"A121-B003","observation_ids":["A121-E03-O01"],"scope":"CPV/EPVmeanofsectionalproportionsandCVclassification,notrawtotalvolumeratio.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F05","F11","F12"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B003"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E03-O01
- arm_ids: ["A121-E03-G01","A121-E03-G02"]
- sample_keys: ["human_masld"]
- metric: 标本均值CPV/EPV与标本内截面CV
- result: CPV和EPV分别定义为每份标本各截面CPA和EPA的平均值。作者报告两指标随纤维化分期改变，均p<0.01；约85%的样本处于中或高CV类别。图5A/D的组内标本CPV/EPV分布与图5B/E的截面CV分类分别解释。
- values: [{"metric":"intermediate_or_high_CV_reported_fraction","value":85,"unit":"%","precision":"approximately","denominator":"CPV/EPV samples as stated; exact endpoint-specific n not reported"}]
- statistics: {"reported_stage_change":{"CPV":"p<0.01","EPV":"p<0.01"},"test":"not_specified_for_stage_change","CV_category_definition":"group-relative mean±SD classes","exact_group_n":"not_reported_for_each_endpoint"}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F04","F05","F11","F12"]
- evidence_kind: direct_report
- limits: ["均值面积比例不自动等于体积加权的ECM体积分数。","约85%来自按组均值±SD划定的相对类别，不是跨样本统一绝对异质性阈值。","IQR箱图描述分期组内标本均值分布，不能与同标本截面CV混成同一变异层级。","缺逐标本配对数据及明确检验名称，无法复算组差异。"]
- protocol_binding_ids: ["A121-B003"]

来源：["F04","F05","F11","F12"]

## A121-E04 本队列推导的CPA及体积指标分期阈值与AUROC表现
- record_id: A121-E04
- title: 本队列推导的CPA及体积指标分期阈值与AUROC表现
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_masld","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"肝实质及细胞外基质","form":"穿刺活检、切除和移植离体标本；个体与用途映射未完全报告","initial_state":"临床取得的离体组织；新鲜来源与FFPE扩展分别记录","biological_n":57,"n_level":"patients","n_status":"reported","stage_counts":{"F0":1,"F1":21,"F2":5,"F3":11,"F4":19},"source_refs":["F02","F17"]}]
- limitations: ["阈值为本研究探索性推导；未见外部验证、独立测试集或临床决策获益分析。","越界CI及EPV F3的1–1区间需要作者澄清；不能截断、修正或反推原始数据。","各ROC的具体二分类对照、分析样本数和置信区间算法未充分说明。","常规2D CPA的面积范围排除门管区、管腔及血管胶原；三维ECM指标与其不自动构成同分母的准确率比较。","ROC输入CPA与常规2D/光学截面CPA的具体分支未明确，不声称CPA比较组已经透明化。"]
- independence_note: 与同队列其他ECM分析相关；重复引用本记录或多个光学截面不增加独立患者数。

### A121-E04-G01 CPA
- sample_keys: ["human_masld"]
- clearing_use: CPA_ROC_input_mapping_unresolved
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S04"],"binding_id":"A121-B004","observation_ids":["A121-E04-O01"],"scope":"ROCcutoffs forCPA/CPV/EPV;CPAcutoffinput originnotuniquelyassignedto2Dhistologyoropticalsectionsbythereadtext,thereforenoP006ten-fieldacquisitionasserted.OriginalCIanomaliesremain.","all_steps_asserted":false}]
- signal: {"signal_source":"本文同时描述常规2D组织学CPA和光学截面CPA；Fig5 CPA阈值/ROC输入究竟绑定何者未明确","molecular_targets":["collagen_area_as_defined_by_source"],"fluorophore_mapping":null,"display_colours":{},"observed_structures":["胶原相关面积；来源分支未唯一确定"]}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F05","F12","F13"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B004"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E04-G02 CPV
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S04"],"binding_id":"A121-B004","observation_ids":["A121-E04-O01"],"scope":"ROCcutoffs forCPA/CPV/EPV;CPAcutoffinput originnotuniquelyassignedto2Dhistologyoropticalsectionsbythereadtext,thereforenoP006ten-fieldacquisitionasserted.OriginalCIanomaliesremain.","all_steps_asserted":false}]
- signal: {"signal_source":"与所列ECM靶点对应的免疫荧光观察；核背景独立","molecular_targets":["collagen type I"],"observed_structures":["所列靶点对应的细胞外纤维性结构"],"display_colours":{"collagen type I":"green","nuclei":"blue"},"display_colour_warning":"颜色为图示显示，不反推天然信号或荧光团/试剂身份","fluorophore_mapping":"未逐面板确认；未提取操作/制备设置","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F05","F12","F13"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B004"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E04-G03 EPV
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S04"],"binding_id":"A121-B004","observation_ids":["A121-E04-O01"],"scope":"ROCcutoffs forCPA/CPV/EPV;CPAcutoffinput originnotuniquelyassignedto2Dhistologyoropticalsectionsbythereadtext,thereforenoP006ten-fieldacquisitionasserted.OriginalCIanomaliesremain.","all_steps_asserted":false}]
- signal: {"signal_source":"与所列ECM靶点对应的免疫荧光观察；核背景独立","molecular_targets":["elastin"],"observed_structures":["所列靶点对应的细胞外纤维性结构"],"display_colours":{"elastin":"yellow","nuclei":"blue"},"display_colour_warning":"颜色为图示显示，不反推天然信号或荧光团/试剂身份","fluorophore_mapping":"未逐面板确认；未提取操作/制备设置","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F05","F12","F13"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B004"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E04-O01
- arm_ids: ["A121-E04-G01","A121-E04-G02","A121-E04-G03"]
- sample_keys: ["human_masld"]
- metric: 分期阈值与ROC判别统计
- result: 作者用ROC及Youden指数选择阈值。补充材料列出12个分期/指标AUROC；其中CPA F3、CPV F1、EPV F1和EPV F2的p值并未达到0.05。若干置信区间越出AUROC的0–1取值范围，原样保留。 补充材料明确报告Youden指数≥50%。常规2D组织学采用Kleiner F0–F4，CPA的总面积排除门管区、管腔及血管胶原；其与图5 CPA-ROC输入的具体映射仍未明。
- values: [{"metric":"CPV_thresholds","unit":"%","value":[{"stage":"F1","lower":4.3,"lower_inclusive":true,"upper":8.7,"upper_inclusive":true},{"stage":"F2","lower":8.7,"lower_inclusive":false,"upper":17.7,"upper_inclusive":true},{"stage":"F3","lower":17.7,"lower_inclusive":false,"upper":24.7,"upper_inclusive":true},{"stage":"F4","lower":24.7,"lower_inclusive":false,"upper":null}]},{"metric":"EPV_thresholds","unit":"%","value":[{"stage":"F1","lower":5.4,"lower_inclusive":true,"upper":9.8,"upper_inclusive":true},{"stage":"F2","lower":9.8,"lower_inclusive":false,"upper":16.6,"upper_inclusive":true},{"stage":"F3","lower":16.6,"lower_inclusive":false,"upper":26.9,"upper_inclusive":true},{"stage":"F4","lower":26.9,"lower_inclusive":false,"upper":null}]},{"metric":"CPA_thresholds","unit":"%","value":[{"stage":"F1","lower":2.3,"lower_inclusive":true,"upper":7.7,"upper_inclusive":true},{"stage":"F2","lower":7.7,"lower_inclusive":false,"upper":13.2,"upper_inclusive":true},{"stage":"F3","lower":13.2,"lower_inclusive":false,"upper":23.7,"upper_inclusive":true},{"stage":"F4","lower":23.7,"lower_inclusive":false,"upper":null}]},{"metric":"stage_specific_AUROC","value":[{"metric":"CPA","stage":"F1","AUROC":0.89,"p_reported":"<0.001","CI95_reported":[0.78,1.0],"CI_outside_AUROC_domain":false,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPA","stage":"F2","AUROC":0.87,"p_reported":"<0.05","CI95_reported":[0.67,1.07],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPA","stage":"F3","AUROC":0.71,"p_reported":"=0.205","CI95_reported":[0.36,1.05],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPA","stage":"F4","AUROC":0.93,"p_reported":"<0.001","CI95_reported":[0.84,1.02],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPV","stage":"F1","AUROC":0.64,"p_reported":"=0.151","CI95_reported":[0.46,0.83],"CI_outside_AUROC_domain":false,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPV","stage":"F2","AUROC":0.86,"p_reported":"<0.05","CI95_reported":[0.71,1.01],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPV","stage":"F3","AUROC":0.95,"p_reported":"<0.01","CI95_reported":[0.85,1.06],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"CPV","stage":"F4","AUROC":0.73,"p_reported":"<0.05","CI95_reported":[0.53,0.94],"CI_outside_AUROC_domain":false,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"EPV","stage":"F1","AUROC":0.62,"p_reported":"=0.324","CI95_reported":[0.37,0.87],"CI_outside_AUROC_domain":false,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"EPV","stage":"F2","AUROC":0.8,"p_reported":"=0.128","CI95_reported":[-0.45,1.14],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"EPV","stage":"F3","AUROC":1.0,"p_reported":"=0.033","CI95_reported":[1.0,1.0],"CI_outside_AUROC_domain":false,"source_status":"verbatim_numeric_transcription_not_recomputed"},{"metric":"EPV","stage":"F4","AUROC":0.85,"p_reported":"<0.05","CI95_reported":[0.63,1.08],"CI_outside_AUROC_domain":true,"source_status":"verbatim_numeric_transcription_not_recomputed"}]}]
- statistics: {"selection":"AUROC/Youden_index_author_report","independent_validation":"not_reported","confidence_intervals":"retained_as_reported_with_domain_flags","selection_condition_as_reported":"Youden index ≥50%"}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F05","F12","F13"]
- evidence_kind: direct_report
- limits: ["阈值为本研究探索性推导；未见外部验证、独立测试集或临床决策获益分析。","越界CI及EPV F3的1–1区间需要作者澄清；不能截断、修正或反推原始数据。","各ROC的具体二分类对照、分析样本数和置信区间算法未充分说明。","常规2D CPA的面积范围排除门管区、管腔及血管胶原；三维ECM指标与其不自动构成同分母的准确率比较。","ROC输入CPA与常规2D/光学截面CPA的具体分支未明确，不声称CPA比较组已经透明化。"]
- reference_measurement: {"histological_staging":"Kleiner F0–F4","conventional_2D_CPA_denominator_exclusions":["portal tracts","lumens","vascular collagen"],"source":"F13","Fig5_CPA_ROC_input_mapping":"unresolved_between_conventional_2D_and_optical_CPA"}
- protocol_binding_ids: ["A121-B004"]

来源：["F05","F12","F13"]

## A121-E05 F3和F4标本的多数光学截面与原分期不一致
- record_id: A121-E05
- title: F3和F4标本的多数光学截面与原分期不一致
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_masld","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"肝实质及细胞外基质","form":"穿刺活检、切除和移植离体标本；个体与用途映射未完全报告","initial_state":"临床取得的离体组织；新鲜来源与FFPE扩展分别记录","biological_n":57,"n_level":"patients","n_status":"reported","stage_counts":{"F0":1,"F1":21,"F2":5,"F3":11,"F4":19},"source_refs":["F02","F17"]}]
- limitations: ["不能解释为44%/47%的患者诊断准确率，不能据此断言53%/56%的患者被误诊。","正文没有明确把这两数字分别绑定到CPV或EPV面板；保留volumetric analysis原归属。","缺每标本截面数、加权/汇总说明和逐患者一致性分布。"]
- independence_note: 与同队列其他ECM分析相关；重复引用本记录或多个光学截面不增加独立患者数。

### A121-E05-G01 原组织学F3
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S04"],"binding_id":"A121-B005","observation_ids":["A121-E05-O01"],"scope":"OpticalsectionclassificationusingresearchderivedCPV/EPVcutoffs;notindependentpatient-levelrepeateddiagnosis.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F01","F06"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B005"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E05-G02 原组织学F4
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S04"],"binding_id":"A121-B005","observation_ids":["A121-E05-O01"],"scope":"OpticalsectionclassificationusingresearchderivedCPV/EPVcutoffs;notindependentpatient-levelrepeateddiagnosis.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F01","F06"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B005"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E05-O01
- arm_ids: ["A121-E05-G01","A121-E05-G02"]
- sample_keys: ["human_masld"]
- metric: 以体积指标阈值分类的光学截面分期一致比例
- result: 作者报告F3标本仅44%、F4标本仅47%的光学截面按所定义阈值仍落在同一期。其余截面可落在更高或更低分期。
- values: [{"stage":"F3","value":44,"unit":"% of optical sections"},{"stage":"F4","value":47,"unit":"% of optical sections"}]
- statistics: {"test":null,"p_value":null,"status":"not_reported_for_this_endpoint"}
- sampling: {"numerator":"sections assigned same stage","denominator":"sections within source-stage specimens","patient_level_confusion_matrix":"not_reported"}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F01","F06"]
- evidence_kind: direct_report
- limits: ["不能解释为44%/47%的患者诊断准确率，不能据此断言53%/56%的患者被误诊。","正文没有明确把这两数字分别绑定到CPV或EPV面板；保留volumetric analysis原归属。","缺每标本截面数、加权/汇总说明和逐患者一致性分布。"]
- protocol_binding_ids: ["A121-B005"]

来源：["F01","F06"]

## A121-E06 六名桥接纤维化移植患者的ECM均值与作者临床解释
- record_id: A121-E06
- title: 六名桥接纤维化移植患者的ECM均值与作者临床解释
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_transplant_subset","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"失代偿慢性肝病移植肝，病理桥接纤维化","form":"移植肝离体标本","initial_state":"离体组织","biological_n":6,"n_level":"selected_patients_from_56_transplants","n_status":"reported_subset","source_refs":["F02","F05"],"overlap_with_main_cohorts":"not_reported; do not add to 110"}]
- limitations: ["EPV组均值24.9%低于作者EPV F4阈值26.9%；不能说两指标均把六人判为F4。","组均值和SD不能确定每个患者的分类。","这六例与主队列重叠未说明，不独立增加总患者数；临床失代偿也不是独立组织学金标准。"]
- independence_note: 6例来自56名移植患者；与57名MASLD、病毒组及FFPE组的重叠未知，不能加到主队列。

### A121-E06-G01 56名移植患者中6名病理F3且临床失代偿病例
- sample_keys: ["human_transplant_subset"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P001","step_ids":["A121-P001-S02","A121-P001-S03","A121-P001-S04","A121-P001-S05","A121-P001-S06","A121-P001-S07","A121-P001-S08","A121-P001-S09"],"binding_id":"A121-B006","observation_ids":["A121-E06-O01"],"scope":"Transplantexplantvariant,no-bis;aggregateof6caseswithin56cohort;EPVgroupmean/thresholdtensionnotresolved.","all_steps_asserted":false},{"protocol_id":"A121-P004","step_ids":["A121-P004-S01","A121-P004-S02","A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B006","observation_ids":["A121-E06-O01"],"scope":"Transplantexplantvariant,no-bis;aggregateof6caseswithin56cohort;EPVgroupmean/thresholdtensionnotresolved.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02"],"binding_id":"A121-B006","observation_ids":["A121-E06-O01"],"scope":"Transplantexplantvariant,no-bis;aggregateof6caseswithin56cohort;EPVgroupmean/thresholdtensionnotresolved.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F02","F05"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B006"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E06-O01
- arm_ids: ["A121-E06-G01"]
- sample_keys: ["human_transplant_subset"]
- metric: 六例CPV/EPV的组均值
- result: 六例的CPV为28.3±3.9%，EPV为24.9±3.4%，均为mean±SD。作者将该结果解释为提示肝硬化。
- values: [{"metric":"CPV","mean":28.3,"error":3.9,"error_type":"SD","unit":"%","n":6},{"metric":"EPV","mean":24.9,"error":3.4,"error_type":"SD","unit":"%","n":6},{"metric":"selected_from_transplant_patients","value":56,"selected":6}]
- statistics: {"test":null,"p_value":null,"status":"not_reported_for_this_endpoint"}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F02","F05"]
- evidence_kind: direct_report
- limits: ["EPV组均值24.9%低于作者EPV F4阈值26.9%；不能说两指标均把六人判为F4。","组均值和SD不能确定每个患者的分类。","这六例与主队列重叠未说明，不独立增加总患者数；临床失代偿也不是独立组织学金标准。"]
- protocol_binding_ids: ["A121-B006"]

来源：["F02","F05"]

## A121-E07 进展期MASLD和病毒性肝病的截面CV分类比较
- record_id: A121-E07
- title: 进展期MASLD和病毒性肝病的截面CV分类比较
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_masld","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"肝实质及细胞外基质","form":"穿刺活检、切除和移植离体标本；个体与用途映射未完全报告","initial_state":"临床取得的离体组织；新鲜来源与FFPE扩展分别记录","biological_n":57,"n_level":"patients","n_status":"reported","stage_counts":{"F0":1,"F1":21,"F2":5,"F3":11,"F4":19},"source_refs":["F02","F17"]},{"sample_key":"human_viral","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"慢性病毒性肝病肝实质","form":"临床离体肝标本","initial_state":"离体组织","biological_n":41,"n_level":"patients_in_supplement/specimens_in_results","n_status":"source_internal_conflict_abstract_38","stage_counts":{"F0":0,"F1":1,"F2":3,"F3":3,"F4":34},"source_refs":["F01","F07","F19"]}]
- limitations: ["不是平均CV数值差的检验，也不是所有分期病因差异。","CV分组界限按组均值±SD定义；图中未报告逐人CV、组别有效n或统一绝对CV阈值。","S4D展示EPV IQR，未给独立显著性结果；不把p=0.002附给IQR。","不显著不等于两病因异质性等效。"]
- independence_note: 与同队列其他ECM分析相关；重复引用本记录或多个光学截面不增加独立患者数。

### A121-E07-G01 MASLD F3–F4
- sample_keys: ["human_masld"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S03","A121-P005-S05"],"binding_id":"A121-B007","observation_ids":["A121-E07-O01"],"scope":"Clinicalfixedliveretiologycomparisononly;nopathogenhandling/engineeringprocedureadded;Chi-squareonlyCVcategorypanels.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F07","F12","F16"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B007"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E07-G02 viral F3–F4
- sample_keys: ["human_viral"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02","A121-P005-S03","A121-P005-S05"],"binding_id":"A121-B007","observation_ids":["A121-E07-O01"],"scope":"Clinicalfixedliveretiologycomparisononly;nopathogenhandling/engineeringprocedureadded;Chi-squareonlyCVcategorypanels.","all_steps_asserted":false}]
- signal: {"signal_source":"间接免疫荧光ECM标记；核染色提供组织背景","molecular_targets":["collagen type I","elastin"],"observed_structures":["本记录对应的细胞外纤维性结构；具体形态见对应观测与图注"],"display_colours":{"collagen_I":"green","elastin":"yellow","nuclei":"blue"},"display_colour_warning":"显示伪彩不等于天然荧光或特定荧光团身份；不据颜色反推试剂","fluorophore_mapping":"未逐面板确认；生物操作/标记制备不提取","scope_note":"不代表每个分期都具备全部桥接/结节周形态","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F07","F12","F16"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B007"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E07-O01
- arm_ids: ["A121-E07-G01","A121-E07-G02"]
- sample_keys: ["human_masld","human_viral"]
- metric: CPV和EPV的CV类别分布病因比较
- result: 补图S4仅限F3–F4。CPV的CV类别分布卡方检验p=0.48；EPV为p=0.002。作者把后者解释为MASLD的弹性蛋白异质性更高。
- values: [{"metric":"CPV_CV_category_distribution","test":"chi-square","p":0.48},{"metric":"EPV_CV_category_distribution","test":"chi-square","p":0.002}]
- statistics: {"scope":"F3–F4_only","tests":[{"panel":"S4A","metric":"CPV CV-class distribution","test":"chi-square","p":0.48},{"panel":"S4C","metric":"EPV CV-class distribution","test":"chi-square","p":0.002}]}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F07","F12","F16"]
- evidence_kind: direct_report
- limits: ["不是平均CV数值差的检验，也不是所有分期病因差异。","CV分组界限按组均值±SD定义；图中未报告逐人CV、组别有效n或统一绝对CV阈值。","S4D展示EPV IQR，未给独立显著性结果；不把p=0.002附给IQR。","不显著不等于两病因异质性等效。"]
- protocol_binding_ids: ["A121-B007"]

来源：["F07","F12","F16"]

## A121-E08 十份档案FFPE肝标本也能获得透明化ECM观察
- record_id: A121-E08
- title: 十份档案FFPE肝标本也能获得透明化ECM观察
- record_kind: experiment_or_observation
- samples: [{"sample_key":"human_ffpe","species":"Homo sapiens","system":"消化系统","organ":"肝","tissue":"非纤维化及进展期MASLD肝组织","form":"FFPE离体标本","initial_state":"福尔马林固定石蜡包埋档案组织","biological_n":10,"n_level":"specimens; unique patients not enumerated","n_status":"reported_specimen_count","source_refs":["F08"],"overlap_with_main_cohorts":"not_reported; do not add to 110"}]
- limitations: ["原文称EPV峰值；不擅自改为EPA，也不当作每例均值的完整范围。","分组n、与新鲜标本配对关系、偏倚及统计比较未报告。","仅可行性扩展，不证明FFPE与新鲜组织结果等效。"]
- independence_note: 10份FFPE是可行性扩展标本；与主队列/移植亚组重叠未报告，不额外增加独立患者n。

### A121-E08-G01 非纤维化FFPE
- sample_keys: ["human_ffpe"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P002","step_ids":["A121-P002-S01","A121-P002-S02"],"binding_id":"A121-B008","observation_ids":["A121-E08-O01"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","all_steps_asserted":false},{"protocol_id":"A121-P004","step_ids":["A121-P004-S01","A121-P004-S03"],"binding_id":"A121-B008","observation_ids":["A121-E08-O01"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02"],"binding_id":"A121-B008","observation_ids":["A121-E08-O01"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","all_steps_asserted":false}]
- signal: {"signal_source":"与所列ECM靶点对应的免疫荧光观察；核背景独立","molecular_targets":["elastin"],"observed_structures":["所列靶点对应的细胞外纤维性结构"],"display_colours":{"elastin":"yellow","nuclei":"blue"},"display_colour_warning":"颜色为图示显示，不反推天然信号或荧光团/试剂身份","fluorophore_mapping":"未逐面板确认；未提取操作/制备设置","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F08"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B008"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E08-G02 进展期MASLD FFPE
- sample_keys: ["human_ffpe"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P002","step_ids":["A121-P002-S01","A121-P002-S02"],"binding_id":"A121-B008","observation_ids":["A121-E08-O01"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","all_steps_asserted":false},{"protocol_id":"A121-P004","step_ids":["A121-P004-S01","A121-P004-S03"],"binding_id":"A121-B008","observation_ids":["A121-E08-O01"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02"],"binding_id":"A121-B008","observation_ids":["A121-E08-O01"],"scope":"FFPEpartialworkflow;freshtransfer/HMtime notconfirmedFFPE-specific;LSM/EPVonlytoreportedapplicationextent.","all_steps_asserted":false}]
- signal: {"signal_source":"与所列ECM靶点对应的免疫荧光观察；核背景独立","molecular_targets":["elastin"],"observed_structures":["所列靶点对应的细胞外纤维性结构"],"display_colours":{"elastin":"yellow","nuclei":"blue"},"display_colour_warning":"颜色为图示显示，不反推天然信号或荧光团/试剂身份","fluorophore_mapping":"未逐面板确认；未提取操作/制备设置","reported_detection_chain":{"scope":"source study human ECM antibody branches; per-sample Collagen I versus Elastin and exact panel allocation remain source-limited","fluorophore":"CY3","secondary":"goat anti-mouse IgG(H+L), 115-165-003","nuclear":"Hoechst33342","protocol_step_refs":["A121-P001-S07","A121-P001-S08","A121-P001-S09"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F08"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B008"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E08-O01
- arm_ids: ["A121-E08-G01","A121-E08-G02"]
- sample_keys: ["human_ffpe"]
- metric: 档案组织透明化可行性及报告的EPV峰值范围
- result: 作者报告10份FFPE肝标本实现透明化，非纤维化样本EPV峰值0–9%，肝硬化14–25%，与新鲜来源标本方向一致。
- values: [{"metric":"specimens","value":10},{"metric":"reported_peak_EPV_range","group":"F0","range":[0,9],"unit":"%"},{"metric":"reported_peak_EPV_range","group":"cirrhosis","range":[14,25],"unit":"%"}]
- statistics: {"test":null,"p_value":null,"status":"not_reported_for_this_endpoint"}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F08"]
- evidence_kind: direct_report
- limits: ["原文称EPV峰值；不擅自改为EPA，也不当作每例均值的完整范围。","分组n、与新鲜标本配对关系、偏倚及统计比较未报告。","仅可行性扩展，不证明FFPE与新鲜组织结果等效。"]
- protocol_binding_ids: ["A121-B008"]

来源：["F08"]

## A121-E09 小鼠模型肝支持ECM三维观察但不足以量化跨物种差异
- record_id: A121-E09
- title: 小鼠模型肝支持ECM三维观察但不足以量化跨物种差异
- record_kind: experiment_or_observation
- samples: [{"sample_key":"mouse_model","species":"Mus musculus","strain_or_type":"C57Bl6/J","sex":"male","system":"消化系统","organ":"肝","tissue":"MASLD模型肝实质","form":"离体肝组织","initial_state":"终点离体样本","biological_n":48,"n_level":"animals_in_overall_model_study","n_status":"reported_total_not_FigS2_panel_n","source_refs":["F10","F14"],"induction_details":"excluded_nonoperational_scope"}]
- limitations: ["图S2B误差棒类型、分期组动物数及精确柱值未报告，未做数字化。","48是总体模型研究数量，不能填入每个分期或成像面板。","动物模型与临床样本不是匹配实验，不推断人体病理机制由模型证实。"]
- independence_note: 独立的动物模型证据类别；总体48只与图S2各分期或成像样本的映射未知，不能当作48个独立人体验证病例。

### A121-E09-G01 模型肝F0–F3
- sample_keys: ["mouse_model"]
- clearing_use: directly_reported
- protocol_uses: [{"protocol_id":"A121-P003","step_ids":["A121-P003-S01","A121-P003-S02","A121-P003-S03","A121-P003-S04","A121-P003-S05"],"binding_id":"A121-B009","observation_ids":["A121-E09-O01"],"scope":"MouseCollagenI1:100/488secondary1:200,not humanCY3.Elastin/humanCVROCnotinherited;S7stagephotosdonotinheritLSMsettings.","all_steps_asserted":false},{"protocol_id":"A121-P004","step_ids":["A121-P004-S01","A121-P004-S02","A121-P004-S03","A121-P004-S05"],"binding_id":"A121-B009","observation_ids":["A121-E09-O01"],"scope":"MouseCollagenI1:100/488secondary1:200,not humanCY3.Elastin/humanCVROCnotinherited;S7stagephotosdonotinheritLSMsettings.","all_steps_asserted":false},{"protocol_id":"A121-P005","step_ids":["A121-P005-S01","A121-P005-S02"],"binding_id":"A121-B009","observation_ids":["A121-E09-O01"],"scope":"MouseCollagenI1:100/488secondary1:200,not humanCY3.Elastin/humanCVROCnotinherited;S7stagephotosdonotinheritLSMsettings.","all_steps_asserted":false}]
- signal: {"signal_source":"与所列ECM靶点对应的免疫荧光观察；核背景独立","molecular_targets":["collagen type I"],"observed_structures":["所列靶点对应的细胞外纤维性结构"],"display_colours":{"collagen type I":"green","nuclei":"blue"},"display_colour_warning":"颜色为图示显示，不反推天然信号或荧光团/试剂身份","fluorophore_mapping":"未逐面板确认；未提取操作/制备设置","reported_detection_chain":{"scope":"mouse collagen branch only","fluorophore":"Alexa Fluor488","secondary":"goat anti-rabbit IgG(H+L), A11008","nuclear":"Hoechst33342","protocol_step_refs":["A121-P003-S03","A121-P003-S04","A121-P003-S05"]}}
- observation_conditions: {"recorded_scope":"离体终点成像；不提取执行设置"}
- source_refs: ["F04","F10","F14"]
- binding_scope: 来源所述分析条件/分期范围，非新增独立实验或个体身份
- protocol_binding_ids: ["A121-B009"]
- historical_protocol_omission_reason: nonoperational_evidence_only
- protocol_use_scope: Only explicit step_ids above are machine-resolved. Other scoped relations remain in protocol_binding_ids; never execute all steps by protocol_id alone.

### A121-E09-O01
- arm_ids: ["A121-E09-G01"]
- sample_keys: ["mouse_model"]
- metric: 三维胶原成像及CPV分期图
- result: 补图S2显示模型肝胶原三维图像和F0–F3 CPV上升图。正文称模型肝胶原变异较少，但未给人鼠正式比较统计。
- values: [{"metric":"overall_model_study_n","value":48,"unit":"male mice","status":"not_panel_n"}]
- statistics: {"test":null,"p_value":null,"status":"not_reported_for_this_endpoint"}
- sampling: {}
- time_description: 横断面离体终点；不同纤维化分期不是同一患者的纵向进展
- source_refs: ["F04","F10","F14"]
- evidence_kind: direct_report
- limits: ["图S2B误差棒类型、分期组动物数及精确柱值未报告，未做数字化。","48是总体模型研究数量，不能填入每个分期或成像面板。","动物模型与临床样本不是匹配实验，不推断人体病理机制由模型证实。"]
- protocol_binding_ids: ["A121-B009"]

来源：["F04","F10","F14"]

## 作者陈述与边界

- record_id: A121-A01
- statement_type: author_interpretation
- title: 作者提出三维病理有助于降低截面取样偏差
- statement: 作者认为全活检体积ECM信息可能改善纤维化分期并解释组织学与临床严重程度不一致。
- source_refs: ["F09","F21"]
- not_demonstrated: ["改善患者预后","外部验证的诊断准确率","消除整肝区域取样偏差"]

- record_id: A121-A02
- statement_type: author_limitation
- title: 作者承认ECM标记范围和临床验证不足
- statement: 仅胶原I及弹性蛋白、F1/F2队列较小、缺MR弹性成像与振动控制瞬时弹性成像比较；需更大和不同人群重新验证阈值及预后价值。
- source_refs: ["F09"]
- not_demonstrated: ["其他ECM组分同样分布","肝静脉压力或长期结局预测"]

- record_id: A121-A03
- statement_type: author_future_proposal
- title: 其他病理特征与组学用途仍是未来应用
- statement: 作者提出将来观察脂肪变、炎症、气球样变、细胞相互作用及组学分析。
- source_refs: ["F21"]
- not_demonstrated: ["本研究已完成这些病理或组学终点","剩余组织的组学质量实测验证"]

## 问题与回答

### A121-GQ-C01-01 实际使用了组织透明化，还是仅提出设想？
实际用于临床非纤维化、MASLD及肝硬化组织，并有代表性透明度与ECM三维图像。
- parent_rq_id: A121-RQ01
- topic_id: A121-C01
- evidence_refs: [{"record_id":"A121-E01","observation_id":"A121-E01-O01","group_ids":["A121-E01-G01"],"focus":"实际透明化与空间模式","source_ids":["F01","F02","F03","F20","F22"],"role":"直接来源报告","figure_or_location":"题目、摘要、发表信息及明确CLARITY实际应用; Results首段：MASLD57、非实质病变切除对照12、ECM形态和六例移植子分析; 图1B–D透明化实例、图2和3的F0–F4 ECM形态; Supplement Video Legends P124–P132：八段ECM展示的作者说明；前四段均写Movie S1，不能据行序直接映射到MOESM文件; 原始补充MOV1–8；每段抽样14帧目视审看；文件与特定Movie图例/分期/标记的逐一映射未确认","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B001"]}]
- answer_scope: 不能用代表图推临床效能；八段视频抽样帧确认旋转体积展示，逐段身份映射未决。

### A121-GQ-C01-02 样本内纤维化是否均匀？
同一活检不同截面可判为F2/F3/F4；CPA/EPA分布宽且F3/F4重叠。
- parent_rq_id: A121-RQ01
- topic_id: A121-C01
- evidence_refs: [{"record_id":"A121-E02","observation_id":"A121-E02-O01","group_ids":["A121-E02-G01","A121-E02-G02","A121-E02-G03","A121-E02-G04","A121-E02-G05"],"focus":"截面CPA/EPA与分期异质性","source_ids":["F04","F15"],"role":"直接来源报告","figure_or_location":"CPA/EPA截面分布与每标本采样数量; Supplement Fig S3：人肝EPA截面分布","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B002"]}]
- answer_scope: 100–400截面、197±99；截面不是患者

### A121-GQ-C02-03 CPV和EPV究竟量化什么？
分别为单份标本多个截面CPA/EPA的平均值，不能无条件称为体积加权ECM占比。
- parent_rq_id: A121-RQ02
- topic_id: A121-C02
- evidence_refs: [{"record_id":"A121-E03","observation_id":"A121-E03-O01","group_ids":["A121-E03-G01","A121-E03-G02"],"focus":"指标定义","source_ids":["F04","F05","F11","F12"],"role":"直接来源报告","figure_or_location":"CPA/EPA截面分布与每标本采样数量; CPV/EPV定义、CV比例、阈值及六例移植汇总值; Image analysis and quantification/Statistical analysis定义; Supplement Image processing段落P033–P035：指标、CV分组与全部AUROC值","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B003"]}]
- answer_scope: 区分标本内CV与组间标本均值IQR

### A121-GQ-C02-04 约85%的中高变异说明什么？
作者报告约85%落在中/高CV相对类别，反映所定义分组的截面变异；不是统一绝对病理阈值。
- parent_rq_id: A121-RQ02
- topic_id: A121-C02
- evidence_refs: [{"record_id":"A121-E03","observation_id":"A121-E03-O01","group_ids":["A121-E03-G01","A121-E03-G02"],"focus":"CV分组","source_ids":["F04","F05","F11","F12"],"role":"直接来源报告","figure_or_location":"CPA/EPA截面分布与每标本采样数量; CPV/EPV定义、CV比例、阈值及六例移植汇总值; Image analysis and quantification/Statistical analysis定义; Supplement Image processing段落P033–P035：指标、CV分组与全部AUROC值","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B003"]}]
- answer_scope: 分类依据组均值±SD

### A121-GQ-C02-05 新阈值已经得到稳健诊断验证了吗？
阈值由本队列ROC推导，部分AUROC检验不显著且若干CI越界；外部验证未报告。
- parent_rq_id: A121-RQ02
- topic_id: A121-C02
- evidence_refs: [{"record_id":"A121-E04","observation_id":"A121-E04-O01","group_ids":["A121-E04-G01","A121-E04-G02","A121-E04-G03"],"focus":"阈值与AUROC","source_ids":["F05","F12","F13"],"role":"直接来源报告","figure_or_location":"CPV/EPV定义、CV比例、阈值及六例移植汇总值; Supplement Image processing段落P033–P035：指标、CV分组与全部AUROC值; Supplement P039：Kleiner分期与2D面积评价的参照范围","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B004"]}]
- answer_scope: 原值保留，不当临床推荐；2D CPA分母排除项和CPA-ROC分支不明，不能据此宣称与CPV等条件比较。

### A121-GQ-C02-06 44%和47%是否代表患者诊断准确率？
不是。这是原F3/F4标本的光学截面在体积阈值分类下与原分期一致的比例。
- parent_rq_id: A121-RQ02
- topic_id: A121-C02
- evidence_refs: [{"record_id":"A121-E05","observation_id":"A121-E05-O01","group_ids":["A121-E05-G01","A121-E05-G02"],"focus":"光学截面分期一致性","source_ids":["F01","F06"],"role":"直接来源报告","figure_or_location":"题目、摘要、发表信息及明确CLARITY实际应用; 光学截面按分期阈值分类的一致比例","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B005"]}]
- answer_scope: 无患者级混淆矩阵

### A121-GQ-C03-07 六例移植患者是否都被两种指标重新判为F4？
不能。CPV均值28.3%高于F4阈值，EPV均值24.9%低于26.9%；作者提示肝硬化的解释与该限制同时保留。
- parent_rq_id: A121-RQ03
- topic_id: A121-C03
- evidence_refs: [{"record_id":"A121-E06","observation_id":"A121-E06-O01","group_ids":["A121-E06-G01"],"focus":"六例汇总量与阈值","source_ids":["F02","F05"],"role":"直接来源报告","figure_or_location":"Results首段：MASLD57、非实质病变切除对照12、ECM形态和六例移植子分析; CPV/EPV定义、CV比例、阈值及六例移植汇总值","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B006"]}]
- answer_scope: 组均值不决定六个个体

### A121-GQ-C03-08 MASLD比病毒性肝病更异质吗？
在F3–F4中，EPV CV类别分布不同p=0.002，CPV类别分布p=0.48；作者将EPV结果解释为更高变异。
- parent_rq_id: A121-RQ03
- topic_id: A121-C03
- evidence_refs: [{"record_id":"A121-E07","observation_id":"A121-E07-O01","group_ids":["A121-E07-G01","A121-E07-G02"],"focus":"病因组CV类别分布","source_ids":["F07","F12","F16"],"role":"直接来源报告","figure_or_location":"病毒性肝病41份标本及与MASLD比较; Supplement Image processing段落P033–P035：指标、CV分组与全部AUROC值; Supplement Fig S4：仅F3–F4病因组的CV类别分布与IQR","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B007"]}]
- answer_scope: 不能扩成全部分期或平均CV差

### A121-GQ-C03-09 档案FFPE样本是否具备使用可行性？
十份标本取得透明化及EPV分布观察；没有与新鲜组织的配对等效验证。
- parent_rq_id: A121-RQ03
- topic_id: A121-C03
- evidence_refs: [{"record_id":"A121-E08","observation_id":"A121-E08-O01","group_ids":["A121-E08-G01","A121-E08-G02"],"focus":"FFPE可行性","source_ids":["F08"],"role":"直接来源报告","figure_or_location":"FFPE10份标本透明化及报告的EPV峰值范围","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B008"]}]
- answer_scope: 标本数不是已知独立患者数

### A121-GQ-C03-10 动物结果能验证人体空间异质性程度吗？
小鼠有胶原三维图和分期CPV趋势；48只为总体研究数，缺分面n和人鼠比较检验。
- parent_rq_id: A121-RQ03
- topic_id: A121-C03
- evidence_refs: [{"record_id":"A121-E09","observation_id":"A121-E09-O01","group_ids":["A121-E09-G01"],"focus":"小鼠模型端点","source_ids":["F04","F10","F14"],"role":"直接来源报告","figure_or_location":"CPA/EPA截面分布与每标本采样数量; Patient materials、Animal materials；仅采集对象身份/伦理及48只小鼠总数; Supplement Fig S2：小鼠肝三维形态及F0–F3 CPV柱状图","scope_resolution":"group_refs_checked; natural-language focus requires semantic reading, not automated filtering","protocol_binding_ids":["A121-B009"]}]
- answer_scope: 不重建疾病诱导或执行参数

### A121-GQ-C04-11 作者提出三维病理有助于降低截面取样偏差？
作者认为全活检体积ECM信息可能改善纤维化分期并解释组织学与临床严重程度不一致。
- parent_rq_id: A121-RQ04
- topic_id: A121-C04
- evidence_refs: [{"record_id":"A121-A01","observation_id":null,"group_ids":[],"focus":"作者提出三维病理有助于降低截面取样偏差","source_ids":["F09","F21"],"role":"author_interpretation","scope_resolution":"author_statement_not_new_observation","protocol_binding_ids":[]}]
- answer_scope: 未证明：改善患者预后；外部验证的诊断准确率；消除整肝区域取样偏差

### A121-GQ-C04-12 作者承认ECM标记范围和临床验证不足？
仅胶原I及弹性蛋白、F1/F2队列较小、缺MR弹性成像与振动控制瞬时弹性成像比较；需更大和不同人群重新验证阈值及预后价值。
- parent_rq_id: A121-RQ04
- topic_id: A121-C04
- evidence_refs: [{"record_id":"A121-A02","observation_id":null,"group_ids":[],"focus":"作者承认ECM标记范围和临床验证不足","source_ids":["F09"],"role":"author_limitation","scope_resolution":"author_statement_not_new_observation","protocol_binding_ids":[]}]
- answer_scope: 未证明：其他ECM组分同样分布；肝静脉压力或长期结局预测

### A121-GQ-C04-13 其他病理特征与组学用途仍是未来应用？
作者提出将来观察脂肪变、炎症、气球样变、细胞相互作用及组学分析。
- parent_rq_id: A121-RQ04
- topic_id: A121-C04
- evidence_refs: [{"record_id":"A121-A03","observation_id":null,"group_ids":[],"focus":"其他病理特征与组学用途仍是未来应用","source_ids":["F21"],"role":"author_future_proposal","scope_resolution":"author_statement_not_new_observation","protocol_binding_ids":[]}]
- answer_scope: 未证明：本研究已完成这些病理或组学终点；剩余组织的组学质量实测验证

## 方法索引
完整方法动作、参数、分支、来源与缺项见 protocol_records.json / protocol_records.md；不得把记录级关系展开为全部步骤执行。
- A121-P001 人肝新鲜块/活检改良CLARITY与ECM标记
- A121-P002 FFPE脱蜡及部分清除支线
- A121-P003 整鼠肝清除、胶原标记和阶段观察
- A121-P004 装管、光片采集及显示
- A121-P005 CPA/EPA、截面均值及异质性分析
- A121-P006 独立二维组织病理及参照CPA

## 未决与范围
[{"issue_id":"A121-U01","type":"source_internal_conflict","subject":"人群总数与病毒组人数","locations":["F01","F07","F09","F19"],"reported_values":{"abstract_components":[57,38,12],"abstract_sum_derived":107,"results_viral_specimens":41,"supplement_viral_patients_sum":41,"discussion_total_patients":110},"resolution":"Results与补表相互支持110的组成，但未发现更正前不能静默修复摘要；总数保持带来源分歧。"},{"issue_id":"A121-U02","type":"source_internal_reporting_tension","subject":"截面采样数量","locations":["F01","F04"],"reported_values":{"abstract":"over 200 sections per sample","results_range":[100,400],"results_mean_SD":[197,99]},"resolution":"采用Results详细范围并并列摘要表述，不推断每份标本超过200。"},{"issue_id":"A121-U03","type":"statistical_reporting_anomaly","subject":"AUROC置信区间","locations":["F12"],"reported_values":"若干95%CI下界<0或上界>1，EPV F3为1–1；完整值见E04-O01。","resolution":"原样保留、标记疑点；无原始数据或更正不能复算/改写。"},{"issue_id":"A121-U04","type":"author_interpretation_vs_threshold","subject":"六例移植亚组的EPV","locations":["F05"],"reported_values":{"EPV_mean":24.9,"F4_threshold_lower_exclusive":26.9},"resolution":"作者提示肝硬化的解释与EPV均值低于F4阈值并列；不据均值判断个体。"},{"issue_id":"A121-U05","type":"unresolved_media_binding","subject":"视频文件与图例身份映射","locations":["F20","F22"],"reported_values":"图例前四条均为Movie S1；原始MOV1–8仅有数字文件名，抽样帧含绿色或黄色展示。","resolution":"八段视频已读范围为抽样帧；不据颜色/顺序指派具体纤维化分期或分子靶点。"},{"conflict_id":"A121-CF01","field":"boricacidunit","sources":[{"locator":"mainp9andSupplementClearingSolution","value":"200nM"}],"resolution":"两处一致但需单位核实；原样保存，未改200mM、未以引用补救。"},{"conflict_id":"A121-CF02","field":"humanPBSTwwashconcentration","sources":[{"locator":"mainp9primary/wash","value":"primary0.1%v/vTween20;wash0.01%v/v"},{"locator":"Supplementstaining","value":"PBSTwdefined0.1%,washPBSTwwithoutrestatedconcentration"}],"resolution":"保留来源包，具体wash值未决。"},{"conflict_id":"A121-CF03","field":"RIandlabellingorder","sources":[{"locator":"mainp9briefenumeration","value":"RIhomogenization listedbefore molecularlabelling"},{"locator":"mainp9detailedstaining,Fig1A,FigS5","value":"label thenRImatching"}],"resolution":"详细染色/图示步骤有明确poststainRIM；不再额外插入一次prelabelRIM，早期RI是否另执行未核。"},{"conflict_id":"A121-CF04","field":"filterwheelrole","sources":[{"locator":"SupplementLSMdevelopment","value":"filterwheelchangesexcitationfilters"},{"locator":"FigS6A","value":"EmissionFilterWheel;separateExcitationFilterslabel"}],"resolution":"原角色说明并列；未复建设备或猜纠错。"},{"conflict_id":"A121-CF05","field":"localmagnificationbinding","sources":[{"locator":"Fig2/3captions","value":"left-bottomimages40×"},{"locator":"mainLSMMethods","value":"total7.5×"},{"locator":"FigS6A","value":"10×objective"}],"resolution":"系统总倍率/物镜和局部40×分层；40×具体inset文字绑定不完整，绝不套用全部3D图。"}]
[]
