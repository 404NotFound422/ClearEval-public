# A156 定向修复报告

版本2026-10-12.targeted-repair.1。作者修复及自检，不是独立验收；计数增量0，等待原审阅者复查。

## A156-IR-01
O04/E04保留S01阳性+S04阴性；G05/G06及机读步骤明确TH-primary与secondary-only，阴性省略S07一抗。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-02
新增S05未清除、S06清除、S07等体积CUBIC2空白与G08–G10；O06/E06绑定三类，测量介质与既往清除状态区分，同组织三次技术读数不合并TH供者/ROI。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-03
D01为男22岁/BMI40.6，D02为男24岁/BMI42.7，两人严重儿童期肥胖；O07/O08/O09及G11–G14链接，未任意分给其他样例。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-04
O01/C01 measurement_time保存Fig1c day1/3/6/9/12/15；补先变硬后1h PBS及后续洗涤通透封闭恢复质地；终末脆弱仍保留。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-05
新增O10/C10/G15表达中心信号下降并回链movieS1/Discussion；O07/C07显式提示；AX01假设原因、AX03未验证建议分开。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-06
O08/C08体积比与O09/C09表面指标分开；surface µm²、对象、每供者4区域、mean±SD汇总和S2八面板覆盖恢复，数值未数字化；CF04仅volume fraction，图轴不据OCR改写。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-90
新增独立新命名SQ/RQ/GQ问答层，每个结果答含实际值、O/G/P选步及未决引用；另有作者解释问题。历史问题缺失不冒充已恢复或继承新验收。
状态：已应用，独立复核待定。原来源未决保持。

## A156-IR-91
samples保留context身份，新增条件/对照/子集G；每个E/O/样本均可回链具体G/P步骤与观察环境。原冲突值不改，明确受影响G/O和用途；不让paper级参数无差别继承。
状态：已应用，独立复核待定。原来源未决保持。

## 实际检查与边界
{
  "all_original_O_values_retained_except_representational_split": true,
  "all_group_result_and_experiment_refs_valid": true,
  "every_selected_step_belongs_to_selected_protocol": true,
  "result_claim_text_and_values_in_question_synchronized": true,
  "embedded_P_equal_actual_author_source": true,
  "source_hashes_match": true,
  "narrow_TH_comparison_repair_retained": true
}

原P整条与作者源一致，原数值/冲突保留；图/视频历史审阅继续明确继承。本轮未做原始栈复算、图值数字化、影片逐帧或新实验，也未运行不匹配新schema的V8工具。不能据P字段齐全宣称整个新证据科学验收。

保护反例：宏观照片不继承显微设置；阴性对照不继承省略的一抗；相同测量介质不等于相同前处理；细胞/区域/孔数不成为供者n；新旧ID只按可证面板内容交叠映射。

仍未决：原文参数冲突/未报、相应图轴、未数字化图值及未确认实际逐样本设置；它们按具体G/O定位，不否定其余有据结果。
