# A156 完整无损阅读投影

本阅读稿逐字段呈现当前完整核心、当前P与问题；不新增科学摘要、不代表expert gold、Pro或出版批准。原短阅读稿和审阅报告保留为独立伴随文件。

## 当前完整科学核心

```json

{
  "schema_version": "reconstructed-research-evidence-1.0",
  "paper_id": "A156",
  "title": "Visualization of sympathetic neural innervation in human white adipose tissue",
  "doi": "10.1098/rsob.210345",
  "version": "2026-10-12.targeted-repair.1",
  "not_historical_hash_restoration": true,
  "old_files_modified": false,
  "publication_approved": false,
  "status": "targeted_repairs_applied_independent_recheck_pending",
  "source_files": [
    {
      "source_id": "A156-R20261012-F01",
      "url": "https://api.repository.cam.ac.uk/server/api/core/bitstreams/71e8d64e-344b-4b92-8a47-9ece39b1b744/content",
      "local_extracts": [
        {
          "path": "sources/inherited_source_excerpts.json",
          "sha256": "aec15c160fa70777a2ba858fffcab741555a1033d1b6c69102d1d4e546a242d6"
        },
        {
          "path": "sources/publisher.pdf",
          "sha256": "8b7dbd5b79ca77daa88a231a634228f0526f0d01f3217a7bb4ac9fa5cae2e26f"
        },
        {
          "path": "sources/publisher.txt",
          "sha256": "fce2c2a2dfb2efc3310fe2765cb949301e45344a31052cc3842dfe08a0f99bb9"
        }
      ],
      "inspection": "Declared main-text/result-caption scope only; no fresh visual digitization or movie decoding."
    }
  ],
  "protocols": [
    {
      "protocol_id": "A156-P001",
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A156/protocol_records.json",
      "source_sha256": "109fa46785a0578399034decc13c8dfa0d6f0f7a93b71bcbaeee6564f645cc22",
      "source_pointer": "/protocol_records/0",
      "record": {
        "record_id": "A156-P001",
        "record_type": "reported_workflow_with_recipe_basis_ambiguities",
        "title": {
          "value": "人白脂肪的整块免疫标记及ScaleCUBIC清除",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.4"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "逐原文恢复已报告方法，并保留清除/未清除、标记/二抗对照和读出支路。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.4"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "两名严重肥胖成年男性；左髂窝皮下脂肪，外科获得约2g材料；与针吸材料的适用性未验证。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.2"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "取得后用PBS洗过的离体组织；Results记dryice上分两块，进入wholemount或10%NBF组织学支路。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp2 §2.1"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "ScaleCUBIC2中用于光片成像的TH标记组织；perilipin未清除支路在清除前分出",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.4"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "Formaldehyde、sucrose、PBS、methanol、ddH2O、H2O2、EDTA、Na(形式未明)、TritonX100、DMSO、glycine、donkeyserum、Tween20、heparin；配方逐步列出",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp5 §4.4"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "THAB152/二抗A31573或perilipinab61682/二抗A11055；二抗稀释缺失",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp5 §4.4"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "ScaleCUBIC1/2组成与原wt分母、Quadrol80%限定见步骤11",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFpp5–6 §4.5"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "离体固定与可选保存",
            "steps": [
              {
                "step_id": "A156-P001-S01",
                "display_order": 1,
                "action": {
                  "value": "在PBS、formaldehyde和sucrose中固定wholemount支路。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "solution": {
                    "value": "20ml PBS+4%formaldehyde(FisherChemical)+10%sucrose(Sigma)；%基准未注明",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "container": {
                    "value": "50ml Falcon",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration_methods": {
                    "value": "overnight",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration_results": {
                    "value": "24h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp2 §2.1"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentle shaking",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "ON与24h各自保存，不据Results把Methods精确改成24h。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P001-S02",
                "display_order": 2,
                "action": {
                  "value": "PBS清洗三次，立即继续或按原文限期储存。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "wash": {
                    "value": "3×5ml PBS;1h each;roomtemperature",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "storage_variant": {
                    "value": "70%ethanol,4°C,maximum1month",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "立即处理与乙醇保存是备选前史，实际各样本选择未知；保存后返回初始缓冲的步骤未另报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "脱水、漂白与复水",
            "steps": [
              {
                "step_id": "A156-P001-S03",
                "display_order": 3,
                "action": {
                  "value": "把固定组织切为原文所述大小，按甲醇梯度脱水。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "reported_piece_size": {
                    "value": "1–2cm³",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "container": {
                    "value": "2ml Eppendorfunlessstatedotherwise",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "volume": {
                    "value": "1.5ml perstep",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "ordered_series": {
                    "value": [
                      "20%methanol/ddH2O30min",
                      "40%30min",
                      "60%30min",
                      "80%30min",
                      "100%30min",
                      "100%30min"
                    ],
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "roomtemperature",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentle shaking",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "原文块容积与2ml管/1.5ml液体适配未解释，不缩改尺寸；百分比基准未明；两个100%段保留。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P001-S04",
                "display_order": 4,
                "action": {
                  "value": "以过氧化氢/甲醇漂白液处理。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "volume": {
                    "value": "1.5ml",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "reported_composition": {
                    "value": "5%H2O2 inmethanol；原文配比1volume30%H2O2 in5volumes100%methanol；10mMEDTA",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "pH": {
                    "value": "8",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "pH_adjuster": {
                    "value": "Na（原文未展开其化学形式）",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "48h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentle shaking",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "Na不能擅改为NaOH；配比与终浓度按作者并列，不另算批量体积。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P001-S05",
                "display_order": 5,
                "action": {
                  "value": "递减甲醇复水，再以Triton/PBS处理两次。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "volume": {
                    "value": "1.5ml perstep",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "ordered_series": {
                    "value": [
                      "80%methanol/ddH2O30min",
                      "60%30min",
                      "40%30min",
                      "20%30min",
                      "PBS+0.2%TritonX100,1h",
                      "PBS+0.2%TritonX100,1h"
                    ],
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "roomtemperature",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentle shaking",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": null,
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "通透与封闭",
            "steps": [
              {
                "step_id": "A156-P001-S06",
                "display_order": 6,
                "action": {
                  "value": "在通透液中旋转孵育，随后转封闭液。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "permeabilization": {
                    "value": "1.5ml PBS+0.2%TritonX100+20%DMSO+0.3Mglycine;37°C48h;gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "blocking": {
                    "value": "1.5ml PBS+0.2%TritonX100+10%DMSO+5%donkeyserum(D9663Sigma);37°C72h;gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "两段合计5days是明确48h+72h处理，不把图日历均分。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "一抗与洗涤",
            "steps": [
              {
                "step_id": "A156-P001-S07",
                "display_order": 7,
                "action": {
                  "value": "按真实标记支路选择TH或perilipin一抗。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "TH": {
                    "value": "1:100;MilliporeAB152;原文称anti-rabbitTHantibody",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "perilipin": {
                    "value": "1:500;Abcamab61682;原文称anti-goatperilipinantibody",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "buffer": {
                    "value": "1.5ml PBS+0.2%Tween20+5%DMSO+5%donkeyserum+10µg/mlheparin",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "96h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "TH与perilipin分别配相应二抗，不能默认双染。这里anti-rabbit/anti-goat按原文保存，二抗结合对象在步骤9明确；不将其解释为分子靶标。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P001-S08",
                "display_order": 8,
                "action": {
                  "value": "按原文清洗一抗孵育后样本。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "wash": {
                    "value": "5×1.5ml PBS+0.2%Tween20+10µg/mlheparin",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "1h each",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "此段洗涤温度未报，不继承后一次洗涤的RT。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "二抗与洗涤",
            "steps": [
              {
                "step_id": "A156-P001-S09",
                "display_order": 9,
                "action": {
                  "value": "用与一抗对应的荧光二抗标记。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "TH_secondary": {
                    "value": "donkeyanti-rabbitAlexa568,InvitrogenA31573",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "perilipin_secondary": {
                    "value": "donkeyanti-goatAlexa488,InvitrogenA11055",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "buffer": {
                    "value": "1.5ml PBS+0.2%Tween20+5%DMSO+5%donkeyserum+10µg/mlheparin",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "96h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "二抗稀释倍数未列，不能继承一抗1:100/1:500；二抗单独对照的全部缓冲孵育细节未另列。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P001-S10",
                "display_order": 10,
                "action": {
                  "value": "洗涤后在PBS中待清除。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "wash": {
                    "value": "5times PBS+0.2%Tween20+10µg/mlheparin",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration_temperature": {
                    "value": "2h each,roomtemperature",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "storage": {
                    "value": "1.5ml PBS,4°C,untilclearing",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "末次五洗体积未单独写出，不能把前一次1.5ml当然继承；储存时长未知。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "ScaleCUBIC来源配方",
            "steps": [
              {
                "step_id": "A156-P001-S11",
                "display_order": 11,
                "action": {
                  "value": "按各自来源组成分别配制Reagent1和Reagent2，并按所述时限保存；两种清除液不相互混合。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "reagent1": {
                    "value": "25wt%urea;25wt%Quadrol80%;15wt%TritonX100;ddH2O",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "reagent2": {
                    "value": "25wt%urea;50wt%sucrose;10wt%triethanolamine;ddH2O",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "reported_wt_definition": {
                    "value": "weightofsolute/weightofsolvent×100（原文定义；非通常按总溶液质量分母）",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "reagent_storage": {
                    "value": "roomtemperature,maximum1month",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "不转换为常规w/w；Quadrol80%是原产品描述与25wt%并列，不推算活性Quadrol最终百分比。未报加料顺序/最终批量/调pH。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "ScaleCUBIC来源流程",
            "steps": [
              {
                "step_id": "A156-P001-S12",
                "display_order": 12,
                "action": {
                  "value": "以半浓度Reagent1预处理，再以原Reagent1清除至透明；按规定换液。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "container": {
                    "value": "2ml Eppendorf",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "first": {
                    "value": "1.5ml1:1Reagent1/ddH2O;37°C3–6h;gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "second": {
                    "value": "1.5mlReagent1;37°C8–15days;gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "replacement": {
                    "value": "refresheveryseconddayuntiltissuelookedclear",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "8–15days与每2日换液为实际条件；Fig1c照片日1/3/6/9/12/15不生成额外处理配置。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P001-S13",
                "display_order": 13,
                "action": {
                  "value": "转半浓度Reagent2/PBS，再转Reagent2进行RI匹配至成像。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "first": {
                    "value": "1.5ml1:1Reagent2/PBS;37°C3–6h;gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "second": {
                    "value": "1.5mlReagent2;37°C72h;gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFpp5–6 §4.5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "Reagent1稀释液是ddH2O，Reagent2稀释液是PBS，不能统一。原文untilimaged不支持额外长期保存时长。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [
          {
            "case_id": "TH_cleared",
            "description": {
              "value": "TH→donkeyanti-rabbitAlexa568；进入ScaleCUBIC并光片成像。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDFp5 §4.4"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "evidence_ids": [
              "A156-E03",
              "A156-E05",
              "A156-E06",
              "A156-E07"
            ]
          },
          {
            "case_id": "perilipin_uncleared",
            "description": {
              "value": "perilipin→donkeyanti-goatAlexa488；§4.7明确在未清除组织用LeicaSP8成像；不应用S11–13清除。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDFp6 §4.7"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "evidence_ids": [
              "A156-E02"
            ]
          },
          {
            "case_id": "secondary_only_controls",
            "description": {
              "value": "Fig2b/c分别为perilipin和TH相应二抗单独对照，原文未另给各阴性对照完整孵育时间。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDFp6 §4.7"
                },
                {
                  "source_id": "F01",
                  "locator": "PDFp3 §2.3 and Fig2b/c caption"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "primary_antibody": "omitted_as_control",
            "remaining_actual_timing": "notseparatelyreported"
          }
        ],
        "reported_precedence": [
          "S01→S02→S03→S04→S05→S06→S07→S08→S09→S10；TH清除支路随后S12→S13；S11是清除液配制/保存定义，不强制在处理第11时才配。",
          "perilipin未清除支路在清除前分出；negativecontrols不凭正样本时程补全部具体值。"
        ],
        "missing_information": [
          "ON vs24h固定差异，实际各样本取值未明。",
          "Na化学形式、wt%分母异常、Quadrol80%25wt%含义及批量配制细节未解决。",
          "二抗稀释，一抗后洗涤温度、末五洗体积和control完整时程未报。",
          "1–2cm³块与2ml管/1.5ml液的适配未解释，不擅改。"
        ],
        "source_conflicts": [],
        "preparation_and_warnings": [
          {
            "value": "作者报告清除后组织fragile且难处理；此为处理限制，不代表已证实所有试剂non-hazardous。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFpp4–5 Discussion"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "review_status": "source_checked_direct_scope;independent_audit_pending"
      },
      "preservation": "inherited values and IDs unchanged"
    },
    {
      "protocol_id": "A156-P002",
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A156/protocol_records.json",
      "source_sha256": "109fa46785a0578399034decc13c8dfa0d6f0f7a93b71bcbaeee6564f645cc22",
      "source_pointer": "/protocol_records/1",
      "record": {
        "record_id": "A156-P002",
        "record_type": "reported_imaging_and_analysis_with_explicit_metric_gaps",
        "title": {
          "value": "脂肪清除前后光学/面积读出和TH三维定量",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "逐原文恢复已报告方法，并保留清除/未清除、标记/二抗对照和读出支路。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "未清除/清除同类脂肪以及清除TH组；读出按各自模态绑定",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "固定/标记/清除到指定阶段的组织",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "透射率、二维面积、三维TH对象体积比例与表面输出",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "100µlScaleCUBIC2；96孔板；SparkM10；ImageJ",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.6"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "ZeissZ1；胶/注射器；Reagent2；ZENblack/Arivis/Fiji/ZENlite/Prism7",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.7"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "透射率读出",
            "steps": [
              {
                "step_id": "A156-P002-S01",
                "display_order": 1,
                "action": {
                  "value": "将未清除和清除组织各置于CUBIC2中作光吸收光谱读数。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "medium_volume": {
                    "value": "100µlCUBIC2",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "plate": {
                    "value": "96wellclear-bottomed(Greiner)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "reader": {
                    "value": "SparkM10(Tecan)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "wavelength": {
                    "value": "400–1000nm,every2nm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "blank": {
                    "value": "equalvolumeCUBIC2insame96wellplates",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "未清除组此处也浸在CUBIC2测量介质中，不据此改成经历完整清除。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P002-S02",
                "display_order": 2,
                "action": {
                  "value": "由吸收计算透射率，按空白与同一组织的三次测量归一/汇总。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "formula": {
                    "value": "T=10^(−A)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "repeats": {
                    "value": "3individualmeasurementsofsametissue",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "reported_output": {
                    "value": "percentagetransmittancenormalizedtoblank=100%",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "作者未详细说明空白是先扣吸光度或后以透射率比校正，不添加未经给出的计算先后；约40%提高是结果并非处理阈值。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "二维面积读出",
            "steps": [
              {
                "step_id": "A156-P002-S03",
                "display_order": 3,
                "action": {
                  "value": "以照片1cm比例尺设标定，沿组织轮廓选择面积并量测。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "software": {
                    "value": "ImageJ",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "scale": {
                    "value": "1cmbar",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "selection": {
                    "value": "tissueperimeter,areaselectiontool",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "output_unit": {
                    "value": "cm²",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "time_scope": {
                    "value": "before/during/afterdehydration,rehydrationandclearing",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "测的是照片二维面积，不是体积；S1曲线点未逐个绑定某固定液步骤时点。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "TH光片采集",
            "steps": [
              {
                "step_id": "A156-P002-S04",
                "display_order": 4,
                "action": {
                  "value": "以胶固定在注射器边缘，置入充Reagent2的成像室，用ZeissZ1采集TH通道。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "mounting": {
                    "value": "glueat edgeofsyringe;avoidbubbleformation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "immersion": {
                    "value": "ScaleCUBIC2",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "illumination": {
                    "value": "singleordual-side",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "objective": {
                    "value": "ECPlan-Neofluar5×/0.16Air",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "excitation": {
                    "value": "561nm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "emission": {
                    "value": "BP575–615nm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "software": {
                    "value": "ZENblack2014SP1v9.2.6.54",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "单/双侧为原文备选设置，具体面板选择未给；不得继承给LeicaSP8的perilipin。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "拼接和显示",
            "steps": [
              {
                "step_id": "A156-P002-S05",
                "display_order": 5,
                "action": {
                  "value": "以Arivis拼接，再以Fiji/ZENlite进行后续图像处理。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "stitching": {
                    "value": "Arivis",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "further_processing": {
                    "value": "FijiandZENlite",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "未给z-step、功率、曝光、拼接容差或显示窗口；影片为固定重建展示。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "TH对象定量",
            "steps": [
              {
                "step_id": "A156-P002-S06",
                "display_order": 6,
                "action": {
                  "value": "每供者取4个Z-stack区域，ArivisVision4D以blobfinder及阈值/分割/拆分敏感度识别纤维对象并求体积。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "software": {
                    "value": "ArivisVision4D",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "regions": {
                    "value": "4Z-stackareaspersubject",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "segmentation": {
                    "value": "blobfinderdiameter,threshold,objectsegmentationandsplittingsensitivity",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "exclusion": {
                    "value": "fibrevolume<600µm³excluded",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "volume": {
                    "value": "sumvolumeofidentifiedobjects,µm³",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "4区域嵌套供者；实际ROI选法、尺寸、阈值和拆分数值未报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A156-P002-S07",
                "display_order": 7,
                "action": {
                  "value": "计算TH对象体积占总体积的比，保存纤维表面读出并绘图。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "relative_fibres_definition": {
                    "value": "fibrevolume(µm³)/totalvolume(µm³)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "fibre_surface": {
                    "value": "ArivisVision4D,µm²（具体surfaceestimator未述）",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "tissue_surface_area": {
                    "value": "ImageJ(Fiji),µm²",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "graphing": {
                    "value": "Prism7",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "summary_display": {
                    "value": "Fig.3g: n=4 tissue areas, mean±standard deviation；区域嵌套供者。",
                    "source_raw": "n=4 tissue areas,mean±standard deviation(error bars)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp4 Fig3 caption"
                      },
                      {
                        "source_id": "F05",
                        "locator": "Fig3g original image"
                      }
                    ],
                    "check_status": "verified_against_primary_source_and_figure"
                  }
                },
                "notes": {
                  "value": "Fig3g无百分号且部分点>1，图示缩放未明；数学体积比定义不能无条件当图示原始数值或擅乘100。tissuesurfacearea与fibresurface不合并。 TH相对比例按纤维总体积/组织总体积定义，不是纤维条数。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [
          {
            "case_id": "transmittance",
            "description": {
              "value": "只属于E04，对未清除/清除测量条件都保留CUBIC2介质。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDFp6 §4.6"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "step_ids": [
              "A156-P002-S01",
              "A156-P002-S02"
            ]
          },
          {
            "case_id": "area",
            "description": {
              "value": "E01阶段照片二维面积。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDFp6 §4.6"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "step_ids": [
              "A156-P002-S03"
            ]
          },
          {
            "case_id": "TH_imaging_quant",
            "description": {
              "value": "清除TH体数据光片/对象定量；不含未清除perilipin。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDFp6 §4.7"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "step_ids": [
              "A156-P002-S04",
              "A156-P002-S05",
              "A156-P002-S06",
              "A156-P002-S07"
            ]
          }
        ],
        "reported_precedence": [
          "透射率S01→S02；面积S03为独立读出；TH成像S04→S05→S06→S07。"
        ],
        "missing_information": [
          "空白归一化计算先后未报；不得发明精确算法流程。",
          "各图采集/ROI/分割具体设置和表面积算法缺失；relativeTHfibres轴缩放未明。"
        ],
        "source_conflicts": [],
        "preparation_and_warnings": [],
        "review_status": "source_checked_direct_scope;independent_audit_pending"
      },
      "preservation": "inherited values and IDs unchanged"
    },
    {
      "protocol_id": "A156-P003",
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A156/protocol_records.json",
      "source_sha256": "109fa46785a0578399034decc13c8dfa0d6f0f7a93b71bcbaeee6564f645cc22",
      "source_pointer": "/protocol_records/2",
      "record": {
        "record_id": "A156-P003",
        "record_type": "partial_reference_branches_not_complete_histologySOP",
        "title": {
          "value": "未清除perilipin共聚焦与H&E组织学方法入口",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "逐原文恢复已报告方法，并保留清除/未清除、标记/二抗对照和读出支路。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "未清除perilipin组织与独立10%NBF固定组织学分支",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "分流的脂肪标本",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "未清除perilipin形态图或H&E切片图",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "10%NBF；25mlpot",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp5 §4.3"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "LeicaSP8；perilipin分支标记",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.7"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "H&E支路",
            "steps": [
              {
                "step_id": "A156-P003-S01",
                "display_order": 1,
                "action": {
                  "value": "H&E用脂肪支路以中性缓冲formalin固定，保留为组织学方法入口。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "fixative": {
                    "value": "10%NBF",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "container": {
                    "value": "25mlhistologypot",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "roomtemperature",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "untilfurtherprocessing",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp5 §4.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "切片厚度、包埋、H&E染色时程与设备未报；不能由图片补完整组织学流程。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "未清除perilipin支路",
            "steps": [
              {
                "step_id": "A156-P003-S02",
                "display_order": 2,
                "action": {
                  "value": "以LeicaSP8对未清除perilipin标记组织成像；二抗单独对照分别保留。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "microscope": {
                    "value": "LeicaSP8confocal",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "signal": {
                    "value": "perilipin/Alexa488versussecondaryonly",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp6 §4.7"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "继承P001perilipin标记身份，未透明化；共聚焦物镜/激发/检测/z-step未报，不采用TH光片561/BP575–615。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [],
        "reported_precedence": [
          "两支路互相独立，不串行。"
        ],
        "missing_information": [
          "H&E完整制备和图像采集未報；perilipin共聚焦详细采集未報。"
        ],
        "source_conflicts": [],
        "preparation_and_warnings": [],
        "review_status": "source_checked_direct_scope;independent_audit_pending"
      },
      "preservation": "inherited values and IDs unchanged"
    }
  ],
  "experiments": [
    {
      "experiment_id": "A156-R20261012-E01",
      "question": "Size and texture during preparation",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G01"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G01",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G01",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S03"
          ],
          "branch_selector": "area photos; cm², not tissue volume",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E02",
      "question": "Histological preservation",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2a; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G02"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G02",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S01"
          ],
          "branch_selector": "H&E branch only; no post-clearing histology",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E03",
      "question": "Uncleared adipocyte labeling",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S03"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G03",
        "A156-R20261012-G04"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G03",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10"
          ],
          "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G03",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "LeicaSP8 uncleared perilipin",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G04",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E04",
      "question": "TH labeling specificity context",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S01",
        "A156-R20261012-S04"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G05",
        "A156-R20261012-G06"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G05",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G05",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH light-sheet acquisition and processing",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G06",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G06",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "Fig2c control imaging; no invented per-panel settings",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E05",
      "question": "Autofluorescence architecture",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2d; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G07"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G07",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "clearing context only; antibody execution not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G07",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S05"
          ],
          "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E06",
      "question": "Optical transmittance",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S05",
        "A156-R20261012-S06",
        "A156-R20261012-S07"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G08",
        "A156-R20261012-G09",
        "A156-R20261012-G10"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G08",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Uncleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G09",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G09",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Cleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G10",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E07",
      "question": "Three-dimensional neural network visualization",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3a–f; Results2.4; moviesS1–S2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G11",
        "A156-R20261012-G12",
        "A156-R20261012-G15"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G11",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G11",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G12",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G12",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G15",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G15",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "movieS1 TH rendering",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    },
    {
      "experiment_id": "A156-R20261012-E08",
      "question": "TH fiber volume fraction and surface",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G13",
        "A156-R20261012-G14"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ]
    }
  ],
  "samples": [
    {
      "sample_id": "A156-R20261012-S01",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human severe-obesity abdominal subcutaneous white adipose tissue, left iliac fossa surgical biopsy; fixed wholemount; two subjects reported for TH analysis",
      "signals": "TH primary rabbit antibody / donkey anti-rabbit Alexa568; sympathetic neural structures; autofluorescence separately",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G01",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G01",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S03"
          ],
          "branch_selector": "area photos; cm², not tissue volume",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G05",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G05",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH light-sheet acquisition and processing",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G07",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "clearing context only; antibody execution not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G07",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S05"
          ],
          "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G11",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G11",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G12",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G12",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G15",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G15",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "movieS1 TH rendering",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1–2.4; Methods4.2–4.7",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G01",
        "A156-R20261012-G05",
        "A156-R20261012-G07",
        "A156-R20261012-G11",
        "A156-R20261012-G13",
        "A156-R20261012-G12",
        "A156-R20261012-G14",
        "A156-R20261012-G15"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    },
    {
      "sample_id": "A156-R20261012-S02",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human adipose split histological piece; independently fixed in neutral-buffered formalin, not assigned the wholemount clearing branch",
      "signals": "H&E histology of adipocytes",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G02",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S01"
          ],
          "branch_selector": "H&E branch only; no post-clearing histology",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1; Figure2a",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G02"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    },
    {
      "sample_id": "A156-R20261012-S03",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human uncleared adipose tissue, perilipin staining and secondary-only control",
      "signals": "perilipin primary goat antibody / donkey anti-goat Alexa488; adipocyte lipid-droplet coat",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G03",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10"
          ],
          "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G03",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "LeicaSP8 uncleared perilipin",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G04",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Methods4.4,4.7",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G03",
        "A156-R20261012-G04"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    },
    {
      "sample_id": "A156-R20261012-S04",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human adipose cleared secondary-only/no-TH control class",
      "signals": "secondary-only background comparison; exact specimen co-reference unknown",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G06",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G06",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "Fig2c control imaging; no invented per-panel settings",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G06"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    },
    {
      "sample_id": "A156-R20261012-S05",
      "sample_identity_level": "measurement_reference_class_not_individual",
      "sample": "Uncleared adipose optical-transmission reference",
      "initial_state": "uncleared",
      "reported_n": null,
      "identity_constraints": "Not assigned to individual TH-analysis donors or four-ROI cohort; CUBIC2 during measurement does not imply prior clearing",
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Methods4.6; Fig2e",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G08",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Uncleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "group_ids": [
        "A156-R20261012-G08"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    },
    {
      "sample_id": "A156-R20261012-S06",
      "sample_identity_level": "measurement_reference_class_not_individual",
      "sample": "Cleared adipose optical-transmission sample",
      "initial_state": "cleared",
      "reported_n": null,
      "identity_constraints": "Not assigned to individual TH-analysis donors or four-ROI cohort; CUBIC2 during measurement does not imply prior clearing",
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Methods4.6; Fig2e",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G09",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G09",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Cleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "group_ids": [
        "A156-R20261012-G09"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    },
    {
      "sample_id": "A156-R20261012-S07",
      "sample_identity_level": "measurement_reference_class_not_individual",
      "sample": "Equal-volume CUBIC2 optical blank; no tissue",
      "initial_state": "reagent blank",
      "reported_n": null,
      "identity_constraints": "Not assigned to individual TH-analysis donors or four-ROI cohort; CUBIC2 during measurement does not imply prior clearing",
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Methods4.6; Fig2e",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G10",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "group_ids": [
        "A156-R20261012-G10"
      ],
      "condition_scope": "Actual condition and step selection is group-specific; sample context is not one specimen or uniform procedure."
    }
  ],
  "artifacts": [
    {
      "artifact_id": "A156-R20261012-AR01",
      "type": "published_result_source",
      "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR02",
      "type": "published_result_source",
      "locator": "Figure2a; Results2.3",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2a; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR03",
      "type": "published_result_source",
      "locator": "Figure2b; Results2.3",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR04",
      "type": "published_result_source",
      "locator": "Figure2c; Results2.3",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR05",
      "type": "published_result_source",
      "locator": "Figure2d; Results2.3",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2d; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR06",
      "type": "published_result_source",
      "locator": "Figure2e; Results2.3; Methods4.6",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR07",
      "type": "published_result_source",
      "locator": "Figure3a–f; Results2.4; moviesS1–S2",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3a–f; Results2.4; moviesS1–S2",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A156-R20261012-AR08",
      "type": "published_result_source",
      "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    }
  ],
  "results": [
    {
      "result_id": "A156-R20261012-O01",
      "experiment_id": "A156-R20261012-E01",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "metric": "Size and texture during preparation",
      "result": "Dehydration reduces area; rehydration restores most original size. Clearing alters shape and produces fragile gel-like consistency. Area observations do not establish volume preservation. During dehydration/rehydration the tissue first became more rigid, then regained its original texture after 1h PBS incubation and subsequent washing, permeabilization and blocking. Fig1c shows a qualitative clearing sequence at days1,3,6,9,12,15; these observation days are not uniform endpoints for every specimen.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": {
        "figure": "Fig1c",
        "days": [
          1,
          3,
          6,
          9,
          12,
          15
        ],
        "time_origin": "clearing sequence as labeled in Fig1c",
        "not_global_process_day": true
      },
      "measurement_time_status": "reported_panel_observation_days",
      "artifact_ids": [
        "A156-R20261012-AR01"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G01"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G01",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G01",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S03"
          ],
          "branch_selector": "area photos; cm², not tissue volume",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O02",
      "experiment_id": "A156-R20261012-E02",
      "sample_context_ids": [
        "A156-R20261012-S02"
      ],
      "metric": "Histological preservation",
      "result": "H&E shows intact adipocytes with large lipid droplets in the separately fixed piece; no post-clearing H&E comparison is established.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR02"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2a; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G02"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G02",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S01"
          ],
          "branch_selector": "H&E branch only; no post-clearing histology",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [],
      "uncertainty_refs": [
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G02"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O03",
      "experiment_id": "A156-R20261012-E03",
      "sample_context_ids": [
        "A156-R20261012-S03"
      ],
      "metric": "Uncleared adipocyte labeling",
      "result": "Perilipin confocal staining supports adipocyte morphology with secondary-only control; this is not evidence that perilipin survives clearing.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR03"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G03",
        "A156-R20261012-G04"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G03",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10"
          ],
          "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G03",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "LeicaSP8 uncleared perilipin",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G04",
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF03"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        },
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G04"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O04",
      "experiment_id": "A156-R20261012-E04",
      "sample_context_ids": [
        "A156-R20261012-S01",
        "A156-R20261012-S04"
      ],
      "metric": "TH labeling specificity context",
      "result": "TH-labeled neural arborizations are visible relative to secondary-only control. No complete fiber detection or zero background claim is made.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR04"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "comparison_groups": [
        {
          "sample_context_id": "A156-R20261012-S01",
          "condition": "TH primary plus secondary"
        },
        {
          "sample_context_id": "A156-R20261012-S04",
          "condition": "secondary only / no TH primary"
        }
      ],
      "group_ids": [
        "A156-R20261012-G05",
        "A156-R20261012-G06"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G05",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G05",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH light-sheet acquisition and processing",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G06",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G06",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "Fig2c control imaging; no invented per-panel settings",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O05",
      "experiment_id": "A156-R20261012-E05",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "metric": "Autofluorescence architecture",
      "result": "Autofluorescence provides tissue architectural context after processing; qualitative appearance does not prove unchanged dimensions.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR05"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2d; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G07"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G07",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "clearing context only; antibody execution not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G07",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S05"
          ],
          "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF02"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G07"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O06",
      "experiment_id": "A156-R20261012-E06",
      "sample_context_ids": [
        "A156-R20261012-S05",
        "A156-R20261012-S06",
        "A156-R20261012-S07"
      ],
      "metric": "Optical transmittance",
      "result": "Clearing increases light transmittance; the approximate reported increase retains the original percentage ambiguity and is not converted to an exact relative gain.",
      "values": {
        "reported_approximate_increase": "about 40%",
        "interpretation": "relative percent versus percentage points not explicitly disambiguated",
        "technical_reads": 3,
        "biological_n": "not established by technical read count",
        "range_nm": [
          400,
          1000
        ],
        "step_nm": 2,
        "normalization": "equal-volume CUBIC2 blank set to 100%; T=10^(-A)"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR06"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G08",
        "A156-R20261012-G09",
        "A156-R20261012-G10"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G08",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Uncleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G09",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G09",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Cleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G10",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF02"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G08"
        },
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G09"
        },
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G10"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O07",
      "experiment_id": "A156-R20261012-E07",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "metric": "Three-dimensional neural network visualization",
      "result": "Orthogonal views visualize neural arborizations in two severely obese subjects. Multiple planes and movies do not add subjects; fine-fiber quantification requires higher magnification. Spatial coverage is nonuniform: authors report lower antibody signal at the tissue centre in movieS1/Discussion (separate O10).",
      "values": {
        "subjects": 2,
        "views": [
          "xy",
          "yz",
          "xz"
        ]
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR07"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3a–f; Results2.4; moviesS1–S2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "donor_ids": [
        "A156-R20261012-D01",
        "A156-R20261012-D02"
      ],
      "group_ids": [
        "A156-R20261012-G11",
        "A156-R20261012-G12"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G11",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G11",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G12",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G12",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O08",
      "experiment_id": "A156-R20261012-E08",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "metric": "Relative TH fiber volume fraction",
      "result": "Segmented TH-object volume divided by total imaged volume, in four areas per subject. Fig3g left summarizes mean±SD across tissue areas; it is not a fiber count. The graph axis scaling remains unresolved.",
      "values": {
        "areas_per_subject": 4,
        "subjects": 2,
        "summary": "mean ± SD across tissue areas",
        "relative_TH_definition": "fiber volume / total imaged volume",
        "minimum_included_object_volume_um3": 600,
        "absolute_graph_values": null,
        "absolute_graph_values_status": "not_redigitized",
        "source_conflict": "A156-CF04"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A156-R20261012-AR08"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "donor_ids": [
        "A156-R20261012-D01",
        "A156-R20261012-D02"
      ],
      "group_ids": [
        "A156-R20261012-G13",
        "A156-R20261012-G14"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03",
        "A156-CF04"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF04"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O09",
      "experiment_id": "A156-R20261012-E08",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "metric": "Mean TH fiber surface",
      "result": "Fig3g right reports mean fibre surface, with between-subject and between-area variation. Supplementary FigS2 displays separate fiber-surface distributions for four areas in each of two subjects. Numeric graph values were not digitized.",
      "values": {
        "unit": "µm²",
        "unit_basis": "Methods4.7 explicit fibre surface unit; no substitution based on PDF OCR mm²",
        "measured_objects": "segmented TH-positive fibre objects",
        "aggregation": "mean fibre surface for each tissue area; Fig3g mean±SD across 4 tissue areas per subject",
        "subjects": 2,
        "areas_per_subject": 4,
        "surface_algorithm": "not_reported",
        "numeric_values": null,
        "numeric_values_status": "not_digitized",
        "supplementary_distribution_scope": [
          {
            "subject": 1,
            "area": 1,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 1,
            "area": 2,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 1,
            "area": 3,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 1,
            "area": 4,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 2,
            "area": 1,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 2,
            "area": 2,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 2,
            "area": 3,
            "numeric_range": null,
            "range_status": "not_digitized"
          },
          {
            "subject": 2,
            "area": 4,
            "numeric_range": null,
            "range_status": "not_digitized"
          }
        ]
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported",
      "artifact_ids": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Fig3g right; Methods4.7; Supplementary FigS2 preserved full-page review",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "donor_ids": [
        "A156-R20261012-D01",
        "A156-R20261012-D02"
      ],
      "group_ids": [
        "A156-R20261012-G13",
        "A156-R20261012-G14"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G13",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G14",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        }
      ]
    },
    {
      "result_id": "A156-R20261012-O10",
      "experiment_id": "A156-R20261012-E07",
      "sample_context_ids": [
        "A156-R20261012-S01"
      ],
      "metric": "Reduced central antibody signal",
      "result": "Authors report reduced antibody signal in the centre of the adipose biopsy, referring to movieS1. This spatially nonuniform signal is an observation; its cause was not experimentally isolated.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported",
      "artifact_ids": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "group_ids": [
        "A156-R20261012-G15"
      ],
      "protocol_uses": [
        {
          "group_id": "A156-R20261012-G15",
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "group_id": "A156-R20261012-G15",
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "movieS1 TH rendering",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "uncertainty_refs": [
        {
          "type": "source_conflict",
          "id": "A156-CF01"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF02"
        },
        {
          "type": "source_conflict",
          "id": "A156-CF03"
        },
        {
          "type": "group_limitations",
          "group_id": "A156-R20261012-G15"
        }
      ]
    }
  ],
  "claims": [
    {
      "claim_id": "A156-R20261012-C01",
      "claim_type": "source_scoped_result_summary",
      "text": "Dehydration reduces area; rehydration restores most original size. Clearing alters shape and produces fragile gel-like consistency. Area observations do not establish volume preservation. During dehydration/rehydration the tissue first became more rigid, then regained its original texture after 1h PBS incubation and subsequent washing, permeabilization and blocking. Fig1c shows a qualitative clearing sequence at days1,3,6,9,12,15; these observation days are not uniform endpoints for every specimen.",
      "supporting_result_ids": [
        "A156-R20261012-O01"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G01"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ]
    },
    {
      "claim_id": "A156-R20261012-C02",
      "claim_type": "source_scoped_result_summary",
      "text": "H&E shows intact adipocytes with large lipid droplets in the separately fixed piece; no post-clearing H&E comparison is established.",
      "supporting_result_ids": [
        "A156-R20261012-O02"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2a; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G02"
      ],
      "source_conflict_ids": []
    },
    {
      "claim_id": "A156-R20261012-C03",
      "claim_type": "source_scoped_result_summary",
      "text": "Perilipin confocal staining supports adipocyte morphology with secondary-only control; this is not evidence that perilipin survives clearing.",
      "supporting_result_ids": [
        "A156-R20261012-O03"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G03",
        "A156-R20261012-G04"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF03"
      ]
    },
    {
      "claim_id": "A156-R20261012-C04",
      "claim_type": "source_scoped_result_summary",
      "text": "TH-labeled neural arborizations are visible relative to secondary-only control. No complete fiber detection or zero background claim is made.",
      "supporting_result_ids": [
        "A156-R20261012-O04"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G05",
        "A156-R20261012-G06"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ]
    },
    {
      "claim_id": "A156-R20261012-C05",
      "claim_type": "source_scoped_result_summary",
      "text": "Autofluorescence provides tissue architectural context after processing; qualitative appearance does not prove unchanged dimensions.",
      "supporting_result_ids": [
        "A156-R20261012-O05"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2d; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G07"
      ],
      "source_conflict_ids": [
        "A156-CF02"
      ]
    },
    {
      "claim_id": "A156-R20261012-C06",
      "claim_type": "source_scoped_result_summary",
      "text": "Clearing increases light transmittance; the approximate reported increase retains the original percentage ambiguity and is not converted to an exact relative gain.",
      "supporting_result_ids": [
        "A156-R20261012-O06"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G08",
        "A156-R20261012-G09",
        "A156-R20261012-G10"
      ],
      "source_conflict_ids": [
        "A156-CF02"
      ]
    },
    {
      "claim_id": "A156-R20261012-C07",
      "claim_type": "source_scoped_result_summary",
      "text": "Orthogonal views visualize neural arborizations in two severely obese subjects. Multiple planes and movies do not add subjects; fine-fiber quantification requires higher magnification. Spatial coverage is nonuniform: authors report lower antibody signal at the tissue centre in movieS1/Discussion (separate O10).",
      "supporting_result_ids": [
        "A156-R20261012-O07"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3a–f; Results2.4; moviesS1–S2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G11",
        "A156-R20261012-G12"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ]
    },
    {
      "claim_id": "A156-R20261012-C08",
      "claim_type": "source_scoped_result_summary",
      "text": "Segmented TH-object volume divided by total imaged volume, in four areas per subject. Fig3g left summarizes mean±SD across tissue areas; it is not a fiber count. The graph axis scaling remains unresolved.",
      "supporting_result_ids": [
        "A156-R20261012-O08"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "group_ids": [
        "A156-R20261012-G13",
        "A156-R20261012-G14"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03",
        "A156-CF04"
      ]
    },
    {
      "claim_id": "A156-R20261012-AX01",
      "claim_type": "author_hypothesis",
      "text": "Authors propose that incomplete lipid clearing reduces antibody penetration and contributes to central signal loss. This causal explanation was not independently tested.",
      "supporting_result_ids": [
        "A156-R20261012-O10"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Discussion",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A156-R20261012-AX02",
      "claim_type": "author_future_prospect",
      "text": "Lean-obese comparison, leptin and weight-loss effects remain proposed future uses.",
      "supporting_result_ids": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Discussion",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A156-R20261012-AX03",
      "claim_type": "author_unvalidated_improvement_suggestion",
      "text": "Smaller samples and increased antibody concentration are suggested as possible improvements, not demonstrated successful optimizations.",
      "supporting_result_ids": [
        "A156-R20261012-O10"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Discussion pp4–5",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ]
    },
    {
      "claim_id": "A156-R20261012-C09",
      "claim_type": "source_scoped_result_summary",
      "text": "Fig3g right reports mean fibre surface, with between-subject and between-area variation. Supplementary FigS2 displays separate fiber-surface distributions for four areas in each of two subjects. Numeric graph values were not digitized.",
      "supporting_result_ids": [
        "A156-R20261012-O09"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Fig3g right; Methods4.7; Supplementary FigS2 preserved full-page review",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "group_ids": [
        "A156-R20261012-G13",
        "A156-R20261012-G14"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ]
    },
    {
      "claim_id": "A156-R20261012-C10",
      "claim_type": "source_scoped_result_summary",
      "text": "Authors report reduced antibody signal in the centre of the adipose biopsy, referring to movieS1. This spatially nonuniform signal is an observation; its cause was not experimentally isolated.",
      "supporting_result_ids": [
        "A156-R20261012-O10"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ],
      "group_ids": [
        "A156-R20261012-G15"
      ],
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ]
    }
  ],
  "relations": [
    {
      "subject": "A156-R20261012-AR01",
      "predicate": "supports",
      "object": "A156-R20261012-O01"
    },
    {
      "subject": "A156-R20261012-E01",
      "predicate": "has_result",
      "object": "A156-R20261012-O01"
    },
    {
      "subject": "A156-R20261012-O01",
      "predicate": "supports",
      "object": "A156-R20261012-C01"
    },
    {
      "subject": "A156-R20261012-AR02",
      "predicate": "supports",
      "object": "A156-R20261012-O02"
    },
    {
      "subject": "A156-R20261012-E02",
      "predicate": "has_result",
      "object": "A156-R20261012-O02"
    },
    {
      "subject": "A156-R20261012-O02",
      "predicate": "supports",
      "object": "A156-R20261012-C02"
    },
    {
      "subject": "A156-R20261012-AR03",
      "predicate": "supports",
      "object": "A156-R20261012-O03"
    },
    {
      "subject": "A156-R20261012-E03",
      "predicate": "has_result",
      "object": "A156-R20261012-O03"
    },
    {
      "subject": "A156-R20261012-O03",
      "predicate": "supports",
      "object": "A156-R20261012-C03"
    },
    {
      "subject": "A156-R20261012-AR04",
      "predicate": "supports",
      "object": "A156-R20261012-O04"
    },
    {
      "subject": "A156-R20261012-E04",
      "predicate": "has_result",
      "object": "A156-R20261012-O04"
    },
    {
      "subject": "A156-R20261012-O04",
      "predicate": "supports",
      "object": "A156-R20261012-C04"
    },
    {
      "subject": "A156-R20261012-AR05",
      "predicate": "supports",
      "object": "A156-R20261012-O05"
    },
    {
      "subject": "A156-R20261012-E05",
      "predicate": "has_result",
      "object": "A156-R20261012-O05"
    },
    {
      "subject": "A156-R20261012-O05",
      "predicate": "supports",
      "object": "A156-R20261012-C05"
    },
    {
      "subject": "A156-R20261012-AR06",
      "predicate": "supports",
      "object": "A156-R20261012-O06"
    },
    {
      "subject": "A156-R20261012-E06",
      "predicate": "has_result",
      "object": "A156-R20261012-O06"
    },
    {
      "subject": "A156-R20261012-O06",
      "predicate": "supports",
      "object": "A156-R20261012-C06"
    },
    {
      "subject": "A156-R20261012-AR07",
      "predicate": "supports",
      "object": "A156-R20261012-O07"
    },
    {
      "subject": "A156-R20261012-E07",
      "predicate": "has_result",
      "object": "A156-R20261012-O07"
    },
    {
      "subject": "A156-R20261012-O07",
      "predicate": "supports",
      "object": "A156-R20261012-C07"
    },
    {
      "subject": "A156-R20261012-AR08",
      "predicate": "supports",
      "object": "A156-R20261012-O08"
    },
    {
      "subject": "A156-R20261012-E08",
      "predicate": "has_result",
      "object": "A156-R20261012-O08"
    },
    {
      "subject": "A156-R20261012-O08",
      "predicate": "supports",
      "object": "A156-R20261012-C08"
    },
    {
      "subject": "A156-R20261012-E01",
      "predicate": "has_group",
      "object": "A156-R20261012-G01"
    },
    {
      "subject": "A156-R20261012-G01",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G01",
      "predicate": "supports_result",
      "object": "A156-R20261012-O01"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G01",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G01",
      "step_ids": [
        "A156-P002-S03"
      ],
      "branch_selector": "area photos; cm², not tissue volume"
    },
    {
      "subject": "A156-R20261012-E02",
      "predicate": "has_group",
      "object": "A156-R20261012-G02"
    },
    {
      "subject": "A156-R20261012-G02",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S02"
    },
    {
      "subject": "A156-R20261012-G02",
      "predicate": "supports_result",
      "object": "A156-R20261012-O02"
    },
    {
      "subject": "A156-P003",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G02",
      "step_ids": [
        "A156-P003-S01"
      ],
      "branch_selector": "H&E branch only; no post-clearing histology"
    },
    {
      "subject": "A156-R20261012-E03",
      "predicate": "has_group",
      "object": "A156-R20261012-G03"
    },
    {
      "subject": "A156-R20261012-G03",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S03"
    },
    {
      "subject": "A156-R20261012-G03",
      "predicate": "supports_result",
      "object": "A156-R20261012-O03"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G03",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10"
      ],
      "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13"
    },
    {
      "subject": "A156-P003",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G03",
      "step_ids": [
        "A156-P003-S02"
      ],
      "branch_selector": "LeicaSP8 uncleared perilipin"
    },
    {
      "subject": "A156-R20261012-E03",
      "predicate": "has_group",
      "object": "A156-R20261012-G04"
    },
    {
      "subject": "A156-R20261012-G04",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S03"
    },
    {
      "subject": "A156-R20261012-G04",
      "predicate": "supports_result",
      "object": "A156-R20261012-O03"
    },
    {
      "subject": "A156-P003",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G04",
      "step_ids": [
        "A156-P003-S02"
      ],
      "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported"
    },
    {
      "subject": "A156-R20261012-E04",
      "predicate": "has_group",
      "object": "A156-R20261012-G05"
    },
    {
      "subject": "A156-R20261012-G05",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G05",
      "predicate": "supports_result",
      "object": "A156-R20261012-O04"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G05",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G05",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05"
      ],
      "branch_selector": "TH light-sheet acquisition and processing"
    },
    {
      "subject": "A156-R20261012-E04",
      "predicate": "has_group",
      "object": "A156-R20261012-G06"
    },
    {
      "subject": "A156-R20261012-G06",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S04"
    },
    {
      "subject": "A156-R20261012-G06",
      "predicate": "supports_result",
      "object": "A156-R20261012-O04"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G06",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G06",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05"
      ],
      "branch_selector": "Fig2c control imaging; no invented per-panel settings"
    },
    {
      "subject": "A156-R20261012-E05",
      "predicate": "has_group",
      "object": "A156-R20261012-G07"
    },
    {
      "subject": "A156-R20261012-G07",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G07",
      "predicate": "supports_result",
      "object": "A156-R20261012-O05"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G07",
      "step_ids": [
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "clearing context only; antibody execution not established"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G07",
      "step_ids": [
        "A156-P002-S05"
      ],
      "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence"
    },
    {
      "subject": "A156-R20261012-E06",
      "predicate": "has_group",
      "object": "A156-R20261012-G08"
    },
    {
      "subject": "A156-R20261012-G08",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S05"
    },
    {
      "subject": "A156-R20261012-G08",
      "predicate": "supports_result",
      "object": "A156-R20261012-O06"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G08",
      "step_ids": [
        "A156-P002-S01",
        "A156-P002-S02"
      ],
      "branch_selector": "optical transmittance Uncleared tissue"
    },
    {
      "subject": "A156-R20261012-E06",
      "predicate": "has_group",
      "object": "A156-R20261012-G09"
    },
    {
      "subject": "A156-R20261012-G09",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S06"
    },
    {
      "subject": "A156-R20261012-G09",
      "predicate": "supports_result",
      "object": "A156-R20261012-O06"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G09",
      "step_ids": [
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "reported clearing branch; per-panel preceding antibody history not established"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G09",
      "step_ids": [
        "A156-P002-S01",
        "A156-P002-S02"
      ],
      "branch_selector": "optical transmittance Cleared tissue"
    },
    {
      "subject": "A156-R20261012-E06",
      "predicate": "has_group",
      "object": "A156-R20261012-G10"
    },
    {
      "subject": "A156-R20261012-G10",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S07"
    },
    {
      "subject": "A156-R20261012-G10",
      "predicate": "supports_result",
      "object": "A156-R20261012-O06"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G10",
      "step_ids": [
        "A156-P002-S01",
        "A156-P002-S02"
      ],
      "branch_selector": "optical transmittance Equal-volume CUBIC2 blank"
    },
    {
      "subject": "A156-R20261012-E07",
      "predicate": "has_group",
      "object": "A156-R20261012-G11"
    },
    {
      "subject": "A156-R20261012-G11",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G11",
      "predicate": "supports_result",
      "object": "A156-R20261012-O07"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G11",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G11",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05"
      ],
      "branch_selector": "TH wholemount visualization"
    },
    {
      "subject": "A156-R20261012-E08",
      "predicate": "has_group",
      "object": "A156-R20261012-G13"
    },
    {
      "subject": "A156-R20261012-G13",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G13",
      "predicate": "supports_result",
      "object": "A156-R20261012-O08"
    },
    {
      "subject": "A156-R20261012-G13",
      "predicate": "supports_result",
      "object": "A156-R20261012-O09"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G13",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G13",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05",
        "A156-P002-S06",
        "A156-P002-S07"
      ],
      "branch_selector": "TH objects; volume fraction and surface are distinct readouts"
    },
    {
      "subject": "A156-R20261012-E07",
      "predicate": "has_group",
      "object": "A156-R20261012-G12"
    },
    {
      "subject": "A156-R20261012-G12",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G12",
      "predicate": "supports_result",
      "object": "A156-R20261012-O07"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G12",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G12",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05"
      ],
      "branch_selector": "TH wholemount visualization"
    },
    {
      "subject": "A156-R20261012-E08",
      "predicate": "has_group",
      "object": "A156-R20261012-G14"
    },
    {
      "subject": "A156-R20261012-G14",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G14",
      "predicate": "supports_result",
      "object": "A156-R20261012-O08"
    },
    {
      "subject": "A156-R20261012-G14",
      "predicate": "supports_result",
      "object": "A156-R20261012-O09"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G14",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G14",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05",
        "A156-P002-S06",
        "A156-P002-S07"
      ],
      "branch_selector": "TH objects; volume fraction and surface are distinct readouts"
    },
    {
      "subject": "A156-R20261012-E07",
      "predicate": "has_group",
      "object": "A156-R20261012-G15"
    },
    {
      "subject": "A156-R20261012-G15",
      "predicate": "uses_sample_context",
      "object": "A156-R20261012-S01"
    },
    {
      "subject": "A156-R20261012-G15",
      "predicate": "supports_result",
      "object": "A156-R20261012-O10"
    },
    {
      "subject": "A156-P001",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G15",
      "step_ids": [
        "A156-P001-S01",
        "A156-P001-S02",
        "A156-P001-S03",
        "A156-P001-S04",
        "A156-P001-S05",
        "A156-P001-S06",
        "A156-P001-S07",
        "A156-P001-S08",
        "A156-P001-S09",
        "A156-P001-S10",
        "A156-P001-S11",
        "A156-P001-S12",
        "A156-P001-S13"
      ],
      "branch_selector": "TH positive wholemount"
    },
    {
      "subject": "A156-P002",
      "predicate": "used_in_group",
      "object": "A156-R20261012-G15",
      "step_ids": [
        "A156-P002-S04",
        "A156-P002-S05"
      ],
      "branch_selector": "movieS1 TH rendering"
    },
    {
      "subject": "A156-R20261012-E08",
      "predicate": "has_result",
      "object": "A156-R20261012-O09"
    },
    {
      "subject": "A156-R20261012-O09",
      "predicate": "supports",
      "object": "A156-R20261012-C09"
    },
    {
      "subject": "A156-R20261012-E07",
      "predicate": "has_result",
      "object": "A156-R20261012-O10"
    },
    {
      "subject": "A156-R20261012-O10",
      "predicate": "supports",
      "object": "A156-R20261012-C10"
    },
    {
      "subject": "A156-R20261012-O01",
      "predicate": "answers",
      "object": "A156-R20261012-GQ01"
    },
    {
      "subject": "A156-R20261012-O01",
      "predicate": "answers",
      "object": "A156-R20261012-RQ01"
    },
    {
      "subject": "A156-R20261012-O02",
      "predicate": "answers",
      "object": "A156-R20261012-GQ02"
    },
    {
      "subject": "A156-R20261012-O02",
      "predicate": "answers",
      "object": "A156-R20261012-RQ02"
    },
    {
      "subject": "A156-R20261012-O03",
      "predicate": "answers",
      "object": "A156-R20261012-GQ03"
    },
    {
      "subject": "A156-R20261012-O03",
      "predicate": "answers",
      "object": "A156-R20261012-RQ03"
    },
    {
      "subject": "A156-R20261012-O04",
      "predicate": "answers",
      "object": "A156-R20261012-GQ04"
    },
    {
      "subject": "A156-R20261012-O04",
      "predicate": "answers",
      "object": "A156-R20261012-RQ04"
    },
    {
      "subject": "A156-R20261012-O05",
      "predicate": "answers",
      "object": "A156-R20261012-GQ05"
    },
    {
      "subject": "A156-R20261012-O05",
      "predicate": "answers",
      "object": "A156-R20261012-RQ05"
    },
    {
      "subject": "A156-R20261012-O06",
      "predicate": "answers",
      "object": "A156-R20261012-GQ06"
    },
    {
      "subject": "A156-R20261012-O06",
      "predicate": "answers",
      "object": "A156-R20261012-RQ06"
    },
    {
      "subject": "A156-R20261012-O07",
      "predicate": "answers",
      "object": "A156-R20261012-GQ07"
    },
    {
      "subject": "A156-R20261012-O10",
      "predicate": "answers",
      "object": "A156-R20261012-GQ07"
    },
    {
      "subject": "A156-R20261012-O07",
      "predicate": "answers",
      "object": "A156-R20261012-RQ07"
    },
    {
      "subject": "A156-R20261012-O10",
      "predicate": "answers",
      "object": "A156-R20261012-RQ07"
    },
    {
      "subject": "A156-R20261012-O08",
      "predicate": "answers",
      "object": "A156-R20261012-GQ08"
    },
    {
      "subject": "A156-R20261012-O09",
      "predicate": "answers",
      "object": "A156-R20261012-GQ08"
    },
    {
      "subject": "A156-R20261012-O08",
      "predicate": "answers",
      "object": "A156-R20261012-RQ08"
    },
    {
      "subject": "A156-R20261012-O09",
      "predicate": "answers",
      "object": "A156-R20261012-RQ08"
    },
    {
      "subject": "A156-R20261012-O01",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O02",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O03",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O04",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O05",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O06",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O07",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O08",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O09",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O10",
      "predicate": "answers",
      "object": "A156-R20261012-SQ01"
    },
    {
      "subject": "A156-R20261012-O10",
      "predicate": "answers",
      "object": "A156-R20261012-RQ99"
    }
  ],
  "inherited_scientific_boundaries": {
    "schema_version": "source_scoped_protocol_records-1.0",
    "paper_id": "A156",
    "review_scope": "本轮直接读主文全文Methods/Results/Discussion与图注，目视PDF5/6及Fig1流程图；恢复13步处理、7步读出、2步部分参考，共3条主记录。人类外科活检方法未编入透明化SOP，来源/样本选择保留。 后续完整目视Fig2/3及两张原始补充PDF全页；未数字化。",
    "source_conflicts": [
      {
        "id": "A156-CF01",
        "topic": "fixationduration",
        "values": [
          "MethodsON4°C",
          "Results24h4°C"
        ],
        "actual": "notresolved"
      },
      {
        "id": "A156-CF02",
        "topic": "recipebasis",
        "detail": "wt%=solute/solvent×100按原文保留，与常规总溶液分母不同；不直接给批量称量表。"
      },
      {
        "id": "A156-CF03",
        "topic": "Na",
        "detail": "漂白液pH8调节试剂只写Na，化学形式未知；不替换NaOH。"
      },
      {
        "id": "A156-CF04",
        "topic": "relativefibresplot",
        "detail": "定义体积比，图轴缩放未知；保存定义与旧O限制，不更正结果。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7 ratio definition"
          },
          {
            "source_id": "F05",
            "locator": "Fig3g left axis and dots"
          }
        ]
      }
    ],
    "remaining_unreviewed": [
      "外引Jiang/Susaki原文未扩大恢复；使用本文已明示改编步骤，pH/配方疑点保留。",
      "两段影片未重新解码或逐帧阅，原始Z-stack/逐ROI数表未取得。",
      "活检手术细节位于原文§4.2，本轮起点为离体标本，不将其重编为新的临床操作指导。"
    ],
    "missing_content_register": [
      {
        "record_id": "A156-P001",
        "missing": [
          "ON vs24h固定差异，实际各样本取值未明。",
          "Na化学形式、wt%分母异常、Quadrol80%25wt%含义及批量配制细节未解决。",
          "二抗稀释，一抗后洗涤温度、末五洗体积和control完整时程未报。",
          "1–2cm³块与2ml管/1.5ml液的适配未解释，不擅改。"
        ]
      },
      {
        "record_id": "A156-P002",
        "missing": [
          "空白归一化计算先后未报；不得发明精确算法流程。",
          "各图采集/ROI/分割具体设置和表面积算法缺失；relativeTHfibres轴缩放未明。"
        ]
      },
      {
        "record_id": "A156-P003",
        "missing": [
          "H&E完整制备和图像采集未報；perilipin共聚焦详细采集未報。"
        ]
      }
    ],
    "observation_conditions": [
      "可选70%ethanol4°C最长1month保存是来源已报告前史，不作为每样本必做。",
      "抗体后PBS4°C至清除为持续储存，时长未定。",
      "Fig1c清除day1/3/6/9/12/15是观察日，不复制成6个清除P，也不把Fig1bday0–30总示意按比例分配操作小时。"
    ],
    "sources": [
      {
        "source_id": "F01",
        "path": "candidate_research_next_20261008f/PMC8924755/originals/PMC8924755.1.pdf",
        "sha256": "5af57716ba0fcf5fa0b07e3340f22eb09da9162331c703b15c7c2f9d24d319cb",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/",
        "this_round_read": "fulltext/p5–6visual"
      },
      {
        "source_id": "F02",
        "path": "candidate_research_next_20261008f/PMC8924755/originals/PMC8924755.1.xml",
        "sha256": "6d70860b5f44a70d70102b482abb89350355af2de5df0bc0d37f87ad79dd8e41",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/",
        "this_round_read": "fulltext/p5–6visual"
      },
      {
        "source_id": "F03",
        "path": "candidate_research_next_20261008f/PMC8924755/originals/rsob210345f01.jpg",
        "sha256": "01e51b9e76718a8aeb40948148607615cbcc505407cb00435e036ee345f626d9",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/figure/RSOB210345F1/",
        "this_round_read": "Fig1fullvisual"
      },
      {
        "source_id": "F04",
        "path": "candidate_research_next_20261008f/PMC8924755/originals/rsob210345f02.jpg",
        "sha256": "be878a859e32d5dac118cfc78f5b1b147859d8065d33a664ffba503891bc66f4",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/figure/RSOB210345F2/",
        "this_round_read": "本轮目视原始Fig2/3全图；核模态、对照、轴与n/mean±SD图注，不数字化。"
      },
      {
        "source_id": "F05",
        "path": "candidate_research_next_20261008f/PMC8924755/originals/rsob210345f03.jpg",
        "sha256": "8973f09a295e8e5afd34122b95ffb54290fe40c893a4994a1951e6c7264b0464",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/figure/RSOB210345F3/",
        "this_round_read": "本轮目视原始Fig2/3全图；核模态、对照、轴与n/mean±SD图注，不数字化。"
      },
      {
        "source_id": "F06",
        "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_001.pdf",
        "sha256": "5fa9e7b5770e22b461301e0c4c623df4f4138929172096728056b2fe5b2d33b5",
        "url": "https://doi.org/10.6084/m9.figshare.19311973.v1",
        "this_round_read": "原始PDF单页完整渲染目视；S1阶段/面积、S2八个对象表面分布；不重建原始数值。"
      },
      {
        "source_id": "F07",
        "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_002.pdf",
        "sha256": "c2a529581e0c6c42e8aba0b251f2089e8128a9ba56f25a30416b4363a9f7e9e5",
        "url": "https://doi.org/10.6084/m9.figshare.19311964.v1",
        "this_round_read": "原始PDF单页完整渲染目视；S1阶段/面积、S2八个对象表面分布；不重建原始数值。"
      },
      {
        "source_id": "F08",
        "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_003.mp4",
        "sha256": "a1a33ff5c14113352e18ec2b25ad205d08389fb66d855e1cf5d73b1a045cf977",
        "url": "https://doi.org/10.6084/m9.figshare.19311970.v1",
        "this_round_read": "maincaptiononly;originalnotnewlyviewed"
      },
      {
        "source_id": "F09",
        "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_004.mp4",
        "sha256": "7cf73502ffc4fefd70fd650d01834e39d532c2ab43c482b38089774b1712120b",
        "url": "https://doi.org/10.6084/m9.figshare.19311967.v1",
        "this_round_read": "maincaptiononly;originalnotnewlyviewed"
      }
    ],
    "review_status": {
      "source_content": "savedwithgaps",
      "independent_audit": "pending",
      "specified_Pro": "unchanged_hold",
      "actual_execution": "notperformed"
    },
    "source_field_check_count": 166,
    "recovery_current_scope_20261010": {
      "paper_id": "A156",
      "recovery_date": "2026-10-10",
      "input_selected": "checkpoint_recovery_20261010/extracted/checkpoint/full_corpus_sources/objects/9c211420228cecc29bf115d87617601206607a4156578c64f030a8a2bb7adb8d.json",
      "input_sha256": "9c211420228cecc29bf115d87617601206607a4156578c64f030a8a2bb7adb8d",
      "layer": "recovered_current_scope_without_new_primary_source_verification",
      "historical_review_and_acceptance_preserved": true,
      "original_review_scope_and_check_status_semantics": "Inherited checkpoint declarations; not claims made by this recovery pass.",
      "current_work": "Inspected embedded source_raw excerpts for named issues and made only explicitly supported internal-consistency repairs. Field inventory is mechanical enumeration, not a reconstructed full scientific audit.",
      "new_primary_source_verified_fields": 0,
      "targeted_internal_checks": {
        "/protocol_records/1/sections/0/steps/1/parameters/repeats": "现存§4.6摘录明确同一组织三次individual measurements。",
        "/protocol_records/1/sections/1/steps/0/action": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/1/steps/0/parameters/software": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/1/steps/0/parameters/scale": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/1/steps/0/parameters/selection": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/1/steps/0/parameters/output_unit": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/1/steps/0/parameters/time_scope": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/1/steps/0/notes": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
        "/protocol_records/1/sections/4/steps/1/notes": "§4.7明确体积除以总体积；未重测Fig3g。"
      },
      "prior_verified_scope_recovered_from_parent": [
        "三次透射率读数来自同一组织，不等同2供体×4区域的TH分析单位。",
        "断连前实际源核记录：约40%提高不能改写成增加40个百分点；面积变化不等于体积变化；TH体积占比不等于纤维条数。"
      ],
      "aggregate_gap_counts_have_no_invented_field_mapping": true,
      "existing_source_conflicts_preserved": [
        {
          "id": "A156-CF01",
          "topic": "fixationduration",
          "values": [
            "MethodsON4°C",
            "Results24h4°C"
          ],
          "actual": "notresolved"
        },
        {
          "id": "A156-CF02",
          "topic": "recipebasis",
          "detail": "wt%=solute/solvent×100按原文保留，与常规总溶液分母不同；不直接给批量称量表。"
        },
        {
          "id": "A156-CF03",
          "topic": "Na",
          "detail": "漂白液pH8调节试剂只写Na，化学形式未知；不替换NaOH。"
        },
        {
          "id": "A156-CF04",
          "topic": "relativefibresplot",
          "detail": "定义体积比，图轴缩放未知；保存定义与旧O限制，不更正结果。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7 ratio definition"
            },
            {
              "source_id": "F05",
              "locator": "Fig3g left axis and dots"
            }
          ]
        }
      ],
      "existing_remaining_unreviewed_preserved": [
        "外引Jiang/Susaki原文未扩大恢复；使用本文已明示改编步骤，pH/配方疑点保留。",
        "两段影片未重新解码或逐帧阅，原始Z-stack/逐ROI数表未取得。",
        "活检手术细节位于原文§4.2，本轮起点为离体标本，不将其重编为新的临床操作指导。"
      ],
      "online_access": "PMC request returned reCAPTCHA for A152/A154/A155/A158; retrieval stopped, no bypass or supplementary batch retrieval. Other papers not requested from blocked host.",
      "publication_approved": false
    }
  },
  "source_conflicts": [
    {
      "id": "A156-CF01",
      "topic": "fixationduration",
      "values": [
        "MethodsON4°C",
        "Results24h4°C"
      ],
      "actual": "notresolved",
      "affected_group_ids": [
        "A156-R20261012-G01",
        "A156-R20261012-G03",
        "A156-R20261012-G05",
        "A156-R20261012-G06",
        "A156-R20261012-G11",
        "A156-R20261012-G13",
        "A156-R20261012-G12",
        "A156-R20261012-G14",
        "A156-R20261012-G15"
      ],
      "affected_result_ids": [
        "A156-R20261012-O01",
        "A156-R20261012-O03",
        "A156-R20261012-O04",
        "A156-R20261012-O07",
        "A156-R20261012-O08",
        "A156-R20261012-O09",
        "A156-R20261012-O10"
      ],
      "use_impact": "The stated parameter/interpretation remains unresolved for these branches; supported observations are not globally invalidated."
    },
    {
      "id": "A156-CF02",
      "topic": "recipebasis",
      "detail": "wt%=solute/solvent×100按原文保留，与常规总溶液分母不同；不直接给批量称量表。",
      "affected_group_ids": [
        "A156-R20261012-G01",
        "A156-R20261012-G05",
        "A156-R20261012-G06",
        "A156-R20261012-G07",
        "A156-R20261012-G09",
        "A156-R20261012-G10",
        "A156-R20261012-G11",
        "A156-R20261012-G13",
        "A156-R20261012-G12",
        "A156-R20261012-G14",
        "A156-R20261012-G15"
      ],
      "affected_result_ids": [
        "A156-R20261012-O01",
        "A156-R20261012-O04",
        "A156-R20261012-O05",
        "A156-R20261012-O06",
        "A156-R20261012-O07",
        "A156-R20261012-O08",
        "A156-R20261012-O09",
        "A156-R20261012-O10"
      ],
      "use_impact": "The stated parameter/interpretation remains unresolved for these branches; supported observations are not globally invalidated."
    },
    {
      "id": "A156-CF03",
      "topic": "Na",
      "detail": "漂白液pH8调节试剂只写Na，化学形式未知；不替换NaOH。",
      "affected_group_ids": [
        "A156-R20261012-G01",
        "A156-R20261012-G03",
        "A156-R20261012-G05",
        "A156-R20261012-G06",
        "A156-R20261012-G11",
        "A156-R20261012-G13",
        "A156-R20261012-G12",
        "A156-R20261012-G14",
        "A156-R20261012-G15"
      ],
      "affected_result_ids": [
        "A156-R20261012-O01",
        "A156-R20261012-O03",
        "A156-R20261012-O04",
        "A156-R20261012-O07",
        "A156-R20261012-O08",
        "A156-R20261012-O09",
        "A156-R20261012-O10"
      ],
      "use_impact": "The stated parameter/interpretation remains unresolved for these branches; supported observations are not globally invalidated."
    },
    {
      "id": "A156-CF04",
      "topic": "relativefibresplot",
      "detail": "定义体积比，图轴缩放未知；保存定义与旧O限制，不更正结果。",
      "source_refs": [
        {
          "source_id": "F01",
          "locator": "PDFp6 §4.7 ratio definition"
        },
        {
          "source_id": "F05",
          "locator": "Fig3g left axis and dots"
        }
      ],
      "affected_group_ids": [
        "A156-R20261012-G13",
        "A156-R20261012-G14"
      ],
      "affected_result_ids": [
        "A156-R20261012-O08"
      ],
      "use_impact": "The stated parameter/interpretation remains unresolved for these branches; supported observations are not globally invalidated."
    }
  ],
  "legacy_mapping": {
    "preserved_evidence_links": [
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A156-E01-G01",
        "group_pointer": "/evidence_records/0/groups/0",
        "observations": [
          {
            "observation_id": "A156-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "全页照片及面积图"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p2 §2.1; p3 §2.2; p6 §4.6"
              },
              {
                "source_id": "F06",
                "location": "全页照片及面积图"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A156-E01-G02",
        "group_pointer": "/evidence_records/0/groups/1",
        "observations": [
          {
            "observation_id": "A156-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "全页照片及面积图"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p2 §2.1; p3 §2.2; p6 §4.6"
              },
              {
                "source_id": "F06",
                "location": "全页照片及面积图"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A156-E01-G03",
        "group_pointer": "/evidence_records/0/groups/2",
        "observations": [
          {
            "observation_id": "A156-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "全页照片及面积图"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p2 §2.1; p3 §2.2; p6 §4.6"
              },
              {
                "source_id": "F06",
                "location": "全页照片及面积图"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A156-E01-G04",
        "group_pointer": "/evidence_records/0/groups/3",
        "observations": [
          {
            "observation_id": "A156-E01-O01",
            "pointer": "/evidence_records/0/observations/0",
            "figure_panels": [
              "Fig1c"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p2 Fig1c/图注; p3 §2.2"
              },
              {
                "source_id": "F03",
                "location": "Fig1c"
              }
            ]
          },
          {
            "observation_id": "A156-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "全页照片及面积图"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p2 §2.1; p3 §2.2; p6 §4.6"
              },
              {
                "source_id": "F06",
                "location": "全页照片及面积图"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A156-E02-G01",
        "group_pointer": "/evidence_records/1/groups/0",
        "observations": [
          {
            "observation_id": "A156-E02-O01",
            "pointer": "/evidence_records/1/observations/0",
            "figure_panels": [
              "Fig2a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2a/图注及§2.3"
              },
              {
                "source_id": "F04",
                "location": "Fig2a"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P003S01(H&E)"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A156-E02-G02",
        "group_pointer": "/evidence_records/1/groups/1",
        "observations": [
          {
            "observation_id": "A156-E02-O02",
            "pointer": "/evidence_records/1/observations/1",
            "figure_panels": [
              "Fig2b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2b/图注及§2.3; p6 §4.7"
              },
              {
                "source_id": "F04",
                "location": "Fig2b"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": {
          "case": "A156-P001 secondary_only_controls",
          "readout": "uncleared perilipin-control LeicaSP8",
          "primary_addition_step_S07": "omitted by secondary-only definition",
          "secondary_identity": "donkeyanti-goatAlexa488",
          "primary_buffer_only_incubation_and_complete_control_timing": "not separately reported; do not infer96h",
          "clearing_steps": "excluded;uncleared"
        }
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A156-E02-G03",
        "group_pointer": "/evidence_records/1/groups/2",
        "observations": [
          {
            "observation_id": "A156-E02-O02",
            "pointer": "/evidence_records/1/observations/1",
            "figure_panels": [
              "Fig2b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2b/图注及§2.3; p6 §4.7"
              },
              {
                "source_id": "F04",
                "location": "Fig2b"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001perilipinmarkingonly+P003S02;noCUBIC;secondaryonlycontrolwhenG02"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A156-E03-G01",
        "group_pointer": "/evidence_records/2/groups/0",
        "observations": [
          {
            "observation_id": "A156-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "Fig2c"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2c/§2.3"
              },
              {
                "source_id": "F04",
                "location": "Fig2c"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": {
          "case": "A156-P001 secondary_only_controls",
          "readout": "cleared TH-control light-sheet",
          "primary_addition_step_S07": "omitted by secondary-only definition",
          "secondary_identity": "donkeyanti-rabbitAlexa568",
          "primary_buffer_only_incubation_and_complete_control_timing": "not separately reported; do not infer96h",
          "clearing_steps": "CUBIC context"
        }
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A156-E03-G02",
        "group_pointer": "/evidence_records/2/groups/1",
        "observations": [
          {
            "observation_id": "A156-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "Fig2c"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2c/§2.3"
              },
              {
                "source_id": "F04",
                "location": "Fig2c"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A156-E03-G03",
        "group_pointer": "/evidence_records/2/groups/2",
        "observations": [
          {
            "observation_id": "A156-E03-O02",
            "pointer": "/evidence_records/2/observations/1",
            "figure_panels": [
              "Fig2d"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2d/§2.3"
              },
              {
                "source_id": "F04",
                "location": "Fig2d"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": {
          "established": "cleared tissue,autofluorescence readout (Fig2d)",
          "clearing_context": "P001 CUBIC reported common method; panel-specific complete history not enumerated",
          "antibody_execution": "TH primary/secondary execution not established for this panel; no binding to P001 S07 or S09",
          "acquisition_context": "paper-wide ZeissZ1 method only; autofluorescence channel and settings not separately reported",
          "not_inherited": [
            "TH-specific primary/secondary",
            "561nm/BP575–615 as confirmed autofluorescence settings"
          ]
        }
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A156-E04-G01",
        "group_pointer": "/evidence_records/3/groups/0",
        "observations": [
          {
            "observation_id": "A156-E04-O01",
            "pointer": "/evidence_records/3/observations/0",
            "figure_panels": [
              "Fig2e"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2e/图注、§2.3; p6 §4.6"
              },
              {
                "source_id": "F04",
                "location": "Fig2e"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P002S01/S02;unclearedG01notP001completeclearing;clearedG02clearinghistoryP001"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A156-E04-G02",
        "group_pointer": "/evidence_records/3/groups/1",
        "observations": [
          {
            "observation_id": "A156-E04-O01",
            "pointer": "/evidence_records/3/observations/0",
            "figure_panels": [
              "Fig2e"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig2e/图注、§2.3; p6 §4.6"
              },
              {
                "source_id": "F04",
                "location": "Fig2e"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P002S01/S02;unclearedG01notP001completeclearing;clearedG02clearinghistoryP001"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A156-E05-G01",
        "group_pointer": "/evidence_records/4/groups/0",
        "observations": [
          {
            "observation_id": "A156-E05-O01",
            "pointer": "/evidence_records/4/observations/0",
            "figure_panels": [
              "Fig3a–f"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p4 Fig3a–f/图注"
              },
              {
                "source_id": "F05",
                "location": "Fig3a–f"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E06",
        "evidence_pointer": "/evidence_records/5",
        "group_id": "A156-E06-G01",
        "group_pointer": "/evidence_records/5/groups/0",
        "observations": [
          {
            "observation_id": "A156-E06-O01",
            "pointer": "/evidence_records/5/observations/0",
            "figure_panels": [
              "Fig3g左"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
              },
              {
                "source_id": "F05",
                "location": "Fig3g左"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O02",
            "pointer": "/evidence_records/5/observations/1",
            "figure_panels": [
              "Fig3g右",
              "全部分布/官方说明"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
              },
              {
                "source_id": "F05",
                "location": "Fig3g右"
              },
              {
                "source_id": "F07",
                "location": "全部分布/官方说明"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O03",
            "pointer": "/evidence_records/5/observations/2",
            "figure_panels": [
              "Subject 1, Area 1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 1, Area 1"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O04",
            "pointer": "/evidence_records/5/observations/3",
            "figure_panels": [
              "Subject 1, Area 2"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 1, Area 2"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O05",
            "pointer": "/evidence_records/5/observations/4",
            "figure_panels": [
              "Subject 1, Area 3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 1, Area 3"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O06",
            "pointer": "/evidence_records/5/observations/5",
            "figure_panels": [
              "Subject 1, Area 4"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 1, Area 4"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E06",
        "evidence_pointer": "/evidence_records/5",
        "group_id": "A156-E06-G02",
        "group_pointer": "/evidence_records/5/groups/1",
        "observations": [
          {
            "observation_id": "A156-E06-O01",
            "pointer": "/evidence_records/5/observations/0",
            "figure_panels": [
              "Fig3g左"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
              },
              {
                "source_id": "F05",
                "location": "Fig3g左"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O02",
            "pointer": "/evidence_records/5/observations/1",
            "figure_panels": [
              "Fig3g右",
              "全部分布/官方说明"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
              },
              {
                "source_id": "F05",
                "location": "Fig3g右"
              },
              {
                "source_id": "F07",
                "location": "全部分布/官方说明"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O07",
            "pointer": "/evidence_records/5/observations/6",
            "figure_panels": [
              "Subject 2, Area 1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 2, Area 1"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O08",
            "pointer": "/evidence_records/5/observations/7",
            "figure_panels": [
              "Subject 2, Area 2"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 2, Area 2"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O09",
            "pointer": "/evidence_records/5/observations/8",
            "figure_panels": [
              "Subject 2, Area 3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 2, Area 3"
              }
            ]
          },
          {
            "observation_id": "A156-E06-O10",
            "pointer": "/evidence_records/5/observations/9",
            "figure_panels": [
              "Subject 2, Area 4"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 §2.4; p6 §4.7"
              },
              {
                "source_id": "F07",
                "location": "Subject 2, Area 4"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A156-E07-G01",
        "group_pointer": "/evidence_records/6/groups/0",
        "observations": [
          {
            "observation_id": "A156-E07-O01",
            "pointer": "/evidence_records/6/observations/0",
            "figure_panels": [
              "全时段25个抽样帧，0–24.5秒；官方说明"
            ],
            "source_refs": [
              {
                "source_id": "F08",
                "location": "全时段25个抽样帧，0–24.5秒；官方说明"
              },
              {
                "source_id": "F01",
                "location": "pp4–5 Discussion中中心信号减弱论述"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
      },
      {
        "core_path": "A156_candidate/A156_evidence.json",
        "evidence_id": "A156-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A156-E07-G02",
        "group_pointer": "/evidence_records/6/groups/1",
        "observations": [
          {
            "observation_id": "A156-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "全时段15个抽样帧，0–9.5秒；官方说明"
            ],
            "source_refs": [
              {
                "source_id": "F09",
                "location": "全时段15个抽样帧，0–9.5秒；官方说明"
              }
            ]
          }
        ],
        "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
        "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
      }
    ],
    "original_mapping": [],
    "status": "no equivalence to lost core asserted",
    "verified_new_result_correspondences": [
      {
        "new_result_id": "A156-R20261012-O06",
        "legacy_observation_ids": [
          "A156-E04-O01"
        ],
        "mapping_type": "panel_and_content_overlap_not_identity_or_hash_restoration",
        "basis": "preserved evidence links and matching source panel/condition"
      },
      {
        "new_result_id": "A156-R20261012-O07",
        "legacy_observation_ids": [
          "A156-E05-O01"
        ],
        "mapping_type": "panel_and_content_overlap_not_identity_or_hash_restoration",
        "basis": "preserved evidence links and matching source panel/condition"
      },
      {
        "new_result_id": "A156-R20261012-O08",
        "legacy_observation_ids": [
          "A156-E06-O01"
        ],
        "mapping_type": "panel_and_content_overlap_not_identity_or_hash_restoration",
        "basis": "preserved evidence links and matching source panel/condition"
      },
      {
        "new_result_id": "A156-R20261012-O09",
        "legacy_observation_ids": [
          "A156-E06-O02"
        ],
        "mapping_type": "panel_and_content_overlap_not_identity_or_hash_restoration",
        "basis": "preserved evidence links and matching source panel/condition"
      },
      {
        "new_result_id": "A156-R20261012-O10",
        "legacy_observation_ids": [
          "A156-E07-O01"
        ],
        "mapping_type": "panel_and_content_overlap_not_identity_or_hash_restoration",
        "basis": "preserved evidence links and matching source panel/condition"
      }
    ],
    "new_question_mapping": "No historical question IDs assigned: old question wording/content was not recovered. New SQ/RQ/GQ is a separate source-scoped answer layer."
  },
  "coverage_dimensions": {
    "historical_review": {
      "status": "inherited_not_reperformed",
      "path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A156/protocol_records.json",
      "sha256": "109fa46785a0578399034decc13c8dfa0d6f0f7a93b71bcbaeee6564f645cc22",
      "pointer": "/baseline",
      "exact_record": {
        "selected_core_files": {
          "evidence_json": {
            "path": "A156_candidate/A156_evidence.json",
            "sha256": "ea741152d196da975e4f2ce3cfd9f07a321838ab3a28411e6acee7b4902f48bb"
          },
          "questions_json": {
            "path": "A156_candidate/A156_questions.json",
            "sha256": "5727d2ab75ab94783aa564d0c7f334ac4f92bfa0385d6f15871c024c2999969a"
          },
          "reading_md": {
            "path": "A156_candidate/A156_reading_zh.md",
            "sha256": "0489a957363e0911b8a168dcad440c3f934d68323f2acff40a0f55a75565eb54"
          }
        },
        "existing_protocol_index": "none",
        "preserved_status": {
          "state": "held_source_reviewed_candidate_pending_specified_review",
          "not_reperformed": "No new scientific acceptance/delivery/count increment",
          "core_status_fields": {
            "record_id_status": "candidate_not_accepted_not_counted",
            "review_status": {
              "same_worker_source_review": "7页正文/图版、3张主图、2补图和2影片全时段抽样已核读；保留13项具体缺项/歧义，未做图形数字化。",
              "independent_review": "completed_verified：来源先行独立审阅覆盖7E/20O/17G/11A/13U/27GQ及66条问题引用；修复S04组织学样本错误继承whole-mount体积范围和GQ08题名，复核后无其余实质修改。",
              "specified_Pro_review": "awaiting_verified_Pro_review; model_identity_unresolved; login_completed",
              "release": "candidate_not_accepted; not_uploaded_not_counted; awaiting_verified_Pro_review; model_identity_unresolved",
              "structural_check": "自编只读776项检查，0错误；7E/20O/17G/11A/13U/27GQ；未运行Skill附带脚本。",
              "independent_structural_check": "独立审阅者自编只读1200项检查，0错误。"
            }
          },
          "local_review_and_scope_records": [
            "A156_candidate/private/independent_audit/independent_review_report.md",
            "A156_candidate/private/independent_audit/main_layout_independent.txt",
            "A156_candidate/private/independent_audit/review_findings.json"
          ]
        },
        "originals_modified": false,
        "acceptance_or_count_changed": false,
        "runtime_integration": false,
        "upload_or_publication": false
      }
    },
    "new_main_text_relationships": "reviewed",
    "fresh_visual_review": "not_performed",
    "specified_Pro_gate": "unchanged_hold",
    "parent_review": "pending",
    "raw_reanalysis": "not_performed_not_required_for_literature_review",
    "new_question_answer_layer": "reconstructed_with_result_group_step_and_uncertainty_links_pending_independent_recheck",
    "targeted_repair_review": "author_targeted_source_check_not_independent_acceptance"
  },
  "sample_count_semantics": {
    "nodes_are": "context_classes_not_individual_specimens",
    "count_nodes_as_n": false,
    "cross_result_individual_overlap": "only_explicit_source_mapping_used"
  },
  "limitations": [
    "All main result panels and reported supplementary limitations are represented; Figure1a/b workflow drawings are not measured experiments.",
    "Fresh source is the published Royal Society PDF served by Cambridge repository; historical visual review remains separately inherited.",
    "Wholemount TH, uncleared perilipin and NBF/H&E branches remain distinct. The split-biopsy histology is not automatically post-clearing histology.",
    "Two subjects, four tissue areas per subject, three technical optical reads and three display planes are separate counting levels.",
    "TH signal is reduced in the sample centre; incomplete penetration and fragile tissue are retained, not described as uniformly complete innervation.",
    "Area changes do not establish volume constancy, and greater transparency does not imply unchanged physical properties.",
    "Approximate 40% transmittance wording is not transformed into exact percentage points or absolute curve values.",
    "All four existing source conflicts retained: overnight versus24h fixation, unusual wt% denominator, unspecified Na chemical identity, and unresolved relative-TH plot scaling.",
    "No lean comparison, weight-loss intervention, fine-needle biopsy validation or human lipolysis causality is claimed."
  ],
  "groups": [
    {
      "group_id": "A156-R20261012-G01",
      "experiment_id": "A156-R20261012-E01",
      "result_ids": [
        "A156-R20261012-O01"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Preparation size/texture and Fig1c clearing series",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S03"
          ],
          "branch_selector": "area photos; cm², not tissue volume",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "phase": "Fig1c clearing observations",
        "days": [
          1,
          3,
          6,
          9,
          12,
          15
        ],
        "relationship_to_operations": "observation days; protocol solution changes remain in P001"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G02",
      "experiment_id": "A156-R20261012-E02",
      "result_ids": [
        "A156-R20261012-O02"
      ],
      "sample_context_id": "A156-R20261012-S02",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Separate neutral-buffered formalin H&E piece",
      "protocol_uses": [
        {
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S01"
          ],
          "branch_selector": "H&E branch only; no post-clearing histology",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "measurement_medium": "not_reported_for_this_panel"
      },
      "source_conflict_ids": [],
      "limitations": [
        "Complete H&E processing/acquisition not reported."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2a; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G03",
      "experiment_id": "A156-R20261012-E03",
      "result_ids": [
        "A156-R20261012-O03"
      ],
      "sample_context_id": "A156-R20261012-S03",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Uncleared perilipin positive",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10"
          ],
          "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "LeicaSP8 uncleared perilipin",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "measurement_medium": "not_reported_for_this_panel"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF03"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G04",
      "experiment_id": "A156-R20261012-E03",
      "result_ids": [
        "A156-R20261012-O03"
      ],
      "sample_context_id": "A156-R20261012-S03",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Uncleared perilipin secondary-only control",
      "protocol_uses": [
        {
          "protocol_id": "A156-P003",
          "step_ids": [
            "A156-P003-S02"
          ],
          "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "measurement_medium": "not_reported_for_this_panel"
      },
      "source_conflict_ids": [],
      "limitations": [
        "Do not assign TH labeling or clearing."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2b; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G05",
      "experiment_id": "A156-R20261012-E04",
      "result_ids": [
        "A156-R20261012-O04"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Cleared TH-primary plus secondary positive",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH light-sheet acquisition and processing",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G06",
      "experiment_id": "A156-R20261012-E04",
      "result_ids": [
        "A156-R20261012-O04"
      ],
      "sample_context_id": "A156-R20261012-S04",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Cleared secondary-only/no-TH control",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "Fig2c control imaging; no invented per-panel settings",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2c; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G07",
      "experiment_id": "A156-R20261012-E05",
      "result_ids": [
        "A156-R20261012-O05"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Cleared tissue autofluorescence Fig2d",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "clearing context only; antibody execution not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S05"
          ],
          "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF02"
      ],
      "limitations": [
        "Autofluorescence channel/acquisition details not separately reported."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2d; Results2.3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G08",
      "experiment_id": "A156-R20261012-E06",
      "result_ids": [
        "A156-R20261012-O06"
      ],
      "sample_context_id": "A156-R20261012-S05",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Uncleared tissue",
      "protocol_uses": [
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Uncleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "measurement_medium": "CUBIC2",
        "phase": "absorbance measurement",
        "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
      },
      "source_conflict_ids": [],
      "limitations": [
        "Biological n and matching to TH donors not established."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G09",
      "experiment_id": "A156-R20261012-E06",
      "result_ids": [
        "A156-R20261012-O06"
      ],
      "sample_context_id": "A156-R20261012-S06",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Cleared tissue",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Cleared tissue",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "measurement_medium": "CUBIC2",
        "phase": "absorbance measurement",
        "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
      },
      "source_conflict_ids": [
        "A156-CF02"
      ],
      "limitations": [
        "Biological n and matching to TH donors not established."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G10",
      "experiment_id": "A156-R20261012-E06",
      "result_ids": [
        "A156-R20261012-O06"
      ],
      "sample_context_id": "A156-R20261012-S07",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Equal-volume CUBIC2 blank",
      "protocol_uses": [
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ],
          "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "measurement_medium": "CUBIC2",
        "phase": "absorbance measurement",
        "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
      },
      "source_conflict_ids": [
        "A156-CF02"
      ],
      "limitations": [
        "Biological n and matching to TH donors not established."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure2e; Results2.3; Methods4.6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "group_id": "A156-R20261012-G11",
      "experiment_id": "A156-R20261012-E07",
      "result_ids": [
        "A156-R20261012-O07"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "TH network Subject1",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3a–f; Results2.4; moviesS1–S2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "donor_id": "A156-R20261012-D01"
    },
    {
      "group_id": "A156-R20261012-G13",
      "experiment_id": "A156-R20261012-E08",
      "result_ids": [
        "A156-R20261012-O08",
        "A156-R20261012-O09"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Subject1, four distinct Z-stack tissue areas",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03",
        "A156-CF04"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "donor_id": "A156-R20261012-D01",
      "area_labels": [
        1,
        2,
        3,
        4
      ],
      "conflict_result_scope": {
        "A156-CF04": [
          "A156-R20261012-O08"
        ]
      }
    },
    {
      "group_id": "A156-R20261012-G12",
      "experiment_id": "A156-R20261012-E07",
      "result_ids": [
        "A156-R20261012-O07"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "TH network Subject2",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "TH wholemount visualization",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3a–f; Results2.4; moviesS1–S2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "donor_id": "A156-R20261012-D02"
    },
    {
      "group_id": "A156-R20261012-G14",
      "experiment_id": "A156-R20261012-E08",
      "result_ids": [
        "A156-R20261012-O08",
        "A156-R20261012-O09"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "Subject2, four distinct Z-stack tissue areas",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ],
          "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03",
        "A156-CF04"
      ],
      "limitations": [],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "donor_id": "A156-R20261012-D02",
      "area_labels": [
        1,
        2,
        3,
        4
      ],
      "conflict_result_scope": {
        "A156-CF04": [
          "A156-R20261012-O08"
        ]
      }
    },
    {
      "group_id": "A156-R20261012-G15",
      "experiment_id": "A156-R20261012-E07",
      "result_ids": [
        "A156-R20261012-O10"
      ],
      "sample_context_id": "A156-R20261012-S01",
      "group_role": "source_scoped_condition_or_sampling_subset_not_extra_independent_experiment",
      "label": "MovieS1 centre-versus-periphery signal report",
      "protocol_uses": [
        {
          "protocol_id": "A156-P001",
          "step_ids": [
            "A156-P001-S01",
            "A156-P001-S02",
            "A156-P001-S03",
            "A156-P001-S04",
            "A156-P001-S05",
            "A156-P001-S06",
            "A156-P001-S07",
            "A156-P001-S08",
            "A156-P001-S09",
            "A156-P001-S10",
            "A156-P001-S11",
            "A156-P001-S12",
            "A156-P001-S13"
          ],
          "branch_selector": "TH positive wholemount",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        },
        {
          "protocol_id": "A156-P002",
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05"
          ],
          "branch_selector": "movieS1 TH rendering",
          "use_status": "reported_branch_with_local_exceptions",
          "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
        }
      ],
      "observation_conditions": {
        "medium": "Reagent2",
        "phase": "imaging"
      },
      "source_conflict_ids": [
        "A156-CF01",
        "A156-CF02",
        "A156-CF03"
      ],
      "limitations": [
        "No exact attenuation ratio, matched penetration experiment or newly replayed video."
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ]
    }
  ],
  "donors": [
    {
      "donor_id": "A156-R20261012-D01",
      "source_subject_label": "Subject 1",
      "sex": "male",
      "age_years": 22,
      "BMI_kg_m2": 40.6,
      "history": "severe childhood obesity",
      "sample_context_id": "A156-R20261012-S01",
      "applies_to_result_ids": [
        "A156-R20261012-O07",
        "A156-R20261012-O08",
        "A156-R20261012-O09"
      ],
      "not_assigned_to": [
        "histology example",
        "optical transmission example",
        "perilipin example"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Methods4.1; Fig3a–g subject labels",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ]
    },
    {
      "donor_id": "A156-R20261012-D02",
      "source_subject_label": "Subject 2",
      "sex": "male",
      "age_years": 24,
      "BMI_kg_m2": 42.7,
      "history": "severe childhood obesity",
      "sample_context_id": "A156-R20261012-S01",
      "applies_to_result_ids": [
        "A156-R20261012-O07",
        "A156-R20261012-O08",
        "A156-R20261012-O09"
      ],
      "not_assigned_to": [
        "histology example",
        "optical transmission example",
        "perilipin example"
      ],
      "source_refs": [
        {
          "source_id": "A156-R20261012-F01",
          "locator": "Methods4.1; Fig3a–g subject labels",
          "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
        }
      ]
    }
  ],
  "questions": [
    {
      "question_id": "A156-R20261012-GQ01",
      "question_type": "result_question",
      "question": "Size and texture during preparation",
      "answer": {
        "statements": [
          {
            "text": "Dehydration reduces area; rehydration restores most original size. Clearing alters shape and produces fragile gel-like consistency. Area observations do not establish volume preservation. During dehydration/rehydration the tissue first became more rigid, then regained its original texture after 1h PBS incubation and subsequent washing, permeabilization and blocking. Fig1c shows a qualitative clearing sequence at days1,3,6,9,12,15; these observation days are not uniform endpoints for every specimen.",
            "reported_values": null,
            "result_ids": [
              "A156-R20261012-O01"
            ],
            "group_ids": [
              "A156-R20261012-G01"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G01",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G01",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S03"
                ],
                "branch_selector": "area photos; cm², not tissue volume",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E01"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ01",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support Size and texture during preparation?",
      "answer": {
        "statements": [
          {
            "text": "Preparation size/texture and Fig1c clearing series",
            "group_ids": [
              "A156-R20261012-G01"
            ],
            "result_ids": [
              "A156-R20261012-O01"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S03"
                ],
                "branch_selector": "area photos; cm², not tissue volume",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "phase": "Fig1c clearing observations",
              "days": [
                1,
                3,
                6,
                9,
                12,
                15
              ],
              "relationship_to_operations": "observation days; protocol solution changes remain in P001"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E01"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ02",
      "question_type": "result_question",
      "question": "Histological preservation",
      "answer": {
        "statements": [
          {
            "text": "H&E shows intact adipocytes with large lipid droplets in the separately fixed piece; no post-clearing H&E comparison is established.",
            "reported_values": null,
            "result_ids": [
              "A156-R20261012-O02"
            ],
            "group_ids": [
              "A156-R20261012-G02"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G02",
                "protocol_id": "A156-P003",
                "step_ids": [
                  "A156-P003-S01"
                ],
                "branch_selector": "H&E branch only; no post-clearing histology",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G02"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2a; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E02"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ02",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support Histological preservation?",
      "answer": {
        "statements": [
          {
            "text": "Separate neutral-buffered formalin H&E piece",
            "group_ids": [
              "A156-R20261012-G02"
            ],
            "result_ids": [
              "A156-R20261012-O02"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P003",
                "step_ids": [
                  "A156-P003-S01"
                ],
                "branch_selector": "H&E branch only; no post-clearing histology",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "measurement_medium": "not_reported_for_this_panel"
            },
            "source_conflict_ids": [],
            "limitations": [
              "Complete H&E processing/acquisition not reported."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2a; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E02"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ03",
      "question_type": "result_question",
      "question": "Uncleared adipocyte labeling",
      "answer": {
        "statements": [
          {
            "text": "Perilipin confocal staining supports adipocyte morphology with secondary-only control; this is not evidence that perilipin survives clearing.",
            "reported_values": null,
            "result_ids": [
              "A156-R20261012-O03"
            ],
            "group_ids": [
              "A156-R20261012-G03",
              "A156-R20261012-G04"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G03",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10"
                ],
                "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G03",
                "protocol_id": "A156-P003",
                "step_ids": [
                  "A156-P003-S02"
                ],
                "branch_selector": "LeicaSP8 uncleared perilipin",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G04",
                "protocol_id": "A156-P003",
                "step_ids": [
                  "A156-P003-S02"
                ],
                "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              },
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G04"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2b; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E03"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ03",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support Uncleared adipocyte labeling?",
      "answer": {
        "statements": [
          {
            "text": "Uncleared perilipin positive",
            "group_ids": [
              "A156-R20261012-G03"
            ],
            "result_ids": [
              "A156-R20261012-O03"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10"
                ],
                "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P003",
                "step_ids": [
                  "A156-P003-S02"
                ],
                "branch_selector": "LeicaSP8 uncleared perilipin",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "measurement_medium": "not_reported_for_this_panel"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF03"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2b; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Uncleared perilipin secondary-only control",
            "group_ids": [
              "A156-R20261012-G04"
            ],
            "result_ids": [
              "A156-R20261012-O03"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P003",
                "step_ids": [
                  "A156-P003-S02"
                ],
                "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "measurement_medium": "not_reported_for_this_panel"
            },
            "source_conflict_ids": [],
            "limitations": [
              "Do not assign TH labeling or clearing."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2b; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E03"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ04",
      "question_type": "result_question",
      "question": "TH labeling specificity context",
      "answer": {
        "statements": [
          {
            "text": "TH-labeled neural arborizations are visible relative to secondary-only control. No complete fiber detection or zero background claim is made.",
            "reported_values": null,
            "result_ids": [
              "A156-R20261012-O04"
            ],
            "group_ids": [
              "A156-R20261012-G05",
              "A156-R20261012-G06"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G05",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G05",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "TH light-sheet acquisition and processing",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G06",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G06",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "Fig2c control imaging; no invented per-panel settings",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2c; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E04"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ04",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support TH labeling specificity context?",
      "answer": {
        "statements": [
          {
            "text": "Cleared TH-primary plus secondary positive",
            "group_ids": [
              "A156-R20261012-G05"
            ],
            "result_ids": [
              "A156-R20261012-O04"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "TH light-sheet acquisition and processing",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2c; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Cleared secondary-only/no-TH control",
            "group_ids": [
              "A156-R20261012-G06"
            ],
            "result_ids": [
              "A156-R20261012-O04"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "Fig2c control imaging; no invented per-panel settings",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2c; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E04"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ05",
      "question_type": "result_question",
      "question": "Autofluorescence architecture",
      "answer": {
        "statements": [
          {
            "text": "Autofluorescence provides tissue architectural context after processing; qualitative appearance does not prove unchanged dimensions.",
            "reported_values": null,
            "result_ids": [
              "A156-R20261012-O05"
            ],
            "group_ids": [
              "A156-R20261012-G07"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G07",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "clearing context only; antibody execution not established",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G07",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S05"
                ],
                "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G07"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2d; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E05"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ05",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support Autofluorescence architecture?",
      "answer": {
        "statements": [
          {
            "text": "Cleared tissue autofluorescence Fig2d",
            "group_ids": [
              "A156-R20261012-G07"
            ],
            "result_ids": [
              "A156-R20261012-O05"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "clearing context only; antibody execution not established",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S05"
                ],
                "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF02"
            ],
            "limitations": [
              "Autofluorescence channel/acquisition details not separately reported."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2d; Results2.3",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E05"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ06",
      "question_type": "result_question",
      "question": "Optical transmittance",
      "answer": {
        "statements": [
          {
            "text": "Clearing increases light transmittance; the approximate reported increase retains the original percentage ambiguity and is not converted to an exact relative gain.",
            "reported_values": {
              "reported_approximate_increase": "about 40%",
              "interpretation": "relative percent versus percentage points not explicitly disambiguated",
              "technical_reads": 3,
              "biological_n": "not established by technical read count",
              "range_nm": [
                400,
                1000
              ],
              "step_nm": 2,
              "normalization": "equal-volume CUBIC2 blank set to 100%; T=10^(-A)"
            },
            "result_ids": [
              "A156-R20261012-O06"
            ],
            "group_ids": [
              "A156-R20261012-G08",
              "A156-R20261012-G09",
              "A156-R20261012-G10"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G08",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S01",
                  "A156-P002-S02"
                ],
                "branch_selector": "optical transmittance Uncleared tissue",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G09",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G09",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S01",
                  "A156-P002-S02"
                ],
                "branch_selector": "optical transmittance Cleared tissue",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G10",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S01",
                  "A156-P002-S02"
                ],
                "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G08"
              },
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G09"
              },
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G10"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2e; Results2.3; Methods4.6",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E06"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ06",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support Optical transmittance?",
      "answer": {
        "statements": [
          {
            "text": "Uncleared tissue",
            "group_ids": [
              "A156-R20261012-G08"
            ],
            "result_ids": [
              "A156-R20261012-O06"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S01",
                  "A156-P002-S02"
                ],
                "branch_selector": "optical transmittance Uncleared tissue",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "measurement_medium": "CUBIC2",
              "phase": "absorbance measurement",
              "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
            },
            "source_conflict_ids": [],
            "limitations": [
              "Biological n and matching to TH donors not established."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2e; Results2.3; Methods4.6",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Cleared tissue",
            "group_ids": [
              "A156-R20261012-G09"
            ],
            "result_ids": [
              "A156-R20261012-O06"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S01",
                  "A156-P002-S02"
                ],
                "branch_selector": "optical transmittance Cleared tissue",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "measurement_medium": "CUBIC2",
              "phase": "absorbance measurement",
              "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
            },
            "source_conflict_ids": [
              "A156-CF02"
            ],
            "limitations": [
              "Biological n and matching to TH donors not established."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2e; Results2.3; Methods4.6",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Equal-volume CUBIC2 blank",
            "group_ids": [
              "A156-R20261012-G10"
            ],
            "result_ids": [
              "A156-R20261012-O06"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S01",
                  "A156-P002-S02"
                ],
                "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "measurement_medium": "CUBIC2",
              "phase": "absorbance measurement",
              "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
            },
            "source_conflict_ids": [
              "A156-CF02"
            ],
            "limitations": [
              "Biological n and matching to TH donors not established."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure2e; Results2.3; Methods4.6",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E06"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ07",
      "question_type": "result_question",
      "question": "Three-dimensional neural network visualization",
      "answer": {
        "statements": [
          {
            "text": "Orthogonal views visualize neural arborizations in two severely obese subjects. Multiple planes and movies do not add subjects; fine-fiber quantification requires higher magnification. Spatial coverage is nonuniform: authors report lower antibody signal at the tissue centre in movieS1/Discussion (separate O10).",
            "reported_values": {
              "subjects": 2,
              "views": [
                "xy",
                "yz",
                "xz"
              ]
            },
            "result_ids": [
              "A156-R20261012-O07"
            ],
            "group_ids": [
              "A156-R20261012-G11",
              "A156-R20261012-G12"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G11",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G11",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "TH wholemount visualization",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G12",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G12",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "TH wholemount visualization",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure3a–f; Results2.4; moviesS1–S2",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Authors report reduced antibody signal in the centre of the adipose biopsy, referring to movieS1. This spatially nonuniform signal is an observation; its cause was not experimentally isolated.",
            "reported_values": null,
            "result_ids": [
              "A156-R20261012-O10"
            ],
            "group_ids": [
              "A156-R20261012-G15"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G15",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G15",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "movieS1 TH rendering",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              },
              {
                "type": "group_limitations",
                "group_id": "A156-R20261012-G15"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
                "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E07"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ07",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support Three-dimensional neural network visualization?",
      "answer": {
        "statements": [
          {
            "text": "TH network Subject1",
            "group_ids": [
              "A156-R20261012-G11"
            ],
            "result_ids": [
              "A156-R20261012-O07"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "TH wholemount visualization",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure3a–f; Results2.4; moviesS1–S2",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "TH network Subject2",
            "group_ids": [
              "A156-R20261012-G12"
            ],
            "result_ids": [
              "A156-R20261012-O07"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "TH wholemount visualization",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure3a–f; Results2.4; moviesS1–S2",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "MovieS1 centre-versus-periphery signal report",
            "group_ids": [
              "A156-R20261012-G15"
            ],
            "result_ids": [
              "A156-R20261012-O10"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05"
                ],
                "branch_selector": "movieS1 TH rendering",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03"
            ],
            "limitations": [
              "No exact attenuation ratio, matched penetration experiment or newly replayed video."
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
                "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E07"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-GQ08",
      "question_type": "result_question",
      "question": "TH fiber volume fraction and surface",
      "answer": {
        "statements": [
          {
            "text": "Segmented TH-object volume divided by total imaged volume, in four areas per subject. Fig3g left summarizes mean±SD across tissue areas; it is not a fiber count. The graph axis scaling remains unresolved.",
            "reported_values": {
              "areas_per_subject": 4,
              "subjects": 2,
              "summary": "mean ± SD across tissue areas",
              "relative_TH_definition": "fiber volume / total imaged volume",
              "minimum_included_object_volume_um3": 600,
              "absolute_graph_values": null,
              "absolute_graph_values_status": "not_redigitized",
              "source_conflict": "A156-CF04"
            },
            "result_ids": [
              "A156-R20261012-O08"
            ],
            "group_ids": [
              "A156-R20261012-G13",
              "A156-R20261012-G14"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G13",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G13",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05",
                  "A156-P002-S06",
                  "A156-P002-S07"
                ],
                "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G14",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G14",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05",
                  "A156-P002-S06",
                  "A156-P002-S07"
                ],
                "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF04"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Fig3g right reports mean fibre surface, with between-subject and between-area variation. Supplementary FigS2 displays separate fiber-surface distributions for four areas in each of two subjects. Numeric graph values were not digitized.",
            "reported_values": {
              "unit": "µm²",
              "unit_basis": "Methods4.7 explicit fibre surface unit; no substitution based on PDF OCR mm²",
              "measured_objects": "segmented TH-positive fibre objects",
              "aggregation": "mean fibre surface for each tissue area; Fig3g mean±SD across 4 tissue areas per subject",
              "subjects": 2,
              "areas_per_subject": 4,
              "surface_algorithm": "not_reported",
              "numeric_values": null,
              "numeric_values_status": "not_digitized",
              "supplementary_distribution_scope": [
                {
                  "subject": 1,
                  "area": 1,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 1,
                  "area": 2,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 1,
                  "area": 3,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 1,
                  "area": 4,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 2,
                  "area": 1,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 2,
                  "area": 2,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 2,
                  "area": 3,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                },
                {
                  "subject": 2,
                  "area": 4,
                  "numeric_range": null,
                  "range_status": "not_digitized"
                }
              ]
            },
            "result_ids": [
              "A156-R20261012-O09"
            ],
            "group_ids": [
              "A156-R20261012-G13",
              "A156-R20261012-G14"
            ],
            "protocol_uses": [
              {
                "group_id": "A156-R20261012-G13",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G13",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05",
                  "A156-P002-S06",
                  "A156-P002-S07"
                ],
                "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G14",
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "group_id": "A156-R20261012-G14",
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05",
                  "A156-P002-S06",
                  "A156-P002-S07"
                ],
                "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "uncertainty_refs": [
              {
                "type": "source_conflict",
                "id": "A156-CF01"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF02"
              },
              {
                "type": "source_conflict",
                "id": "A156-CF03"
              }
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Fig3g right; Methods4.7; Supplementary FigS2 preserved full-page review",
                "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E08"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ08",
      "question_type": "method_and_scope_question",
      "question": "Which actual branches, controls, sampling units and unresolved conditions support TH fiber volume fraction and surface?",
      "answer": {
        "statements": [
          {
            "text": "Subject1, four distinct Z-stack tissue areas",
            "group_ids": [
              "A156-R20261012-G13"
            ],
            "result_ids": [
              "A156-R20261012-O08",
              "A156-R20261012-O09"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05",
                  "A156-P002-S06",
                  "A156-P002-S07"
                ],
                "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03",
              "A156-CF04"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          },
          {
            "text": "Subject2, four distinct Z-stack tissue areas",
            "group_ids": [
              "A156-R20261012-G14"
            ],
            "result_ids": [
              "A156-R20261012-O08",
              "A156-R20261012-O09"
            ],
            "protocol_uses": [
              {
                "protocol_id": "A156-P001",
                "step_ids": [
                  "A156-P001-S01",
                  "A156-P001-S02",
                  "A156-P001-S03",
                  "A156-P001-S04",
                  "A156-P001-S05",
                  "A156-P001-S06",
                  "A156-P001-S07",
                  "A156-P001-S08",
                  "A156-P001-S09",
                  "A156-P001-S10",
                  "A156-P001-S11",
                  "A156-P001-S12",
                  "A156-P001-S13"
                ],
                "branch_selector": "TH positive wholemount",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              },
              {
                "protocol_id": "A156-P002",
                "step_ids": [
                  "A156-P002-S04",
                  "A156-P002-S05",
                  "A156-P002-S06",
                  "A156-P002-S07"
                ],
                "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
                "use_status": "reported_branch_with_local_exceptions",
                "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
              }
            ],
            "observation_conditions": {
              "medium": "Reagent2",
              "phase": "imaging"
            },
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03",
              "A156-CF04"
            ],
            "limitations": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
                "verification": "publisher_text_inspected_20261012"
              }
            ]
          }
        ]
      },
      "experiment_ids": [
        "A156-R20261012-E08"
      ],
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-SQ01",
      "question_type": "study_synthesis",
      "question": "What does this study establish, and what limits its use?",
      "answer": {
        "result_question_ids": [
          "A156-R20261012-GQ01",
          "A156-R20261012-GQ02",
          "A156-R20261012-GQ03",
          "A156-R20261012-GQ04",
          "A156-R20261012-GQ05",
          "A156-R20261012-GQ06",
          "A156-R20261012-GQ07",
          "A156-R20261012-GQ08"
        ],
        "statements": [
          {
            "text": "In abdominal subcutaneous WAT from two men with severe childhood obesity, separately scoped histology/perilipin controls and cleared TH imaging support tissue/nerve visualization, improved transmittance, and volume-fraction/surface readouts. Central antibody signal is reduced, tissue becomes fragile, and fine nerve-fiber quantification was not completed. Optical technical triplicates are separate from two donors with four TH-analysis areas each; the suggested causes and improvements are untested.",
            "result_ids": [
              "A156-R20261012-O01",
              "A156-R20261012-O02",
              "A156-R20261012-O03",
              "A156-R20261012-O04",
              "A156-R20261012-O05",
              "A156-R20261012-O06",
              "A156-R20261012-O07",
              "A156-R20261012-O08",
              "A156-R20261012-O09",
              "A156-R20261012-O10"
            ],
            "group_ids": [
              "A156-R20261012-G01",
              "A156-R20261012-G02",
              "A156-R20261012-G03",
              "A156-R20261012-G04",
              "A156-R20261012-G05",
              "A156-R20261012-G06",
              "A156-R20261012-G07",
              "A156-R20261012-G08",
              "A156-R20261012-G09",
              "A156-R20261012-G10",
              "A156-R20261012-G11",
              "A156-R20261012-G13",
              "A156-R20261012-G12",
              "A156-R20261012-G14",
              "A156-R20261012-G15"
            ],
            "source_conflict_ids": [
              "A156-CF01",
              "A156-CF02",
              "A156-CF03",
              "A156-CF04"
            ],
            "limitations": [
              "All main result panels and reported supplementary limitations are represented; Figure1a/b workflow drawings are not measured experiments.",
              "Fresh source is the published Royal Society PDF served by Cambridge repository; historical visual review remains separately inherited.",
              "Wholemount TH, uncleared perilipin and NBF/H&E branches remain distinct. The split-biopsy histology is not automatically post-clearing histology.",
              "Two subjects, four tissue areas per subject, three technical optical reads and three display planes are separate counting levels.",
              "TH signal is reduced in the sample centre; incomplete penetration and fragile tissue are retained, not described as uniformly complete innervation.",
              "Area changes do not establish volume constancy, and greater transparency does not imply unchanged physical properties.",
              "Approximate 40% transmittance wording is not transformed into exact percentage points or absolute curve values.",
              "All four existing source conflicts retained: overnight versus24h fixation, unusual wt% denominator, unspecified Na chemical identity, and unresolved relative-TH plot scaling.",
              "No lean comparison, weight-loss intervention, fine-needle biopsy validation or human lipolysis causality is claimed."
            ],
            "protocol_group_refs": [
              "A156-R20261012-G01",
              "A156-R20261012-G02",
              "A156-R20261012-G03",
              "A156-R20261012-G04",
              "A156-R20261012-G05",
              "A156-R20261012-G06",
              "A156-R20261012-G07",
              "A156-R20261012-G08",
              "A156-R20261012-G09",
              "A156-R20261012-G10",
              "A156-R20261012-G11",
              "A156-R20261012-G13",
              "A156-R20261012-G12",
              "A156-R20261012-G14",
              "A156-R20261012-G15"
            ]
          }
        ]
      },
      "new_question_not_legacy_restoration": true
    },
    {
      "question_id": "A156-R20261012-RQ99",
      "question_type": "author_interpretation_scope",
      "question": "Which explanations, external comparisons and proposed applications are distinct from observations?",
      "answer": {
        "statements": [
          {
            "text": "Authors propose that incomplete lipid clearing reduces antibody penetration and contributes to central signal loss. This causal explanation was not independently tested.",
            "claim_ids": [
              "A156-R20261012-AX01"
            ],
            "result_ids": [
              "A156-R20261012-O10"
            ],
            "group_ids": [
              "A156-R20261012-G15"
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Discussion",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "evidence_role": "author_hypothesis",
            "limitations": [
              "This statement retains its author interpretation/prospect/external-background role, not an additional validated experiment."
            ]
          },
          {
            "text": "Lean-obese comparison, leptin and weight-loss effects remain proposed future uses.",
            "claim_ids": [
              "A156-R20261012-AX02"
            ],
            "result_ids": [],
            "group_ids": [],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Discussion",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "evidence_role": "author_future_prospect",
            "limitations": [
              "This statement retains its author interpretation/prospect/external-background role, not an additional validated experiment."
            ]
          },
          {
            "text": "Smaller samples and increased antibody concentration are suggested as possible improvements, not demonstrated successful optimizations.",
            "claim_ids": [
              "A156-R20261012-AX03"
            ],
            "result_ids": [
              "A156-R20261012-O10"
            ],
            "group_ids": [
              "A156-R20261012-G15"
            ],
            "source_refs": [
              {
                "source_id": "A156-R20261012-F01",
                "locator": "Discussion pp4–5",
                "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
              }
            ],
            "evidence_role": "author_unvalidated_improvement_suggestion",
            "limitations": [
              "This statement retains its author interpretation/prospect/external-background role, not an additional validated experiment."
            ]
          }
        ]
      },
      "new_question_not_legacy_restoration": true
    }
  ]
}
```

## 完整当前P对象（角色与限制原样保留）

```json

{
  "schema_version": "source_scoped_protocol_records-1.0",
  "paper_id": "A156",
  "title": "Visualization of sympathetic neural innervation in human white adipose tissue",
  "doi": "10.1098/rsob.210345",
  "baseline": {
    "selected_core_files": {
      "evidence_json": {
        "path": "A156_candidate/A156_evidence.json",
        "sha256": "ea741152d196da975e4f2ce3cfd9f07a321838ab3a28411e6acee7b4902f48bb"
      },
      "questions_json": {
        "path": "A156_candidate/A156_questions.json",
        "sha256": "5727d2ab75ab94783aa564d0c7f334ac4f92bfa0385d6f15871c024c2999969a"
      },
      "reading_md": {
        "path": "A156_candidate/A156_reading_zh.md",
        "sha256": "0489a957363e0911b8a168dcad440c3f934d68323f2acff40a0f55a75565eb54"
      }
    },
    "existing_protocol_index": "none",
    "preserved_status": {
      "state": "held_source_reviewed_candidate_pending_specified_review",
      "not_reperformed": "No new scientific acceptance/delivery/count increment",
      "core_status_fields": {
        "record_id_status": "candidate_not_accepted_not_counted",
        "review_status": {
          "same_worker_source_review": "7页正文/图版、3张主图、2补图和2影片全时段抽样已核读；保留13项具体缺项/歧义，未做图形数字化。",
          "independent_review": "completed_verified：来源先行独立审阅覆盖7E/20O/17G/11A/13U/27GQ及66条问题引用；修复S04组织学样本错误继承whole-mount体积范围和GQ08题名，复核后无其余实质修改。",
          "specified_Pro_review": "awaiting_verified_Pro_review; model_identity_unresolved; login_completed",
          "release": "candidate_not_accepted; not_uploaded_not_counted; awaiting_verified_Pro_review; model_identity_unresolved",
          "structural_check": "自编只读776项检查，0错误；7E/20O/17G/11A/13U/27GQ；未运行Skill附带脚本。",
          "independent_structural_check": "独立审阅者自编只读1200项检查，0错误。"
        }
      },
      "local_review_and_scope_records": [
        "A156_candidate/private/independent_audit/independent_review_report.md",
        "A156_candidate/private/independent_audit/main_layout_independent.txt",
        "A156_candidate/private/independent_audit/review_findings.json"
      ]
    },
    "originals_modified": false,
    "acceptance_or_count_changed": false,
    "runtime_integration": false,
    "upload_or_publication": false
  },
  "review_scope": "本轮直接读主文全文Methods/Results/Discussion与图注，目视PDF5/6及Fig1流程图；恢复13步处理、7步读出、2步部分参考，共3条主记录。人类外科活检方法未编入透明化SOP，来源/样本选择保留。 后续完整目视Fig2/3及两张原始补充PDF全页；未数字化。",
  "protocol_records": [
    {
      "record_id": "A156-P001",
      "record_type": "reported_workflow_with_recipe_basis_ambiguities",
      "title": {
        "value": "人白脂肪的整块免疫标记及ScaleCUBIC清除",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.4"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "逐原文恢复已报告方法，并保留清除/未清除、标记/二抗对照和读出支路。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.4"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "两名严重肥胖成年男性；左髂窝皮下脂肪，外科获得约2g材料；与针吸材料的适用性未验证。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.2"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "取得后用PBS洗过的离体组织；Results记dryice上分两块，进入wholemount或10%NBF组织学支路。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp2 §2.1"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "ScaleCUBIC2中用于光片成像的TH标记组织；perilipin未清除支路在清除前分出",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.4"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "Formaldehyde、sucrose、PBS、methanol、ddH2O、H2O2、EDTA、Na(形式未明)、TritonX100、DMSO、glycine、donkeyserum、Tween20、heparin；配方逐步列出",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.4"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "THAB152/二抗A31573或perilipinab61682/二抗A11055；二抗稀释缺失",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.4"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "ScaleCUBIC1/2组成与原wt分母、Quadrol80%限定见步骤11",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFpp5–6 §4.5"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "离体固定与可选保存",
          "steps": [
            {
              "step_id": "A156-P001-S01",
              "display_order": 1,
              "action": {
                "value": "在PBS、formaldehyde和sucrose中固定wholemount支路。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.3"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "solution": {
                  "value": "20ml PBS+4%formaldehyde(FisherChemical)+10%sucrose(Sigma)；%基准未注明",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "container": {
                  "value": "50ml Falcon",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration_methods": {
                  "value": "overnight",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration_results": {
                  "value": "24h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp2 §2.1"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentle shaking",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "ON与24h各自保存，不据Results把Methods精确改成24h。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.3"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P001-S02",
              "display_order": 2,
              "action": {
                "value": "PBS清洗三次，立即继续或按原文限期储存。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.3"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "wash": {
                  "value": "3×5ml PBS;1h each;roomtemperature",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "storage_variant": {
                  "value": "70%ethanol,4°C,maximum1month",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "立即处理与乙醇保存是备选前史，实际各样本选择未知；保存后返回初始缓冲的步骤未另报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.3"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "脱水、漂白与复水",
          "steps": [
            {
              "step_id": "A156-P001-S03",
              "display_order": 3,
              "action": {
                "value": "把固定组织切为原文所述大小，按甲醇梯度脱水。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "reported_piece_size": {
                  "value": "1–2cm³",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "container": {
                  "value": "2ml Eppendorfunlessstatedotherwise",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "volume": {
                  "value": "1.5ml perstep",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "ordered_series": {
                  "value": [
                    "20%methanol/ddH2O30min",
                    "40%30min",
                    "60%30min",
                    "80%30min",
                    "100%30min",
                    "100%30min"
                  ],
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "roomtemperature",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentle shaking",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "原文块容积与2ml管/1.5ml液体适配未解释，不缩改尺寸；百分比基准未明；两个100%段保留。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P001-S04",
              "display_order": 4,
              "action": {
                "value": "以过氧化氢/甲醇漂白液处理。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "volume": {
                  "value": "1.5ml",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "reported_composition": {
                  "value": "5%H2O2 inmethanol；原文配比1volume30%H2O2 in5volumes100%methanol；10mMEDTA",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "pH": {
                  "value": "8",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "pH_adjuster": {
                  "value": "Na（原文未展开其化学形式）",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "48h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentle shaking",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "Na不能擅改为NaOH；配比与终浓度按作者并列，不另算批量体积。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P001-S05",
              "display_order": 5,
              "action": {
                "value": "递减甲醇复水，再以Triton/PBS处理两次。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "volume": {
                  "value": "1.5ml perstep",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "ordered_series": {
                  "value": [
                    "80%methanol/ddH2O30min",
                    "60%30min",
                    "40%30min",
                    "20%30min",
                    "PBS+0.2%TritonX100,1h",
                    "PBS+0.2%TritonX100,1h"
                  ],
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "roomtemperature",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentle shaking",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": null,
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "通透与封闭",
          "steps": [
            {
              "step_id": "A156-P001-S06",
              "display_order": 6,
              "action": {
                "value": "在通透液中旋转孵育，随后转封闭液。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "permeabilization": {
                  "value": "1.5ml PBS+0.2%TritonX100+20%DMSO+0.3Mglycine;37°C48h;gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "blocking": {
                  "value": "1.5ml PBS+0.2%TritonX100+10%DMSO+5%donkeyserum(D9663Sigma);37°C72h;gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "两段合计5days是明确48h+72h处理，不把图日历均分。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "一抗与洗涤",
          "steps": [
            {
              "step_id": "A156-P001-S07",
              "display_order": 7,
              "action": {
                "value": "按真实标记支路选择TH或perilipin一抗。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "TH": {
                  "value": "1:100;MilliporeAB152;原文称anti-rabbitTHantibody",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "perilipin": {
                  "value": "1:500;Abcamab61682;原文称anti-goatperilipinantibody",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "buffer": {
                  "value": "1.5ml PBS+0.2%Tween20+5%DMSO+5%donkeyserum+10µg/mlheparin",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "96h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "TH与perilipin分别配相应二抗，不能默认双染。这里anti-rabbit/anti-goat按原文保存，二抗结合对象在步骤9明确；不将其解释为分子靶标。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P001-S08",
              "display_order": 8,
              "action": {
                "value": "按原文清洗一抗孵育后样本。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "wash": {
                  "value": "5×1.5ml PBS+0.2%Tween20+10µg/mlheparin",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "1h each",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "此段洗涤温度未报，不继承后一次洗涤的RT。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "二抗与洗涤",
          "steps": [
            {
              "step_id": "A156-P001-S09",
              "display_order": 9,
              "action": {
                "value": "用与一抗对应的荧光二抗标记。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "TH_secondary": {
                  "value": "donkeyanti-rabbitAlexa568,InvitrogenA31573",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "perilipin_secondary": {
                  "value": "donkeyanti-goatAlexa488,InvitrogenA11055",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "buffer": {
                  "value": "1.5ml PBS+0.2%Tween20+5%DMSO+5%donkeyserum+10µg/mlheparin",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "96h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "二抗稀释倍数未列，不能继承一抗1:100/1:500；二抗单独对照的全部缓冲孵育细节未另列。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P001-S10",
              "display_order": 10,
              "action": {
                "value": "洗涤后在PBS中待清除。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "wash": {
                  "value": "5times PBS+0.2%Tween20+10µg/mlheparin",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration_temperature": {
                  "value": "2h each,roomtemperature",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "storage": {
                  "value": "1.5ml PBS,4°C,untilclearing",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "末次五洗体积未单独写出，不能把前一次1.5ml当然继承；储存时长未知。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "ScaleCUBIC来源配方",
          "steps": [
            {
              "step_id": "A156-P001-S11",
              "display_order": 11,
              "action": {
                "value": "按各自来源组成分别配制Reagent1和Reagent2，并按所述时限保存；两种清除液不相互混合。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFpp5–6 §4.5"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "reagent1": {
                  "value": "25wt%urea;25wt%Quadrol80%;15wt%TritonX100;ddH2O",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "reagent2": {
                  "value": "25wt%urea;50wt%sucrose;10wt%triethanolamine;ddH2O",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "reported_wt_definition": {
                  "value": "weightofsolute/weightofsolvent×100（原文定义；非通常按总溶液质量分母）",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "reagent_storage": {
                  "value": "roomtemperature,maximum1month",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "不转换为常规w/w；Quadrol80%是原产品描述与25wt%并列，不推算活性Quadrol最终百分比。未报加料顺序/最终批量/调pH。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFpp5–6 §4.5"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "ScaleCUBIC来源流程",
          "steps": [
            {
              "step_id": "A156-P001-S12",
              "display_order": 12,
              "action": {
                "value": "以半浓度Reagent1预处理，再以原Reagent1清除至透明；按规定换液。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFpp5–6 §4.5"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "container": {
                  "value": "2ml Eppendorf",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "first": {
                  "value": "1.5ml1:1Reagent1/ddH2O;37°C3–6h;gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "second": {
                  "value": "1.5mlReagent1;37°C8–15days;gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "replacement": {
                  "value": "refresheveryseconddayuntiltissuelookedclear",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "8–15days与每2日换液为实际条件；Fig1c照片日1/3/6/9/12/15不生成额外处理配置。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFpp5–6 §4.5"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P001-S13",
              "display_order": 13,
              "action": {
                "value": "转半浓度Reagent2/PBS，再转Reagent2进行RI匹配至成像。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFpp5–6 §4.5"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "first": {
                  "value": "1.5ml1:1Reagent2/PBS;37°C3–6h;gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "second": {
                  "value": "1.5mlReagent2;37°C72h;gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFpp5–6 §4.5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "Reagent1稀释液是ddH2O，Reagent2稀释液是PBS，不能统一。原文untilimaged不支持额外长期保存时长。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFpp5–6 §4.5"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [
        {
          "case_id": "TH_cleared",
          "description": {
            "value": "TH→donkeyanti-rabbitAlexa568；进入ScaleCUBIC并光片成像。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp5 §4.4"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "evidence_ids": [
            "A156-E03",
            "A156-E05",
            "A156-E06",
            "A156-E07"
          ]
        },
        {
          "case_id": "perilipin_uncleared",
          "description": {
            "value": "perilipin→donkeyanti-goatAlexa488；§4.7明确在未清除组织用LeicaSP8成像；不应用S11–13清除。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.7"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "evidence_ids": [
            "A156-E02"
          ]
        },
        {
          "case_id": "secondary_only_controls",
          "description": {
            "value": "Fig2b/c分别为perilipin和TH相应二抗单独对照，原文未另给各阴性对照完整孵育时间。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.7"
              },
              {
                "source_id": "F01",
                "locator": "PDFp3 §2.3 and Fig2b/c caption"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "primary_antibody": "omitted_as_control",
          "remaining_actual_timing": "notseparatelyreported"
        }
      ],
      "reported_precedence": [
        "S01→S02→S03→S04→S05→S06→S07→S08→S09→S10；TH清除支路随后S12→S13；S11是清除液配制/保存定义，不强制在处理第11时才配。",
        "perilipin未清除支路在清除前分出；negativecontrols不凭正样本时程补全部具体值。"
      ],
      "missing_information": [
        "ON vs24h固定差异，实际各样本取值未明。",
        "Na化学形式、wt%分母异常、Quadrol80%25wt%含义及批量配制细节未解决。",
        "二抗稀释，一抗后洗涤温度、末五洗体积和control完整时程未报。",
        "1–2cm³块与2ml管/1.5ml液的适配未解释，不擅改。"
      ],
      "source_conflicts": [],
      "preparation_and_warnings": [
        {
          "value": "作者报告清除后组织fragile且难处理；此为处理限制，不代表已证实所有试剂non-hazardous。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFpp4–5 Discussion"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "review_status": "source_checked_direct_scope;independent_audit_pending"
    },
    {
      "record_id": "A156-P002",
      "record_type": "reported_imaging_and_analysis_with_explicit_metric_gaps",
      "title": {
        "value": "脂肪清除前后光学/面积读出和TH三维定量",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "逐原文恢复已报告方法，并保留清除/未清除、标记/二抗对照和读出支路。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "未清除/清除同类脂肪以及清除TH组；读出按各自模态绑定",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "固定/标记/清除到指定阶段的组织",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "透射率、二维面积、三维TH对象体积比例与表面输出",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "100µlScaleCUBIC2；96孔板；SparkM10；ImageJ",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.6"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "ZeissZ1；胶/注射器；Reagent2；ZENblack/Arivis/Fiji/ZENlite/Prism7",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "透射率读出",
          "steps": [
            {
              "step_id": "A156-P002-S01",
              "display_order": 1,
              "action": {
                "value": "将未清除和清除组织各置于CUBIC2中作光吸收光谱读数。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.6"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "medium_volume": {
                  "value": "100µlCUBIC2",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "plate": {
                  "value": "96wellclear-bottomed(Greiner)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "reader": {
                  "value": "SparkM10(Tecan)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "wavelength": {
                  "value": "400–1000nm,every2nm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "blank": {
                  "value": "equalvolumeCUBIC2insame96wellplates",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "未清除组此处也浸在CUBIC2测量介质中，不据此改成经历完整清除。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.6"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P002-S02",
              "display_order": 2,
              "action": {
                "value": "由吸收计算透射率，按空白与同一组织的三次测量归一/汇总。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.6"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "formula": {
                  "value": "T=10^(−A)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "repeats": {
                  "value": "3individualmeasurementsofsametissue",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "reported_output": {
                  "value": "percentagetransmittancenormalizedtoblank=100%",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "作者未详细说明空白是先扣吸光度或后以透射率比校正，不添加未经给出的计算先后；约40%提高是结果并非处理阈值。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.6"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "二维面积读出",
          "steps": [
            {
              "step_id": "A156-P002-S03",
              "display_order": 3,
              "action": {
                "value": "以照片1cm比例尺设标定，沿组织轮廓选择面积并量测。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.6"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "software": {
                  "value": "ImageJ",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "scale": {
                  "value": "1cmbar",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "selection": {
                  "value": "tissueperimeter,areaselectiontool",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "output_unit": {
                  "value": "cm²",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "time_scope": {
                  "value": "before/during/afterdehydration,rehydrationandclearing",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "测的是照片二维面积，不是体积；S1曲线点未逐个绑定某固定液步骤时点。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.6"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "TH光片采集",
          "steps": [
            {
              "step_id": "A156-P002-S04",
              "display_order": 4,
              "action": {
                "value": "以胶固定在注射器边缘，置入充Reagent2的成像室，用ZeissZ1采集TH通道。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "mounting": {
                  "value": "glueat edgeofsyringe;avoidbubbleformation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "immersion": {
                  "value": "ScaleCUBIC2",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "illumination": {
                  "value": "singleordual-side",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "objective": {
                  "value": "ECPlan-Neofluar5×/0.16Air",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "excitation": {
                  "value": "561nm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "emission": {
                  "value": "BP575–615nm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "software": {
                  "value": "ZENblack2014SP1v9.2.6.54",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "单/双侧为原文备选设置，具体面板选择未给；不得继承给LeicaSP8的perilipin。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "拼接和显示",
          "steps": [
            {
              "step_id": "A156-P002-S05",
              "display_order": 5,
              "action": {
                "value": "以Arivis拼接，再以Fiji/ZENlite进行后续图像处理。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "stitching": {
                  "value": "Arivis",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "further_processing": {
                  "value": "FijiandZENlite",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "未给z-step、功率、曝光、拼接容差或显示窗口；影片为固定重建展示。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "TH对象定量",
          "steps": [
            {
              "step_id": "A156-P002-S06",
              "display_order": 6,
              "action": {
                "value": "每供者取4个Z-stack区域，ArivisVision4D以blobfinder及阈值/分割/拆分敏感度识别纤维对象并求体积。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "software": {
                  "value": "ArivisVision4D",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "regions": {
                  "value": "4Z-stackareaspersubject",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "segmentation": {
                  "value": "blobfinderdiameter,threshold,objectsegmentationandsplittingsensitivity",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "exclusion": {
                  "value": "fibrevolume<600µm³excluded",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "volume": {
                  "value": "sumvolumeofidentifiedobjects,µm³",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "4区域嵌套供者；实际ROI选法、尺寸、阈值和拆分数值未报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A156-P002-S07",
              "display_order": 7,
              "action": {
                "value": "计算TH对象体积占总体积的比，保存纤维表面读出并绘图。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "relative_fibres_definition": {
                  "value": "fibrevolume(µm³)/totalvolume(µm³)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "fibre_surface": {
                  "value": "ArivisVision4D,µm²（具体surfaceestimator未述）",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "tissue_surface_area": {
                  "value": "ImageJ(Fiji),µm²",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "graphing": {
                  "value": "Prism7",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "summary_display": {
                  "value": "Fig.3g: n=4 tissue areas, mean±standard deviation；区域嵌套供者。",
                  "source_raw": "n=4 tissue areas,mean±standard deviation(error bars)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp4 Fig3 caption"
                    },
                    {
                      "source_id": "F05",
                      "locator": "Fig3g original image"
                    }
                  ],
                  "check_status": "verified_against_primary_source_and_figure"
                }
              },
              "notes": {
                "value": "Fig3g无百分号且部分点>1，图示缩放未明；数学体积比定义不能无条件当图示原始数值或擅乘100。tissuesurfacearea与fibresurface不合并。 TH相对比例按纤维总体积/组织总体积定义，不是纤维条数。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [
        {
          "case_id": "transmittance",
          "description": {
            "value": "只属于E04，对未清除/清除测量条件都保留CUBIC2介质。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.6"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "step_ids": [
            "A156-P002-S01",
            "A156-P002-S02"
          ]
        },
        {
          "case_id": "area",
          "description": {
            "value": "E01阶段照片二维面积。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.6"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "step_ids": [
            "A156-P002-S03"
          ]
        },
        {
          "case_id": "TH_imaging_quant",
          "description": {
            "value": "清除TH体数据光片/对象定量；不含未清除perilipin。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp6 §4.7"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "step_ids": [
            "A156-P002-S04",
            "A156-P002-S05",
            "A156-P002-S06",
            "A156-P002-S07"
          ]
        }
      ],
      "reported_precedence": [
        "透射率S01→S02；面积S03为独立读出；TH成像S04→S05→S06→S07。"
      ],
      "missing_information": [
        "空白归一化计算先后未报；不得发明精确算法流程。",
        "各图采集/ROI/分割具体设置和表面积算法缺失；relativeTHfibres轴缩放未明。"
      ],
      "source_conflicts": [],
      "preparation_and_warnings": [],
      "review_status": "source_checked_direct_scope;independent_audit_pending"
    },
    {
      "record_id": "A156-P003",
      "record_type": "partial_reference_branches_not_complete_histologySOP",
      "title": {
        "value": "未清除perilipin共聚焦与H&E组织学方法入口",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.3"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "逐原文恢复已报告方法，并保留清除/未清除、标记/二抗对照和读出支路。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.3"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "未清除perilipin组织与独立10%NBF固定组织学分支",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.3"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "分流的脂肪标本",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.3"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "未清除perilipin形态图或H&E切片图",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp5 §4.3"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "10%NBF；25mlpot",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp5 §4.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "LeicaSP8；perilipin分支标记",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp6 §4.7"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "H&E支路",
          "steps": [
            {
              "step_id": "A156-P003-S01",
              "display_order": 1,
              "action": {
                "value": "H&E用脂肪支路以中性缓冲formalin固定，保留为组织学方法入口。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.3"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "fixative": {
                  "value": "10%NBF",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "container": {
                  "value": "25mlhistologypot",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "roomtemperature",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "untilfurtherprocessing",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp5 §4.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "切片厚度、包埋、H&E染色时程与设备未报；不能由图片补完整组织学流程。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp5 §4.3"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "未清除perilipin支路",
          "steps": [
            {
              "step_id": "A156-P003-S02",
              "display_order": 2,
              "action": {
                "value": "以LeicaSP8对未清除perilipin标记组织成像；二抗单独对照分别保留。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "microscope": {
                  "value": "LeicaSP8confocal",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "signal": {
                  "value": "perilipin/Alexa488versussecondaryonly",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp6 §4.7"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "继承P001perilipin标记身份，未透明化；共聚焦物镜/激发/检测/z-step未报，不采用TH光片561/BP575–615。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp6 §4.7"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [],
      "reported_precedence": [
        "两支路互相独立，不串行。"
      ],
      "missing_information": [
        "H&E完整制备和图像采集未報；perilipin共聚焦详细采集未報。"
      ],
      "source_conflicts": [],
      "preparation_and_warnings": [],
      "review_status": "source_checked_direct_scope;independent_audit_pending"
    }
  ],
  "legacy_mapping": [],
  "source_conflicts": [
    {
      "id": "A156-CF01",
      "topic": "fixationduration",
      "values": [
        "MethodsON4°C",
        "Results24h4°C"
      ],
      "actual": "notresolved"
    },
    {
      "id": "A156-CF02",
      "topic": "recipebasis",
      "detail": "wt%=solute/solvent×100按原文保留，与常规总溶液分母不同；不直接给批量称量表。"
    },
    {
      "id": "A156-CF03",
      "topic": "Na",
      "detail": "漂白液pH8调节试剂只写Na，化学形式未知；不替换NaOH。"
    },
    {
      "id": "A156-CF04",
      "topic": "relativefibresplot",
      "detail": "定义体积比，图轴缩放未知；保存定义与旧O限制，不更正结果。",
      "source_refs": [
        {
          "source_id": "F01",
          "locator": "PDFp6 §4.7 ratio definition"
        },
        {
          "source_id": "F05",
          "locator": "Fig3g left axis and dots"
        }
      ]
    }
  ],
  "remaining_unreviewed": [
    "外引Jiang/Susaki原文未扩大恢复；使用本文已明示改编步骤，pH/配方疑点保留。",
    "两段影片未重新解码或逐帧阅，原始Z-stack/逐ROI数表未取得。",
    "活检手术细节位于原文§4.2，本轮起点为离体标本，不将其重编为新的临床操作指导。"
  ],
  "missing_content_register": [
    {
      "record_id": "A156-P001",
      "missing": [
        "ON vs24h固定差异，实际各样本取值未明。",
        "Na化学形式、wt%分母异常、Quadrol80%25wt%含义及批量配制细节未解决。",
        "二抗稀释，一抗后洗涤温度、末五洗体积和control完整时程未报。",
        "1–2cm³块与2ml管/1.5ml液的适配未解释，不擅改。"
      ]
    },
    {
      "record_id": "A156-P002",
      "missing": [
        "空白归一化计算先后未报；不得发明精确算法流程。",
        "各图采集/ROI/分割具体设置和表面积算法缺失；relativeTHfibres轴缩放未明。"
      ]
    },
    {
      "record_id": "A156-P003",
      "missing": [
        "H&E完整制备和图像采集未報；perilipin共聚焦详细采集未報。"
      ]
    }
  ],
  "observation_conditions": [
    "可选70%ethanol4°C最长1month保存是来源已报告前史，不作为每样本必做。",
    "抗体后PBS4°C至清除为持续储存，时长未定。",
    "Fig1c清除day1/3/6/9/12/15是观察日，不复制成6个清除P，也不把Fig1bday0–30总示意按比例分配操作小时。"
  ],
  "evidence_links": [
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A156-E01-G01",
      "group_pointer": "/evidence_records/0/groups/0",
      "observations": [
        {
          "observation_id": "A156-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "全页照片及面积图"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p2 §2.1; p3 §2.2; p6 §4.6"
            },
            {
              "source_id": "F06",
              "location": "全页照片及面积图"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A156-E01-G02",
      "group_pointer": "/evidence_records/0/groups/1",
      "observations": [
        {
          "observation_id": "A156-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "全页照片及面积图"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p2 §2.1; p3 §2.2; p6 §4.6"
            },
            {
              "source_id": "F06",
              "location": "全页照片及面积图"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A156-E01-G03",
      "group_pointer": "/evidence_records/0/groups/2",
      "observations": [
        {
          "observation_id": "A156-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "全页照片及面积图"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p2 §2.1; p3 §2.2; p6 §4.6"
            },
            {
              "source_id": "F06",
              "location": "全页照片及面积图"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A156-E01-G04",
      "group_pointer": "/evidence_records/0/groups/3",
      "observations": [
        {
          "observation_id": "A156-E01-O01",
          "pointer": "/evidence_records/0/observations/0",
          "figure_panels": [
            "Fig1c"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p2 Fig1c/图注; p3 §2.2"
            },
            {
              "source_id": "F03",
              "location": "Fig1c"
            }
          ]
        },
        {
          "observation_id": "A156-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "全页照片及面积图"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p2 §2.1; p3 §2.2; p6 §4.6"
            },
            {
              "source_id": "F06",
              "location": "全页照片及面积图"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001对应实际处理阶段；P002S03面积；宏观照片不继承光片设置。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A156-E02-G01",
      "group_pointer": "/evidence_records/1/groups/0",
      "observations": [
        {
          "observation_id": "A156-E02-O01",
          "pointer": "/evidence_records/1/observations/0",
          "figure_panels": [
            "Fig2a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2a/图注及§2.3"
            },
            {
              "source_id": "F04",
              "location": "Fig2a"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P003S01(H&E)"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A156-E02-G02",
      "group_pointer": "/evidence_records/1/groups/1",
      "observations": [
        {
          "observation_id": "A156-E02-O02",
          "pointer": "/evidence_records/1/observations/1",
          "figure_panels": [
            "Fig2b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2b/图注及§2.3; p6 §4.7"
            },
            {
              "source_id": "F04",
              "location": "Fig2b"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": {
        "case": "A156-P001 secondary_only_controls",
        "readout": "uncleared perilipin-control LeicaSP8",
        "primary_addition_step_S07": "omitted by secondary-only definition",
        "secondary_identity": "donkeyanti-goatAlexa488",
        "primary_buffer_only_incubation_and_complete_control_timing": "not separately reported; do not infer96h",
        "clearing_steps": "excluded;uncleared"
      }
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A156-E02-G03",
      "group_pointer": "/evidence_records/1/groups/2",
      "observations": [
        {
          "observation_id": "A156-E02-O02",
          "pointer": "/evidence_records/1/observations/1",
          "figure_panels": [
            "Fig2b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2b/图注及§2.3; p6 §4.7"
            },
            {
              "source_id": "F04",
              "location": "Fig2b"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001perilipinmarkingonly+P003S02;noCUBIC;secondaryonlycontrolwhenG02"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A156-E03-G01",
      "group_pointer": "/evidence_records/2/groups/0",
      "observations": [
        {
          "observation_id": "A156-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "Fig2c"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2c/§2.3"
            },
            {
              "source_id": "F04",
              "location": "Fig2c"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": {
        "case": "A156-P001 secondary_only_controls",
        "readout": "cleared TH-control light-sheet",
        "primary_addition_step_S07": "omitted by secondary-only definition",
        "secondary_identity": "donkeyanti-rabbitAlexa568",
        "primary_buffer_only_incubation_and_complete_control_timing": "not separately reported; do not infer96h",
        "clearing_steps": "CUBIC context"
      }
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A156-E03-G02",
      "group_pointer": "/evidence_records/2/groups/1",
      "observations": [
        {
          "observation_id": "A156-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "Fig2c"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2c/§2.3"
            },
            {
              "source_id": "F04",
              "location": "Fig2c"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A156-E03-G03",
      "group_pointer": "/evidence_records/2/groups/2",
      "observations": [
        {
          "observation_id": "A156-E03-O02",
          "pointer": "/evidence_records/2/observations/1",
          "figure_panels": [
            "Fig2d"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2d/§2.3"
            },
            {
              "source_id": "F04",
              "location": "Fig2d"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": {
        "established": "cleared tissue,autofluorescence readout (Fig2d)",
        "clearing_context": "P001 CUBIC reported common method; panel-specific complete history not enumerated",
        "antibody_execution": "TH primary/secondary execution not established for this panel; no binding to P001 S07 or S09",
        "acquisition_context": "paper-wide ZeissZ1 method only; autofluorescence channel and settings not separately reported",
        "not_inherited": [
          "TH-specific primary/secondary",
          "561nm/BP575–615 as confirmed autofluorescence settings"
        ]
      }
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A156-E04-G01",
      "group_pointer": "/evidence_records/3/groups/0",
      "observations": [
        {
          "observation_id": "A156-E04-O01",
          "pointer": "/evidence_records/3/observations/0",
          "figure_panels": [
            "Fig2e"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2e/图注、§2.3; p6 §4.6"
            },
            {
              "source_id": "F04",
              "location": "Fig2e"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P002S01/S02;unclearedG01notP001completeclearing;clearedG02clearinghistoryP001"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A156-E04-G02",
      "group_pointer": "/evidence_records/3/groups/1",
      "observations": [
        {
          "observation_id": "A156-E04-O01",
          "pointer": "/evidence_records/3/observations/0",
          "figure_panels": [
            "Fig2e"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig2e/图注、§2.3; p6 §4.6"
            },
            {
              "source_id": "F04",
              "location": "Fig2e"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P002S01/S02;unclearedG01notP001completeclearing;clearedG02clearinghistoryP001"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A156-E05-G01",
      "group_pointer": "/evidence_records/4/groups/0",
      "observations": [
        {
          "observation_id": "A156-E05-O01",
          "pointer": "/evidence_records/4/observations/0",
          "figure_panels": [
            "Fig3a–f"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p4 Fig3a–f/图注"
            },
            {
              "source_id": "F05",
              "location": "Fig3a–f"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E06",
      "evidence_pointer": "/evidence_records/5",
      "group_id": "A156-E06-G01",
      "group_pointer": "/evidence_records/5/groups/0",
      "observations": [
        {
          "observation_id": "A156-E06-O01",
          "pointer": "/evidence_records/5/observations/0",
          "figure_panels": [
            "Fig3g左"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
            },
            {
              "source_id": "F05",
              "location": "Fig3g左"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O02",
          "pointer": "/evidence_records/5/observations/1",
          "figure_panels": [
            "Fig3g右",
            "全部分布/官方说明"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
            },
            {
              "source_id": "F05",
              "location": "Fig3g右"
            },
            {
              "source_id": "F07",
              "location": "全部分布/官方说明"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O03",
          "pointer": "/evidence_records/5/observations/2",
          "figure_panels": [
            "Subject 1, Area 1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 1, Area 1"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O04",
          "pointer": "/evidence_records/5/observations/3",
          "figure_panels": [
            "Subject 1, Area 2"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 1, Area 2"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O05",
          "pointer": "/evidence_records/5/observations/4",
          "figure_panels": [
            "Subject 1, Area 3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 1, Area 3"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O06",
          "pointer": "/evidence_records/5/observations/5",
          "figure_panels": [
            "Subject 1, Area 4"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 1, Area 4"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E06",
      "evidence_pointer": "/evidence_records/5",
      "group_id": "A156-E06-G02",
      "group_pointer": "/evidence_records/5/groups/1",
      "observations": [
        {
          "observation_id": "A156-E06-O01",
          "pointer": "/evidence_records/5/observations/0",
          "figure_panels": [
            "Fig3g左"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
            },
            {
              "source_id": "F05",
              "location": "Fig3g左"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O02",
          "pointer": "/evidence_records/5/observations/1",
          "figure_panels": [
            "Fig3g右",
            "全部分布/官方说明"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p4 Fig3g/图注; p6 §4.7"
            },
            {
              "source_id": "F05",
              "location": "Fig3g右"
            },
            {
              "source_id": "F07",
              "location": "全部分布/官方说明"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O07",
          "pointer": "/evidence_records/5/observations/6",
          "figure_panels": [
            "Subject 2, Area 1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 2, Area 1"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O08",
          "pointer": "/evidence_records/5/observations/7",
          "figure_panels": [
            "Subject 2, Area 2"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 2, Area 2"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O09",
          "pointer": "/evidence_records/5/observations/8",
          "figure_panels": [
            "Subject 2, Area 3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 2, Area 3"
            }
          ]
        },
        {
          "observation_id": "A156-E06-O10",
          "pointer": "/evidence_records/5/observations/9",
          "figure_panels": [
            "Subject 2, Area 4"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 §2.4; p6 §4.7"
            },
            {
              "source_id": "F07",
              "location": "Subject 2, Area 4"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A156-E07-G01",
      "group_pointer": "/evidence_records/6/groups/0",
      "observations": [
        {
          "observation_id": "A156-E07-O01",
          "pointer": "/evidence_records/6/observations/0",
          "figure_panels": [
            "全时段25个抽样帧，0–24.5秒；官方说明"
          ],
          "source_refs": [
            {
              "source_id": "F08",
              "location": "全时段25个抽样帧，0–24.5秒；官方说明"
            },
            {
              "source_id": "F01",
              "location": "pp4–5 Discussion中中心信号减弱论述"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
    },
    {
      "core_path": "A156_candidate/A156_evidence.json",
      "evidence_id": "A156-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A156-E07-G02",
      "group_pointer": "/evidence_records/6/groups/1",
      "observations": [
        {
          "observation_id": "A156-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "全时段15个抽样帧，0–9.5秒；官方说明"
          ],
          "source_refs": [
            {
              "source_id": "F09",
              "location": "全时段15个抽样帧，0–9.5秒；官方说明"
            }
          ]
        }
      ],
      "binding_basis": "按标记/清除状态/读出精确匹配；paperwide共同方法不覆盖局部例外。",
      "protocol_binding": "P001TH/CUBIC+P002THimaging；Gsecondaryonly保留该阴性对照，Gautofluorescence不宣称THspecificsignal；quant仅E06。"
    }
  ],
  "sources": [
    {
      "source_id": "F01",
      "path": "candidate_research_next_20261008f/PMC8924755/originals/PMC8924755.1.pdf",
      "sha256": "5af57716ba0fcf5fa0b07e3340f22eb09da9162331c703b15c7c2f9d24d319cb",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/",
      "this_round_read": "fulltext/p5–6visual"
    },
    {
      "source_id": "F02",
      "path": "candidate_research_next_20261008f/PMC8924755/originals/PMC8924755.1.xml",
      "sha256": "6d70860b5f44a70d70102b482abb89350355af2de5df0bc0d37f87ad79dd8e41",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/",
      "this_round_read": "fulltext/p5–6visual"
    },
    {
      "source_id": "F03",
      "path": "candidate_research_next_20261008f/PMC8924755/originals/rsob210345f01.jpg",
      "sha256": "01e51b9e76718a8aeb40948148607615cbcc505407cb00435e036ee345f626d9",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/figure/RSOB210345F1/",
      "this_round_read": "Fig1fullvisual"
    },
    {
      "source_id": "F04",
      "path": "candidate_research_next_20261008f/PMC8924755/originals/rsob210345f02.jpg",
      "sha256": "be878a859e32d5dac118cfc78f5b1b147859d8065d33a664ffba503891bc66f4",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/figure/RSOB210345F2/",
      "this_round_read": "本轮目视原始Fig2/3全图；核模态、对照、轴与n/mean±SD图注，不数字化。"
    },
    {
      "source_id": "F05",
      "path": "candidate_research_next_20261008f/PMC8924755/originals/rsob210345f03.jpg",
      "sha256": "8973f09a295e8e5afd34122b95ffb54290fe40c893a4994a1951e6c7264b0464",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8924755/figure/RSOB210345F3/",
      "this_round_read": "本轮目视原始Fig2/3全图；核模态、对照、轴与n/mean±SD图注，不数字化。"
    },
    {
      "source_id": "F06",
      "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_001.pdf",
      "sha256": "5fa9e7b5770e22b461301e0c4c623df4f4138929172096728056b2fe5b2d33b5",
      "url": "https://doi.org/10.6084/m9.figshare.19311973.v1",
      "this_round_read": "原始PDF单页完整渲染目视；S1阶段/面积、S2八个对象表面分布；不重建原始数值。"
    },
    {
      "source_id": "F07",
      "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_002.pdf",
      "sha256": "c2a529581e0c6c42e8aba0b251f2089e8128a9ba56f25a30416b4363a9f7e9e5",
      "url": "https://doi.org/10.6084/m9.figshare.19311964.v1",
      "this_round_read": "原始PDF单页完整渲染目视；S1阶段/面积、S2八个对象表面分布；不重建原始数值。"
    },
    {
      "source_id": "F08",
      "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_003.mp4",
      "sha256": "a1a33ff5c14113352e18ec2b25ad205d08389fb66d855e1cf5d73b1a045cf977",
      "url": "https://doi.org/10.6084/m9.figshare.19311970.v1",
      "this_round_read": "maincaptiononly;originalnotnewlyviewed"
    },
    {
      "source_id": "F09",
      "path": "candidate_research_next_20261008f/PMC8924755/figshare/originals/rsob210345_si_004.mp4",
      "sha256": "7cf73502ffc4fefd70fd650d01834e39d532c2ab43c482b38089774b1712120b",
      "url": "https://doi.org/10.6084/m9.figshare.19311967.v1",
      "this_round_read": "maincaptiononly;originalnotnewlyviewed"
    }
  ],
  "review_status": {
    "source_content": "savedwithgaps",
    "independent_audit": "pending",
    "specified_Pro": "unchanged_hold",
    "actual_execution": "notperformed"
  },
  "source_field_check_count": 166,
  "recovery_current_scope_20261010": {
    "paper_id": "A156",
    "recovery_date": "2026-10-10",
    "input_selected": "checkpoint_recovery_20261010/extracted/checkpoint/full_corpus_sources/objects/9c211420228cecc29bf115d87617601206607a4156578c64f030a8a2bb7adb8d.json",
    "input_sha256": "9c211420228cecc29bf115d87617601206607a4156578c64f030a8a2bb7adb8d",
    "layer": "recovered_current_scope_without_new_primary_source_verification",
    "historical_review_and_acceptance_preserved": true,
    "original_review_scope_and_check_status_semantics": "Inherited checkpoint declarations; not claims made by this recovery pass.",
    "current_work": "Inspected embedded source_raw excerpts for named issues and made only explicitly supported internal-consistency repairs. Field inventory is mechanical enumeration, not a reconstructed full scientific audit.",
    "new_primary_source_verified_fields": 0,
    "targeted_internal_checks": {
      "/protocol_records/1/sections/0/steps/1/parameters/repeats": "现存§4.6摘录明确同一组织三次individual measurements。",
      "/protocol_records/1/sections/1/steps/0/action": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/1/steps/0/parameters/software": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/1/steps/0/parameters/scale": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/1/steps/0/parameters/selection": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/1/steps/0/parameters/output_unit": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/1/steps/0/parameters/time_scope": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/1/steps/0/notes": "§4.6对应读出为ImageJ轮廓面积cm²，不证明体积变化。",
      "/protocol_records/1/sections/4/steps/1/notes": "§4.7明确体积除以总体积；未重测Fig3g。"
    },
    "prior_verified_scope_recovered_from_parent": [
      "三次透射率读数来自同一组织，不等同2供体×4区域的TH分析单位。",
      "断连前实际源核记录：约40%提高不能改写成增加40个百分点；面积变化不等于体积变化；TH体积占比不等于纤维条数。"
    ],
    "aggregate_gap_counts_have_no_invented_field_mapping": true,
    "existing_source_conflicts_preserved": [
      {
        "id": "A156-CF01",
        "topic": "fixationduration",
        "values": [
          "MethodsON4°C",
          "Results24h4°C"
        ],
        "actual": "notresolved"
      },
      {
        "id": "A156-CF02",
        "topic": "recipebasis",
        "detail": "wt%=solute/solvent×100按原文保留，与常规总溶液分母不同；不直接给批量称量表。"
      },
      {
        "id": "A156-CF03",
        "topic": "Na",
        "detail": "漂白液pH8调节试剂只写Na，化学形式未知；不替换NaOH。"
      },
      {
        "id": "A156-CF04",
        "topic": "relativefibresplot",
        "detail": "定义体积比，图轴缩放未知；保存定义与旧O限制，不更正结果。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp6 §4.7 ratio definition"
          },
          {
            "source_id": "F05",
            "locator": "Fig3g left axis and dots"
          }
        ]
      }
    ],
    "existing_remaining_unreviewed_preserved": [
      "外引Jiang/Susaki原文未扩大恢复；使用本文已明示改编步骤，pH/配方疑点保留。",
      "两段影片未重新解码或逐帧阅，原始Z-stack/逐ROI数表未取得。",
      "活检手术细节位于原文§4.2，本轮起点为离体标本，不将其重编为新的临床操作指导。"
    ],
    "online_access": "PMC request returned reCAPTCHA for A152/A154/A155/A158; retrieval stopped, no bypass or supplementary batch retrieval. Other papers not requested from blocked host.",
    "publication_approved": false
  }
}
```

## 当前问题对象（非expert gold）

```json

[
  {
    "question_id": "A156-R20261012-GQ01",
    "question_type": "result_question",
    "question": "Size and texture during preparation",
    "answer": {
      "statements": [
        {
          "text": "Dehydration reduces area; rehydration restores most original size. Clearing alters shape and produces fragile gel-like consistency. Area observations do not establish volume preservation. During dehydration/rehydration the tissue first became more rigid, then regained its original texture after 1h PBS incubation and subsequent washing, permeabilization and blocking. Fig1c shows a qualitative clearing sequence at days1,3,6,9,12,15; these observation days are not uniform endpoints for every specimen.",
          "reported_values": null,
          "result_ids": [
            "A156-R20261012-O01"
          ],
          "group_ids": [
            "A156-R20261012-G01"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G01",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G01",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S03"
              ],
              "branch_selector": "area photos; cm², not tissue volume",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E01"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ01",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support Size and texture during preparation?",
    "answer": {
      "statements": [
        {
          "text": "Preparation size/texture and Fig1c clearing series",
          "group_ids": [
            "A156-R20261012-G01"
          ],
          "result_ids": [
            "A156-R20261012-O01"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S03"
              ],
              "branch_selector": "area photos; cm², not tissue volume",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "phase": "Fig1c clearing observations",
            "days": [
              1,
              3,
              6,
              9,
              12,
              15
            ],
            "relationship_to_operations": "observation days; protocol solution changes remain in P001"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Results2.1–2.2; Figure1c; SupplementaryFigureS1",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E01"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ02",
    "question_type": "result_question",
    "question": "Histological preservation",
    "answer": {
      "statements": [
        {
          "text": "H&E shows intact adipocytes with large lipid droplets in the separately fixed piece; no post-clearing H&E comparison is established.",
          "reported_values": null,
          "result_ids": [
            "A156-R20261012-O02"
          ],
          "group_ids": [
            "A156-R20261012-G02"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G02",
              "protocol_id": "A156-P003",
              "step_ids": [
                "A156-P003-S01"
              ],
              "branch_selector": "H&E branch only; no post-clearing histology",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G02"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2a; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E02"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ02",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support Histological preservation?",
    "answer": {
      "statements": [
        {
          "text": "Separate neutral-buffered formalin H&E piece",
          "group_ids": [
            "A156-R20261012-G02"
          ],
          "result_ids": [
            "A156-R20261012-O02"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P003",
              "step_ids": [
                "A156-P003-S01"
              ],
              "branch_selector": "H&E branch only; no post-clearing histology",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "measurement_medium": "not_reported_for_this_panel"
          },
          "source_conflict_ids": [],
          "limitations": [
            "Complete H&E processing/acquisition not reported."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2a; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E02"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ03",
    "question_type": "result_question",
    "question": "Uncleared adipocyte labeling",
    "answer": {
      "statements": [
        {
          "text": "Perilipin confocal staining supports adipocyte morphology with secondary-only control; this is not evidence that perilipin survives clearing.",
          "reported_values": null,
          "result_ids": [
            "A156-R20261012-O03"
          ],
          "group_ids": [
            "A156-R20261012-G03",
            "A156-R20261012-G04"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G03",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10"
              ],
              "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G03",
              "protocol_id": "A156-P003",
              "step_ids": [
                "A156-P003-S02"
              ],
              "branch_selector": "LeicaSP8 uncleared perilipin",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G04",
              "protocol_id": "A156-P003",
              "step_ids": [
                "A156-P003-S02"
              ],
              "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            },
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G04"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2b; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E03"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ03",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support Uncleared adipocyte labeling?",
    "answer": {
      "statements": [
        {
          "text": "Uncleared perilipin positive",
          "group_ids": [
            "A156-R20261012-G03"
          ],
          "result_ids": [
            "A156-R20261012-O03"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10"
              ],
              "branch_selector": "perilipin branch at S07/S09; omit clearing S11–S13",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P003",
              "step_ids": [
                "A156-P003-S02"
              ],
              "branch_selector": "LeicaSP8 uncleared perilipin",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "measurement_medium": "not_reported_for_this_panel"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF03"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2b; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Uncleared perilipin secondary-only control",
          "group_ids": [
            "A156-R20261012-G04"
          ],
          "result_ids": [
            "A156-R20261012-O03"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P003",
              "step_ids": [
                "A156-P003-S02"
              ],
              "branch_selector": "secondary-only control; omit perilipin primary; exact full control history not reported",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "measurement_medium": "not_reported_for_this_panel"
          },
          "source_conflict_ids": [],
          "limitations": [
            "Do not assign TH labeling or clearing."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2b; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E03"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ04",
    "question_type": "result_question",
    "question": "TH labeling specificity context",
    "answer": {
      "statements": [
        {
          "text": "TH-labeled neural arborizations are visible relative to secondary-only control. No complete fiber detection or zero background claim is made.",
          "reported_values": null,
          "result_ids": [
            "A156-R20261012-O04"
          ],
          "group_ids": [
            "A156-R20261012-G05",
            "A156-R20261012-G06"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G05",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G05",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "TH light-sheet acquisition and processing",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G06",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G06",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "Fig2c control imaging; no invented per-panel settings",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2c; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E04"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ04",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support TH labeling specificity context?",
    "answer": {
      "statements": [
        {
          "text": "Cleared TH-primary plus secondary positive",
          "group_ids": [
            "A156-R20261012-G05"
          ],
          "result_ids": [
            "A156-R20261012-O04"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "TH light-sheet acquisition and processing",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2c; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Cleared secondary-only/no-TH control",
          "group_ids": [
            "A156-R20261012-G06"
          ],
          "result_ids": [
            "A156-R20261012-O04"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "no TH primary at S07; secondary-only branch; exact control timing not fully reported",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "Fig2c control imaging; no invented per-panel settings",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2c; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E04"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ05",
    "question_type": "result_question",
    "question": "Autofluorescence architecture",
    "answer": {
      "statements": [
        {
          "text": "Autofluorescence provides tissue architectural context after processing; qualitative appearance does not prove unchanged dimensions.",
          "reported_values": null,
          "result_ids": [
            "A156-R20261012-O05"
          ],
          "group_ids": [
            "A156-R20261012-G07"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G07",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "clearing context only; antibody execution not established",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G07",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S05"
              ],
              "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G07"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2d; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E05"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ05",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support Autofluorescence architecture?",
    "answer": {
      "statements": [
        {
          "text": "Cleared tissue autofluorescence Fig2d",
          "group_ids": [
            "A156-R20261012-G07"
          ],
          "result_ids": [
            "A156-R20261012-O05"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "clearing context only; antibody execution not established",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S05"
              ],
              "branch_selector": "processing context; TH-specific561nm/BP575–615 not confirmed for autofluorescence",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF02"
          ],
          "limitations": [
            "Autofluorescence channel/acquisition details not separately reported."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2d; Results2.3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E05"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ06",
    "question_type": "result_question",
    "question": "Optical transmittance",
    "answer": {
      "statements": [
        {
          "text": "Clearing increases light transmittance; the approximate reported increase retains the original percentage ambiguity and is not converted to an exact relative gain.",
          "reported_values": {
            "reported_approximate_increase": "about 40%",
            "interpretation": "relative percent versus percentage points not explicitly disambiguated",
            "technical_reads": 3,
            "biological_n": "not established by technical read count",
            "range_nm": [
              400,
              1000
            ],
            "step_nm": 2,
            "normalization": "equal-volume CUBIC2 blank set to 100%; T=10^(-A)"
          },
          "result_ids": [
            "A156-R20261012-O06"
          ],
          "group_ids": [
            "A156-R20261012-G08",
            "A156-R20261012-G09",
            "A156-R20261012-G10"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G08",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S01",
                "A156-P002-S02"
              ],
              "branch_selector": "optical transmittance Uncleared tissue",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G09",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G09",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S01",
                "A156-P002-S02"
              ],
              "branch_selector": "optical transmittance Cleared tissue",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G10",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S01",
                "A156-P002-S02"
              ],
              "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G08"
            },
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G09"
            },
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G10"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2e; Results2.3; Methods4.6",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E06"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ06",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support Optical transmittance?",
    "answer": {
      "statements": [
        {
          "text": "Uncleared tissue",
          "group_ids": [
            "A156-R20261012-G08"
          ],
          "result_ids": [
            "A156-R20261012-O06"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S01",
                "A156-P002-S02"
              ],
              "branch_selector": "optical transmittance Uncleared tissue",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "measurement_medium": "CUBIC2",
            "phase": "absorbance measurement",
            "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
          },
          "source_conflict_ids": [],
          "limitations": [
            "Biological n and matching to TH donors not established."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2e; Results2.3; Methods4.6",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Cleared tissue",
          "group_ids": [
            "A156-R20261012-G09"
          ],
          "result_ids": [
            "A156-R20261012-O06"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "reported clearing branch; per-panel preceding antibody history not established",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S01",
                "A156-P002-S02"
              ],
              "branch_selector": "optical transmittance Cleared tissue",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "measurement_medium": "CUBIC2",
            "phase": "absorbance measurement",
            "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
          },
          "source_conflict_ids": [
            "A156-CF02"
          ],
          "limitations": [
            "Biological n and matching to TH donors not established."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2e; Results2.3; Methods4.6",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Equal-volume CUBIC2 blank",
          "group_ids": [
            "A156-R20261012-G10"
          ],
          "result_ids": [
            "A156-R20261012-O06"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S01",
                "A156-P002-S02"
              ],
              "branch_selector": "optical transmittance Equal-volume CUBIC2 blank",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "measurement_medium": "CUBIC2",
            "phase": "absorbance measurement",
            "technical_repeats": "three measurements of same tissue; blank is mathematical normalization, not tissue replicate"
          },
          "source_conflict_ids": [
            "A156-CF02"
          ],
          "limitations": [
            "Biological n and matching to TH donors not established."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure2e; Results2.3; Methods4.6",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E06"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ07",
    "question_type": "result_question",
    "question": "Three-dimensional neural network visualization",
    "answer": {
      "statements": [
        {
          "text": "Orthogonal views visualize neural arborizations in two severely obese subjects. Multiple planes and movies do not add subjects; fine-fiber quantification requires higher magnification. Spatial coverage is nonuniform: authors report lower antibody signal at the tissue centre in movieS1/Discussion (separate O10).",
          "reported_values": {
            "subjects": 2,
            "views": [
              "xy",
              "yz",
              "xz"
            ]
          },
          "result_ids": [
            "A156-R20261012-O07"
          ],
          "group_ids": [
            "A156-R20261012-G11",
            "A156-R20261012-G12"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G11",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G11",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "TH wholemount visualization",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G12",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G12",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "TH wholemount visualization",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure3a–f; Results2.4; moviesS1–S2",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Authors report reduced antibody signal in the centre of the adipose biopsy, referring to movieS1. This spatially nonuniform signal is an observation; its cause was not experimentally isolated.",
          "reported_values": null,
          "result_ids": [
            "A156-R20261012-O10"
          ],
          "group_ids": [
            "A156-R20261012-G15"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G15",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G15",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "movieS1 TH rendering",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            },
            {
              "type": "group_limitations",
              "group_id": "A156-R20261012-G15"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
              "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E07"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ07",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support Three-dimensional neural network visualization?",
    "answer": {
      "statements": [
        {
          "text": "TH network Subject1",
          "group_ids": [
            "A156-R20261012-G11"
          ],
          "result_ids": [
            "A156-R20261012-O07"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "TH wholemount visualization",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure3a–f; Results2.4; moviesS1–S2",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "TH network Subject2",
          "group_ids": [
            "A156-R20261012-G12"
          ],
          "result_ids": [
            "A156-R20261012-O07"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "TH wholemount visualization",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure3a–f; Results2.4; moviesS1–S2",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "MovieS1 centre-versus-periphery signal report",
          "group_ids": [
            "A156-R20261012-G15"
          ],
          "result_ids": [
            "A156-R20261012-O10"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05"
              ],
              "branch_selector": "movieS1 TH rendering",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03"
          ],
          "limitations": [
            "No exact attenuation ratio, matched penetration experiment or newly replayed video."
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Discussion pp4–5 and movieS1 citation; historical movie review inherited, not replayed",
              "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E07"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-GQ08",
    "question_type": "result_question",
    "question": "TH fiber volume fraction and surface",
    "answer": {
      "statements": [
        {
          "text": "Segmented TH-object volume divided by total imaged volume, in four areas per subject. Fig3g left summarizes mean±SD across tissue areas; it is not a fiber count. The graph axis scaling remains unresolved.",
          "reported_values": {
            "areas_per_subject": 4,
            "subjects": 2,
            "summary": "mean ± SD across tissue areas",
            "relative_TH_definition": "fiber volume / total imaged volume",
            "minimum_included_object_volume_um3": 600,
            "absolute_graph_values": null,
            "absolute_graph_values_status": "not_redigitized",
            "source_conflict": "A156-CF04"
          },
          "result_ids": [
            "A156-R20261012-O08"
          ],
          "group_ids": [
            "A156-R20261012-G13",
            "A156-R20261012-G14"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G13",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G13",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05",
                "A156-P002-S06",
                "A156-P002-S07"
              ],
              "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G14",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G14",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05",
                "A156-P002-S06",
                "A156-P002-S07"
              ],
              "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF04"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Fig3g right reports mean fibre surface, with between-subject and between-area variation. Supplementary FigS2 displays separate fiber-surface distributions for four areas in each of two subjects. Numeric graph values were not digitized.",
          "reported_values": {
            "unit": "µm²",
            "unit_basis": "Methods4.7 explicit fibre surface unit; no substitution based on PDF OCR mm²",
            "measured_objects": "segmented TH-positive fibre objects",
            "aggregation": "mean fibre surface for each tissue area; Fig3g mean±SD across 4 tissue areas per subject",
            "subjects": 2,
            "areas_per_subject": 4,
            "surface_algorithm": "not_reported",
            "numeric_values": null,
            "numeric_values_status": "not_digitized",
            "supplementary_distribution_scope": [
              {
                "subject": 1,
                "area": 1,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 1,
                "area": 2,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 1,
                "area": 3,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 1,
                "area": 4,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 2,
                "area": 1,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 2,
                "area": 2,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 2,
                "area": 3,
                "numeric_range": null,
                "range_status": "not_digitized"
              },
              {
                "subject": 2,
                "area": 4,
                "numeric_range": null,
                "range_status": "not_digitized"
              }
            ]
          },
          "result_ids": [
            "A156-R20261012-O09"
          ],
          "group_ids": [
            "A156-R20261012-G13",
            "A156-R20261012-G14"
          ],
          "protocol_uses": [
            {
              "group_id": "A156-R20261012-G13",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G13",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05",
                "A156-P002-S06",
                "A156-P002-S07"
              ],
              "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G14",
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "group_id": "A156-R20261012-G14",
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05",
                "A156-P002-S06",
                "A156-P002-S07"
              ],
              "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "uncertainty_refs": [
            {
              "type": "source_conflict",
              "id": "A156-CF01"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF02"
            },
            {
              "type": "source_conflict",
              "id": "A156-CF03"
            }
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Fig3g right; Methods4.7; Supplementary FigS2 preserved full-page review",
              "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E08"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ08",
    "question_type": "method_and_scope_question",
    "question": "Which actual branches, controls, sampling units and unresolved conditions support TH fiber volume fraction and surface?",
    "answer": {
      "statements": [
        {
          "text": "Subject1, four distinct Z-stack tissue areas",
          "group_ids": [
            "A156-R20261012-G13"
          ],
          "result_ids": [
            "A156-R20261012-O08",
            "A156-R20261012-O09"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05",
                "A156-P002-S06",
                "A156-P002-S07"
              ],
              "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03",
            "A156-CF04"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        },
        {
          "text": "Subject2, four distinct Z-stack tissue areas",
          "group_ids": [
            "A156-R20261012-G14"
          ],
          "result_ids": [
            "A156-R20261012-O08",
            "A156-R20261012-O09"
          ],
          "protocol_uses": [
            {
              "protocol_id": "A156-P001",
              "step_ids": [
                "A156-P001-S01",
                "A156-P001-S02",
                "A156-P001-S03",
                "A156-P001-S04",
                "A156-P001-S05",
                "A156-P001-S06",
                "A156-P001-S07",
                "A156-P001-S08",
                "A156-P001-S09",
                "A156-P001-S10",
                "A156-P001-S11",
                "A156-P001-S12",
                "A156-P001-S13"
              ],
              "branch_selector": "TH positive wholemount",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            },
            {
              "protocol_id": "A156-P002",
              "step_ids": [
                "A156-P002-S04",
                "A156-P002-S05",
                "A156-P002-S06",
                "A156-P002-S07"
              ],
              "branch_selector": "TH objects; volume fraction and surface are distinct readouts",
              "use_status": "reported_branch_with_local_exceptions",
              "source_basis": "selected step source_raw plus group source_refs; parameters remain in unchanged P"
            }
          ],
          "observation_conditions": {
            "medium": "Reagent2",
            "phase": "imaging"
          },
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03",
            "A156-CF04"
          ],
          "limitations": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ]
    },
    "experiment_ids": [
      "A156-R20261012-E08"
    ],
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-SQ01",
    "question_type": "study_synthesis",
    "question": "What does this study establish, and what limits its use?",
    "answer": {
      "result_question_ids": [
        "A156-R20261012-GQ01",
        "A156-R20261012-GQ02",
        "A156-R20261012-GQ03",
        "A156-R20261012-GQ04",
        "A156-R20261012-GQ05",
        "A156-R20261012-GQ06",
        "A156-R20261012-GQ07",
        "A156-R20261012-GQ08"
      ],
      "statements": [
        {
          "text": "In abdominal subcutaneous WAT from two men with severe childhood obesity, separately scoped histology/perilipin controls and cleared TH imaging support tissue/nerve visualization, improved transmittance, and volume-fraction/surface readouts. Central antibody signal is reduced, tissue becomes fragile, and fine nerve-fiber quantification was not completed. Optical technical triplicates are separate from two donors with four TH-analysis areas each; the suggested causes and improvements are untested.",
          "result_ids": [
            "A156-R20261012-O01",
            "A156-R20261012-O02",
            "A156-R20261012-O03",
            "A156-R20261012-O04",
            "A156-R20261012-O05",
            "A156-R20261012-O06",
            "A156-R20261012-O07",
            "A156-R20261012-O08",
            "A156-R20261012-O09",
            "A156-R20261012-O10"
          ],
          "group_ids": [
            "A156-R20261012-G01",
            "A156-R20261012-G02",
            "A156-R20261012-G03",
            "A156-R20261012-G04",
            "A156-R20261012-G05",
            "A156-R20261012-G06",
            "A156-R20261012-G07",
            "A156-R20261012-G08",
            "A156-R20261012-G09",
            "A156-R20261012-G10",
            "A156-R20261012-G11",
            "A156-R20261012-G13",
            "A156-R20261012-G12",
            "A156-R20261012-G14",
            "A156-R20261012-G15"
          ],
          "source_conflict_ids": [
            "A156-CF01",
            "A156-CF02",
            "A156-CF03",
            "A156-CF04"
          ],
          "limitations": [
            "All main result panels and reported supplementary limitations are represented; Figure1a/b workflow drawings are not measured experiments.",
            "Fresh source is the published Royal Society PDF served by Cambridge repository; historical visual review remains separately inherited.",
            "Wholemount TH, uncleared perilipin and NBF/H&E branches remain distinct. The split-biopsy histology is not automatically post-clearing histology.",
            "Two subjects, four tissue areas per subject, three technical optical reads and three display planes are separate counting levels.",
            "TH signal is reduced in the sample centre; incomplete penetration and fragile tissue are retained, not described as uniformly complete innervation.",
            "Area changes do not establish volume constancy, and greater transparency does not imply unchanged physical properties.",
            "Approximate 40% transmittance wording is not transformed into exact percentage points or absolute curve values.",
            "All four existing source conflicts retained: overnight versus24h fixation, unusual wt% denominator, unspecified Na chemical identity, and unresolved relative-TH plot scaling.",
            "No lean comparison, weight-loss intervention, fine-needle biopsy validation or human lipolysis causality is claimed."
          ],
          "protocol_group_refs": [
            "A156-R20261012-G01",
            "A156-R20261012-G02",
            "A156-R20261012-G03",
            "A156-R20261012-G04",
            "A156-R20261012-G05",
            "A156-R20261012-G06",
            "A156-R20261012-G07",
            "A156-R20261012-G08",
            "A156-R20261012-G09",
            "A156-R20261012-G10",
            "A156-R20261012-G11",
            "A156-R20261012-G13",
            "A156-R20261012-G12",
            "A156-R20261012-G14",
            "A156-R20261012-G15"
          ]
        }
      ]
    },
    "new_question_not_legacy_restoration": true
  },
  {
    "question_id": "A156-R20261012-RQ99",
    "question_type": "author_interpretation_scope",
    "question": "Which explanations, external comparisons and proposed applications are distinct from observations?",
    "answer": {
      "statements": [
        {
          "text": "Authors propose that incomplete lipid clearing reduces antibody penetration and contributes to central signal loss. This causal explanation was not independently tested.",
          "claim_ids": [
            "A156-R20261012-AX01"
          ],
          "result_ids": [
            "A156-R20261012-O10"
          ],
          "group_ids": [
            "A156-R20261012-G15"
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Discussion",
              "verification": "publisher_text_inspected_20261012"
            }
          ],
          "evidence_role": "author_hypothesis",
          "limitations": [
            "This statement retains its author interpretation/prospect/external-background role, not an additional validated experiment."
          ]
        },
        {
          "text": "Lean-obese comparison, leptin and weight-loss effects remain proposed future uses.",
          "claim_ids": [
            "A156-R20261012-AX02"
          ],
          "result_ids": [],
          "group_ids": [],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Discussion",
              "verification": "publisher_text_inspected_20261012"
            }
          ],
          "evidence_role": "author_future_prospect",
          "limitations": [
            "This statement retains its author interpretation/prospect/external-background role, not an additional validated experiment."
          ]
        },
        {
          "text": "Smaller samples and increased antibody concentration are suggested as possible improvements, not demonstrated successful optimizations.",
          "claim_ids": [
            "A156-R20261012-AX03"
          ],
          "result_ids": [
            "A156-R20261012-O10"
          ],
          "group_ids": [
            "A156-R20261012-G15"
          ],
          "source_refs": [
            {
              "source_id": "A156-R20261012-F01",
              "locator": "Discussion pp4–5",
              "verification": "primary_text_or_preserved_source_raw_checked_targeted_repair"
            }
          ],
          "evidence_role": "author_unvalidated_improvement_suggestion",
          "limitations": [
            "This statement retains its author interpretation/prospect/external-background role, not an additional validated experiment."
          ]
        }
      ]
    },
    "new_question_not_legacy_restoration": true
  }
]

```
