# A156 source reconstruction

New namespace, not restoration of the historical core/hash. Original protocol records and historical review declarations are retained with exact hashed pointers. All declared result rows were read against publisher text/captions; no new image digitization, raw-data recomputation or movie decoding is claimed.

## Bidirectional scientific checks
- All main result panels and reported supplementary limitations are represented; Figure1a/b workflow drawings are not measured experiments.
- Fresh source is the published Royal Society PDF served by Cambridge repository; historical visual review remains separately inherited.
- Wholemount TH, uncleared perilipin and NBF/H&E branches remain distinct. The split-biopsy histology is not automatically post-clearing histology.
- Two subjects, four tissue areas per subject, three technical optical reads and three display planes are separate counting levels.
- TH signal is reduced in the sample centre; incomplete penetration and fragile tissue are retained, not described as uniformly complete innervation.
- Area changes do not establish volume constancy, and greater transparency does not imply unchanged physical properties.
- Approximate 40% transmittance wording is not transformed into exact percentage points or absolute curve values.
- All four existing source conflicts retained: overnight versus24h fixation, unusual wt% denominator, unspecified Na chemical identity, and unresolved relative-TH plot scaling.
- No lean comparison, weight-loss intervention, fine-needle biopsy validation or human lipolysis causality is claimed.

## Coverage
- Size and texture during preparation: Results2.1–2.2; Figure1c; SupplementaryFigureS1
- Histological preservation: Figure2a; Results2.3
- Uncleared adipocyte labeling: Figure2b; Results2.3
- TH labeling specificity context: Figure2c; Results2.3
- Autofluorescence architecture: Figure2d; Results2.3
- Optical transmittance: Figure2e; Results2.3; Methods4.6
- Three-dimensional neural network visualization: Figure3a–f; Results2.4; moviesS1–S2
- TH fiber volume fraction and surface: Figure3g; Methods4.7; Results2.4; SupplementaryFigureS2

No dangling relation endpoints. Panel-specific n and source conflicts remain distinct from specimen identity and administrative approval. Source missingness does not justify guessed values. Raw-data reproduction is not required to close supported literature claims. Parent content review pending; specified Pro/candidate gate unchanged.

Source delta: O04/E04 explicitly compare TH primary+secondary S01 against secondary-only S04; comparison groups and supporting artifact edges updated.

## Targeted independent-review repairs
Version 2026-10-12.targeted-repair.1. Source-backed missing observations, explicit condition/sampling groups, selected protocol steps, conflict scopes and a new SQ/RQ/GQ answer layer were added. The embedded P records remain unchanged. New question IDs are not claimed to restore lost historical questions. See REPAIR_REPORT.md for finding-level disposition. Structural checks passed; this is author repair/self-check, not independent acceptance. Count increment remains 0 pending the original reviewer’s recheck.
