M009 ClearT / ClearT2：轻量证据交付包
DOI: 10.1242/dev.091844

最终科学记录evidence_record.json与已验收的本地完整记录逐字节一致。
SHA256: 118b2ab104a2b603a7f825f5cf924ffcf854477deb3ae07d39e3e9b5ba881b39

内容：最终JSON、7份CSV、中文逐篇说明、必要审查/验收记录、来源链接与结构检查脚本。
为避免在没有明确再分发许可时分发原始论文，本包不附原文全文、PDF、图像、渲染图或原文缓存。
来源URL与当时缓存哈希仍在科学JSON中；缓存路径是本地原始审查记录，不表示这些文件随本包交付。
review中的来源哈希核验与阅读陈述是已完成的历史独立审查；在本轻量包里运行结构检查不会重新验证来源。
历史版本与原始缓存保留在本地完整包；引用的历史路径可能不在本轻量交付包中。

建议先读“逐篇证据说明.txt”。protocol_steps.csv包含78个真实操作，samples.csv包含27个样本分支，experiment_arms.csv包含47个组，results.csv包含28个结果。
claims.csv包含29行，其中C19已superseded，C19R是接受的纠正；有效结论共28条。
unknowns.csv保留10项未知，source_conflicts.csv保留6类差异/注意事项。
样本ID指样本类别/实验分支，不表示跨图为同一实体或动物。完成不表示所有未知参数已恢复。

解压后在本目录运行：
python validate_record.py --structure-only evidence_record.json

--structure-only显式跳过原文缓存存在性与哈希检查。输出source_cache_verification.status应为not_reverified_structure_only，并列出未复验的source IDs。
passed=true只表示该次结构检查通过，不能解读为来源已重新核验，也不能替代科学审查。
不加--structure-only会要求本地缓存，本轻量包不提供这些文件。

本交付副本仅修改结构脚本与交付说明，未改变最终科学JSON；原5MB完整本地包未修改。
