R022 肌骨组织清透综述：四轮核查后的纯派生证据包

当前版本：record_R3.json；独立最终接收见 review/final_acceptance.json。
冻结记录里的“pending”只是冻结当时状态，接收以独立最终接收文件为准。R1、R2及早期修订请求是历史审计材料，不应用来替代R3。

范围：固定后组织清透、标记相容、成像、荧光与形态结局。共74项主张、25表行、46数值记录、29标签记录、13示意图区、116书目、30来源问题和10项缺口。25表行包含21固定组织语境、3在体范围排除及1固定状态不明；不能把25视为合格实验数。

证据层级：综述全文、全部3表及3张真实示意图已复核。5篇被引原研究只读官方摘要或指定正文/表格段落；全部primary_verified=false。这里没有完整原始实验验证，表行不是实验，示意图不是实验图。所有总流程时长保持null。

重要冲突：约40天labeling与原研究clearing 40/42天并列保留；4天仅为PEGASOS脱钙。ScaleA2/ClearT2的组织、标记及终点各自限定。PEGASOS分类、RI、配方差异，SCM试剂角色和FASTClear样本/Vimentin限制都保留出处。

使用：优先阅读R3说明_中文.txt、record_R3.json及同名R3 CSV投影。source_locator_index_R3.json提供定位和散列，不附原文。external_crosschecks_R3.json记录有限外部核对。review目录保留查询、修订与独立复核凭据。

包内没有原文XML/PDF、原图、视频、sourceblocks或原始资料缓存。路径只是来源定位，不表示文件随包附送。未修改旧库、未公开发布。

校验：解压后在本目录运行 python verify_package.py。它核对包内清单散列、JSON/CSV可读性、R3记录身份及primary_verified标志；它不替代科学复核。
