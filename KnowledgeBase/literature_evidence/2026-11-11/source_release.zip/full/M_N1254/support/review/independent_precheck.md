# Independent source-first precheck: M_N1254

Status: source-first checks completed; R1 not yet available, so no record acceptance has been issued.
Reviewer: review_audisco_paper
Source: PMC6104128 deposited JATS XML, read directly; publisher main text independently accessed 2026-10-19.

## Mandatory scientific distinctions for subsequent R2/R3
- Prepared tissue inputs: adult mouse (2–3 months); Thy1-GFP-M brain slices, hemispheres, whole brain; Cx3cr1-GFP whole brain microglia. Brain slice thickness 1 mm, coronal. Do not convert reagent stages into fictitious samples.
- Scope begins at prepared tissue; retain relevant fixation state as specimen metadata, but no animal construction or anesthesia/perfusion recipe required.
- Optimal a-uDISCO pH 9.0–9.5 applies to both tert-butanol series and BABB-D4. Other screened conditions: unadjusted uDISCO, pH 7.5–8.0 and 10.5–11.0. Do not collapse screened branches into the selected protocol.
- tert-butanol concentrations: 30, 50, 70, 80, 90, 96, 100 vol%. Brain slices: 2 h each except 96% overnight, BABB-D4 1 h room temperature. Whole brain/hemisphere: 35°C dehydration; details depend on Supplementary Table 1; DCM 45–60 min room temperature; hemisphere BABB-D4 at least 3 h, whole brain 5 h. Do not fill missing times from original uDISCO or another paper without explicit provenance.
- BABB-D4 composition: benzyl alcohol, benzyl benzoate, diphenyl ether 4:8:3 by volume with 0.4 vol% vitamin E. No numerical RI is reported in main text; do not import literature RI silently.
- Storage in BABB-D4, exchanged every 3–4 days. This is maintenance interval, not workflow duration.
- Author states whole adult brain clearing takes 4 days; this is clearing-only author estimate, not total including prepared tissue, labeling or imaging. Keep overnight nonnumeric unless source gives hours.
- Figure 1 pH screen measures day3/day0 mean cortical wide-field intensity. Do not compare with uncleared wide-field baseline due to scattering.
- Figure 2 compares surface confocal same-cell MIP intensity after clearing / before clearing. a-uDISCO ~136% immediate and ~80% at day3; uDISCO ~73% immediate and <7% day3. The day3 percentages are of pre-clearing baseline, not of immediate after-clearing signal.
- Figure 2 sample counts: uDISCO 23 and 15 cell bodies (day0/day3), 6 slices; a-uDISCO 28 cell bodies in 6 slices (both timepoints). These are cell counts, not mice.
- Figure 3 measures cortical signal-to-background ratio from 30-µm z projection, not fluorescent protein retention %. Hemispheres n=5/method, timepoints 0,7,14,28,42 days. Hippocampal images are illustrative and must not replace the cortical quantification region.
- Whole brain transmittance: 400–800 nm, n=3/method, similar to uDISCO, no main-text numeric transmittance. Size: n=4/method; determine meaning of approximately 65% from Figure 4D axis, avoiding reduced-by vs reduced-to ambiguity.
- Cx3cr1-GFP microglia and Thy1-GFP-M dendritic spines morphology preserved on brain surface. No general quantitative deep-tissue morphology claim.
- GFP demonstrated. RFP/YFP/CFP, immunofluorescent labels, nuclear dyes explicitly require future validation; not evidence of incompatibility.
- Supplementary Fig4 includes spinal cord, muscle, intestine, stomach, lung, heart, kidney, liver, spleen. Main discussion describes good clearing muscle/stomach/lung, poor heme-rich heart/liver/kidney, especially spleen. Caption alone is insufficient for quantitative organ efficacy or GFP preservation in every organ.
- Troubleshooting PBS 37°C for several hours prior to clearing is author suggestion for heme-rich tissue; do not count as validated separate experimental group or mandatory all-tissue protocol.

## R4 external queries actually executed
1. Publisher main article opened successfully: https://www.frontiersin.org/journals/neuroanatomy/articles/10.3389/fnana.2018.00067/full . Independently verified bibliographic identity and main scientific methods. No concrete access denial occurred.
2. Search: "10.3389/fnana.2018.00067" correction corrigendum. Returned original PubMed, publisher and bibliographic records, no identified correction. This is limited search-negative evidence, not proof no correction exists.
3. Search: "a-uDISCO" "Table 1" "35". Results included original publisher and other protocols/reviews. Those secondary or different-protocol parameters are not admissible replacements for unread a-uDISCO supplement.
4. Publisher supplement index independently verified 4 figures, 3 tables and 2 videos. Acquisition delegated to extractor to avoid duplicate downloads. Files remain pending independent inspection.

## Supplement and figure inspection update (2026-10-19 01:44 UTC)
- Extractor acquired the public Europe PMC supplement archive once; reviewer independently read the shared original DOCX table cells with python-docx, all 4 supplementary JPEG figures with view_image, and all 5 main figures with view_image.
- Table 1 resolves temperatures and step times. Slices: RT throughout, 2h each tert-butanol except 96% overnight; no DCM; BABB-D4 1h. Hemisphere: 35°C tert-butanol 30/50/70/80/90/96/100% = ON/4/4/ON/4/4/ON h; DCM 45min RT; BABB-D4 3h RT. Whole brain: same series = ON/10/ON/10/ON/10/ON h at 35°C; DCM 60min RT; BABB-D4 5h RT. ON is undefined in hours.
- Table 1 hemisphere BABB-D4 lists nominal 3h; main text says at least 3h. Preserve qualification; no substantial contradiction.
- Table 2 contains reagent identity, supplier and hazard details; procurement excluded from in-scope scientific fields. Core agent composition already in main text.
- Table 3 provides troubleshooting recommendations, not demonstrated additional experimental branches: crystallized 100% tert-butanol -> 25°C water bath; insufficient clearing -> extend each step; excessive post-fixation -> limit to 24h; weak fluorescence -> check pre-clearing signal/use fresh agents; bleaching -> reduce laser/increase gain. Perfusion-specific recommendations outside prepared-sample scope.
- Figure 4D: plotted linear-size ratio approximately 0.65–0.70, not 65% lost volume. Figure4E and Supplementary Figure1 red channels are after-clearing pseudocolor, not red fluorescent protein evidence.
- NEW SOURCE CONFLICT: Supplementary Figure3B ImageJ screenshot labels 100–500 as pixel^2; main-text image processing states 100–500 µm². No independent calibration resolves this. Record both, do not silently assert equivalence.
- Supplementary Figure4: spinal cord bright-field and GFP fluorescent structures shown; peripheral organ panel is reflective before/after appearance only. Intestine visually clear, whereas spleen remains dark; qualitative image evidence, no numerical transmittance or protein-retention assays for those organs.
- Videos independently inspected by representative frames spanning the whole duration (10s sampling including ending), not watched frame-by-frame. Video1: 128s, uDISCO/a-uDISCO hemisphere comparison at days 0/7/14/28/42; Video2: 119.04s, a-uDISCO Thy1-GFP-M whole brain and regional high-magnification structures. These playback durations are not protocol times. Derived contact sheets stay in source_views and must not be in the derived-only delivery package.
