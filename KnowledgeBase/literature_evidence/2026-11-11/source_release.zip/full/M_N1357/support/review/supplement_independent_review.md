# Independent supplement review
Reviewed local publisher supplement.pdf, eight pages, text and rendered image inspection, 2026-10-19 01:43 UTC. No supplement access failure remains; download coordinated through extractor, not repeated.

- S1 (pp2–3): apparatus geometry shown; device fabrication/procurement is out of extraction scope. Existing instrument identity and NCES operational context may be retained.
- S2 (p3): 10/12/24 h PFA post-fixation; all A4P0 embedding 24 h and electrophoresis 24 h. Visual increase in expansion/homogeneity for shorter fixation. No numerical expansion ratio.
- S3 (p4): 10 h fixation, A4P0, 60 h NCES at 37 C/25 V; paired no versus 1% alpha-thioglycerol. Yellowing reduced with additive; not a fluorescence-retention measurement.
- S4 (p4): (a) 28 h fixation, A4P0 slice, 4 d passive with 4% SDS and 5% alpha-thioglycerol, opaque central area; 2 mm thickness from main text. (b) independent 1 d electrophoresis/1% alpha-thioglycerol versus 6 d passive/5% alpha-thioglycerol. Do not turn the S4b comparison into a PRE sequential protocol.
- S5 (p5): all three A4P0 clearing routes, before/after borate pH7.2. Passive/PRE before images retain SDS, stored in PBST at 4 C for unspecified duration; opacity is confounded and is not a measured long-term loss of transparency. 12 h/37 C borate treatment given in main Results. No expansion factor.
- S6 (p6): hippocampal DG, NeuN1:40, DAPI1:1000, 20x/0.75dry confocal. PBST 133 um z-stack vs borate180 um; displayed planes60/120 and60/120/180um. Main Methods supply 1mm slices/3h centrifugation and conjugated AF488 identity. This is not TH wholebrain penetration.
- S7 (p7): paired preclear/post-RIMS88%Histodenz or63%TDE photographs and outlines show TDE less expanded than RIMS; both retain expansion compared with preclear. No numerical morphology/volume ratio.
- S8 (p8): A4P0 electrophoresis-cleared brain transmission spectrum400–900nm rises with wavelength. No exact numeric table, no independent replicates. Visual580nm estimate agrees roughly48%, but does not resolve main-text48/45 or57/54 conflicts.

Supplement contains no independent endogenous fluorescent-protein retention assay, protein-loss quantification, long-term fluorescence stability assay, or RNA assay. These remain unknown/not assessed rather than negative.
