# M_N1357 independent scientific review of frozen R1

Reviewer: review_modified_clarity_paper
Review time: 2026-10-19 01:47–01:49 UTC.
Input: R1_frozen_record.json; locally available complete PMC6646319 JATS; publisher main PDF11pp; publisher supplement PDF8pp. Main Figs1–7 and supplement S1–S8 visually inspected independently. Supplement retrieved once by extractor and shared locally.

## R2 outcome: revision required before acceptance

Scientific extraction is broad and source-bound: six principal clearing branches, three sample geometries, twelve experiments, forty operations and twenty results. It correctly preserves major textual contradictions and unsuccessful control. This is not yet unconditional acceptance.

Required corrections sent to extractor:
1. Define ancillary branch identifiers CEN40, EXP12, PEN_PBST, PEN_BOR and connect them to experiments/specimens. Do not leave operation/assay branch references dangling. Add atomic supplemental operations where conditions currently live only in experiment notes.
2. Add actual microscopy/processing acquisition fields: Leica SP8 confocal; ZEISS Z1 light-sheet; dry20x/0.75 and5x/0.16; Imaris9.0.1/filament auto-path where appropriate. Current source locator alone does not make these reusable scientific fields.
3. Change F05 `not_tested_in_this_paper` and U08 `not_tested` to `not_reported`/`no assay identified`. The source explicitly says protein loss/microdeformation were not assessed, but does not explicitly deny all endogenous-FP experiments. Absence of a reported assay is not a negative biological result.
4. P18 currently has evidence_class `reported` although the5%alphaTG medium is an inference through “same clearing buffer.” Make the mixed evidence status machine-readable, or split field-level provenance.
5. Remove branch-wide copied note “A4P4 control also uses NCES” from purely passive B3/B4; limit that design caveat to electrophoretic comparisons or express it globally without misleading branch assignment.
6. P32 should enumerate inherited5%goat serum/0.1%TritonX100/0.05%Proclin300 components rather than only saying preceding components, with inherited status. This is a database usability gap, not a new unsupported recipe.
7. Add statistical method two-tailed t-test and alpha0.05 to scientific data, beyond a source-span text fragment. Retain n=3 only for relevant plotted comparisons, not every figure/assay.
8. Add NCES operating characteristics that affect tissue treatment (noncirculation, platinum-wire electrodes, qualitative filter barrier against deposition,37C bath). Do not turn S1 apparatus fabrication dimensions or purchase details into sample dimensions/procurement requirements.

## Field-level scientific checks

- Samples SA_W/SA_2MM/SA_1MM: verified against Methods, PRE Results, S4/S6.1month maleC57BL/6 applies principal cohort;2mmcoronal mechanism slice and1mmNeuN slices are separate. Same-position paired slices are from two brains, not paired slices from one brain.
- B1–B6/P01–P18: fixation10h versus28h; A4P0 infiltration24h4C/VA0440.25%/degas10min/polymerization6h37C verified. A4P4 parameters absent in article remain absent rather than borrowed from cited protocol. B1 stops after5d still inadequate;B2=60h;B3=1month;B4=14d;B5=1+15d;B6=1+5d. B5 alphaTG1%electro/5%passive differs from B1 baseline. B6 passive37C supported by Fig1g. Passive pH not overclaimed where not separately given.
- P19–P24: passive antibody1:30, cumulative50/30/20uL addition into3mL on days1/3/5,2dprewash and3dpostwashes supported. Secondary one-week time relies on per-antibody Discussion and Fig2d context; kept as qualified inheritance. DAPI lastday overlaps secondary.
- P25–P36: CEN40 predecessor is B2-based with40h perantibody;CEx is24h perantibody for B2/B4/B6.1200rpm retained, not converted to RCF. Formal CEx5h washing comes from solution-substitution reference; labels must preserve that inheritance.37C12h expansion assay is not a mandatory inserted step. DAPI last12h overlaps secondary.
- P37/P38:63%TDEinPBS24hRT;88%Histodenz comparator not sequential. TecanInfinite200Pro,submerged in clearing buffer/equalwellheights,400–900nmscan and580nm comparison verified. Printed formula is scientifically suspect and correctly left flagged rather than silently used.
- E02–E11 and R07–R16: supplemental specificity complete; S2 all24h electrophoresis;S3 same60h25V37C;S4b1d electro versus6d passive independent;S5 residualSDS/storage confound preserved;S6 DGNeuN/AF488+DAPI3h 133/180um demonstration;S7 no expansion ratio;S8 no digitized numbers fabricated.
- R01–R06:30/48(or45)/51/55/61/57(or54)% values and pairwise significance preserved by comparison. Source conflict is real in PDFp6 as well as XML, not an extraction/OCR artifact.
- R17–R19:TH/AF555 and DAPI images positive;dendrite reconstruction colors not separate biological labels. Fig4 stack extents516.62/698.5um are not maximum depth. Basalganglia almostentire labeling is qualitative and not uniform wholebrain/celltype proof.
- R20 and time_audit: visually checked Fig2d PDFp4. Approx22d and2.6d agree with plotted bars; conditional stage sums22d and63h are clearly distinguished from exact experimental elapsed observations. Neither includes RI24h or tissue preparation. Generic “one week” headline cannot describe every PRE end-to-end workflow.
- F01–F04/F06–F07: direct vs indirect antibody modes and dye distinctions correct. Protein loss explicitly unassessed and repeat staining background-only. F05 absence classification requires correction as above.
- C01–C05: appropriately retain transmittance contradiction, formula concern, genericheadline problem, S4/S5mis-citation, and B6 buffer-reference ambiguity.

## R3 focused audit

Timing, specimen assignment, labeling, fluorescence evidence, clearing-vs-staining branch linkage, RI alternatives and observed-vs-inferred relationships have been independently checked. No additional numerical source error found. Remaining defects above are repairable provenance/structure/completeness issues. Final acceptance is withheld until revised files are independently reread and reference checks pass.

## R4 real gap-filling queries

See R4_independent_queries.json. Two live search batches sought supplement, DOI-specific correction, S6 details and fluorescence retention. Publisher and PMC bibliographic identification confirmed. No relevant correction or independent primary assay was found; results about other “modified CLARITY” papers excluded. Shared publisher supplement resolves supplement-access gap. No attempt to bypass CAPTCHA or access refusal; no author outreach performed. Source discrepancies and unavailable raw measurements remain unresolved.
