# A152 R1 visual addendum, 2026-10-19

Historical normalized v6.1 SHA256 a5462a507976a17b7b535c121d844ae63cead963d01a3a3f169f8c2024567be7 is an exact accepted version. It is retained unchanged in inherited_v6.1.json; inherited scientific acceptance is NOT restarted or reassigned to the new version.

Current work: read actual 7 main and 9 supplementary figures; S1 DOCX rows match inherited rows exactly; viewed 7 frames from each of 4 official supplementary movies, including Movie4's stated proximity window. Separate actual-viewing matrix and timestamp log are supplied. No graph digitization, statistical rerun, raw-stack replication or novel wet-lab optimization was performed.

New issues requiring review: S2/S3 SNR curves cross; S3/S4 actual panel depths disagree with captions; movie caption figure crosslinks appear stale. All prior unresolved source conflicts remain. Current source files were downloaded to private_sources only and are excluded from this derived package. Filename Fig*.jpg holds server image/png bytes; renderer detects content correctly, hashes in source manifest identify exact files.

Eligibility: prior semantic extraction retained as accepted within its prior scope. New R1 is a candidate with independent review pending. No full acceptance yet. After independent review, coverage can be assessed for published main/supplementary evidence; raw BioImageArchive stacks remain un-reanalyzed and are not required for an observational paper extraction, but cannot be claimed validated. Legacy antibody-chain, volume, acquisition and timing inconsistencies remain source uncertainties, not resolved facts.

Reviewer: independently inspect private source figures S2/S3/S4 and Movie4 frame window, compare correction IDs and synchronized Q answers, verify table equality and historical hash, then give scope-limited acceptance or concrete fixes. Do not infer biological n from 20 ROI, image counts, reused blocks or movie counts.
