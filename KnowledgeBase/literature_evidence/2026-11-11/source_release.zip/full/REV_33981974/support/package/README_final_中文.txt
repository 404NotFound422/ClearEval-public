REV_33981974 完整篇章复核交付包

文献：Tissue clearing and imaging methods for cardiovascular development
DOI：https://doi.org/10.1016/j.isci.2021.102387

最终状态：独立复核通过。权威最终验收为review/final_acceptance.json，其逐文件SHA256绑定17个派生候选文件。作者候选文件中pending/false是冻结时的历史阶段值；最终验收文件在不修改候选内容的前提下给出最终结论。

主数据为record_R2.json，配套CSV提供方法、时间角色、标签、成像、图示、结果、冲突和书目身份。R3_revision_response.json保留7项修改前后对照；review/R2_independent_review.json记录审查问题，review/independent_checks_R4.json记录全部独立回核。

核验范围：正文81段、17节、4幅来源实图、图2至4共14面板、图1的63个相容性单元、两表各21行。此次引用修订重检全部21方法、42条表行映射、61条限定论断归因及9份科学CSV全部单元。Sucrose从混挂38条变为两表仅bib194，另37条仅作上下文导航。

证据边界：193条仅为书目身份记录，零篇被引原始论文被提升为全文已验证。年龄、样本范围、天然GFP/抗体检测、时间边界及可疑原文挂引仍保留。未发现来源集所列补充材料，不代表证明不存在。书目中2026年更正仅记录通知，未评估其内容。

包中仅含派生记录、审查结论及清单。不含原论文全文、原图、完整sourceblocks、访问或下载脚本。未修改原库、未发布。归档实际解压与校验结果另见同级archive_verification.json。
