子宫与卵巢组织透明综述：已独立核验的派生证据包

文献：Liu等，2025，3D visualization of uterus and ovary: tissue clearing techniques and biomedical applications。
DOI：https://doi.org/10.3389/fbioe.2025.1610539
PMID：40692613；PMCID：PMC12277315。

状态：完成独立科学审阅与返修回核，在下述证据范围内验收。未公开发布。

内容：摘要与43段科学正文、3幅实际示意图、3张实表（21/8/3行）的完整综述拆解。包含26个归因单元、50条主张、11条阶段/时间记录、23项来源冲突或边界提示，以及138条参考文献的身份映射。该综述未发现已知补充材料。

证据边界：这是一篇二级综述，没有本文原创实验。138篇引文的身份核查不等于全文验证，所有original_fulltext_complete仍为false。Feng、Chung、Tong、McKey2022、Ma和Liu原文仅进行了明确标注的定向纠错选段核查，未声称完成每篇原始论文全部图表与补充。

关键校正：
1. Feng约300000倍是卵泡体积变化，不是数量。综述accumulate未定义同阶段聚集指标，不能据此断言聚集上升或已证实方向反转；该句原综述引用B45，Feng B31作为独立比较依据。
2. 24%和41%蛋白损失属于Chung的小鼠脑PFA/Triton及ScaleU2比较，不能当作CUBIC子宫或卵巢数据；50% Triton说法仍未核实。
3. Ma和Liu表1的mouse原值保留，另列rat纠正。Tong原文同时包含mouse及rat队列，不能把全篇统一改成大鼠。
4. McKey2020成年卵巢方法与2022胎发育研究分开。不同样本、终介质和成像分支不合并；Tong的SON与综述错误的SCN分开记录。
5. Ce3D的表1分类与图1/正文冲突。表2是未逐样本验证的泛化试剂表，不是通用兼容性证明或现成操作方案。

检索使用：复合主张优先使用claim_components逐子句引文。C38的possible_related_unit_ids仅为待证关联，不可用于肯定的研究绑定。source_conflicts需与主记录联合检索；assertion_eligible仅表示所写eligibility_scope内可用，不代表原始实验已经验证。F2五条路径只是原综述示意，禁止作为已验证推荐或评分规则。

时间与未知：Feng4–8周（28–56天）是被动清透阶段，不是免疫标记或总工期；大小/年龄依赖来自单列原始Methods选段。E15.5/E18.5、P0–P21等是发育年龄。未报告的尺寸、n、标记和阶段时间保持unknown，不补零、不跨研究拼接工期。

文件：record.json是最终核心；tables/含同步JSON及UTF-8 CSV；final_acceptance.json为独立审阅凭据；validation.json记录可复核检查；manifest.json列出每个交付文件的SHA256。CSV中数组/对象按JSON保存在单元格内，JSON为首选机器读取格式。

本包仅含派生文本和数据，不含原文、原图、视频、原始元数据响应或旧候选稿。excluded_source:ID是来源注册标识，不表示包中存在原始文件；使用来源ID、哈希、文献标识和段落定位回溯。固定组织透明、标记和成像为范围，上游手术、造模与活体操作不纳入。
