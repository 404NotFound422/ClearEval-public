# R006 组织光透明机制综述四轮审核派生包

本包针对Yu等2021年综述 Physical and chemical mechanisms of tissue optical clearing（DOI10.1016/j.isci.2021.102178），保存经四轮审核的科学提取与证据关系。原文全文、原始图片、完整原文块索引、reading_blocks及下载脚本均未收入本包，继续留在本地审查缓存。

## 已核内容

61段科学正文形成53条分层主张；6幅编号图及1幅图形摘要实际读图；5表78行、308单元格与5个结构图经过独立比对；2公式保留假设。138条书目title/year/DOI与综述原文对应，另有289次引用关系。11条时间记录、14项信号读出及30项被引样本情境分别存储，未知条件保留null。

审核证据见review/final_acceptance.json。签核输入记录以原字节保存在provenance/accepted_R2_record.json，最终record.json仅追加最终审核metadata，未改任何原有科学字段。metadata_only_diff.json记录该差异。R1历史提取记录也保留，但不携带其原文/图片缓存。

## 仍须遵守的证据范围

原始被引论文的完整全文独立核验数仍为0。Feng2016仅用原始摘要补核排序；Hua等仅用PubMed元数据补核2008年11月4日；FluoClearBABB仅用摘要/简介补核1-propanol/tert-butanol名称；NIST仅补核formamide氢键供体条目。不得将这些局部检查算作原始全文审查、数据复现或正式勘误。

完整缓存XML未声明补充材料，不代表出版方所有附件绝对不存在。遇到验证挑战的网页入口已停止访问。所有原图与全文是否实际读过，以独立审阅记录为证；原始资产不随派生包分发。

## 关键使用边界

式2的n_s=1.475和k=739.8仅对应589nm的Intralipid模型及固定粒径/密度条件，不作组织通用评分式。式1的a按综述保留mean diameter。RI表缺统一物性测量口径，不自动等于具体方法的终末介质RI；磷酸行保留原浓度限定8.5–14.2M。

60min猪皮观察、5–10min局部颅骨EDTA/SRS观察和ps模拟指标均不代表整器官总清透耗时。TIME04–11明确绑定处理环节、样本、读出与比较；ClearT的更有效不强制解释成更短时间。

七项原文冲突或措辞问题仍分列。Figure3B图注与正文排序不一致；外部摘要支持正文但不删除原冲突。脱水降低背景RI的方向疑点不作为无条件真值。LUCID猜测关联删除，TOMEI只留显式bib30，bib70保留为TDE段落上下文。B017内部块号采用sec2网页锚点回退，精确XPath不变。

## 离线核验

解压后在本目录执行：

python validate_package.py --derived-only --root .

该验证仅依赖标准Python与包内派生记录，检查签核哈希、字段一致性、主张/引用/时间关系、覆盖、文件类型和完整性。它不打开原图或原文，也不重新宣称完成科学读源。source_access_ledger.json保存来源网址与哈希；已签记录中的旧本地路径仅为历史来源信息，不是包内文件路径。

record.json的final_review_metadata与final_status.json为当前最终审核状态。record内原有record_version、review_rounds和release_status保留签核前历史值；当前四轮结果另见review_rounds.csv。

MANIFEST.json与SHA256SUMS.txt用于完整性核验；package_content_scan.json记录实际文件类型与完整正文段落复制检查。本包真实解压后再次运行derived-only验证。原证据库未修改，未发布GitHub或其他外部平台。
