# APP214：缺氧胰岛细胞外基质的3D评估

文献：Ramirez等，Islets，2024；DOI：10.1080/19382014.2023.2298518；PMCID：PMC10810165。

## 一句话结论
在人离体胰岛中，低氧下ECM的总体积占比未显示明确的组间变化，但中央聚集、层粘连蛋白节点减少及E-cadherin空间/强度改变提示组织结构改变。不能把“体积分数未显著变化”解释成ECM没有变化或证明等效。

## 完成范围
已逐项读取合法全文XML、主图1–7和图形摘要、附图1–3、附表1–3及完整DIA参数说明。来源与阅读记录可在record.json、reading_log.csv、source_block_index.json追溯。旧库未覆盖或修改。本小包只含派生记录、审查及验证材料，不含论文原图、全文XML或原附件。

本记录限于现成离体胰岛的固定、标记、透明与成像，以及论文报道的实验条件和结果。不包含动物手术、模型构建或试剂制造采购。CUBIC附表已读取并记录范围限制，不复写配方制造内容。

## 样本与流程
- 人胰岛来自2批供者，58岁/BMI29/HbA1c5.0%及32岁/BMI26.9/HbA1c4.9%；接收后恢复48小时。人样本承担ECM应用分析，也用于技术验证。
- 大鼠为雄性Wistar的已分离胰岛，主要用于技术、活性和分泌验证；不得把大鼠GSIS或DIA/RIA结论搬到人胰岛。
- 组别是ND1正常氧过夜、ND5正常氧总5天、HD5低氧总5天。Methods的正常氧为21% O2，低氧为1% O2，均5% CO2。图形摘要20%正常氧与Methods不一致，已保留。
- 固定、免疫标记、CUBIC1、琼脂糖包埋、CUBIC2过渡与终末折射率匹配、LSFM、DIA逐阶段建档。人一抗与二抗各3天；大鼠各7天。作者称人样本固定到DIA约10天，不能把3/7天当成两次孵育的总时间，也不对未明确的“过夜”强行换算小时。
- 人与大鼠光学设置不同。人LSFM检测20×/1.0；大鼠5×/0.16；共聚焦比较20×/0.8。四激发通道对应多套panel，并非所有标记同时采集。

## 主要可用数值
- 第5天活性：人ND5 88%、HD5 62%，p=.04；大鼠79%、29%，p=.001。
- 人层粘连蛋白节点：ND1 6.4、ND5 7、HD5 1.5；论文所标SD分别0.6、1.8、0.5；胰岛n分别5、9、4。HD5与正常氧组p<.05。
- 人E-cadherin平均强度：ND1 8598、ND5 6463、HD5 14805任意单位；HD5更高，p<.01。
- E-cadherin中央缺失区体积比例：2.5%、3.1%、8.6%，组间趋势未达显著。
- 同一个约180 µm人胰岛的LSFM/共聚焦采集时间3.5/31分钟；NA、位深、帧大小、切片数及采样厚度不同，不能推广为所有条件下固定倍数优势。

具体n、reported_SD、对照、定位及解释限制见quantitative_results.csv。图像只有散点或横线的数值未自行数字化补造。

## 必须保留的局限和来源矛盾
1. 人胰岛数不是独立供者数；仅2供者批次，供者与各组/各胰岛的对应未给。
2. Fig6D纤维连接蛋白ND1上方出现单星，而正文概括“无显著差异”；图未明确成对比较对象，不能宣称所有对比均不显著。
3. 附图S3的横线及散点离散程度与正文mean/SD定义有疑点。保留正文reported_SD，不擅改SEM。
4. 附图S2的ND5/G15汇总呈现与正文可能不一致；保留正文精确值和冲突，不用目测均值替代。
5. 大鼠抗兔AF488二抗表格列Chicken，multiplex #5列Donkey，尚不能判定实际使用哪一支。
6. 正文称无后处理滤镜，DIA导出模板有Number of Voxels下限10；模板的执行适用性不明。
7. Hoechst正文和附表均写3342；记录源文写法，不静默更改型号。CUBIC1温度正文未明示，未借用其他小节默认室温。
8. 正文中央坏死属于形态学提示；E-cadherin孔洞对应ECM瘢痕为推测。DIA阳性体积分数不是绝对蛋白质量。

## 文件索引
- record.json：主结构化记录，包含所有领域和来源定位。
- protocols.csv、markers.csv、secondary_antibodies.csv、multiplex_panels.csv：现成样本流程与荧光身份。
- imaging_channels.csv、imaging_comparison.csv：通道和模态比较。
- quantitative_results.csv、assays.csv：结果和验证读出。
- source_conflicts.csv、missing_fields.csv：尚未解决的明确缺口。
- review/：独立审校及来源补缺的派生记录。
- validation.json：结构、数字、CSV同步与派生小包检查。

公开来源：[全文](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10810165/fullTextXML)；[公开附录归档](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10810165/supplementaryFiles)。出版商历史403未重试；PMC页面出现reCAPTCHA后停止该入口；附件来自独立匿名公开EuropePMC服务。

原始图像仓库：[UCLouvain Dataverse](https://doi.org/10.14428/DVN/GVARMX)。独立审查读取了公开元数据，列出146个.ims文件；未下载这些大型图像做重分析，也未用库存文件数替代论文分析n。
