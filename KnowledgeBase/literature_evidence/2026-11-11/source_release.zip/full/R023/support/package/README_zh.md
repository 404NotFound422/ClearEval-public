# R023：组织清透与三维成像的生物医学应用

文献：Gómez-Gaviro 等，iScience 23(8), 101432，2020。DOI：[10.1016/j.isci.2020.101432](https://doi.org/10.1016/j.isci.2020.101432)。[PMC全文入口](https://pmc.ncbi.nlm.nih.gov/articles/PMC7452225/)。

## 当前状态

R1/R2冻结快照均保留不变。独立R2/R3审阅、19次R4定向查询，以及作者六项修订的独立回核均已通过。本综述已完成四轮验收，签署见review/final_acceptance.json。验收范围为完整JATS及全部列出图表，未另核PDF逐页版式。

全部科学条目属于综述层级（secondary）。参考文献身份索引不意味着读过被引论文全文；本记录中被引原始论文的完整全文核查数为0。实际图像属于综述实例或示意，不提升为方法一般有效性的证据。

## 已实际阅读

- 完整JATS的67个非图表正文段落。全部body p节点为87，其中16为图注段、4为表题/表注段
- 表1的61行、549个文本单元格；表2的23行、69个文本单元格及23个化学结构图
- 6张编号主图和1张图形摘要的原始图像
- 摘要与158个参考文献条目的身份索引
- 本版本JATS没有列出补充材料，PMC元数据为has-supplement=no；并非存在附件但没有下载
- 未另行阅读PDF版式，不声称逐页PDF核查

## 派生记录

- 38条综述主张，覆盖全部正文
- 92条器官、物种、方法、样本背景和结果绑定的应用记录
- 61条方法表事实、23条化学表事实
- 44条时间证据、27条数值证据、25条标记/报告系统记录
- 7条主图/图形摘要实读记录及25项源文冲突

JSON为嵌套主记录；CSV共14份，其中12份对应record.json的平面导出，另2份为sources.csv与reading_log.csv。未知值在JSON为null，在CSV为空白。布尔false与未报告null不同。所有方法性能、标签相容性、时间和尺寸都应连同来源位置、组织背景及限制一起使用。

## 最重要的使用边界

1. claims中的reference_ids是所列段落的背景引文集合，reference_scope明确标为paragraph_context_not_claim_level_support，不代表每条引文都直接支持细分主张。
2. 表1的“Protocol Length”通常没有给完整阶段边界。不得作为包含固定、免疫标记、洗涤、清透、RI匹配和成像的统一全流程时长。FASTClear的45分钟尤其不能当总流程；SCM的心脏/脑时间绑定存在错误风险。vDISCO的两个阶段分别保存，不相加。
3. 图4仅将小鼠心脏、CUBIC、Lectin-649Alexa与635 nm激发/670 nm发射联系起来。图4D/E是同一重建的两角度，不能计为两个样本。SPIM、VSNR Fiji去条纹和ImageJ重建也仅绑定该实例；NA、浸液、步长、曝光和时长未知。通用装置参数没有传播到各引用应用。
4. 图3只有七种器官的外观示例，没有n、定量透射率、逐器官时间或荧光保留率。图5/6只是器官与方法索引。
5. 3DISCO/iDISCO合并行的NY不能拆成两种方法的精确相容性。表中Y/N属于作者综述概括，不是所有标签和样本的保证。
6. EyeCi、LUCID、PARS、SCM、ReagentF、SeeDB等行存在引用归属差异。原表保留，并单列冲突，未悄悄替换为新的原始证据。
7. 正文与图1的589/590 nm及531/534 nm不同；光片厚度“t2 μm”无法可靠标准化。表2的DCM、tert-butanol分子量含引文污染；Triton X-、PEG和saponin身份范围也有限。相关规范数值保留null。
8. 活体皮肤/颅骨段落已读，但不导出活体增透或动物操作参数。动物疾病建模、手术、基因/病毒构建、病原操作等上游内容不在本派生包范围。
9. 淋巴结75%甘油和大鼠颞骨前处理5%明胶分别绑定其组织与阶段，百分比基准未知；75%不赋给FocusClear。胶原结构作为观察目标保存，不能当已明确荧光标签。LacZ、纳米颗粒、FP、抗体、染料和FISH已区分类别，未知荧光团不补写。
10. Dong垂直扫描LSFM结肠应用与Arranz炎症结肠结构变化分别记录。病理活检条目的human仅作为语境推定，明示物种字段为null。
11. “临床诊断潜力”不能解释为临床敏感度、特异度或患者结局已验证。

## 文件

record_R1.json为未改动的初次冻结快照；record_R2.json为独立验收所签署的科学修订快照。record.json是当前已验收别名，科学字段与record_R2.json完全相同，仅验收状态和审阅日志更新；CSV对应record.json。冻结快照中的历史待验收状态不代表当前状态，当前验收以review/final_acceptance.json为准。revision_R2_changes.json记录六项返修及溶剂分类字段澄清。claims、applications、methods、chemical_facts、time_evidence、numeric_evidence、markers、figures、references、source_conflicts、missing_fields等CSV与JSON对应。

reading_log.csv逐项记录正文、表行及源图的阅读覆盖。source_locator_index.json提供不含正文原文的定位与哈希索引。sources.csv提供公开来源与源文件哈希。coverage.json和structure_check.json说明当前覆盖与结构检查；结构检查不是独立科学验收。

原文XML、PDF、原图和长篇原文摘录均不作为交付文件。原始来源仅用于私下核验；只交付派生数据和来源链接。旧资料库未修改。
