# A103｜CAA尸检脑Aβ空间分布证据拆解

版本：0.1.1-revised-for-reaudit；状态：来源核读草稿，未计完成。



Expansive spatial pattern of Aβ deposition in patients with cerebral amyloid angiopathy: A three-dimensional surface-to-depth analysis

Hayashi等，Science Advances 12(6):eaea7539，正式发表2026-02-06。DOI：10.1126/sciadv.aea7539。

来源：[PMC正式版](https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)。仅用正式版及其补充，不用2024预印本。



## 科学问题与关键边界

组织透明化与三维光片成像揭示了CAA尸检脑中怎样的连续血管及血管周Aβ空间分布，其证据边界是什么？

- 6尸检患者→每人额/枕2块，共12块→1639血管单位→分支段/血管周spots。两个CAA阴性对照另行质性呈现。

- 3D支持连续动脉树的空间定位；不实测时间进展、清除流向或治疗作用。

- 正文1104阳性与DataS1的1108标记为待解释计数不一致。原始来源各自保留。



## 问题索引

### A103-GQ-001｜可分析人群与血管层级

组织透明化与3D成像能在何种患者、脑区和血管层级描述CAA分布？

6名CAA尸检患者、12块额/枕叶样本；正文1639单位中1104阳性（额513/865、枕591/774）。DataS1标记1108阳性，待解释。直接双标和光片3D可追踪连续动脉树；≥8µm动脉/小动脉，未量化毛细血管/静脉。未量化比较透明化性能。

支持：A103-E01/A103-E01-O01, A103-A03/作者/审计陈述



### A103-GQ-002｜Aβ空间阶次分布

Aβ是否以脑表面和浅分支段受累为主？

LMA、D0正文阳性率96.2%、99.5%；更深段整体较少但D4→D5不单调。D0–D1正文97.9%与Fig3A箱体约半数不一致。11条跳过中间皮层段的例外仍有LMA或D0阳性。D为分支阶次；静态连续性不能确证时间传播。

支持：A103-E02/A103-E02-O01, A103-E02/A103-E02-O02, A103-A01/作者/审计陈述



### A103-GQ-003｜SMA缺失位置

SMA信号缺失是否也以表浅段为主？

正文547/1104阳性单位有SMA缺失；每样本最浅缺失位置中位数LMA40%、D0 21%、D1及更深0%。分母是该样本有SMA缺失的单位；未评价Aβ阴性单位，信号不能追踪不是直接细胞计数。

支持：A103-E03/A103-E03-O01



### A103-GQ-004｜D0外径

Aβ阳性单位的D0外径与阴性单位是否不同？

阳性36.73(29.41–44.45)µm、阴性25.94(20.47–33.39)µm，报告P=1.73×10^-67。额/枕外径n.s.。外径不是管腔径；未报告患者聚类校正，且可能包含dyshoric邻近信号。DataS1+标记n=1108与正文1104待解释。

支持：A103-E04/A103-E04-O01, A103-E04/A103-E04-O02, A103-E04/A103-E04-O03



### A103-GQ-005｜球形SP长度密度

Aβ阳性血管周围球形SP密度是否降低，范围是什么？

整体阴性.0218(.0142–.0300)对阳性.0189(.0131–.0261)spots/µm，P=.0001；额阴性较高，枕P=.130且图中阳性中位线略高（定性读图）。不是所有脑区方向一致或均显著。spots/filament长度不是体积密度/总Aβ；最终分组n未完整报告。

支持：A103-E05/A103-E05-O01, A103-E05/A103-E05-O02, A103-E05/A103-E05-O03, A103-A02/作者/审计陈述



### A103-GQ-006｜dyshoric沉积

未纳入球形SP算法的dyshoric沉积出现在哪里？

纳入465皮层Aβ阳性单位中12.7%有dyshoric变化；6样本来自Pt1/4/5双脑区，各样本3.4–66.7%；D0占全部受累段91.5%。精确阳性整数与各样本分母未报，不反推。

支持：A103-E06/A103-E06-O01



### A103-GQ-007｜与2D组织学相邻区域核验

3D斑块外观与相邻传统组织学的验证达到什么程度？

Pt2/Pt6额叶的3D截面与相邻2D染色区域外观可比，neuritic/diffuse成分影响强度；没有单斑块一对一匹配、准确率或等效性检验。 S1只绑定Aβ邻片比较，不绑定共同组织学中的其余染色为同片串行操作。

支持：A103-E07/A103-E07-O01



### A103-GQ-008｜双光片系统比较

两台光片系统是否获得相同量化结果？

S5只展示Pt4/6小额叶块的SMA血管外观无明显差别；不等于Aβ信号、定量分布或分辨率等效。主分析Pt1/3/5枕叶用Olympus，其余用Blaze。 S5 small samples尺寸未报，主队列0.5cm³和两系统的具体设置不能自动当S5实用参数。

支持：A103-E08/A103-E08-O01



### A103-GQ-009｜阴性对照与背景

CAA阴性对照是否完全无Aβ通道信号？

不是。S6两位阴性患者显示实质几乎无沉积，但29岁例有脑表面非特异信号，83岁例有双通道自发荧光。不能写零背景或严格特异性数值；两例不进入6名CAA统计主队列。

支持：A103-E09/A103-E09-O01, A103-E09/A103-E09-O02



### A103-GQ-010｜方法与来源的可恢复边界

原文参数能否恢复为唯一已确认实施的流程？

主文给出处理梯度及成像分配，但Fig1A与方法末两次100%MeOH顺序和BABB时长不同；多个图文/数据/距离定义差异未解释。Protocol保留原报告、缺项与冲突，不补未知、不借外部参考当实际用值。

支持：A103-A04/作者/审计陈述



## 患者与取材背景

{
  "patient_count": 6,
  "analyzed_region_samples": 12,
  "regions_per_patient": 2,
  "patients": [
    {
      "patient_id": "Pt1",
      "age_years": 74,
      "sex": "M",
      "CAA_type": 2,
      "CAA_Thal_stage": 2,
      "vascular_Abeta_load_frontal": "low",
      "vascular_Abeta_load_occipital": "moderate",
      "APOE_genotype": "3/3",
      "other_pathological_diagnoses": "—",
      "source_refs": [
        "F17"
      ]
    },
    {
      "patient_id": "Pt2",
      "age_years": 95,
      "sex": "M",
      "CAA_type": 2,
      "CAA_Thal_stage": 2,
      "vascular_Abeta_load_frontal": "low",
      "vascular_Abeta_load_occipital": "moderate",
      "APOE_genotype": "3/3",
      "other_pathological_diagnoses": "AD",
      "source_refs": [
        "F17"
      ]
    },
    {
      "patient_id": "Pt3",
      "age_years": 67,
      "sex": "M",
      "CAA_type": 2,
      "CAA_Thal_stage": 2,
      "vascular_Abeta_load_frontal": "moderate",
      "vascular_Abeta_load_occipital": "high",
      "APOE_genotype": "3/3",
      "other_pathological_diagnoses": "AD; MSA",
      "source_refs": [
        "F17"
      ]
    },
    {
      "patient_id": "Pt4",
      "age_years": 79,
      "sex": "F",
      "CAA_type": 1,
      "CAA_Thal_stage": 3,
      "vascular_Abeta_load_frontal": "moderate",
      "vascular_Abeta_load_occipital": "high",
      "APOE_genotype": "3/3",
      "other_pathological_diagnoses": "AD; PD(limbic)",
      "source_refs": [
        "F17"
      ]
    },
    {
      "patient_id": "Pt5",
      "age_years": 78,
      "sex": "F",
      "CAA_type": 1,
      "CAA_Thal_stage": 3,
      "vascular_Abeta_load_frontal": "high",
      "vascular_Abeta_load_occipital": "high",
      "APOE_genotype": "3/3",
      "other_pathological_diagnoses": "AD",
      "source_refs": [
        "F17"
      ]
    },
    {
      "patient_id": "Pt6",
      "age_years": 84,
      "sex": "M",
      "CAA_type": 1,
      "CAA_Thal_stage": 2,
      "vascular_Abeta_load_frontal": "high",
      "vascular_Abeta_load_occipital": "high",
      "APOE_genotype": "4/4",
      "other_pathological_diagnoses": "AD; CPM/EPM; PD(limbic)",
      "source_refs": [
        "F17"
      ]
    }
  ],
  "MRI_context": {
    "available_patients": 5,
    "white_matter_hyperintensity": 5,
    "EPVS": 4,
    "T2star_available": 4,
    "microbleeds": 3,
    "lobar_hemorrhage": "Pt5; grossly hemorrhagic sample regions excluded",
    "source_refs": [
      "F02",
      "F13",
      "F14",
      "F17"
    ]
  },
  "controls": "Two additional CAA-negative patients shown qualitatively in Fig.S6, excluded from 6-patient analytic cohort",
  "nested_units": "patient -> two region blocks -> continuous vascular units -> branch segments / perivascular spots",
  "count_conflict": "main 1104 Aβ+ vs DataS1 1108 + rows; unresolved, no source overwritten"
}



## 实验与观测

### A103-E01｜CAA尸检额叶与枕叶组织中动脉血管单位的3D重建与Aβ阳性分布

透明化、直接双标和光片成像使固定组织块的连续动脉树可追踪；未设置透明度、穿透深度、信号保留或其他透明化方法的量化性能对照。

样本 caa_frontal：Homo sapiens—central nervous system—brain—frontal lobe including middle frontal gyrus—six frontal tissue blocks from six CAA patients

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

样本 caa_occipital：Homo sapiens—central nervous system—brain—occipital Brodmann areas18/19 retaining leptomeningeal arteries—six occipital tissue blocks from same six CAA patients

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E01-G01：额叶；样本=caa_frontal；方法=A103-P001 + A103-P002 + A103-P004 + A103-P005。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "血管单位追踪", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

条件 A103-E01-G02：枕叶；样本=caa_occipital；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "血管单位追踪", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

#### A103-E01-O01｜Aβ阳性血管单位数/全部可分析血管单位数

图/位置：Fig.1B–E; Results first subsection；时间：尸检横断面；没有纵向测量。

所选组：A103-E01-G01, A103-E01-G02；样本：caa_frontal, caa_occipital

额叶513/865=59.3%；枕叶591/774=76.4%；合计1104/1639。6名患者各取额、枕叶组织，共12样本。

统计：{"test": "此计数汇总未报告区域差异检验"}

原文值/分母：[{"group_id": "A103-E01-G01", "value": 59.3, "unit": "%", "numerator": 513, "denominator": 865, "n_unit": "vascular units, clustered in 6 frontal samples from 6 patients", "value_type": "source_text_exact"}, {"group_id": "A103-E01-G02", "value": 76.4, "unit": "%", "numerator": 591, "denominator": 774, "n_unit": "vascular units, clustered in 6 occipital samples from same 6 patients", "value_type": "source_text_exact"}]

限制：正文1104与Data file S1的1108阳性标记冲突，保留双来源；不用文件重写正文计数。；6患者、12组织块、1639血管单位为不同层级；不能将血管单位视为独立生物重复。

来源：F01, F02, F17, F20



### A103-E02｜CAA阳性动脉单位中的Aβ沉积以LMA与浅表分支段为主

定位沉积沿连续树的分支阶次分布

样本 caa_Apos_trees：Homo sapiens—central nervous system—brain—frontal (including middle frontal gyrus) and occipital (Brodmann areas 18/19)—正文1104 Aβ阳性连续血管单位，嵌套于12块/6患者

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E02-G01：全部正文Aβ阳性血管单位；样本=caa_Apos_trees；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "追踪/分段/阳性判定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

#### A103-E02-O01｜每样本各分支段Aβ阳性率；D为分支阶次

图/位置：Fig.2A–D; Fig.3A；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E02-G01；样本：caa_Apos_trees

原文报告LMA96.2%、D0 99.5%、D0–D1分叉97.9%、D1 45.8%、D2 19.8%、D3 10.0%、D4 4.5%、D5 6.3%、D6及更深0%。Fig.3A显示各样本比例的箱图；不是每个百分比都以1104为同一分母。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[{"segment": "LMA", "value": 96.2, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D0", "value": 99.5, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D0-D1", "value": 97.9, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D1", "value": 45.8, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D2", "value": 19.8, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D3", "value": 10.0, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D4", "value": 4.5, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D5", "value": 6.3, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}, {"segment": "D6+", "value": 0, "unit": "%", "value_type": "source_text_exact", "denominator": "segment-specific evaluable vascular segments/units within each sample; exact counts not provided", "aggregation_note": "fig3A is per-sample boxplot; text does not explicitly name aggregation for these listed percentages"}]

限制：D0到D6是分支顺序，不是固定物理深度或皮层层号。；D5值高于D4，不能写严格单调下降。；每样本每段可评估分母和原始数据未给。；正文D0–D1为97.9%，Fig.3A对应箱体中心可见约半数而非近100%；未做图形数值化。作为待解释的图文/汇总不一致，不能用任一方静默覆盖。

来源：F04



#### A103-E02-O02｜连续沉积及跳跃沉积例外

图/位置：Fig.2D; Fig.3A；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E02-G01；样本：caa_Apos_trees

多数单位的Aβ分布由表浅向深层解剖连续；11条单位深部沉积跳过中间皮层段，但这些例外仍有LMA或D0阳性。额/枕、low/moderate/high、CAA type1/2分层的表浅富集方向相似。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[{"value": 11, "unit": "vascular units", "value_type": "source_text_exact"}]

限制：讨论6.2%白质局限沉积的分母不明；不能与11/1639的<0.7%直接等同。；横断面空间相连不能单独证明沉积扩展的时间方向。

来源：F04, F09



### A103-E03｜Aβ阳性血管中SMA信号缺失的最浅位置以LMA和D0为主

将平滑肌信号缺失与Aβ分布关联

样本 caa_Apos_SMA：Homo sapiens—central nervous system—brain—frontal (including middle frontal gyrus) and occipital (Brodmann areas 18/19)—正文1104 Aβ阳性血管单位，其中547条有SMA信号缺失

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E03-G01：全部Aβ阳性单位中的SMA判读；最浅缺失位置分析限其SMA-loss子集；样本=caa_Apos_SMA；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005 + A103-P006。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "单位/段界定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P006", "sequence": 5, "stage": "SMA-only通道判读", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F05"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

#### A103-E03-O01｜SMA缺失单位计数及最浅缺失段比例

图/位置：Fig.2C–D; Fig.3B；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E03-G01；样本：caa_Apos_SMA

正文547/1104条Aβ阳性单位有SMA缺失。每样本最浅SMA缺失段分布中位数：LMA40%，D0 21%，D1 0%；更深段中位数0%。深层缺失通常伴表浅缺失；未评估Aβ阴性单位的SMA缺失。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[{"metric": "SMA-loss units", "numerator": 547, "denominator": 1104, "unit": "vascular units", "value_type": "source_text_exact"}, {"segment": "LMA", "value": 40, "unit": "%", "summary": "median of per-sample distribution", "denominator": "all SMA-loss vascular units in each sample"}, {"segment": "D0", "value": 21, "unit": "%", "summary": "median", "denominator": "all SMA-loss vascular units in each sample"}, {"segment": "D1 and deeper", "value": 0, "unit": "%", "summary": "median", "denominator": "all SMA-loss vascular units in each sample"}]

限制：不可把40%等解释为所有LMA段的SMA缺失概率；是最浅缺失段位置分布。；缺失定义为SMA通道不能追踪，不是直接平滑肌细胞计数；非Aβ血管病参与未知。

来源：F05, F09



### A103-E04｜Aβ阳性血管单位的D0外径大于阴性单位

核对外径读数、分层检验与血管数分母

样本 diameter_units：Homo sapiens—central nervous system—brain—frontal (including middle frontal gyrus) and occipital (Brodmann areas 18/19)—所有1639血管单位D0外径，6患者12块

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E04-G01：Aβ阴性；样本=diameter_units；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005 + A103-P007。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "单位判定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P007", "sequence": 5, "stage": "D0外径测量", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F06"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

条件 A103-E04-G02：Aβ阳性；样本=diameter_units；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005 + A103-P007。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "单位判定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P007", "sequence": 5, "stage": "D0外径测量", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F06"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

#### A103-E04-O01｜D0血管外径

图/位置：Fig.4A–C；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E04-G01, A103-E04-G02；样本：diameter_units

Aβ阳性36.73(29.41–44.45)µm，大于阴性25.94(20.47–33.39)µm，Mann–Whitney U P=1.73×10^-67；是外径，不是管腔径。

统计：{"test": "Mann–Whitney U", "p_value": "1.73e-67", "analysis_unit": "vascular unit", "clustering_adjustment": "not reported"}

原文值/分母：[{"group": "Aβ+", "value": 36.73, "q1": 29.41, "q3": 44.45, "summary": "median (25th–75th percentile)", "unit": "µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "Aβ−", "value": 25.94, "q1": 20.47, "q3": 33.39, "summary": "median (25th–75th percentile)", "unit": "µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}]

限制：血管级比较包含同一患者/样本内多条单位，未报告聚类或配对调整；极小P不等同6患者独立证据量。；可能测到中膜外界；dyshoric Aβ与血管壁重叠可能扩大测量，不能解释为功能性扩张已证明。；原文阳性1104与Data S1阳性1108有待解释的计数不一致，不能指定本检验确切阳性n。

来源：F06, F10, F20



#### A103-E04-O02｜区域和亚组D0外径比较

图/位置：Fig.4C–D；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E04-G01, A103-E04-G02；样本：diameter_units

额32.72(25.09–42.03)µm、枕33.85(26.08–41.36)µm；正文P=.357，Fig4C P=.3572，均n.s.。阳性>阴性的亚组P：额2.32×10^-48、枕7.20×10^-21、low7.44×10^-5、moderate4.06×10^-28、high5.89×10^-14、type1 2.12×10^-24、type2 8.52×10^-14。

统计：{"test": "Mann–Whitney U for each two-group comparison", "p_values": {"region_text": 0.357, "region_figure": 0.3572, "Frontal_Apos_vs_Aneg": "2.32e-48", "Occipital_Apos_vs_Aneg": "7.20e-21", "low": "7.44e-5", "moderate": "4.06e-28", "high": "5.89e-14", "type1": "2.12e-24", "type2": "8.52e-14"}}

原文值/分母：[{"group": "Frontal", "value": 32.72, "q1": 25.09, "q3": 42.03, "summary": "median (25th–75th percentile)", "unit": "µm", "n": 865, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "Occipital", "value": 33.85, "q1": 26.08, "q3": 41.36, "summary": "median (25th–75th percentile)", "unit": "µm", "n": 774, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}]

限制：本文误指区域比较为Fig3C，实际对应Fig4C；保留原错指。；分层不是新患者队列；CAA负荷组按样本划分，患者可跨不同负荷组。

来源：F06, F10



#### A103-E04-O03｜Data S1逐行核对的单位数量与正文关系

图/位置：Data file S1 sheet vascular_unit_diameter rows2–1640；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E04-G01, A103-E04-G02；样本：diameter_units

只读Excel A1:F1640含1639记录、6患者；Region额865/枕774吻合。列vascular unit Aβ +/-以精确“+”计为1108（额516/枕592），“−”实际ASCII“-”计为531；正文对应1104（额513/枕591）、推算阴535。字段名、表说明未给另行排除4行的规则；暂作待解释计数不一致，不断言何者错误。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[{"value": 1108, "unit": "rows marked +", "value_type": "derived_from_supplement", "formula": "count(C2:C1640 == \"+\")"}, {"value": 531, "unit": "rows marked -", "value_type": "derived_from_supplement", "formula": "count(C2:C1640 == \"-\")"}]

限制：补充说明称all vascular units，正文未交代可匹配的4条排除规则；不按自动计数修正文中结果。；补充中位数与正文相符，四分位小差可能来自JMP与线性插值约定；不当成科学矛盾。

来源：F19, F20, F01



### A103-E05｜皮层Aβ阳性单位周围可识别球形SP的长度归一化密度较低

区分球形SP空间密度与总脑实质Aβ负荷

样本 cortical_plaque_units：Homo sapiens—central nervous system—brain—frontal (including middle frontal gyrus) and occipital (Brodmann areas 18/19)—用于斑块分析的皮层血管单位；从1639排除伪影299，另排穿白质血管；最终n及组分母未完整报告

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E05-G01：皮层Aβ阴性血管单位邻近斑块；样本=cortical_plaque_units；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005 + A103-P008。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "filament追踪", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P008", "sequence": 5, "stage": "SP spots识别与长度归一化", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F07"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

条件 A103-E05-G02：皮层Aβ阳性血管单位邻近斑块；样本=cortical_plaque_units；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005 + A103-P008。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "filament追踪", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P008", "sequence": 5, "stage": "SP spots识别与长度归一化", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F07"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

#### A103-E05-O01｜每血管单位10–100µm范围内SP spots数/filament总长

图/位置：Fig.5A–C,H–I；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E05-G01, A103-E05-G02；样本：cortical_plaque_units

阴性邻近SP密度0.0218(0.0142–0.0300) spots/µm，高于阳性0.0189(0.0131–0.0261)，P=.0001。只包含可识别球形斑块，不包含dyshoric线性沉积。

统计：{"test": "Mann–Whitney U", "p_value": 0.0001, "analysis_unit": "cortical vascular unit", "final_n": "not unambiguously reported after artifact and white-matter exclusions"}

原文值/分母：[{"group": "Aβ−", "value": 0.0218, "q1": 0.0142, "q3": 0.03, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "Aβ+", "value": 0.0189, "q1": 0.0131, "q3": 0.0261, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}]

限制：299伪影排除后算术剩1340不能自动作为最终斑块分析n，因白质排除另有规定。；距离表述存在filament/斑块中心示意与血管surface文字歧义；不是核实的固定体积壳层。；原文声称total filament length2.36×10^5 µm，median1.55×10^3(1.02–2.31×10^3)；斑块总4.72×10^4，median30(19–45)。量级/最终分母关系未解释，保留不猜改指数。；长度归一化不等于体积密度、总Aβ浓度或负荷，亦不计斑块强度/每斑块含量。

来源：F07, F10



#### A103-E05-O02｜SP密度区域、血管Aβ负荷及CAA类型比较

图/位置：Fig.5D–G；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E05-G01, A103-E05-G02；样本：cortical_plaque_units

额0.0200(.0139–.0261)与枕.0202(.0126–.0284)spots/µm，P=.9707；low.0211(.0146–.0300)、moderate.0171(.0112–.0243)、high.0216(.0147–.0294)。Kruskal–Wallis P=6.17×10^-12；Steel–Dwass低/中P=4.72×10^-6、高/中2.05×10^-11、低/高.998。Type1 .0208(.0146–.0276) > type2 .0191(.0121–.0272)，P=.0024。

统计：{"tests": "Mann–Whitney U (two groups); Kruskal–Wallis then Steel–Dwass (three groups)", "p_values": {"region": 0.9707, "Kruskal_Wallis": "6.17e-12", "low_vs_moderate": "4.72e-6", "high_vs_moderate": "2.05e-11", "low_vs_high": 0.998, "type1_vs_type2": 0.0024}}

原文值/分母：[{"group": "Frontal", "value": 0.02, "q1": 0.0139, "q3": 0.0261, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "Occipital", "value": 0.0202, "q1": 0.0126, "q3": 0.0284, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "low", "value": 0.0211, "q1": 0.0146, "q3": 0.03, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "moderate", "value": 0.0171, "q1": 0.0112, "q3": 0.0243, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "high", "value": 0.0216, "q1": 0.0147, "q3": 0.0294, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "type1", "value": 0.0208, "q1": 0.0146, "q3": 0.0276, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}, {"group": "type2", "value": 0.0191, "q1": 0.0121, "q3": 0.0272, "summary": "median (25th–75th percentile)", "unit": "spots/µm", "n": null, "n_unit": "vascular units; nested in 12 blocks/6 patients", "value_type": "source_text_exact"}]

限制：血管Aβ负荷low/mod/high为涉及血管的比例分组，不是直接严重血管病评分，也不是病程早中晚分组。

来源：F07, F10



#### A103-E05-O03｜每分层内Aβ阴性/阳性邻近SP密度

图/位置：Fig.5I；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E05-G01, A103-E05-G02；样本：cortical_plaque_units

Fig5I分层Aβ±比较：额叶阴性单位邻近SP密度较高，P<.0001；枕叶P=.130，未显示显著差异，图示中位线阳性略高于阴性（仅定性读图，不数字化取值）。low P=.0338、moderate P<.0001、high P<.0001、type1 P=.0136、type2 P<.0001的图示方向为阴性较高。Discussion“不受解剖位置影响”的统一逆关系强于实际枕叶证据，不能写所有脑区方向一致或均显著。

统计：{"test": "Mann–Whitney U", "p_values_figure_labels": {"frontal": "<0.0001", "occipital": 0.13, "low": 0.0338, "moderate": "<0.0001", "high": "<0.0001", "type1": 0.0136, "type2": "<0.0001"}, "source": "visually read exact printed P labels; no bar-height digitization"}

原文值/分母：[]

限制：n.s.不是等效；各分层为相同6患者来源，未报告患者聚类模型。；枕叶的中位方向与总体/额叶不同；n.s.不代表两组相等，不能用总体方向补该亚组。

来源：F07, F09, F10



### A103-E06｜皮层Aβ阳性单位中的dyshoric沉积主要位于D0

保留算法未计入的线性血管周Aβ空间读数

样本 dyshoric_cortical：Homo sapiens—central nervous system—brain—frontal (including middle frontal gyrus) and occipital (Brodmann areas 18/19)—纳入465条皮层Aβ阳性血管单位；阳性dyshoric样本来自Pt1/4/5额、枕叶

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E06-G01：纳入皮层Aβ阳性单位；样本=dyshoric_cortical；方法=A103-P001 + A103-P002 + (A103-P003 OR A103-P004) + A103-P005 + A103-P009。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "取材/固定", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F02", "F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "仅Pt1/3/5枕叶；与P004互斥成像分支，不在同一样本上串行重复", "alternative_group": "LSFM_platform", "condition": "Pt1/3/5 occipital"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM分支", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "其余研究样本；与P003互斥成像分支", "alternative_group": "LSFM_platform", "condition": "all remaining main-cohort samples"}, {"protocol_id": "A103-P005", "sequence": 4, "stage": "单位/深度分段", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F04"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P009", "sequence": 5, "stage": "dyshoric独立判读", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F08"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

#### A103-E06-O01｜伴dyshoric线性Aβ沉积单位的比例和段分布

图/位置：Fig.S2A–C; Results pp5–6；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E06-G01；样本：dyshoric_cortical

465条皮层Aβ阳性单位中12.7%出现dyshoric变化。发生于Pt1、4、5的额/枕六样本：Pt1F66.7%、Pt1O23.6%、Pt4F27.0%、Pt4O24.3%、Pt5F3.4%、Pt5O13.6%。D0占全部受累段91.5%。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[{"metric": "dyshoric-positive units", "value": 12.7, "denominator": 465, "unit": "%", "numerator": null, "value_type": "source_text_exact"}, {"metric": "affected segments located at D0", "value": 91.5, "unit": "%", "denominator": "all affected segments; count not reported", "value_type": "source_text_exact"}, {"sample": "Pt1F", "value": 66.7, "unit": "%", "denominator": "cortical Aβ-positive vascular units in that sample; counts not reported", "value_type": "source_text_exact"}, {"sample": "Pt1O", "value": 23.6, "unit": "%", "denominator": "cortical Aβ-positive vascular units in that sample; counts not reported", "value_type": "source_text_exact"}, {"sample": "Pt4F", "value": 27.0, "unit": "%", "denominator": "cortical Aβ-positive vascular units in that sample; counts not reported", "value_type": "source_text_exact"}, {"sample": "Pt4O", "value": 24.3, "unit": "%", "denominator": "cortical Aβ-positive vascular units in that sample; counts not reported", "value_type": "source_text_exact"}, {"sample": "Pt5F", "value": 3.4, "unit": "%", "denominator": "cortical Aβ-positive vascular units in that sample; counts not reported", "value_type": "source_text_exact"}, {"sample": "Pt5O", "value": 13.6, "unit": "%", "denominator": "cortical Aβ-positive vascular units in that sample; counts not reported", "value_type": "source_text_exact"}]

限制：不从12.7%反推精确59条；每例分母未报告。；dyshoric变化未进入E05 spot计数，不能把二者相加成已验证总Aβ负荷。；465对应纳入皮层阳性单位；与1639/1104的筛选谱系未完整逐行给出。

来源：F08, F12



### A103-E07｜Pt2与Pt6额叶3D切面和相邻常规Aβ染色的质性比较

界定3D斑块外观核验的范围

样本 pt2_pt6_frontal_3d：Homo sapiens—central nervous system—brain—frontal cortex—Pt2、Pt6额叶3D组织与相邻薄切片

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"description": "main analytic blocks reported as 0.5 cm³; Fig.1A source slab 1 cm thick is not block thickness", "volume_value": 0.5, "volume_unit": "cm³", "thickness_value": null, "thickness_unit": null, "thickness_stage": "not reported for individual 3D block", "status": "partial_report"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

样本 pt2_pt6_frontal_2d：Homo sapiens—central nervous system—brain—frontal cortex—相邻4µm石蜡切片

初始状态：Autopsy delay 250±116 min (range150–480); 10% buffered formalin, fixed 2–3 years. No new intervention; retrospective postmortem material.

尺寸：{"thickness_value": 4, "thickness_unit": "µm", "thickness_stage": "paraffin section", "status": "reported"}

标记：[{"reagent_name": "anti-Aβ11–28", "manufacturer": "IBL, Gunma, Japan", "dilution": "1:50", "target": "Aβ11–28 epitope", "fluorophore": null, "signal_source": "conventional immunohistochemistry", "observed_structure": "parenchymal Aβ plaques and vascular Aβ", "antigen_retrieval": "formic acid", "source_refs": ["F02", "F11"]}]

条件 A103-E07-G01：3D截面（Pt2 A; Pt6 C）；样本=pt2_pt6_frontal_3d；方法=A103-P001 + A103-P002 + A103-P004。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "固定取材", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/双标", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze LSFM", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补"}]

条件 A103-E07-G02：相邻2D IHC（Pt2 B; Pt6 D）；样本=pt2_pt6_frontal_2d；方法=A103-P010[共同路线；S1仅Aβ邻片分支，其他染色未绑定]。

方法关联与缺项：[{"protocol_id": "A103-P010", "sequence": 1, "stage": "共同传统组织学路线中的Aβ邻片分支", "binding_basis": "sample_schedule_match", "stored_steps": "common_histology_reference_with_Abeta_branch", "source_refs": ["F02", "F11"], "step_selection": "all_recorded_rows", "note": "P010为研究共同组织学路线；FigS1只绑定4µm相邻切片的Aβ免疫组化分支。H&E、Klüver–Barrera、p-tau和p-α-synuclein不作为该S1切片串行实做。兼容读取器仍返回全行作共同方法背景，需按本note人工限定；不声称机器已筛步骤或染色子分支。", "audit_status": "S1_Abeta_branch_only; other_stains_not_bound_to_same_slice"}]

#### A103-E07-O01｜区域斑块分布与信号外观

图/位置：Fig.S1A–D；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E07-G01, A103-E07-G02；样本：pt2_pt6_frontal_3d, pt2_pt6_frontal_2d

Pt2额叶以neuritic plaques为主、Aβ信号较强；Pt6以diffuse plaques为主、信号较弱。相邻2D与3D截面区域分布/数量外观可比；没有逐一匹配单斑块或计算准确率。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[]

限制：S1图注末(C,D) IHC与图像A/C为3D、B/D为2D关系不符，保留面板归属疑点。；3D抗体表位17–24与一般2D方法11–28不同；无等效性统计。；P010列出研究共同组织学；S1不证明H&E/Klüver–Barrera/p-tau/p-α-syn在同一相邻切片串行执行。

来源：F01, F11



### A103-E08｜同一额叶小样本的两光片系统SMA外观比较

说明两仪器使用的验证强度

样本 pt4_pt6_frontal_SMA：Homo sapiens—central nervous system—brain—frontal lobe—Pt4与Pt6小额叶块，在两个光片系统成像

初始状态：来源为主CAA队列Pt4、Pt6的固定额叶小样本；S5未逐例重列固定时长、原块尺寸或是否再次切小。主队列10%缓冲福尔马林固定2–3年只作背景。

尺寸：{"description": "S5 states small samples, exact dimensions not reported", "status": "not_reported"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}]

条件 A103-E08-G01：UltraMicroscope Blaze；样本=pt4_pt6_frontal_SMA；方法=A103-P001[共同背景，非S5尺寸确认] + A103-P002[处理方法关联] + A103-P004[仪器确认，S5具体设置未确认]。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "共同固定/来源背景（非S5全流程实做确认）", "binding_basis": "sample_schedule_match", "stored_steps": "recorded_reference_context", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "P001全部行只返回研究共同取材/固定背景。第2步0.5cm³不是S5小样本已确认尺寸；不得作为S5实际参数。step_selection保留兼容值，不声称已自动选取部分步骤。", "audit_status": "sample_specific_implementation_not_confirmed"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P004", "sequence": 3, "stage": "Blaze", "binding_basis": "direct_report", "stored_steps": "instrument_identity_direct; settings_reference", "source_refs": ["F03", "F15"], "step_selection": "all_recorded_rows", "note": "S5直接报告使用本仪器，且与另一仪器为同样本外观比较；P所列激发/物镜/digital zoom为主分析设置，S5没有逐项说明是否相同，不能返回为S5确认实用值。", "audit_status": "S5_imaging_settings_not_individually_confirmed"}]

条件 A103-E08-G02：Olympus MVX10-LS；样本=pt4_pt6_frontal_SMA；方法=A103-P001[共同背景，非S5尺寸确认] + A103-P002[处理方法关联] + A103-P003[仪器确认，S5具体设置未确认]。

方法关联与缺项：[{"protocol_id": "A103-P001", "sequence": 1, "stage": "共同固定/来源背景（非S5全流程实做确认）", "binding_basis": "sample_schedule_match", "stored_steps": "recorded_reference_context", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "P001全部行只返回研究共同取材/固定背景。第2步0.5cm³不是S5小样本已确认尺寸；不得作为S5实际参数。step_selection保留兼容值，不声称已自动选取部分步骤。", "audit_status": "sample_specific_implementation_not_confirmed"}, {"protocol_id": "A103-P002", "sequence": 2, "stage": "透明化/标记", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03"], "step_selection": "all_recorded_rows", "note": "本文报告使用；未报参数不推补；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}, {"protocol_id": "A103-P003", "sequence": 3, "stage": "Olympus", "binding_basis": "direct_report", "stored_steps": "instrument_identity_direct; settings_reference", "source_refs": ["F03", "F15"], "step_selection": "all_recorded_rows", "note": "S5直接报告使用本仪器，且与另一仪器为同样本外观比较；P所列激发/物镜/digital zoom为主分析设置，S5没有逐项说明是否相同，不能返回为S5确认实用值。", "audit_status": "S5_imaging_settings_not_individually_confirmed"}]

#### A103-E08-O01｜SMA血管显示外观

图/位置：Fig.S5A–D；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E08-G01, A103-E08-G02；样本：pt4_pt6_frontal_SMA

Pt4/6额叶SMA血管结构在Blaze(A,C)与Olympus(B,D)中目视无明显形态/勾画质量差异；比例尺500µm。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[]

限制：未量化分辨率、追踪误差、信号强度或Aβ检测等效；不能排除两仪器批次偏差。；S5仅称small samples，0.5cm³是主队列块体积；两台仪器的S5实际数值设置均未逐项确认。

来源：F15, F03



### A103-E09｜两名CAA阴性对照显示实质Aβ缺乏但仍有表面非特异及自发荧光

界定标记特异性与伪影排除依据

样本 control_DMD_29M：Homo sapiens—central nervous system—brain—brain region not reported—CAA阴性对照患者A脑块

初始状态：CAA-negative Japanese control; processed in same manner per main Methods, case-specific fixation duration not stated

尺寸：{"status": "not_reported", "description": "No case-specific block size in S6; do not automatically assign 0.5cm³ from main cohort"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

样本 control_BMD_83M：Homo sapiens—central nervous system—brain—brain region not reported—CAA阴性对照患者B脑块

初始状态：CAA-negative Japanese control; processed in same manner per main Methods, case-specific fixation duration not stated

尺寸：{"status": "not_reported", "description": "No case-specific block size in S6; do not automatically assign 0.5cm³ from main cohort"}

标记：[{"reagent_name": "Alexa Fluor 647-conjugated anti-α-SMA", "manufacturer": "Novus Biologicals", "catalog_or_clone": "1A4/asm-1", "dilution": "1:100", "fluorophore": "Alexa Fluor 647", "target": "α-smooth muscle actin", "observed_structure": "arteries and arterioles; smooth-muscle-associated vascular signal", "signal_source": "directly conjugated primary antibody", "display_color": "yellow", "source_refs": ["F03"]}, {"reagent_name": "anti-Aβ17–24", "manufacturer": "BioLegend", "catalog_or_clone": "SIG-39220", "dilution": "1:100", "fluorophore": "HiLyte Fluor 555", "label_preparation": "HiLyte Fluor 555 Labeling Kit-NH2 (Dojindo)", "target": "Aβ17–24 epitope; not an Aβ40/Aβ42 isoform-specific measurement", "observed_structure": "vascular Aβ and discrete parenchymal plaques; dyshoric Aβ assessed separately", "signal_source": "fluorophore-labeled primary antibody", "display_color": "blue/cyan", "source_refs": ["F03"]}]

条件 A103-E09-G01：29岁男性Duchenne对照；样本=control_DMD_29M；方法=A103-P002。

方法关联与缺项：[{"protocol_id": "A103-P002", "sequence": 1, "stage": "same-manner processing", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03", "F16"], "step_selection": "all_recorded_rows", "note": "正文称same manner；对照逐例成像仪器/固定时程未说明；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}]

条件 A103-E09-G02：83岁男性Becker对照；样本=control_BMD_83M；方法=A103-P002。

方法关联与缺项：[{"protocol_id": "A103-P002", "sequence": 1, "stage": "same-manner processing", "binding_basis": "direct_report", "stored_steps": "recorded_partial_parameters", "source_refs": ["F03", "F16"], "step_selection": "all_recorded_rows", "note": "正文称same manner；对照逐例成像仪器/固定时程未说明；Fig1A与Methods的MeOH顺序、BABB时长并列，具体实际值未解决", "audit_status": "parameter_conflict_requires_confirmation"}]

#### A103-E09-O01｜阴性对照Aβ/SMA信号

图/位置：Fig.S6A；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E09-G01；样本：control_DMD_29M

脑表面有点状及线状Aβ通道信号，作者判非特异染色；脑实质几乎无Aβ沉积。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[]

限制：非“所有结构无Aβ信号”；无灵敏度/特异度数值。

来源：F16



#### A103-E09-O02｜阴性对照双通道高信号

图/位置：Fig.S6B–C；时间：尸检终点；固定/透明化后成像，不是同一患者随时间进展。

所选组：A103-E09-G02；样本：control_BMD_83M

存在大量点状高信号，SMA与Aβ双通道同时阳性，作者视为自发荧光伪影，不是真正SMA/Aβ沉积。

统计：{"test": "未报告适用的定量检验"}

原文值/分母：[]

限制：正文仅称一个negative sample和No Aβ-positive structures，补图实际2患者且有背景；并列记录。；这两例不属于6名CAA统计主队列，也不是血管Aβ阴性组的来源。

来源：F16



## 作者解释和边界

### A103-A01｜表浅到深层扩展及IPAD机制的作者解释

作者认为表浅优势及血管树内解剖连续性支持表浅到深层Aβ扩展；讨论IPAD下游阻塞、SMA丢失/扩张和进一步排出受损的循环。

边界：本研究为回顾性尸检横断面；未直接测Aβ流动、清除率、血管功能或时间演变，不能确证上述因果链。

来源：F09

### A103-A02｜血管周球形SP逆关系的适用范围

讨论称各解剖位置均有逆关系，推测实质Aβ迁移到血管及dyshoric沉积；作者同时承认排除了微小/弥散/线性Aβ，且以长度代替体积。

边界：Fig.5I枕叶P=.130，不支持所有区域均显著；不能推断总Aβ减少或迁移已实测。

来源：F07, F09

### A103-A03｜可分析血管层级与患者代表性

作者仅可靠量化SMA可描绘动脉/小动脉，不量化毛细血管或静脉；选定额/枕区域，入脑位置不明单位及宏观出血区排除；未测Aβ阴性单位SMA丢失。

边界：不推广为全脑全血管无遗漏覆盖、毛细血管无病变、出血效应或全部CAA群体结论；6尸检患者、12块样本，血管级结果嵌套。

来源：F02, F04, F09

### A103-A04｜原文图文、数据文件与方法参数的未决边界

正文、图版、补图与数据文件存在多个待解释差异；各来源并列，不通过多数票或自动计数修正文献。具体见A103-U01–U13。

边界：资料齐全不等于精确实施已确认；方法文字分支仅为原文记载，非本次推荐操作方案。

来源：F03, F04, F07, F11, F16, F18, F20



## Protocol方法索引

单张Protocol，17列，31步/10个方法配置。详细已报参数只在工作簿保存。P003/P004按样本互斥，不是重复串行成像。

- A103-P001 尸检固定及取材：Excel行2–3；本文直接报告；未报参数保留

- A103-P002 透明化与直接双免疫标记：Excel行4–12；parameter_conflict_requires_confirmation；其余为已报/缺项并存

- A103-P003 Olympus光片成像：Excel行13–13；主分析设置直接报告；S5仪器身份确认、具体设置未逐项确认

- A103-P004 Blaze光片成像：Excel行14–14；主分析设置直接报告；S5仪器身份确认、具体设置未逐项确认

- A103-P005 血管单位追踪与分段：Excel行15–19；本文直接报告；未报参数保留

- A103-P006 SMA缺失段判读：Excel行20–21；本文直接报告；未报参数保留

- A103-P007 D0血管外径测量：Excel行22–22；本文直接报告；未报参数保留

- A103-P008 SP识别与血管周长度密度：Excel行23–27；本文直接报告；未报参数保留

- A103-P009 dyshoric独立形态判读：Excel行28–29；本文直接报告；未报参数保留

- A103-P010 相邻切片传统组织学：Excel行30–32；共同组织学路线；S1仅Aβ邻片分支



## 未决与原文不一致

### A103-U01 (source_discrepancy_or_ambiguity_not_resolved)

正文1639单位中1104 Aβ+、frontal513/865、occipital591/774；独立读取Data S1为1108 Aβ+、516/865、592/774。

位置：主文p3 Results / Data S1全表

处理：保留各来源计数，不校正原文件，不以统一n覆盖不同读数。

关联：A103-E01-O01, A103-E04-O03

### A103-U02 (source_discrepancy_or_ambiguity_not_resolved)

Fig1A末两次100% MeOH为4h后overnight，Methods为overnight后4h。

位置：主文p2 Fig1A / p9 Methods

处理：方法正文作为带来源的叙述分支，图示冲突单列，不能称唯一实际顺序确认。

关联：A103-P002 steps7–8

### A103-U03 (source_discrepancy_or_ambiguity_not_resolved)

Fig1A BABB 1 day；Methods overnight。

位置：主文p2 Fig1A / p9 Methods

处理：并列原时长，不能擅定overnight=24h。

关联：A103-P002 step9

### A103-U04 (source_discrepancy_or_ambiguity_not_resolved)

正文D0-D1 Aβ阳性率97.9%；Fig3A该箱体可见位于约半数，而不是近100%，非精确数字化。

位置：主文p3 Results / p5 Fig3A

处理：保留正文报告值及图示不一致，分母与汇总法仍需核实。

关联：A103-E02-O01

### A103-U05 (source_discrepancy_or_ambiguity_not_resolved)

正文简写一份negative sample且No Aβ-positive structures；S6两名CAA阴性病例分别有表面非特异信号和双通道自荧光。

位置：主文p10 Aβ specificity / supplement p7 FigS6

处理：两例质性阴性对照必须独立说明；不写信号全阴性/零背景或严格特异性数值。

关联：A103-E09-O01, A103-E09-O02

### A103-U06 (source_discrepancy_or_ambiguity_not_resolved)

总血管长原报2.36e5 µm；个体median1.55e3 µm，与数量规模存在算术疑点；明确列出的299排除不足以恢复最终全部纳入流。

位置：主文p3 Perivascular plaque / p10 Methods

处理：保留原值和分母未决，不猜指数或把1639-299=1340称所有面板最终n。

关联：A103-E05-O01

### A103-U07 (source_discrepancy_or_ambiguity_not_resolved)

枕叶Aβ±斑块密度差异不显著，图5I P=.130；Discussion称regardless anatomical location。

位置：主文p5 Results / p7 Fig5I / p8 Discussion

处理：结果以具体分层证据范围展示，作者广泛解释作为存在限制的作者陈述。

关联：A103-E05-O03, A103-A02

### A103-U08 (source_discrepancy_or_ambiguity_not_resolved)

斑块距离方法先称from filament，后称from surface；图示72.0µm是plaque center到filament。

位置：主文p7 Fig5B+caption / p10 Methods

处理：不能无条件解释为血管外壁shell体积；保留距离参考点不一致。

关联：A103-P008 step3, A103-E05-O01

### A103-U09 (source_discrepancy_or_ambiguity_not_resolved)

11个跳跃单位同时有LMA或D0 Aβ；Discussion白质局限6.2%未给分母，与全体<.7%不是同一可合并比例。

位置：主文p8 Discussion / p3,p7 Results

处理：不得写完全无表浅沉积或反推6.2%分母。

关联：A103-E02-O02

### A103-U10 (source_discrepancy_or_ambiguity_not_resolved)

图像A,C为3D，B,D为2D；caption末写(C,D) IHC。

位置：supplement p2 FigS1 caption

处理：保留明确面板图像关系和图注错位，不把C当作常规IHC。

关联：A103-E07-O01

### A103-U11 (source_discrepancy_or_ambiguity_not_resolved)

题名及判定操作支持Aβ+/SMA+，描述首句却写SMA negative。

位置：supplement p9 MovieS7 legend

处理：视频抽帧/过程与图注措辞分开；不得静默消除。

关联：A103-E03, A103-P006

### A103-U12 (not_reported)

最终斑块分析的全部/分组单位n、白质排除数量、每样本各分支段可评估分母未完整给出；数据S1仅供直径，不补成斑块分析原始数据。

位置：见关联记录

处理：保留未报告，不补推断

关联：A103-E02, A103-E05, A103-E06

### A103-U13 (not_reported)

IHC温度/pH、PBS洗涤时程/次数、体素尺寸/z步距/NA/发射窗、ROI分割阈值等未报告；外部参考未展开，不冒充实际实施值。

位置：见关联记录

处理：保留未报告，不补推断

关联：A103-P002, A103-P003, A103-P004, A103-P005



## 原文位置

- F01｜A103-MAIN｜PDF页[2, 3]｜Results: 3D visualization and characterization; Fig.1：6患者、12额/枕样本、1639血管单位，正文1104阳性（额513/865，枕591/774）；血管单位定义为共同LMA分支的连续血管树。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F02｜A103-MAIN｜PDF页[9]｜Methods: Patients and human brain samples; Histopathological analysis：6名2017–2020尸检CAA患者，4男2女，79.5±9.5岁；CAA Thal stage2有4人、stage3有2人；CAA type1和type2各3人；MRI/病理范围与出血排除。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F03｜A103-MAIN｜PDF页[2, 9, 10]｜Methods: Tissue block clearance and 3D imaging; Fig.1A：0.5cm³额/枕脑块，固定2–3年；1,2-hexanediol/H2O2/direct primary labels/MeOH/BABB流程，两LSFM系统；图与文字的末端时程差异保留。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F04｜A103-MAIN｜PDF页[3, 4, 5, 10]｜Results: Aβ deposition sites; Fig.2 and Fig.3A; Methods: Quantification of arteries and arterioles：D0–D6为分支阶次，按每样本的段阳性比例；11条跳过皮层的异常单位也有LMA或D0沉积。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F05｜A103-MAIN｜PDF页[3, 4, 5, 10]｜Results: Distribution of vascular segments with SMA loss; Fig.2C–D/3B; Methods corresponding subsection：547/1104正文阳性血管单位有SMA缺失；最浅缺失段分布，分母为各样本内有SMA缺失的血管单位。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F06｜A103-MAIN｜PDF页[3, 6, 10]｜Results: Changes in size; Fig.4A–D; Methods corresponding subsection：D0外径测量，不是管腔径；组间原文中位数、IQR及P值。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F07｜A103-MAIN｜PDF页[3, 5, 7, 10]｜Results: Perivascular plaque density; Fig.5A–I; Methods: Large-scale quantification：spots/µm filament length；10–100µm距离，50µm spot设定；排除伪影299、髓质穿行血管、dyshoric变化；枕叶组间n.s.。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F08｜A103-MAIN｜PDF页[5, 6, 10]｜Results final perivascular paragraphs; Methods dyshoric change definition：465皮层Aβ阳性血管单位中12.7%出现dyshoric change；D0占受累段91.5%，6样本个别比例。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F09｜A103-MAIN｜PDF页[6, 7, 8, 9]｜Discussion, including limitations：空间连续性支持作者表浅到深层进展解释，但没有纵向/机制因果测试；无法量化毛细/静脉；排出血；spots不等于总Aβ负荷。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F10｜A103-MAIN｜PDF页[10]｜Methods: Statistical analysis：非正态连续变量median(IQR)；Mann–Whitney U；Kruskal–Wallis后Steel–Dwass；JMP Pro17，P<.05；未报告患者聚类/配对模型。 (https://pmc.ncbi.nlm.nih.gov/articles/PMC12880530/)

- F11｜A103-SUPP｜PDF页[2]｜Fig.S1：Pt2/Pt6额叶3D横断面与相邻2D免疫组化比较；未逐斑块对应 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F12｜A103-SUPP｜PDF页[3]｜Fig.S2：Pt4枕叶纵/横断及Pt1枕叶dyshoric图 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F13｜A103-SUPP｜PDF页[4]｜Fig.S3：Pt2/4/5 MRI代表图 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F14｜A103-SUPP｜PDF页[5]｜Fig.S4：Pt1/5额、枕取材；Pt5避出血区 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F15｜A103-SUPP｜PDF页[6]｜Fig.S5：Pt4/6小额叶样本在两个LSFM系统间SMA外观比较 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F16｜A103-SUPP｜PDF页[7]｜Fig.S6：两例CAA阴性对照；29岁Duchenne/83岁Becker男性；表面非特异Aβ与双通道自发荧光 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F17｜A103-SUPP｜PDF页[8]｜Table S1 and complete footnotes：患者病理分层、APOE、MRI、血管阳性率分组；不是12独立患者 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F18｜A103-SUPP｜PDF页[9]｜Movies S1–S7 legends：每个视频的患者、区域、通道、追踪/切换用途 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F19｜A103-SUPP｜PDF页[10]｜Data file S1 legend：所有D0外径xlsx逐血管数值文件 (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_sm.pdf)

- F20｜A103-DATA｜PDF页不适用｜Sheet vascular_unit_diameter A1:F1640; rows2:1640：1639条原始行；额865/枕774；实际标记阳性1108、阴性531，与正文阳性1104存在待解释的计数不一致；see sources/diameter_data_check.json (https://pmc.ncbi.nlm.nih.gov/articles/instance/12880530/bin/sciadv.aea7539_data_file_s1.zip)



## 实际读取与核验范围

{
  "main_text": "Main PDF12 pages read, science/results/methods pp1–10; references/metadata pp11–12 inspected. All Fig1–5 images visually read.",
  "supplement_document": "Supplement18页；S1–S6、TableS1全表/脚注、7视频图注、DataS1说明已读；参考文献清单仅核对相关引用，未逐篇展开外部文献。",
  "movies": "All7 MP4 downloaded; four timestamped frames per movie visually inspected via contact sheets generated by source reviewer, also independently viewed by extraction agent. Not full playback or frame-complete inspection. Timestamps in audit/movie_frames/sampling_manifest.json.",
  "data_file": "DataS1 all1639 rows imported read-only with artifact-tool; derived groups in sources/diameter_data_check.json; no P recomputation.",
  "external_references": "No external protocol reconstruction used as implementation; 2024 preprint excluded.",
  "raw_image_stacks": "Not acquired; no segmentation rerun."
}

结构检查不是科学验真；独立候选审阅和修正复审完成前不计入100篇。