# A135 ClearEye 人眼组织透明证据抽取

本记录针对 Darche 等 2023 年论文 Light sheet fluorescence microscopy of cleared human eyes，DOI 10.1038/s42003-023-05401-0。R1 冻结后已通过父任务独立 R2、R3、R4 验收。最终签核绑定冻结文件 SHA256。record_R1.json 是冻结稿，record.json 是相同内容副本；其中待审状态为冻结时历史信息，当前状态见 final_metadata.json 与 review/final_acceptance.json。旧库和公开 GitHub 均未修改。

## 已完成内容

- 20 个处理、标记、成像及保存阶段，保留原始时间表达和时间角色
- 3 种标记，22 行补充表逐面板参数
- 主图 1 和 2 全部面板，补图 S1 与 S2，共 30 个分解图项
- 6 项结果、15 项来源差异或冲突、13 项真实未知
- 8 个源材料，含公开审稿回复、动态 XFA Reporting Summary 和补充视频

## 核心结论与适用边界

ClearEye 证明已制备人眼组织可经免疫标记和透明处理，以 mesoSPIM 显示整眼与前节复杂神经血管结构。正文包含 4 个整眼及 10 个前节，整眼去除了晶状体；图 2 称展示 6 名供者。样本数量不能直接换成独立供者总数。年龄不能作为供者唯一标识。

这是一项技术可行性研究。形态展示不能升级为年龄效应、疾病诊断效能或与其它透明方法的匹配定量比较。作者没有量化信噪比，也没有给出荧光保留百分比、体积收缩率或本研究眼内实测点扩散函数。保存一年后仍透明和有免疫荧光是作者观察性陈述。

## 时间与样本绑定

正文的一抗 20 天之后另有无 SDS 的 PBSGT 4 天，再进行二抗 48 小时。图 1a 的免疫阶段只画 20+2 天，没有显示该 4 天阶段。图示固定 15 小时与正文 overnight 分开保留。图示透明 2.5 天不是全流程耗时。DBE 浴每次 2 小时但次数未报；overnight 未统一换算小时数，因此没有编造精确总时间。

图示 LSFM few hours 与补图 S1a 的 6 cm³ 样本 4 小时属于采集时间。可隔数月复查和至少一年保存稳定属于观察窗口。人工分割耗时没有数值，不能用采集时间替代。

## 必须保留的源差异

- 图 2h 为 ColIV/TubIII 双色展示，但补表及 Reporting Summary 对应二抗均列 647 nm，采集对应方式未解
- 视频 154 秒称 Figure 2D 为 16 岁，补表为 47 岁
- 视频 204 秒称 Figure 2F 为 47 岁 ColIV，补表为 89 岁 TubIII，不能自行重编号
- 视频 252 秒称 Figure 2J 为 40 岁，补表为 84 岁
- Reporting Summary 声称使用无已知眼病样本，图 2c 图注明确有 dry eye，保留两者
- 图 2e 与 2f 的不同供者已由审稿回复解释，不视为同一样本连续视图
- 审稿回复提到 saponin 和 546 nm 属历史来源；不把 saponin 加入最终配方，最终激发通道字段按正文与补表记录 561 nm

## 阅读与文件说明

sources/article.xml 复用已存在的正确全文缓存。sources/blocks.json 为稳定段落定位。补充 PDF、主图、视频均保存 SHA256。MOESM5 是动态 XFA PDF，常规 pdftotext 只给 Please wait 占位；实际科研字段来自 reporting_datasets.xml，并对 reporting_template.xml 的复选值作了核对。没有把下载成功当成表单内容审查完成。

视频共约 321.154 秒，采用 64 个 5 秒间隔抽帧覆盖内容并另核关键标题；不声称逐帧观看。contact sheet 时间为近似采样窗口，关键冲突引用精确 seek 的 154、204、252 秒截图。公开审稿回复的科研相关内容已读，拼写和编辑意见未逐条结构化。

CSV 与 JSON 是同一抽取记录的不同呈现。source_conflicts.csv 同时包括未解冲突、可解释的口径差异和已由原文解释的差异，其 status 字段须一起读取。missing_fields.csv 的未知基于本次全文及全部相关补充源覆盖，不表示其他研究也未报告。

原文和图像按 Creative Commons Attribution 4.0 署名使用。中文转述和结构化字段为本次派生内容，保留科学范围及不确定性。来源论文：https://doi.org/10.1038/s42003-023-05401-0 。

## 派生包使用说明

包内不含原文全文、原始图像、PDF、视频、完整段落文本或下载脚本。sources/*路径仅说明研究时缓存位置，不表示随包附送。sources.csv和record中的sources字段提供公开原文URL；source_locator_index.json提供46条段落XPath及真实XML标识、审稿PDF物理页码、XFA字段定位，可据此回查原文。

final_metadata.json提供最终状态；review/final_acceptance.json为独立签核原件。冻结稿及其CSV保留当时版本以便审计，不把后续签核倒写为抽取者自行验收。
