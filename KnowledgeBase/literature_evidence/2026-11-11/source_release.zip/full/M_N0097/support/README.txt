MACS M_N0097 已完成四轮科学审核的派生证据包
最终主记录：derived/record_final.json
验收快照：derived/record_R1.json
中文说明：derived/中文说明.md
审阅记录：review/final_acceptance.json、root_R4_queries.json、R2_R3_response.json
离线验证：python validate_package.py
仅含派生内容，不含原文全文、PDF、原图或视频。视频阅读范围为每段12帧抽样，未声称连续逐帧阅读。
