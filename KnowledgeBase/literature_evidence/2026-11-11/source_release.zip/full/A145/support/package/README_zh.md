# A145 已验收派生证据包

论文：CLARITY reveals dynamics of ovarian follicular architecture and vasculature in three-dimensions，Scientific Reports 7:44810（2017）。DOI：https://doi.org/10.1038/srep44810 。主文：https://pmc.ncbi.nlm.nih.gov/articles/PMC5363086/ 。

## 版本与验收

默认 record.json 是经独立复核验收的最终版；figures.csv、sample_groups.csv、results.csv 等均与该版一致。科学内容来自修订后 R3，最终盖章仅改验收状态。完整签署及适用范围见 audit/independent_acceptance.json。

18 个正式问题、作者记录的 49 处字段修改均逐项回核。另补全 R57/R58 的 G25/G26 样本绑定，并收窄 Fig3B 未报告的动情阶段分配。全部 35 个面板、5 部电影条目和 46 条结果的样本绑定进行了同类检查，真实 Fig6C/7C PECAM1 证据保留。

history/ 保存冻结 R1、修订 R2、科学 R3 和历史审计资料，其中 pending/false 是当时状态，不是当前验收结论。历史 manifest 的路径属于其原阶段工作区，不能当作本包清单使用；本包使用 package_manifest.json。原始科学记录和历史 manifest 未覆盖修改。

## 覆盖范围

- 8 个固定样本处理阶段、4 条成像/分析条目、15 条抗体记录（9 一抗、6 二抗）
- 46 条结果、26 个条件级样本组、35 个静态面板（7 主图、4 补图）
- 3 个补表：S1 为 11 行，S2 为 6 行，S3 抗体纳入 markers.csv
- 5 部补充电影均核对 10%/50%/90% 静态抽帧；另对 S3/S4/S5 核对 38 张密集静态帧
- 11 项原文冲突、15 项原文未报告字段明确保留

主文、相关 Methods、Discussion、补充正文及全部实际静态图表已读。电影为静态抽帧核验，未声称连续完整播放；未进行曲线数值化或原始图像栈重分析。只有文献身份/摘要的其他论文不计作全文完成。R4 实际检索与访问结果见 audit/R4_query_log.json；遇到的访问限制已停止，未绕过。

## 必须保留的解释边界

1. 被动 CLARITY 的 4–8 周是清透阶段耗时。清透特异温度未报告，不能从后续免疫染色段推成 37°C。
2. 滤泡向心迁移、动情周期变化属于固定终点的横断面空间推断，不能当作活体纵向运动轨迹。
3. TH 的部分信号是非特异性轮廓；PECAM1 在部分卵母细胞有背景。未证明所有抗体两两组合均兼容，未证明内源 GFP/RFP 保留。
4. Fig6A/B、Fig7A/B/D 和 FigS4 是辅助分型、大体外观、重量或卵母细胞计数。Fig6C/7C 保留真实血管荧光及重建证据。
5. 代表图中的卵泡数和血管主干直径不是组均值或动物重复数。H&E 并列比较的样本配对关系未报告。
6. Fig5D 的 adult/immature 身份冲突、补充电影交叉引用/描述范围问题等不静默纠正。S5 实帧含 0/12/24/48 h；S3 依次显示 TH 与 PECAM1 并非单一 TH 图像和血管描述的矛盾。五部电影与 PMC 原标签的 MD5 一致。
7. 验收表示在上述范围内没有已知关键抽取缺口，不表示原论文本身报告完备，也不表示所有原始科学结论都已独立实验验证。

不收录动物模型建立、手术、麻醉、灌注、PCR 等上游操作流程。

## 文件使用

- 默认 JSON/CSV：当前结构化记录、结果、图表、样本、标记、缺失和冲突
- source_locator_index.json：来源位置与哈希；新增样本绑定另见 audit/sample_binding_audit.json
- reading_log.csv：本次独立阅读覆盖；review_rounds.csv：各轮完成情况
- audit/：独立复核、修订闭合、实际补缺检索、抽帧与电影身份审计
- history/：历史版本，仅用于比较与追溯
- package_manifest.json：本包每个有效载荷文件的 SHA256（不自包含）

本包仅含派生 JSON、CSV、Markdown。原始 PDF/XML/全文转写、原图、截图、影片及 review_assets 图像均未装入；记录里的来源路径只是定位信息。没有公开发布至 GitHub。
