# A107 科学范围收口

历史有据的全E/G/O/问题证据阅读＋当前P的有界方法恢复、适用关系同步；不要求重新读取已有科学审阅；并非无缺项执行方案。

已逐项整合 31 O 与 83 个当前P绑定。继承的原始审阅及当前参数逐字段审阅见 scientific_coverage.json，具体O见 observation_review.json。

- A107-R09.challenge.02中“两份源表均显式含公式”只有一份已保存具名表转录；第二表身份/内容未核。
- 原XLSX公式格真实性本轮未重新取得；已核8行与3+5汇总的数学语义保持，正文年轻4只冲突不消除。

本轮补核/改动：[{"category": "source_mismatch", "path": "/evidence_records/2/observations/1/result", "before": "两组均未达显著差异；图5D轴写per 1mm，源表标题写per 1mm3。各组3只，原值不转换单位。", "after": "两组均未达显著差异；当前已核方法稿及2026-10-11定向复查保留Fig5D与源表标题均为per1mm³。各组3只；具体归一化实施细节仍未报告，不补体积或分母。", "basis": ["current protocol A107-R04.branches.01", "review_application_remaining_20261011/A107/REPORT.md"], "review_kind": "继承已有定向来源审阅并同步E/O、未决及GQ；不是本轮重新看Fig5原像"}]

没有新增Pro审阅、原数据分析或实验。当前合并副本为candidate；历史接受仅覆盖其原字节与声明范围。
