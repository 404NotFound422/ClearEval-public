# Independent visual and source-data review
Reviewer: review_ezclear_full_record; executed 2026-10-19 01:32–01:34 UTC.
Assets supplied via author's normal public EuropePMC supplementary download, under sources/assets. Independent inspection uses local copies; no bypass of the stopped eLife challenge.

## Images actually opened and visually inspected
- Fig1: A has 20 h delipidation, 4 h wash, 24 h RI, 2 days. This is a real step-level difference from Methods16 h, distinct from compatible 44h subtotal vs within48h. B comparator appearance; C brain size (pixels), D–F Thy1-EGFP; G visible organs; H lectin organ branch.
- Fig1 supplement1: comparative timelines and stage pictures; B tabulates RI endpoint ratio1.072±0.062 and delipidated1.071±0.005. Displayed stages omit water wash; do not claim chart demonstrates no intermediate swelling.
- Fig2: RI tuning; RIMS vs EZView images; K intensity at1–5mm; L storage14/17/43/70days. Plot L and lectin649 imagery corroborate body over caption typographical errors. No day0 baseline shown.
- Fig3: Evans blue qualitative paired hemispheres A–F; independent lectin intensity/contrast G–I; no dye merge.
- Fig4: A standard wholemount13days, wash blocks24h each. G–J GFP/GFAP cortex and CC/CoF are standard staining branch. ToPro3 and SMA-Cy3 comparative panels separate.
- Fig5: existing GFP-positive lesion/lectin vasculature, cryosection medium comparison, preserved GFP/lectin and H&E. No need to reconstruct model creation.
- Fig5 supplement1: fixation-only versus EZClear H&E, cortex/lateral ventricle/third ventricle; qualitative control, no inferred numeric quality score.
- Fig6: A16h block/24h primary/4h wash/24h secondary/4h wash/16h mount; author total4days. This schematic differs from textual overnight/three1h washes and untimed mount. B separate marker panels CD31/GFAP/SMA-Cy3/betaIII-tubulin and unstained control. C–D nominal100µm section per text; D scale0–120µm is a plotted depth range, not a substitute section thickness.
- Fig7: custom magnetic mount, agarose embedding and expanded chamber; imaging hardware benefit is not claim of universally unmodified commercial chamber compatibility.

## XLSX files actually inspected read-only
All worksheet contents parsed from XLSX XML into source_data_independent_dump.json; no workbook edited. Headers, representative raw replicate rows and summaries examined.
- Fig1-data1 Sheet1: raw specimen rows A–P; 4 specimens/method, endpoints in pixels. Baseline pooled summary does not change Methods'2D measurement definition.
- Fig1-s1-data1 Sheet1: independent ratios inspected. EZClear water-wash ratio L11:L14=1.5950523/1.5798743/1.5882638/1.6518515, L21 mean1.603760478; final RI M21=1.072424454. Intermediate increase limits unqualified claim size remains constant throughout; no statistical significance invented.
- Fig2-data1 Nycodenz w Urea: actual replicated RI measurements,8M labeled oversaturated; EZ vs RIMS intensity:1–5mm,3 replicate columns/arm; EZ-tracing:days14/17/43/70,3 replicate columns each,1–5mm. Storage assay cannot prove baseline retention percentage or long-term GFP stability.
- Fig3-data1: EZ vs FAST intensity3 columns/arm at1–5mm; contrast includes min/max/contrast with depth; organ sheet has testis/ovary/kidney/heart/eye separately, relative-depth normalized axes. Summary organ traces alone do not establish every sample's biological replicate identity.
- Fig4-data1: ToPro3 diffusion lateral traces for two regions, IF vs iDISCO; separate ToPro3 and SMA-Cy3 sheets3 columns/arm at1–5mm. Does not supply a GFAP quantitative comparison or GFP retention ratio.
- ReportingDOCX: no sample-size computation in advance; experiential/practical replicate choice; no outliers excluded; numerical data mean±SD; group allocation NA. Not evidence of randomized or masked design.

All newly found issues forwarded to author before R1 freeze. This is source pre-review; formal R2–R4 will be executed against frozen versions, not represented as already complete.
