# M028 independent source precheck
Reviewer: review_ezclear_full_record
Date: 2026-10-19 UTC
Scope: existing fixed-tissue clearing, imaging and downstream staining only. No animal manipulation, disease-model construction, transgenic construction, reagent manufacture, or procurement-quality extension.

Source actually read: local PMC9555867.xml, abstract; Results s2-1–s2-5; Discussion s3; Methods s4-4 and s4-8–s4-14; figure captions 1–7 including supplements Fig1-s1 and Fig5-s1; key-resource table. Model-generation/perfusion sections were present but are outside the operational extraction scope.

Independent points to test against the frozen record:
- Time: abstract/Results describe in 48 h; Discussion says within 48 h. Methods timed incubations are 16 h delipidation + 4 × 1 h water wash + 24 h RI matching = 44 h. These are compatible as timed-stage subtotal and reported workflow duration/upper bound. No invented 4 h stage; fixation, immunostaining, agarose mounting/equilibration and storage are separate.
- Wholemount branch: fixed adult mouse brains after delipidation/wash, standard staining vs iDISCO, αSMA-Cy3/To-Pro3 quantitative comparisons; independent Thy1-EGFP-M + GFAP standard wholemount branch preserves endogenous reporter. Do not claim all organs/all markers or iDISCO reporter preservation was tested.
- Post-imaging branch: pre-existing P104 GFP-positive glioma brain with lectin649, imaged then cryosectioned. 12 µm H&E vs 100 µm IF; CD31/GFAP/betaIII-tubulin primary antibody branch; αSMA-Cy3 direct-conjugate staining with Hoechst. Endogenous GFP and pre-existing lectin signal preserved; GFAP illustrated across 100 µm thickness. These are distinct from wholemount GFAP.
- Organ evidence: visible transparency brain/eye/heart/lung/liver/spleen/kidney/testis; wholemount lectin image/contrast eye/heart/kidney/testis/ovary. General Methods includes all nine organs, but demonstrated fluorescence cannot be expanded by Cartesian product.
- Storage: lectin649 in EZ View at days14/17/43/70, not clearing duration or proof of 70-day endogenous GFP stability.
- Size endpoint: figure calls volume, Methods quantifies 2D projected outline pixel area; retain provenance and do not state direct 3D volumetry.
- Fig2 caption uses lectin694 and panel(I) for stability while body/source-data caption uses lectin649 and L; preserve typo annotation, not alternate label branch.
- Fig3 Evans blue comparison uses paired hemispheres; lectin quantitative comparison described whole brains in Results but hemispheres in caption; do not merge dyes or resolve sample-unit ambiguity without evidence.
- RI: Results EZ View1.518 ±0.0003; Methods range1.512–1.518; no silent single-value replacement.
- Sample mounting axial sampling differs Results Fig3 3.675µm vs general Methods3.627µm. Keep contextual values if extracted.
- Limits: larger samples, nonmouse species and younger/embryonic tissues untested. General applicability is not a demonstrated branch.

Access event: normal public web open of https://elifesciences.org/articles/77419 returned Client Challenge / JavaScript disabled at approximately01:28UTC. Stopped that entry; no bypass attempted. Author notified. Local XML remains available; author's independently initiated normal EuropePMC public supplementary source may provide material for local independent review. R2–R4 have NOT yet been executed: waiting for frozen R1.
