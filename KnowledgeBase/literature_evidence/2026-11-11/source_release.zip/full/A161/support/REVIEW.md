# A161 历史媒体覆盖缺口补核

结论：当前任务相关全文科学范围已覆盖。沿用经最终独立复核且字节匹配的历史科学记录，只补此前缺凭据的媒体阅读，不重新抽取、不改原库。

历史记录核对：7 个文件全部匹配。恢复官方源文件 17 个全部匹配历史 SHA256。

本次实际媒体审阅：
- Figure 1：Workflow graphic separates tissue selection, staining, RI matching, confocal reconstruction and landmark matching. No new experimental result inferred.
- Figure 2a-d：Four tissue contexts: esophagus, upper stomach, lower stomach and colon; top/side/3D and separate HE images. CD34-white and SYTO16-blue are display assignments, not native emission identity. Existing O02-O04 match.
- Figure 3a-b：Esophageal noncarcinoma/carcinoma and colon nonadenoma/adenoma comparisons remain separate; 3D CD34/SYTO16 versus sectional CD31 and HE not conflated. Existing O05/O06 supported without deriving new quantitative values.
- Figure 4a-b：Arrowheads and crypt outlines link selected NBI landmarks to reconstructed vessels in esophagus, stomach and colon. Visual matching examples do not add cases to the inherited 10/14 denominator.
- Figure 5：Two colon ROIs containing labelled vessels 1-3 and 4-6; top and side views correspond to existing six table-measurement results O09-O14. No image remeasurement.
- Figure S1：Before/after brightfield views of esophagus, stomach and colon with 5 mm grid support reported qualitative clearing; no dimensions or volume preservation inferred.
- Figure S4：Esophageal NBI selection and rotation, five labelled vessel ROIs with top/side views. Matches existing case 2 Table S1 scope O15-O19; five ROIs are not five patients.
- Figure S5：Stomach NBI and five labelled vessel ROIs with top/side views; matches existing case 5 Table S1 scope O20-O24, no independent added samples.
- Video S1, esophagus：12 representative frames cover full volume, zoom and rotated views of looped vessels and subepithelial network. Existing O02 supported, no new caliber measurement.
- Video S2, upper stomach：12 representative frames cover overview, zoom and top/side rotation. Polygonal vessel arrangement around pits agrees with existing O03 upper-stomach branch.
- Video S3, lower stomach：12 representative frames cover overview, ridge/loop detail and side rotation. Distinct lower-stomach architecture agrees with existing O03; not pooled with upper stomach.
- Video S4, colon：12 representative frames show crypt-centred vascular mesh at surface and vertical vessels from side views. Existing O04 supported; no inference of functional perfusion.

R1 沿用；R2 历史来源独立审核加本次媒体独立核对；R3 保留阶段、样本、标记和读出界限；R4 已实际查询档案及官方源并关闭媒体缺口。不能把这些写成四轮均在本窗口重新执行。

仍保留原文未报参数、源冲突及原始数据不可复算边界，这些不是未读已知相关来源。本次未新增科学事实，未修改总账，未执行临床/湿实验操作，未发布 GitHub。
