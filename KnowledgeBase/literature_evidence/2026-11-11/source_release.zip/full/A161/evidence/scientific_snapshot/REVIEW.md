# A161 source reconstruction

New namespace, not restoration of the historical core/hash. Original protocol records and historical review declarations are retained with exact hashed pointers. All declared result rows were read against publisher text/captions; no new image digitization, raw-data recomputation or movie decoding is claimed.

## Bidirectional scientific checks
- All5main figures,Tables1–3,6supplementary figures,TableS1 and4video-described anatomical contexts covered. Figure1workflow is context, not an independent experiment.
- Fresh fulltextXML, AppendixS1 andTableS1 originalDOCX read; S2/S3/S6 originalTIFFs inspected for axes, printed equation/significance and metric identity.
- Fourteen case labels and10/14matching outcome retained. Esophagus3/3,stomach2/4,colorectum5/7, including4failed cases; no inflated denominator from vessels/ROIs.
- All16published vessel depth/caliber pairs preserved exactly:6case9Table3,5case2and5case5TableS1.
- S6four-case regression y=0.8823x+8.547,R²=0.9748 is depth-only. SSLcases11/13 enter histology comparison despite failedendoscopy matching.
- CD34directAlexa647 andSYTO16 are separated fromsectionCD31/D2-40/H&E. Nuclear blue pseudocolor is notSYTO16emission identity.
- All3inherited source conflicts preserved. S3formula typo and boxplot representation remain distinct fromAppendixmean±SD test description.
- Projection thickness150/250µm, opticalzsteps0.8/4.2µm and imaging reach~350µm are not tissue dimensions.
- Matching is manualmultiobserver correspondence withlandmark selection; no blindeddiagnostic accuracy,sensitivity/specificity or clinical superiority validation is inferred.
- High-resolution30×small field and failurewith uniform/poorlandmarks retained; rawmeasurements and acquiredstacks not recomputed.

## Coverage
- Clearing and imaging reach: Results first subsection; FigureS1,S2a
- Noncancerous esophageal vessels: Figure2a;VideoS1
- Noncancerous gastric regional architecture: Figure2b–c;VideoS2,S3
- Noncancerous colon architecture: Figure2d;VideoS4
- Esophageal cancer vascular changes: Figure3a;FigureS2;AppendixS1
- Colon adenoma morphology/tortuosity: Figure3b;FigureS3;AppendixS1
- Case-level one-to-one matching: Table1;Figure4;Results matching
- Continuous vessel versus discontinuous endoscopic appearance: Figure5;Results matching
- Case9 vessel1 measured depth/caliber: Table3;Figure5
- Case9 vessel2 measured depth/caliber: Table3;Figure5
- Case9 vessel3 measured depth/caliber: Table3;Figure5
- Case9 vessel4 measured depth/caliber: Table3;Figure5
- Case9 vessel5 measured depth/caliber: Table3;Figure5
- Case9 vessel6 measured depth/caliber: Table3;Figure5
- Case2 vessel1 measured depth/caliber: TableS1;FigureS4
- Case2 vessel2 measured depth/caliber: TableS1;FigureS4
- Case2 vessel3 measured depth/caliber: TableS1;FigureS4
- Case2 vessel4 measured depth/caliber: TableS1;FigureS4
- Case2 vessel5 measured depth/caliber: TableS1;FigureS4
- Case5 vessel1 measured depth/caliber: TableS1;FigureS5
- Case5 vessel2 measured depth/caliber: TableS1;FigureS5
- Case5 vessel3 measured depth/caliber: TableS1;FigureS5
- Case5 vessel4 measured depth/caliber: TableS1;FigureS5
- Case5 vessel5 measured depth/caliber: TableS1;FigureS5
- Depth correlation with histology: FigureS6a–c;Results matching

No dangling relation endpoints. Panel-specific n and source conflicts remain distinct from specimen identity and administrative approval. Source missingness does not justify guessed values. Raw-data reproduction is not required to close supported literature claims. Parent content review pending; specified Pro/candidate gate unchanged.
