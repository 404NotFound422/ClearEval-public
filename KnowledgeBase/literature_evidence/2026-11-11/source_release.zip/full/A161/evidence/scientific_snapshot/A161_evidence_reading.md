# A161 文献证据阅读稿

Three-dimensional optically cleared tissue imaging for analyzing endoscopic images of gastrointestinal neoplasms (with video)

主文DOI：10.1111/den.15000

底稿版本：2026-10-12-source-reconstruction.1；SHA256：1f1010a6cf464cfd29ba64f5e6d15e4b96c6183f35e22b0f7c4e7c7d114b5323

这是一份当前证据层的来源限定阅读投影。不是专家gold、模型评分集或新增独立科学验收。旧核心/旧问题ID并未恢复，指定Pro及发布状态不因本稿改变。

覆盖当前25条结果、26条结论。下面保留完整结果对象，防止把定量值、采样层级或未知状态压缩掉。

## 全篇范围与限制

- All5main figures,Tables1–3,6supplementary figures,TableS1 and4video-described anatomical contexts covered. Figure1workflow is context, not an independent experiment.

- Fresh fulltextXML, AppendixS1 andTableS1 originalDOCX read; S2/S3/S6 originalTIFFs inspected for axes, printed equation/significance and metric identity.

- Fourteen case labels and10/14matching outcome retained. Esophagus3/3,stomach2/4,colorectum5/7, including4failed cases; no inflated denominator from vessels/ROIs.

- All16published vessel depth/caliber pairs preserved exactly:6case9Table3,5case2and5case5TableS1.

- S6four-case regression y=0.8823x+8.547,R²=0.9748 is depth-only. SSLcases11/13 enter histology comparison despite failedendoscopy matching.

- CD34directAlexa647 andSYTO16 are separated fromsectionCD31/D2-40/H&E. Nuclear blue pseudocolor is notSYTO16emission identity.

- All3inherited source conflicts preserved. S3formula typo and boxplot representation remain distinct fromAppendixmean±SD test description.

- Projection thickness150/250µm, opticalzsteps0.8/4.2µm and imaging reach~350µm are not tissue dimensions.

- Matching is manualmultiobserver correspondence withlandmark selection; no blindeddiagnostic accuracy,sensitivity/specificity or clinical superiority validation is inferred.

- High-resolution30×small field and failurewith uniform/poorlandmarks retained; rawmeasurements and acquiredstacks not recomputed.

## 方法索引

实际方法关联见各问题；本索引保存来源位置，不将候选/参考方法认定为每个实验实际实施。

- A161-P001：食管、胃与结直肠FFPE组织块的整块标记、ECi透明化与共聚焦三维采集；完整记录位于A161_reconstructed_evidence.json的protocols及其source_record_path/source_pointer。

- A161-P002：比较用组织切片的染色入口、全片扫描与测量；完整记录位于A161_reconstructed_evidence.json的protocols及其source_record_path/source_pointer。

- A161-P003：内镜与三维图像匹配、血管量测及限定统计；完整记录位于A161_reconstructed_evidence.json的protocols及其source_record_path/source_pointer。

## 来源限定问题与完整证据

### A161-R20261012-Q001

该研究对“Clearing and imaging reach”报告了什么？样本、方法、量值与限制分别是什么？

All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O01",
  "experiment_id": "A161-R20261012-E01",
  "sample_context_ids": [
    "A161-R20261012-S01",
    "A161-R20261012-S02",
    "A161-R20261012-S03",
    "A161-R20261012-S04",
    "A161-R20261012-S05",
    "A161-R20261012-S06",
    "A161-R20261012-S07"
  ],
  "metric": "Clearing and imaging reach",
  "result": "All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.",
  "values": {
    "reported_depth_um": 350,
    "approximate": true,
    "objective": 30,
    "wholemount_labels": [
      "CD34-AF647",
      "SYTO16"
    ]
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR01"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Results first subsection; FigureS1,S2a",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C01 [source_scoped_result_summary]：All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.

明确方法关联：A161-P001

样本上下文：A161-R20261012-S01、A161-R20261012-S02、A161-R20261012-S03、A161-R20261012-S04、A161-R20261012-S05、A161-R20261012-S06、A161-R20261012-S07

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Results first subsection; FigureS1,S2a", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q002

该研究对“Noncancerous esophageal vessels”报告了什么？样本、方法、量值与限制分别是什么？

IPCL and subepithelial network visualized; surface loops narrower than drainage vein.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O02",
  "experiment_id": "A161-R20261012-E02",
  "sample_context_ids": [
    "A161-R20261012-S01"
  ],
  "metric": "Noncancerous esophageal vessels",
  "result": "IPCL and subepithelial network visualized; surface loops narrower than drainage vein.",
  "values": {
    "surface_loop_caliber_um": 10,
    "drainage_vein_caliber_um": 50,
    "approximate": true
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR02"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Figure2a;VideoS1",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C02 [source_scoped_result_summary]：IPCL and subepithelial network visualized; surface loops narrower than drainage vein.

明确方法关联：A161-P001

样本上下文：A161-R20261012-S01

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Figure2a;VideoS1", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q003

该研究对“Noncancerous gastric regional architecture”报告了什么？样本、方法、量值与限制分别是什么？

Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O03",
  "experiment_id": "A161-R20261012-E03",
  "sample_context_ids": [
    "A161-R20261012-S03"
  ],
  "metric": "Noncancerous gastric regional architecture",
  "result": "Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.",
  "values": null,
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR03"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Figure2b–c;VideoS2,S3",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C03 [source_scoped_result_summary]：Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.

明确方法关联：A161-P001

样本上下文：A161-R20261012-S03

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Figure2b–c;VideoS2,S3", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q004

该研究对“Noncancerous colon architecture”报告了什么？样本、方法、量值与限制分别是什么？

Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O04",
  "experiment_id": "A161-R20261012-E04",
  "sample_context_ids": [
    "A161-R20261012-S05"
  ],
  "metric": "Noncancerous colon architecture",
  "result": "Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.",
  "values": null,
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR04"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Figure2d;VideoS4",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C04 [source_scoped_result_summary]：Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.

明确方法关联：A161-P001

样本上下文：A161-R20261012-S05

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Figure2d;VideoS4", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q005

该研究对“Esophageal cancer vascular changes”报告了什么？样本、方法、量值与限制分别是什么？

Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O05",
  "experiment_id": "A161-R20261012-E05",
  "sample_context_ids": [
    "A161-R20261012-S01",
    "A161-R20261012-S02"
  ],
  "metric": "Esophageal cancer vascular changes",
  "result": "Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.",
  "values": {
    "height_test": "two-sample t-test",
    "height_p": "<0.05",
    "caption_n": 10,
    "n_unit": "not explicitly identified in caption; not10patients",
    "summary": "mean ±SD perAppendixS1",
    "means": null,
    "means_status": "not digitized",
    "fresh_visual": "S2panelc star/axis checked"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR05"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Figure3a;FigureS2;AppendixS1",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F04",
      "locator": "FigureS2c",
      "verification": "freshvisual"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C05 [source_scoped_result_summary]：Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.

明确方法关联：A161-P001、A161-P002、A161-P003

样本上下文：A161-R20261012-S01、A161-R20261012-S02

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Figure3a;FigureS2;AppendixS1", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F04", "locator": "FigureS2c", "verification": "freshvisual"}

### A161-R20261012-Q006

该研究对“Colon adenoma morphology/tortuosity”报告了什么？样本、方法、量值与限制分别是什么？

Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O06",
  "experiment_id": "A161-R20261012-E06",
  "sample_context_ids": [
    "A161-R20261012-S05",
    "A161-R20261012-S06"
  ],
  "metric": "Colon adenoma morphology/tortuosity",
  "result": "Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.",
  "values": {
    "tortuosity_p": "<0.05",
    "test": "two-sample t-test perAppendix",
    "caption_n": 3,
    "n_unit": "not explicitly resolved",
    "metric": "sum of path segments at40µm depth intervals to200µm divided by shortestD0–D200 distance",
    "source_formula_conflict": "A161-CF02",
    "display": "S3boxplot, not converted to mean±SD points",
    "fresh_visual": "formula typography and boxplot checked"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR06"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Figure3b;FigureS3;AppendixS1",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F05",
      "locator": "FigureS3a–b",
      "verification": "freshvisual"
    },
    {
      "source_id": "A161-R20261012-F03",
      "locator": "Measurement of tortuosity;Statistics",
      "verification": "freshfulltext"
    }
  ],
  "source_conflict_refs": [
    "A161-CF02"
  ]
}

```

结论及身份：

- A161-R20261012-C06 [source_scoped_result_summary]：Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.

明确方法关联：A161-P001、A161-P002、A161-P003

样本上下文：A161-R20261012-S05、A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Figure3b;FigureS3;AppendixS1", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F05", "locator": "FigureS3a–b", "verification": "freshvisual"}

- 来源：{"source_id": "A161-R20261012-F03", "locator": "Measurement of tortuosity;Statistics", "verification": "freshfulltext"}

直接相关原文冲突：

```json

[
  {
    "issue_id": "A161-CF02",
    "type": "source_formula_typography",
    "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
  }
]

```

### A161-R20261012-Q007

该研究对“Case-level one-to-one matching”报告了什么？样本、方法、量值与限制分别是什么？

Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O07",
  "experiment_id": "A161-R20261012-E07",
  "sample_context_ids": [
    "A161-R20261012-S02",
    "A161-R20261012-S04",
    "A161-R20261012-S06",
    "A161-R20261012-S07"
  ],
  "metric": "Case-level one-to-one matching",
  "result": "Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.",
  "values": {
    "esophagus": {
      "success": 3,
      "total": 3
    },
    "stomach": {
      "success": 2,
      "total": 4
    },
    "colorectum": {
      "success": 5,
      "total": 7
    },
    "matched_case_ids": [
      1,
      2,
      3,
      4,
      5,
      8,
      9,
      10,
      12,
      14
    ],
    "unmatched_case_ids": [
      6,
      7,
      11,
      13
    ],
    "criterion": "at least5 vessel/crypt structures, agreement of3engineers,pathologist,endoscopist",
    "total_cases": 14
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR07"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table1;Figure4;Results matching",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C07 [source_scoped_result_summary]：Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S02、A161-R20261012-S04、A161-R20261012-S06、A161-R20261012-S07

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table1;Figure4;Results matching", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q008

该研究对“Continuous vessel versus discontinuous endoscopic appearance”报告了什么？样本、方法、量值与限制分别是什么？

Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O08",
  "experiment_id": "A161-R20261012-E08",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Continuous vessel versus discontinuous endoscopic appearance",
  "result": "Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.",
  "values": {
    "case_id": 9,
    "vessel_ids": [
      1,
      2,
      3,
      4,
      5,
      6
    ],
    "narrative_depth_change_um": 20,
    "narrative_status": "approximately contextual path-depth change, not allTable3values20"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR08"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Figure5;Results matching",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C08 [source_scoped_result_summary]：Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Figure5;Results matching", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q009

该研究对“Case9 vessel1 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O09",
  "experiment_id": "A161-R20261012-E09",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Case9 vessel1 measured depth/caliber",
  "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
  "values": {
    "case_id": 9,
    "vessel_no": 1,
    "depth_um": 28.0,
    "caliber_um": 10.0,
    "value_type": "exact_table_value"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR09"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table3;Figure5",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C09 [source_scoped_result_summary]：Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table3;Figure5", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q010

该研究对“Case9 vessel2 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O10",
  "experiment_id": "A161-R20261012-E10",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Case9 vessel2 measured depth/caliber",
  "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
  "values": {
    "case_id": 9,
    "vessel_no": 2,
    "depth_um": 108.9,
    "caliber_um": 6.2,
    "value_type": "exact_table_value"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR10"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table3;Figure5",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C10 [source_scoped_result_summary]：Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table3;Figure5", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q011

该研究对“Case9 vessel3 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O11",
  "experiment_id": "A161-R20261012-E11",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Case9 vessel3 measured depth/caliber",
  "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
  "values": {
    "case_id": 9,
    "vessel_no": 3,
    "depth_um": 20.3,
    "caliber_um": 15.1,
    "value_type": "exact_table_value"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR11"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table3;Figure5",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C11 [source_scoped_result_summary]：Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table3;Figure5", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q012

该研究对“Case9 vessel4 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O12",
  "experiment_id": "A161-R20261012-E12",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Case9 vessel4 measured depth/caliber",
  "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
  "values": {
    "case_id": 9,
    "vessel_no": 4,
    "depth_um": 35.0,
    "caliber_um": 12.1,
    "value_type": "exact_table_value"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR12"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table3;Figure5",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C12 [source_scoped_result_summary]：Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table3;Figure5", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q013

该研究对“Case9 vessel5 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O13",
  "experiment_id": "A161-R20261012-E13",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Case9 vessel5 measured depth/caliber",
  "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
  "values": {
    "case_id": 9,
    "vessel_no": 5,
    "depth_um": 54.6,
    "caliber_um": 11.1,
    "value_type": "exact_table_value"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR13"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table3;Figure5",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C13 [source_scoped_result_summary]：Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table3;Figure5", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q014

该研究对“Case9 vessel6 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O14",
  "experiment_id": "A161-R20261012-E14",
  "sample_context_ids": [
    "A161-R20261012-S06"
  ],
  "metric": "Case9 vessel6 measured depth/caliber",
  "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
  "values": {
    "case_id": 9,
    "vessel_no": 6,
    "depth_um": 32.3,
    "caliber_um": 11.1,
    "value_type": "exact_table_value"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR14"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "Table3;Figure5",
      "verification": "publisher_text_inspected_20261012"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C14 [source_scoped_result_summary]：Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S06

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Table3;Figure5", "verification": "publisher_text_inspected_20261012"}

### A161-R20261012-Q015

该研究对“Case2 vessel1 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O15",
  "experiment_id": "A161-R20261012-E15",
  "sample_context_ids": [
    "A161-R20261012-S02"
  ],
  "metric": "Case2 vessel1 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 2,
    "vessel_no": 1,
    "depth_um": 14.1,
    "caliber_um": 18.7,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR15"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS4",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C15 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S02

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS4", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q016

该研究对“Case2 vessel2 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O16",
  "experiment_id": "A161-R20261012-E16",
  "sample_context_ids": [
    "A161-R20261012-S02"
  ],
  "metric": "Case2 vessel2 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 2,
    "vessel_no": 2,
    "depth_um": 22.7,
    "caliber_um": 24.5,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR16"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS4",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C16 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S02

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS4", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q017

该研究对“Case2 vessel3 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O17",
  "experiment_id": "A161-R20261012-E17",
  "sample_context_ids": [
    "A161-R20261012-S02"
  ],
  "metric": "Case2 vessel3 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 2,
    "vessel_no": 3,
    "depth_um": 35.3,
    "caliber_um": 12.5,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR17"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS4",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C17 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S02

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS4", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q018

该研究对“Case2 vessel4 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O18",
  "experiment_id": "A161-R20261012-E18",
  "sample_context_ids": [
    "A161-R20261012-S02"
  ],
  "metric": "Case2 vessel4 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 2,
    "vessel_no": 4,
    "depth_um": 31.1,
    "caliber_um": 10.5,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR18"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS4",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C18 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S02

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS4", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q019

该研究对“Case2 vessel5 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O19",
  "experiment_id": "A161-R20261012-E19",
  "sample_context_ids": [
    "A161-R20261012-S02"
  ],
  "metric": "Case2 vessel5 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 2,
    "vessel_no": 5,
    "depth_um": 22.7,
    "caliber_um": 10.5,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR19"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS4",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C19 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S02

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS4", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q020

该研究对“Case5 vessel1 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O20",
  "experiment_id": "A161-R20261012-E20",
  "sample_context_ids": [
    "A161-R20261012-S04"
  ],
  "metric": "Case5 vessel1 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 5,
    "vessel_no": 1,
    "depth_um": 49.6,
    "caliber_um": 11.9,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR20"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS5",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C20 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S04

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS5", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q021

该研究对“Case5 vessel2 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O21",
  "experiment_id": "A161-R20261012-E21",
  "sample_context_ids": [
    "A161-R20261012-S04"
  ],
  "metric": "Case5 vessel2 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 5,
    "vessel_no": 2,
    "depth_um": 52.9,
    "caliber_um": 10.5,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR21"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS5",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C21 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S04

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS5", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q022

该研究对“Case5 vessel3 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O22",
  "experiment_id": "A161-R20261012-E22",
  "sample_context_ids": [
    "A161-R20261012-S04"
  ],
  "metric": "Case5 vessel3 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 5,
    "vessel_no": 3,
    "depth_um": 45.5,
    "caliber_um": 11.7,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR22"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS5",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C22 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S04

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS5", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q023

该研究对“Case5 vessel4 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O23",
  "experiment_id": "A161-R20261012-E23",
  "sample_context_ids": [
    "A161-R20261012-S04"
  ],
  "metric": "Case5 vessel4 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 5,
    "vessel_no": 4,
    "depth_um": 69.0,
    "caliber_um": 12.0,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR23"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS5",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C23 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S04

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS5", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q024

该研究对“Case5 vessel5 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？

Exact original supplementary table3Dmeasurement; vessel count is not patient count.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O24",
  "experiment_id": "A161-R20261012-E24",
  "sample_context_ids": [
    "A161-R20261012-S04"
  ],
  "metric": "Case5 vessel5 measured depth/caliber",
  "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
  "values": {
    "case_id": 5,
    "vessel_no": 5,
    "depth_um": 47.1,
    "caliber_um": 8.6,
    "value_type": "exact_table_value",
    "source_asset": "DEN-37-659-s005.docx"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR24"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "TableS1;FigureS5",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F02",
      "locator": "TableS1 case/vessel row as in values",
      "verification": "freshoriginalDOCXtable_cells_read"
    }
  ],
  "source_conflict_refs": []
}

```

结论及身份：

- A161-R20261012-C24 [source_scoped_result_summary]：Exact original supplementary table3Dmeasurement; vessel count is not patient count.

明确方法关联：A161-P001、A161-P003

样本上下文：A161-R20261012-S04

- 来源：{"source_id": "A161-R20261012-F01", "locator": "TableS1;FigureS5", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F02", "locator": "TableS1 case/vessel row as in values", "verification": "freshoriginalDOCXtable_cells_read"}

### A161-R20261012-Q025

该研究对“Depth correlation with histology”报告了什么？样本、方法、量值与限制分别是什么？

Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.

完整结果记录：

```json

{
  "result_id": "A161-R20261012-O25",
  "experiment_id": "A161-R20261012-E25",
  "sample_context_ids": [
    "A161-R20261012-S06",
    "A161-R20261012-S07"
  ],
  "metric": "Depth correlation with histology",
  "result": "Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.",
  "values": {
    "case_ids": [
      8,
      9,
      11,
      13
    ],
    "x": "3Ddepthµm",
    "y": "histologydepthµm",
    "slope": 0.8823,
    "intercept": 8.547,
    "R_squared": 0.9748,
    "value_type": "exact_printed_figure_annotation",
    "fresh_visual": true,
    "raw_points": null,
    "raw_points_status": "bar/scatter positions not digitized",
    "error_type": "not separately resolved forS6bars",
    "source_conflict": "A161-CF03"
  },
  "result_type": "author_reported_text_and_caption",
  "measurement_time": null,
  "measurement_time_status": "not_reported_unless_explicit_in_values",
  "artifact_ids": [
    "A161-R20261012-AR25"
  ],
  "source_refs": [
    {
      "source_id": "A161-R20261012-F01",
      "locator": "FigureS6a–c;Results matching",
      "verification": "publisher_text_inspected_20261012"
    },
    {
      "source_id": "A161-R20261012-F06",
      "locator": "FigureS6a–c",
      "verification": "freshvisualprintedregression"
    }
  ],
  "source_conflict_refs": [
    "A161-CF03"
  ]
}

```

结论及身份：

- A161-R20261012-C25 [source_scoped_result_summary]：Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.

明确方法关联：A161-P001、A161-P002、A161-P003

样本上下文：A161-R20261012-S06、A161-R20261012-S07

- 来源：{"source_id": "A161-R20261012-F01", "locator": "FigureS6a–c;Results matching", "verification": "publisher_text_inspected_20261012"}

- 来源：{"source_id": "A161-R20261012-F06", "locator": "FigureS6a–c", "verification": "freshvisualprintedregression"}

直接相关原文冲突：

```json

[
  {
    "issue_id": "A161-CF03",
    "type": "source_metric_scope",
    "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
  }
]

```

### A161-R20261012-Q026

作者提出了什么解释、限制或前景，其证据身份是什么？

结论及身份：

- A161-R20261012-AX01 [author_future_prospect]：Method may improve endoscopic interpretation/technology; larger representative series and diagnosticclassification validation remain future work.

明确方法关联：未绑定独立执行协议；保持原范围。

样本上下文：作者陈述/综合范围，不新增样本。

- 来源：{"source_id": "A161-R20261012-F01", "locator": "Discussion", "verification": "publisher_text_inspected_20261012"}

## 样本上下文与信号身份

以下是原核心上下文，不把节点数当作动物、患者或标本n。

```json

[
  {
    "sample_id": "A161-R20261012-S01",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human esophageal noncancerous tissue adjacent to resected neoplasms; FFPE block",
    "signals": "wholemount directly conjugated CD34-AF647 vessels andSYTO16 nuclei; comparator sections CD31, D2-40/H&E are distinct",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Figures2a,3a; Methods",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  },
  {
    "sample_id": "A161-R20261012-S02",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human esophageal squamous cell carcinoma FFPE contexts; published cases1–3",
    "signals": "CD34-AF647 vessels;SYTO16 nuclei; histology/CD31 comparison separately",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Table1; Figures3a,4a;S2/S4",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  },
  {
    "sample_id": "A161-R20261012-S03",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human noncancerous upper/lower stomach FFPE contexts",
    "signals": "CD34-AF647 andSYTO16",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Figure2b–c",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  },
  {
    "sample_id": "A161-R20261012-S04",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human gastric neoplasm FFPE contexts; cases4–7, adenoma/adenocarcinoma specified perTable1",
    "signals": "CD34-AF647 andSYTO16",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Table1;Figure4;S5",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  },
  {
    "sample_id": "A161-R20261012-S05",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human nonadenoma colon FFPE context",
    "signals": "CD34-AF647 andSYTO16;CD31 sections separate",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Figures2d,3b;S3",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  },
  {
    "sample_id": "A161-R20261012-S06",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human colorectal adenoma/adenocarcinoma FFPE contexts;cases8,9,10,12,14",
    "signals": "CD34-AF647 andSYTO16",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Table1;Figures3b,4,5;Table3;S6",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  },
  {
    "sample_id": "A161-R20261012-S07",
    "sample_identity_level": "context_class_not_individual",
    "sample": "Human sessile serrated lesion FFPE contexts;cases11,13, failed endoscopic one-to-one matching but present indepth comparison",
    "signals": "CD34-AF647 wholemount;CD31 histology comparison",
    "reported_n": null,
    "n_status": "only_panel_specific_counts_in_results",
    "measurement_elapsed_time": null,
    "measurement_elapsed_time_status": "not_reported",
    "protocol_uses": [
      {
        "protocol_id": "A161-P001",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P002",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      },
      {
        "protocol_id": "A161-P003",
        "scope": "declared_branch_only",
        "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
      }
    ],
    "source_refs": [
      {
        "source_id": "A161-R20261012-F01",
        "locator": "Table1;FigureS6",
        "verification": "publisher_text_inspected_20261012"
      }
    ]
  }
]

```

## 全部来源与核验层级

```json

{
  "sources": [
    {
      "source_id": "A161-R20261012-F01",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/fullTextXML",
      "local_extracts": [
        {
          "path": "sources/DEN-37-659-s001.tif",
          "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937"
        },
        {
          "path": "sources/DEN-37-659-s001.tif.png",
          "sha256": "4f9470733a480c948d8595657f18d3cedb02cefb3a0f13a0b155d7d2c27470b7"
        },
        {
          "path": "sources/DEN-37-659-s002.tif",
          "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da"
        },
        {
          "path": "sources/DEN-37-659-s002.tif.png",
          "sha256": "6835483e1dbc457e0417741409282ded7caf97cc9e98549862a5997bf345928f"
        },
        {
          "path": "sources/DEN-37-659-s005.docx",
          "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48"
        },
        {
          "path": "sources/DEN-37-659-s005.txt",
          "sha256": "39e59cbca96e1cbcf983634e542da88a222b4d934919ffb645f091b4aaa11b0b"
        },
        {
          "path": "sources/DEN-37-659-s006.tif",
          "sha256": "f6ce6511b2f8c841cd57a61219253b95c8b1ad71127969327bdab8242bd7aea1"
        },
        {
          "path": "sources/DEN-37-659-s007.tif",
          "sha256": "ce946971381764881239d939ecbbc78703f9782579ed0687fa8fff1f5a292eef"
        },
        {
          "path": "sources/DEN-37-659-s009.tif",
          "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91"
        },
        {
          "path": "sources/DEN-37-659-s009.tif.png",
          "sha256": "8767f8ce285b4cfab1be642e13b12743bd86c0fa4d4a910be8e3f0779c6768b2"
        },
        {
          "path": "sources/DEN-37-659-s011.docx",
          "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b"
        },
        {
          "path": "sources/DEN-37-659-s011.txt",
          "sha256": "1e64b7b8f0ceda3efa5266f2e2c0059aafd90bc8cad2516e374fdc31cda43a31"
        },
        {
          "path": "sources/DEN-37-659-s012.tif",
          "sha256": "cc3a8719577e910fcba74167a9f9f171dc3a6b14f8f81b8ad2ee0fe8af522d8c"
        },
        {
          "path": "sources/article_readable.txt",
          "sha256": "af1c70390cd8053a86afb1fa66bfbad07133a7f26ff2e5492bdd00def679cec0"
        },
        {
          "path": "sources/europepmc.xml",
          "sha256": "4776fdfe21f6ea816556832302c9cb258b846013765848d417242be40a239e59"
        },
        {
          "path": "sources/fetch_DEN-37-659-s005.docx.json",
          "sha256": "d00ff06f2eb8345ff864529341a948f3b64af7f6ae6a6683d4ae2832c372c1ad"
        },
        {
          "path": "sources/fetch_DEN-37-659-s011.docx.json",
          "sha256": "940eb641c01da07f39168262fe6d36280281d23240edfa037003a35d636d1d9c"
        },
        {
          "path": "sources/inherited_source_excerpts.json",
          "sha256": "9402335b2043938bf7258b3eaffab36d062cf5e3df986204e0a6c235daa1fb83"
        },
        {
          "path": "sources/retrieval.json",
          "sha256": "6fb3e85d2fe9b1697eec9aa3d0036bc74d19e3120a3bda0a5150b62fb72c4bd9"
        },
        {
          "path": "sources/supplement_retrieval.json",
          "sha256": "6f1e2481a1bee3295ebbf57158a4ecf8219e839561775adeff59fd3a2c826d4c"
        },
        {
          "path": "sources/supplements.zip",
          "sha256": "2ddced6570c58c8c96d17b9dce71fb8a156be09f732859734dac0160f7a1a4c6"
        }
      ],
      "inspection": "Full articleXML, AppendixS1,TableS1; FiguresS2/S3/S6 visually checked; other figure/movie coverage inherited."
    },
    {
      "source_id": "A161-R20261012-F02",
      "local_path": "sources/DEN-37-659-s005.docx",
      "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "TableS1 full10vessel depth/caliber rows"
    },
    {
      "source_id": "A161-R20261012-F03",
      "local_path": "sources/DEN-37-659-s011.docx",
      "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "AppendixS1fulltext"
    },
    {
      "source_id": "A161-R20261012-F04",
      "local_path": "sources/DEN-37-659-s001.tif",
      "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS2limitedvisual"
    },
    {
      "source_id": "A161-R20261012-F05",
      "local_path": "sources/DEN-37-659-s009.tif",
      "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS3limitedvisual"
    },
    {
      "source_id": "A161-R20261012-F06",
      "local_path": "sources/DEN-37-659-s002.tif",
      "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS6limitedvisual"
    }
  ],
  "coverage_dimensions": {
    "historical_review": {
      "status": "inherited_not_reperformed",
      "path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "pointer": "/baseline",
      "exact_record": {
        "selected_core_files": {
          "evidence_json": {
            "path": "A161_candidate/A161_evidence.json",
            "sha256": "00a4d65bfe5ee26ddbc5530c979720787035b6613060ff58eca7955090cc3a0f"
          },
          "questions_json": {
            "path": "A161_candidate/A161_questions.json",
            "sha256": "16dbc4328ff4088057e133fb70f276464a3680c987c3c288dcbe266235e729e9"
          },
          "reading_md": {
            "path": "A161_candidate/A161_reading_zh.md",
            "sha256": "4066b8b125d49c1db9b545fe7ebd4f29b27f50d725bd88979d800bbde2e9d362"
          }
        },
        "existing_protocol_index": "none",
        "preserved_status": {
          "state": "held_source_reviewed_candidate_pending_specified_review",
          "not_reperformed": "No new scientific acceptance/delivery/count increment",
          "core_status_fields": {
            "record_id_status": "candidate_not_accepted_not_counted",
            "review_status": {
              "source_first_self_review": "completed for stated scope",
              "independent_review": "completed_repairs_verified_no_remaining_blocking_or_major_issue_in_nonoperational_scope",
              "structural_check": "passed",
              "bundled_skill_scripts_run": false,
              "applicable_rules": "R0–R5/R7–R8 applied to nonoperational evidence; R4 execution recovery excluded; R6 digitization not performed; RS selection support not requested",
              "self_review_repairs": [
                "按实际源图限定E01各器官与E02各视频来源",
                "移除通用ME-NBI条件继承；E09切片不继承ECi",
                "分开量化信号与HE/CD31/NBI参照信号",
                "仅30×明确硅油浸；JPG阅图副本未称无损转换"
              ],
              "structural_check_report": "review_assets/structure_check.json",
              "independent_review_report": "A161_independent_review.md",
              "independent_checks": "A161_independent_checks.json",
              "pro_acceptance": false,
              "formal_acceptance": false,
              "reviewed_scientific_snapshot_hashes": {
                "A161_reading_zh.md": "42328b8540f3640ec71fce6a3a6dd22188d60ff0130553b65b575d882e417367",
                "A161_evidence.json": "1d8bf2cde2b7dea81840d32a38ca17ffb85a82c0a7b408735733a5ebc3c4894d",
                "A161_questions.json": "bd6b647d51d0c9f9fa83c1cc8d0f9cc0ad0e6f2571c22ca0d0fa0b9821fade13"
              }
            }
          },
          "local_review_and_scope_records": [
            "A161_candidate/A161_independent_checks.json",
            "A161_candidate/A161_independent_review.md"
          ]
        },
        "originals_modified": false,
        "acceptance_or_count_changed": false,
        "runtime_integration": false,
        "upload_or_publication": false
      }
    },
    "new_main_text_relationships": "reviewed",
    "fresh_visual_review": {
      "status": "performed_limited",
      "assets": [
        "DEN-37-659-s001.tif",
        "DEN-37-659-s009.tif",
        "DEN-37-659-s002.tif"
      ],
      "scope": "FiguresS2/S3/S6 axes/significance/formula and S6exact printed regression; not numericalbar digitization"
    },
    "specified_Pro_gate": "unchanged_hold",
    "parent_review": "pending",
    "raw_reanalysis": "not_performed_not_required_for_literature_review"
  },
  "all_source_conflicts": [
    {
      "issue_id": "A161-CF01",
      "type": "source_locator_difference",
      "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
    },
    {
      "issue_id": "A161-CF02",
      "type": "source_formula_typography",
      "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
    },
    {
      "issue_id": "A161-CF03",
      "type": "source_metric_scope",
      "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
    }
  ]
}

```
