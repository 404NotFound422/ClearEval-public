# A161 完整无损阅读投影

本阅读稿逐字段呈现当前完整核心、当前P与问题；不新增科学摘要、不代表expert gold、Pro或出版批准。原短阅读稿和审阅报告保留为独立伴随文件。

## 当前完整科学核心

```json

{
  "schema_version": "reconstructed-research-evidence-1.0",
  "paper_id": "A161",
  "title": "Three-dimensional optically cleared tissue imaging for analyzing endoscopic images of gastrointestinal neoplasms (with video)",
  "doi": "10.1111/den.15000",
  "version": "2026-10-12-source-reconstruction.1",
  "not_historical_hash_restoration": true,
  "old_files_modified": false,
  "publication_approved": false,
  "status": "new_source_reconstruction_parent_review_pending",
  "source_files": [
    {
      "source_id": "A161-R20261012-F01",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/fullTextXML",
      "local_extracts": [
        {
          "path": "sources/DEN-37-659-s001.tif",
          "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937"
        },
        {
          "path": "sources/DEN-37-659-s001.tif.png",
          "sha256": "4f9470733a480c948d8595657f18d3cedb02cefb3a0f13a0b155d7d2c27470b7"
        },
        {
          "path": "sources/DEN-37-659-s002.tif",
          "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da"
        },
        {
          "path": "sources/DEN-37-659-s002.tif.png",
          "sha256": "6835483e1dbc457e0417741409282ded7caf97cc9e98549862a5997bf345928f"
        },
        {
          "path": "sources/DEN-37-659-s005.docx",
          "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48"
        },
        {
          "path": "sources/DEN-37-659-s005.txt",
          "sha256": "39e59cbca96e1cbcf983634e542da88a222b4d934919ffb645f091b4aaa11b0b"
        },
        {
          "path": "sources/DEN-37-659-s006.tif",
          "sha256": "f6ce6511b2f8c841cd57a61219253b95c8b1ad71127969327bdab8242bd7aea1"
        },
        {
          "path": "sources/DEN-37-659-s007.tif",
          "sha256": "ce946971381764881239d939ecbbc78703f9782579ed0687fa8fff1f5a292eef"
        },
        {
          "path": "sources/DEN-37-659-s009.tif",
          "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91"
        },
        {
          "path": "sources/DEN-37-659-s009.tif.png",
          "sha256": "8767f8ce285b4cfab1be642e13b12743bd86c0fa4d4a910be8e3f0779c6768b2"
        },
        {
          "path": "sources/DEN-37-659-s011.docx",
          "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b"
        },
        {
          "path": "sources/DEN-37-659-s011.txt",
          "sha256": "1e64b7b8f0ceda3efa5266f2e2c0059aafd90bc8cad2516e374fdc31cda43a31"
        },
        {
          "path": "sources/DEN-37-659-s012.tif",
          "sha256": "cc3a8719577e910fcba74167a9f9f171dc3a6b14f8f81b8ad2ee0fe8af522d8c"
        },
        {
          "path": "sources/article_readable.txt",
          "sha256": "af1c70390cd8053a86afb1fa66bfbad07133a7f26ff2e5492bdd00def679cec0"
        },
        {
          "path": "sources/europepmc.xml",
          "sha256": "4776fdfe21f6ea816556832302c9cb258b846013765848d417242be40a239e59"
        },
        {
          "path": "sources/fetch_DEN-37-659-s005.docx.json",
          "sha256": "d00ff06f2eb8345ff864529341a948f3b64af7f6ae6a6683d4ae2832c372c1ad"
        },
        {
          "path": "sources/fetch_DEN-37-659-s011.docx.json",
          "sha256": "940eb641c01da07f39168262fe6d36280281d23240edfa037003a35d636d1d9c"
        },
        {
          "path": "sources/inherited_source_excerpts.json",
          "sha256": "9402335b2043938bf7258b3eaffab36d062cf5e3df986204e0a6c235daa1fb83"
        },
        {
          "path": "sources/retrieval.json",
          "sha256": "6fb3e85d2fe9b1697eec9aa3d0036bc74d19e3120a3bda0a5150b62fb72c4bd9"
        },
        {
          "path": "sources/supplement_retrieval.json",
          "sha256": "6f1e2481a1bee3295ebbf57158a4ecf8219e839561775adeff59fd3a2c826d4c"
        },
        {
          "path": "sources/supplements.zip",
          "sha256": "2ddced6570c58c8c96d17b9dce71fb8a156be09f732859734dac0160f7a1a4c6"
        }
      ],
      "inspection": "Full articleXML, AppendixS1,TableS1; FiguresS2/S3/S6 visually checked; other figure/movie coverage inherited."
    },
    {
      "source_id": "A161-R20261012-F02",
      "local_path": "sources/DEN-37-659-s005.docx",
      "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "TableS1 full10vessel depth/caliber rows"
    },
    {
      "source_id": "A161-R20261012-F03",
      "local_path": "sources/DEN-37-659-s011.docx",
      "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "AppendixS1fulltext"
    },
    {
      "source_id": "A161-R20261012-F04",
      "local_path": "sources/DEN-37-659-s001.tif",
      "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS2limitedvisual"
    },
    {
      "source_id": "A161-R20261012-F05",
      "local_path": "sources/DEN-37-659-s009.tif",
      "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS3limitedvisual"
    },
    {
      "source_id": "A161-R20261012-F06",
      "local_path": "sources/DEN-37-659-s002.tif",
      "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS6limitedvisual"
    }
  ],
  "protocols": [
    {
      "protocol_id": "A161-P001",
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "source_sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "source_pointer": "/protocol_records/0",
      "record": {
        "record_id": "A161-P001",
        "record_type": "reported_workflow_with_explicit_unreported_details",
        "title": {
          "value": "食管、胃与结直肠FFPE组织块的整块标记、ECi透明化与共聚焦三维采集",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.4, Tissue-block processing"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "恢复本文Table2与AppendixS1直接给出的处理条件及重叠标记时间；不套用切片成像设置。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.4, Tissue-block processing"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "人食管/胃ESD、结肠EMR取得；10% buffered formalin固定并石蜡包埋；共14例，器官/病种适用范围保留原核心。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.2, Human specimens"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "存档FFPE块，经内镜和切除组织图定位选块，组织学连续切片先取出，随后整块处理。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "ECi透明化块的CD34与核染三维图像",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.4, Tissue-block processing"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "已固定并石蜡包埋的组织；10% buffered formalin固定史（具体时长/温度未报）",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF p.2, Human specimens"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "Xylene、100/70/50% ethanol、PBS",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF p.4, Table 2"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "Citrate pH6 S2369；PBS T900；TritonX100 T9284；BSA013-27054；CD34–Alexa647 QBend10/FAB7227R；SYTO16S7578；ECi112372",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "FV3000、UPLSAPO10x/UPLSAPO30x SIR；Imaris",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "选择与脱蜡",
            "steps": [
              {
                "step_id": "A161-P001-S01",
                "display_order": 1,
                "action": {
                  "value": "选择同时具备白光、NBI、ME-NBI和切除组织体视图的材料；内镜医师和病理医师据图选择包含ROI的组织块。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {},
                "notes": {
                  "value": "该选择限定本文分析样本；不推断随机或连续入组。组织学切片支路见P002。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A161-P001-S02",
                "display_order": 2,
                "action": {
                  "value": "从石蜡块切出组织，刀片去除多余石蜡，并以paraffin block trimmer加热。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    },
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "cut_out": {
                    "value": "RT, 5 min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "trimmer": {
                    "value": "62 °C, 5 min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "刀片去除多余蜡来自Appendix S1；切出与trimmer先后按Table2，不补块尺寸或刀片型号。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A161-P001-S03",
                "display_order": 3,
                "action": {
                  "value": "以二甲苯连续两轮脱蜡。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "first_xylene": {
                    "value": "60 °C, 90 min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "second_xylene": {
                    "value": "60 °C, 90 min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "两个独立列出的xylene段保留；不因同试剂合并丢失重复。体积和换液方式未报告。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A161-P001-S04",
                "display_order": 4,
                "action": {
                  "value": "依序乙醇复水，最后PBS过夜。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "ordered_series": {
                    "value": [
                      "100% ethanol, RT, 60 min",
                      "70% ethanol, RT, 60 min",
                      "50% ethanol, RT, 60 min",
                      "PBS, RT, overnight"
                    ],
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "percentage_basis": {
                    "value": "表中未说明v/v或w/v；100%表示所报使用浓度，不推产品纯度",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": null,
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "抗原修复与通透封闭",
            "steps": [
              {
                "step_id": "A161-P001-S05",
                "display_order": 5,
                "action": {
                  "value": "在柠檬酸抗原修复液中加热。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "buffer": {
                    "value": "Dako Target Retrieval Solution Citrate pH6, S2369; Agilent",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "pH": {
                    "value": "6",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "95 °C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "30 min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": null,
                "legacy_P_or_row": null
              },
              {
                "step_id": "A161-P001-S06",
                "display_order": 6,
                "action": {
                  "value": "在通透/封闭液中过夜。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "composition": {
                    "value": "PBS (T900, Takara Bio) +0.25% Triton X-100 (T9284,Sigma-Aldrich) +1% BSA (013-27054,FUJIFILM Wako)；仅组成整理，%基准与加料/定容细节未报告",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "4 °C",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "overnight",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": null,
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "重叠整块染色",
            "steps": [
              {
                "step_id": "A161-P001-S07",
                "display_order": 7,
                "action": {
                  "value": "以直接荧光偶联CD34抗体作整块免疫染色。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "antibody": {
                    "value": "Alexa647-CD34 monoclonal; cloneQBend10; FAB7227R; R&D Systems",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "dilution": {
                    "value": "1/100",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "4 °C",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "14 days",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "工作液是否与通透封闭液完全相同、体积、洗液更换和震荡条件未明确，不自动继承。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              },
              {
                "step_id": "A161-P001-S08",
                "display_order": 8,
                "action": {
                  "value": "抗体孵育开始7天后加入SYTO16核染；其7天染色与CD34最后7天重叠。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "nuclear_stain": {
                    "value": "SYTO16 (S7578; Invitrogen)",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "dilution": {
                    "value": "1/1000",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "addition_time": {
                    "value": "7 days after initiation of antibody incubation",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "SYTO16_temperature": {
                    "value": "4 °C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "SYTO16_duration": {
                    "value": "7 days",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "不是CD34完成14天后再串行染7天；不把两者累加为21天。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "染后清洗与脱水",
            "steps": [
              {
                "step_id": "A161-P001-S09",
                "display_order": 9,
                "action": {
                  "value": "以PBS清洗，随后依次乙醇脱水。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "ordered_series": {
                    "value": [
                      "PBS,4 °C,6 h",
                      "50% ethanol,4 °C,12 h",
                      "70% ethanol,4 °C,12 h",
                      "100% ethanol,4 °C,12 h"
                    ],
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "percentage_basis": {
                    "value": "未单标v/v或w/v",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "各段体积及是否有内部换液未报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "ECi折射率匹配",
            "steps": [
              {
                "step_id": "A161-P001-S10",
                "display_order": 10,
                "action": {
                  "value": "将组织在ethyl cinnamate中孵育透明化。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "reagent": {
                    "value": "ethyl cinnamate (112372; Sigma-Aldrich)",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "duration": {
                    "value": "24 h（Table2写1day）",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "room temperature",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "gentle shaking",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "light": {
                    "value": "dark",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "温度/轻摇/避光在Appendix明确修饰ECi段；不扩展给此前所有段。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "清除组织共聚焦采集",
            "steps": [
              {
                "step_id": "A161-P001-S11",
                "display_order": 11,
                "action": {
                  "value": "用倒置FV3000共聚焦系统采集光学切片。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "instrument": {
                    "value": "FV3000; Evident",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "objective_branch_10x": {
                    "value": "UPLSAPO10x; z-step4.2 µm",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "objective_branch_30x": {
                    "value": "UPLSAPO30x SIR silicone immersion; z-step0.8 µm",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "nuclear_channel": {
                    "value": "SYTO16 excitation488 nm; detection500–540 nm variable barrier filter",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "vessel_channel": {
                    "value": "Alexa647-CD34 excitation640 nm; detection650–750 nm variable barrier filter",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "acquisition_temperature": {
                    "value": "RT",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "acquisition_duration": {
                    "value": "1–2 h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Table 2"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "known_panel_objectives": {
                    "value": "Fig.S2a三维全层图（不含其配对HE图）：10×；Fig.2核/血管图：30×，作者报告可见深度约350µm。其他逐病例/面板选择未充分报告。",
                    "source_raw": "all layers ... using a10× objective lens (Fig.S2a); captured to a depth of~350µm ... using a30× objective lens (Fig.2)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.7 Results > 3D reconstructed images of optically cleared noncancerous gastrointestinal tissues"
                      }
                    ],
                    "check_status": "verified_against_primary_source",
                    "read_basis": "this_round_primary_PDF_text_and_visual"
                  }
                },
                "notes": {
                  "value": "Fig.S2a三维全层图（不含HE）明确10×；Fig.2明确30×与约350µm成像深度。其他病例/面板使用分支未完全列出；不将全部图继承同一z-step。曝光/功率/pinhole/像素采样及成像腔配液未报。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "三维重建",
            "steps": [
              {
                "step_id": "A161-P001-S12",
                "display_order": 12,
                "action": {
                  "value": "用Imaris重建光学切片，以top-view对应内镜、side-view对应组织学平面。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Tissue-block processing"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "software": {
                    "value": "Imaris (Bitplane AG), version not reported",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Tissue-block processing"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "view_definitions": {
                    "value": "原文描述top-view from direction parallel to mucosal plane；side-view from vertical cross-sectional direction",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.4, Tissue-block processing"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "保留作者视向词及图示用途；不根据惯常几何替换原文parallel/vertical措辞。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Tissue-block processing"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [
          {
            "case_id": "CD34_SYTO16_overlap",
            "description": {
              "value": "SYTO16加入节点是CD34开始后第7天；两种标记同于14天抗体孵育的后半段。",
              "source_refs": [
                {
                  "source_id": "F14",
                  "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "temporal_relation": {
              "parent_step": "A161-P001-S07",
              "nested_step": "A161-P001-S08",
              "offset_days": 7,
              "nested_duration_days": 7,
              "parent_duration_days": 14
            }
          },
          {
            "case_id": "10x_or_30x_acquisition",
            "description": {
              "value": "10×/4.2µm 与30×/0.8µm为不同采集配置；本来源不能把某配置无条件赋给全部病例/面板。 已知例外：S2a的三维全层图为10×（同面板配对HE图不继承），Fig.2为30×；其余面板选择未完全列明。",
              "source_refs": [
                {
                  "source_id": "F14",
                  "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                },
                {
                  "source_id": "F01",
                  "locator": "PDF p.7 Results: whole-layer3D image Fig.S2a10× and Fig.2 30×"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "per_case_selection": "not_fully_reported"
          },
          {
            "case_id": "Fig2_display_and_known_objective",
            "description": {
              "value": "Fig.2的显示厚度与已报告成像深度不同；相应器官支路分别保存。",
              "source_raw": "Top-view thickness250µm esophagus;150µm stomach,colon; side-view thickness150µm;30×;~350µm",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDF pp.5,7 Fig.2 caption and Results"
                }
              ],
              "check_status": "verified_against_primary_source",
              "read_basis": "this_round_primary_PDF_text_and_visual"
            },
            "panel_scope": {
              "value": {
                "Fig.2a": {
                  "organ": "esophagus",
                  "top_view_display_thickness_um": 250,
                  "side_view_display_thickness_um": 150
                },
                "Fig.2b/c": {
                  "organ": "stomach upper/lower",
                  "top_view_display_thickness_um": 150,
                  "side_view_display_thickness_um": 150
                },
                "Fig.2d": {
                  "organ": "colon",
                  "top_view_display_thickness_um": 150,
                  "side_view_display_thickness_um": 150
                }
              },
              "source_raw": "Top-view thickness250µm esophagus;150µm stomach,colon; side-view thickness150µm;30×;~350µm",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDF pp.5,7 Fig.2 caption and Results"
                }
              ],
              "check_status": "verified_against_primary_caption"
            },
            "meaning": "显示slab厚度；不是实体组织厚度、通用采集范围或z-step。",
            "known_objective": "30×",
            "reported_imaging_depth": "~350µm"
          }
        ],
        "reported_precedence": {
          "edges": [
            [
              "A161-P001-S01",
              "A161-P001-S02"
            ],
            [
              "A161-P001-S02",
              "A161-P001-S03"
            ],
            [
              "A161-P001-S03",
              "A161-P001-S04"
            ],
            [
              "A161-P001-S04",
              "A161-P001-S05"
            ],
            [
              "A161-P001-S05",
              "A161-P001-S06"
            ],
            [
              "A161-P001-S06",
              "A161-P001-S07"
            ],
            [
              "A161-P001-S08",
              "A161-P001-S09"
            ],
            [
              "A161-P001-S09",
              "A161-P001-S10"
            ],
            [
              "A161-P001-S10",
              "A161-P001-S11"
            ],
            [
              "A161-P001-S11",
              "A161-P001-S12"
            ]
          ],
          "overlap": {
            "step": "A161-P001-S08",
            "within": "A161-P001-S07",
            "offset": "7days",
            "ends_with": "S07 at14days"
          },
          "before_whole_block_processing": "P002 serial histology sections are obtained before processing the remaining block",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "Table2 and Tissue-block selection"
            },
            {
              "source_id": "F14",
              "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
            }
          ]
        },
        "missing_information": [
          "原固定时长/温度和处理前存档时长、组织块实际尺寸未报告。",
          "配液基准、体积、孵育中换液/混匀细节未充分；不以常用配方补写。",
          "除S2a10×/Fig.2 30×已知外，其余具体病例/面板归属、功率/pinhole/像素大小未完全报告。",
          "Table2 day列是计划阶段标签；ON保持原义，不反推小时或精确总时长。"
        ],
        "source_conflicts": [],
        "review_status": "source_checked_direct_reported_scope; independent_audit_pending"
      },
      "preservation": "inherited values and IDs unchanged"
    },
    {
      "protocol_id": "A161-P002",
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "source_sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "source_pointer": "/protocol_records/1",
      "record": {
        "record_id": "A161-P002",
        "record_type": "partial_histology_and_reported_slide_imaging",
        "title": {
          "value": "比较用组织切片的染色入口、全片扫描与测量",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "保留二维组织学分支，避免与整块CD34/共聚焦路线混淆。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "所选FFPE块的连续组织切片；H&E、CD31或podoplanin支路。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "选定FFPE组织块",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "组织学切片图像及VS200 ASW测量",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "H&E；anti-CD31 JC70；antipodoplanin D2-40；Roche Diagnostics",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF pp.2,4, Tissue-block selection"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "VS200、UPLXAPO20x、VS200 ASW",
            "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "切片与染色参考",
            "steps": [
              {
                "step_id": "A161-P002-S01",
                "display_order": 1,
                "action": {
                  "value": "对所选组织块连续切片，作H&E和免疫染色。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "histology_stains": {
                    "value": "hematoxylin and eosin",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.2,4, Tissue-block selection"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "CD31": {
                    "value": "anti-CD31; cloneJC70; Roche Diagnostics",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.2,4, Tissue-block selection"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "podoplanin": {
                    "value": "antipodoplanin; cloneD2-40; Roche Diagnostics",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.2,4, Tissue-block selection"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "切片厚度、染色稀释、修复、显色和孵育参数未给；仅方法入口，不制造完整组织学SOP。不要把CD34–Alexa647整块条件继承到CD31/D2-40切片。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "二维切片扫描",
            "steps": [
              {
                "step_id": "A161-P002-S02",
                "display_order": 2,
                "action": {
                  "value": "用全玻片扫描系统与20×物镜采集组织切片图。",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "scanner": {
                    "value": "VS200; Evident Corporation",
                    "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "objective": {
                    "value": "20× UPLXAPO20x; Evident",
                    "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "不继承FV3000、10×/30×光学层扫描或SYTO16设置。",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "二维切片测量",
            "steps": [
              {
                "step_id": "A161-P002-S03",
                "display_order": 3,
                "action": {
                  "value": "用VS200 ASW软件对切片图进行测量分析。",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "software": {
                    "value": "VS200 ASW; Evident",
                    "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "逐项测量校准、血管/切片抽样数、误差及配对规则未报告。S6明确CD31组织学深度图，不自动使用D2-40作该读出。",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [],
        "reported_precedence": [
          "选块→切片染色→VS200采集→VS200 ASW测量；切片在剩余组织块整块染色/透明化前取得。"
        ],
        "missing_information": [
          "组织学染色细节在本材料缺失，流程仅部分报告。",
          "不是全部器官/每幅图都采用相同切片标记；按面板及G/O匹配。"
        ],
        "source_conflicts": [],
        "review_status": "source_checked_direct_reported_scope; independent_audit_pending"
      },
      "preservation": "inherited values and IDs unchanged"
    },
    {
      "protocol_id": "A161-P003",
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "source_sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "source_pointer": "/protocol_records/2",
      "record": {
        "record_id": "A161-P003",
        "record_type": "reported_matching_and_measurement_workflow_with_algorithm_gaps",
        "title": {
          "value": "内镜与三维图像匹配、血管量测及限定统计",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "分开器官匹配门槛、病例位置深度、食管高度和结肠曲折度，保持读出各自条件。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "已有ME-NBI图与清除后3D图；匹配条件及后续测量按器官/病例分开。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "已取得的内镜图及Imaris三维重建",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "人工对应关系、血管深度/管径或限定组织形态量测",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "已有EVISX1/GIF-XZ1200或CF-XZ1200内镜图",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF p.2, Human specimens"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "Imaris或ImageJ",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF p.5, Measurement of vessel depth and caliber"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "Minitab21.4.2",
            "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Statistical analysis; rendered pp.3"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "内镜影像上下文",
            "steps": [
              {
                "step_id": "A161-P003-S01",
                "display_order": 1,
                "action": {
                  "value": "使用既存内镜图作为匹配输入；保留原采集设备和器官分支倍数。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.2, Human specimens"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "device": {
                    "value": "EVIS X1 (Olympus Medical Systems) with GIF-XZ1200 or CF-XZ1200",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.2, Human specimens"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "esophagus_stomach_magnification": {
                    "value": "70×–80×",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.2, Human specimens"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "colon_magnification": {
                    "value": "70×–100×",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.2, Human specimens"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "这是本文已有影像的采集上下文，不是对受试者重新进行内镜操作的指南。具体型号逐病例分配未报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.2, Human specimens"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "人工一对一匹配",
            "steps": [
              {
                "step_id": "A161-P003-S02",
                "display_order": 2,
                "action": {
                  "value": "由三名非医疗工程师比较血管/隐窝形状和相对位置，选出相应区域，再由病理医师及内镜医师确认。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "minimum_structures": {
                    "value": "at least5",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "esophagus_criterion": {
                    "value": "至少5条血管形状与相对位置相符",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "stomach_colon_criterion": {
                    "value": "血管与隐窝合计至少5个结构相符",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "observer_rule": {
                    "value": "3 engineers +1 pathologist +1 endoscopist；5人任一不同意即未匹配",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "人工匹配标准，不等于自动配准或诊断准确率；没有额外构造评分阈值。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "成功匹配ROI的深度/管径",
            "steps": [
              {
                "step_id": "A161-P003-S03",
                "display_order": 3,
                "action": {
                  "value": "仅在实现一对一对应的病例，以side-view测血管距黏膜表面的深度及管径；ROI选择覆盖ME-NBI外观不同的血管。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.5, Measurement of vessel depth and caliber"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "software": {
                    "value": "Imaris or ImageJ (NIH)",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.5, Measurement of vessel depth and caliber"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "measurements": {
                    "value": "vessel depth from mucosal surface and caliber",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.5, Measurement of vessel depth and caliber"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "measurement_view": {
                    "value": "side-view",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDF p.5, Measurement of vessel depth and caliber"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "病例2、5的五个编号位置见S4/S5/TableS1；病例9两个ROI位置见Fig.5/Table3；不把它们合并成同一组样本。管径轴向、边界选择与逐ROI重复规则未给。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.5, Measurement of vessel depth and caliber"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "结肠曲折度分支",
            "steps": [
              {
                "step_id": "A161-P003-S04",
                "display_order": 4,
                "action": {
                  "value": "从黏膜表面至200µm深处追踪血管，每40µm标记；D0定义为浅表血管向深层分支处，求标记点间总距离与D0到200µm最短距离之比。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "range": {
                    "value": "surface to200 µm",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "marking_interval": {
                    "value": "40 µm",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "origin": {
                    "value": "D0: superficial vessel branches into deeper layers",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "ratio_definition": {
                    "value": "sum of distances between successive marks / shortest distance D0–D200",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "ratio_figure_note": {
                    "value": "S3a分母D0–200；图上连续段D0–40、D40–80、D80–120、D120–160、D160–200；公式第二项排版4位置与下标有异。",
                    "source_raw": "D0–40; D40–80; D80–120; D120–160; D160–200; D0–200",
                    "source_refs": [
                      {
                        "source_id": "F10",
                        "locator": "Supplementary Fig.S3a original TIFF"
                      }
                    ],
                    "check_status": "verified_against_primary_figure"
                  }
                },
                "notes": {
                  "value": "仅绑定结肠腺瘤/非腺瘤曲折度比较，不能将40µm当所有共聚焦z-step。S3a公式第二项字形上下标排版异常，图内各段明确含D40–80；本字段采用Appendix连续标记描述与图示分段，不宣称印刷公式无歧义。",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "组织类型限定的统计",
            "steps": [
              {
                "step_id": "A161-P003-S05",
                "display_order": 5,
                "action": {
                  "value": "食管非癌/癌的血管高度、结肠非腺瘤/腺瘤的血管曲折度使用两样本t检验。",
                  "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "software": {
                    "value": "Minitab v21.4.2",
                    "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "test": {
                    "value": "two-sample t-test",
                    "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "summary": {
                    "value": "mean (± standard deviation) vessel heights; mean vessel tortuosity as stated",
                    "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "significance": {
                    "value": "p<0.05",
                    "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                    "source_refs": [
                      {
                        "source_id": "F14",
                        "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "来源未给所有比较的配对/独立层级或单/双侧，不自行填双侧；S2n10/S3n3层级未明。S3b为箱形图，箱须定义不能改成SD。",
                  "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "三维与组织学深度比较分支",
            "steps": [
              {
                "step_id": "A161-P003-S06",
                "display_order": 6,
                "action": {
                  "value": "对结肠病例8、9、11、13显示各病例3D与组织学平均血管深度，并作二者关系图。",
                  "source_raw": "Cases8,9,11,13; mean vessel depths;3D;Histology(CD31);Depth3D;Depthhistology",
                  "source_refs": [
                    {
                      "source_id": "F13",
                      "locator": "Supplementary Fig.S6a–c original TIFF and F01 p.11 caption"
                    }
                  ],
                  "check_status": "verified_against_primary_figure"
                },
                "parameters": {
                  "case_scope": {
                    "value": "8/9 adenoma;11/13 sessile serrated lesion",
                    "source_raw": "Case8,9: Adenoma;11,13: Sessile serrated lesion",
                    "source_refs": [
                      {
                        "source_id": "F13",
                        "locator": "S6a original TIFF labels"
                      }
                    ],
                    "check_status": "verified_against_primary_figure"
                  },
                  "modalities": {
                    "value": "3D compared with Histology(CD31)",
                    "source_raw": "3D;Histology(CD31)",
                    "source_refs": [
                      {
                        "source_id": "F13",
                        "locator": "S6a,c original TIFF"
                      }
                    ],
                    "check_status": "verified_against_primary_figure"
                  },
                  "axes": {
                    "value": "x:Depth,3D(µm);y:Depth,histology(µm)",
                    "source_raw": "Depth,3D(µm);Depth,histology(µm)",
                    "source_refs": [
                      {
                        "source_id": "F13",
                        "locator": "S6b original TIFF axes"
                      }
                    ],
                    "check_status": "verified_against_primary_figure"
                  }
                },
                "notes": {
                  "value": "具体回归软件/模型调用、每病例血管数/配对规则和误差类型未报告。仅源图支持深度，不能扩展成管径相关性步骤。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.5, Measurement of vessel depth and caliber"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [
          {
            "case_id": "esophagus_height",
            "description": {
              "value": "食管非癌/癌血管高度仅作为Appendix指定统计分支；没有完整逐血管测高规则。",
              "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
              "source_refs": [
                {
                  "source_id": "F14",
                  "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "evidence_ids": [
              "A161-E03"
            ],
            "step_ids": [
              "A161-P003-S05"
            ]
          },
          {
            "case_id": "colon_tortuosity",
            "description": {
              "value": "结肠曲折度采用200µm范围、40µm标记，仅对应E04。",
              "source_refs": [
                {
                  "source_id": "F14",
                  "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "evidence_ids": [
              "A161-E04"
            ],
            "step_ids": [
              "A161-P003-S04",
              "A161-P003-S05"
            ]
          },
          {
            "case_id": "matched_case_depth_caliber",
            "description": {
              "value": "先成功匹配，再测相应ROI深度/管径；器官病例独立。",
              "source_refs": [
                {
                  "source_id": "F01",
                  "locator": "PDF p.5, Measurement of vessel depth and caliber"
                }
              ],
              "check_status": "verified_against_primary_source"
            },
            "evidence_ids": [
              "A161-E06",
              "A161-E07",
              "A161-E08"
            ],
            "step_ids": [
              "A161-P003-S02",
              "A161-P003-S03"
            ]
          },
          {
            "case_id": "paired_modalities_colon_depth",
            "description": {
              "value": "S6结肠3D与CD31切片深度比较，组织学图像走P002。",
              "source_raw": "3D;Histology(CD31)",
              "source_refs": [
                {
                  "source_id": "F13",
                  "locator": "S6a–c"
                }
              ],
              "check_status": "verified_against_primary_figure"
            },
            "evidence_ids": [
              "A161-E09"
            ],
            "step_ids": [
              "A161-P003-S06"
            ]
          }
        ],
        "reported_precedence": [
          "S01既存图→S02人工匹配→S03匹配成功病例的ROI量测。",
          "S04结肠曲折度与食管高度是独立形态比较，不要求先经S02内镜一对一成功。",
          "S06病例3D/组织学深度关系为独立比较，不把所有S03量测串到S06。"
        ],
        "missing_information": [
          "食管血管高度完整边界/测量细节未给；不将深度定义完全替代高度。",
          "各统计n层级、病例-血管/ROI关系、箱须定义、误差和回归实现未报。",
          "S3a排版异常与Appendix定义并列，未静默重写原图。"
        ],
        "source_conflicts": [],
        "review_status": "source_checked_direct_reported_scope; independent_audit_pending"
      },
      "preservation": "inherited values and IDs unchanged"
    }
  ],
  "experiments": [
    {
      "experiment_id": "A161-R20261012-E01",
      "question": "Clearing and imaging reach",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S01",
        "A161-R20261012-S02",
        "A161-R20261012-S03",
        "A161-R20261012-S04",
        "A161-R20261012-S05",
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Results first subsection; FigureS1,S2a",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E02",
      "question": "Noncancerous esophageal vessels",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S01"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2a;VideoS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E03",
      "question": "Noncancerous gastric regional architecture",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S03"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c;VideoS2,S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E04",
      "question": "Noncancerous colon architecture",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S05"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2d;VideoS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E05",
      "question": "Esophageal cancer vascular changes",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S01",
        "A161-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3a;FigureS2;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E06",
      "question": "Colon adenoma morphology/tortuosity",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S05",
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3b;FigureS3;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E07",
      "question": "Case-level one-to-one matching",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S02",
        "A161-R20261012-S04",
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E08",
      "question": "Continuous vessel versus discontinuous endoscopic appearance",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure5;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E09",
      "question": "Case9 vessel1 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E10",
      "question": "Case9 vessel2 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E11",
      "question": "Case9 vessel3 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E12",
      "question": "Case9 vessel4 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E13",
      "question": "Case9 vessel5 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E14",
      "question": "Case9 vessel6 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E15",
      "question": "Case2 vessel1 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E16",
      "question": "Case2 vessel2 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E17",
      "question": "Case2 vessel3 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E18",
      "question": "Case2 vessel4 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E19",
      "question": "Case2 vessel5 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E20",
      "question": "Case5 vessel1 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E21",
      "question": "Case5 vessel2 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E22",
      "question": "Case5 vessel3 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E23",
      "question": "Case5 vessel4 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E24",
      "question": "Case5 vessel5 measured depth/caliber",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "experiment_id": "A161-R20261012-E25",
      "question": "Depth correlation with histology",
      "partition_role": "analytical_partition_not_independent_experiment",
      "sample_context_ids": [
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "FigureS6a–c;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    }
  ],
  "samples": [
    {
      "sample_id": "A161-R20261012-S01",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human esophageal noncancerous tissue adjacent to resected neoplasms; FFPE block",
      "signals": "wholemount directly conjugated CD34-AF647 vessels andSYTO16 nuclei; comparator sections CD31, D2-40/H&E are distinct",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figures2a,3a; Methods",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S02",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human esophageal squamous cell carcinoma FFPE contexts; published cases1–3",
      "signals": "CD34-AF647 vessels;SYTO16 nuclei; histology/CD31 comparison separately",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1; Figures3a,4a;S2/S4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S03",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human noncancerous upper/lower stomach FFPE contexts",
      "signals": "CD34-AF647 andSYTO16",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S04",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human gastric neoplasm FFPE contexts; cases4–7, adenoma/adenocarcinoma specified perTable1",
      "signals": "CD34-AF647 andSYTO16",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;S5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S05",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human nonadenoma colon FFPE context",
      "signals": "CD34-AF647 andSYTO16;CD31 sections separate",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figures2d,3b;S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S06",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human colorectal adenoma/adenocarcinoma FFPE contexts;cases8,9,10,12,14",
      "signals": "CD34-AF647 andSYTO16",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figures3b,4,5;Table3;S6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S07",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human sessile serrated lesion FFPE contexts;cases11,13, failed endoscopic one-to-one matching but present indepth comparison",
      "signals": "CD34-AF647 wholemount;CD31 histology comparison",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;FigureS6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    }
  ],
  "artifacts": [
    {
      "artifact_id": "A161-R20261012-AR01",
      "type": "published_result_source",
      "locator": "Results first subsection; FigureS1,S2a",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Results first subsection; FigureS1,S2a",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR02",
      "type": "published_result_source",
      "locator": "Figure2a;VideoS1",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2a;VideoS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR03",
      "type": "published_result_source",
      "locator": "Figure2b–c;VideoS2,S3",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c;VideoS2,S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR04",
      "type": "published_result_source",
      "locator": "Figure2d;VideoS4",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2d;VideoS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR05",
      "type": "published_result_source",
      "locator": "Figure3a;FigureS2;AppendixS1",
      "visual_reinspection_this_round": true,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3a;FigureS2;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F04",
          "locator": "FigureS2c",
          "verification": "freshvisual"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR06",
      "type": "published_result_source",
      "locator": "Figure3b;FigureS3;AppendixS1",
      "visual_reinspection_this_round": true,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3b;FigureS3;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F05",
          "locator": "FigureS3a–b",
          "verification": "freshvisual"
        },
        {
          "source_id": "A161-R20261012-F03",
          "locator": "Measurement of tortuosity;Statistics",
          "verification": "freshfulltext"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR07",
      "type": "published_result_source",
      "locator": "Table1;Figure4;Results matching",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR08",
      "type": "published_result_source",
      "locator": "Figure5;Results matching",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure5;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR09",
      "type": "published_result_source",
      "locator": "Table3;Figure5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR10",
      "type": "published_result_source",
      "locator": "Table3;Figure5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR11",
      "type": "published_result_source",
      "locator": "Table3;Figure5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR12",
      "type": "published_result_source",
      "locator": "Table3;Figure5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR13",
      "type": "published_result_source",
      "locator": "Table3;Figure5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR14",
      "type": "published_result_source",
      "locator": "Table3;Figure5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR15",
      "type": "published_result_source",
      "locator": "TableS1;FigureS4",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR16",
      "type": "published_result_source",
      "locator": "TableS1;FigureS4",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR17",
      "type": "published_result_source",
      "locator": "TableS1;FigureS4",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR18",
      "type": "published_result_source",
      "locator": "TableS1;FigureS4",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR19",
      "type": "published_result_source",
      "locator": "TableS1;FigureS4",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR20",
      "type": "published_result_source",
      "locator": "TableS1;FigureS5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR21",
      "type": "published_result_source",
      "locator": "TableS1;FigureS5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR22",
      "type": "published_result_source",
      "locator": "TableS1;FigureS5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR23",
      "type": "published_result_source",
      "locator": "TableS1;FigureS5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR24",
      "type": "published_result_source",
      "locator": "TableS1;FigureS5",
      "visual_reinspection_this_round": false,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "artifact_id": "A161-R20261012-AR25",
      "type": "published_result_source",
      "locator": "FigureS6a–c;Results matching",
      "visual_reinspection_this_round": true,
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "FigureS6a–c;Results matching",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F06",
          "locator": "FigureS6a–c",
          "verification": "freshvisualprintedregression"
        }
      ]
    }
  ],
  "results": [
    {
      "result_id": "A161-R20261012-O01",
      "experiment_id": "A161-R20261012-E01",
      "sample_context_ids": [
        "A161-R20261012-S01",
        "A161-R20261012-S02",
        "A161-R20261012-S03",
        "A161-R20261012-S04",
        "A161-R20261012-S05",
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "metric": "Clearing and imaging reach",
      "result": "All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.",
      "values": {
        "reported_depth_um": 350,
        "approximate": true,
        "objective": 30,
        "wholemount_labels": [
          "CD34-AF647",
          "SYTO16"
        ]
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR01"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Results first subsection; FigureS1,S2a",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O02",
      "experiment_id": "A161-R20261012-E02",
      "sample_context_ids": [
        "A161-R20261012-S01"
      ],
      "metric": "Noncancerous esophageal vessels",
      "result": "IPCL and subepithelial network visualized; surface loops narrower than drainage vein.",
      "values": {
        "surface_loop_caliber_um": 10,
        "drainage_vein_caliber_um": 50,
        "approximate": true
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2a;VideoS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O03",
      "experiment_id": "A161-R20261012-E03",
      "sample_context_ids": [
        "A161-R20261012-S03"
      ],
      "metric": "Noncancerous gastric regional architecture",
      "result": "Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR03"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c;VideoS2,S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O04",
      "experiment_id": "A161-R20261012-E04",
      "sample_context_ids": [
        "A161-R20261012-S05"
      ],
      "metric": "Noncancerous colon architecture",
      "result": "Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.",
      "values": null,
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2d;VideoS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O05",
      "experiment_id": "A161-R20261012-E05",
      "sample_context_ids": [
        "A161-R20261012-S01",
        "A161-R20261012-S02"
      ],
      "metric": "Esophageal cancer vascular changes",
      "result": "Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.",
      "values": {
        "height_test": "two-sample t-test",
        "height_p": "<0.05",
        "caption_n": 10,
        "n_unit": "not explicitly identified in caption; not10patients",
        "summary": "mean ±SD perAppendixS1",
        "means": null,
        "means_status": "not digitized",
        "fresh_visual": "S2panelc star/axis checked"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR05"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3a;FigureS2;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F04",
          "locator": "FigureS2c",
          "verification": "freshvisual"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O06",
      "experiment_id": "A161-R20261012-E06",
      "sample_context_ids": [
        "A161-R20261012-S05",
        "A161-R20261012-S06"
      ],
      "metric": "Colon adenoma morphology/tortuosity",
      "result": "Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.",
      "values": {
        "tortuosity_p": "<0.05",
        "test": "two-sample t-test perAppendix",
        "caption_n": 3,
        "n_unit": "not explicitly resolved",
        "metric": "sum of path segments at40µm depth intervals to200µm divided by shortestD0–D200 distance",
        "source_formula_conflict": "A161-CF02",
        "display": "S3boxplot, not converted to mean±SD points",
        "fresh_visual": "formula typography and boxplot checked"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3b;FigureS3;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F05",
          "locator": "FigureS3a–b",
          "verification": "freshvisual"
        },
        {
          "source_id": "A161-R20261012-F03",
          "locator": "Measurement of tortuosity;Statistics",
          "verification": "freshfulltext"
        }
      ],
      "source_conflict_refs": [
        "A161-CF02"
      ]
    },
    {
      "result_id": "A161-R20261012-O07",
      "experiment_id": "A161-R20261012-E07",
      "sample_context_ids": [
        "A161-R20261012-S02",
        "A161-R20261012-S04",
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "metric": "Case-level one-to-one matching",
      "result": "Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.",
      "values": {
        "esophagus": {
          "success": 3,
          "total": 3
        },
        "stomach": {
          "success": 2,
          "total": 4
        },
        "colorectum": {
          "success": 5,
          "total": 7
        },
        "matched_case_ids": [
          1,
          2,
          3,
          4,
          5,
          8,
          9,
          10,
          12,
          14
        ],
        "unmatched_case_ids": [
          6,
          7,
          11,
          13
        ],
        "criterion": "at least5 vessel/crypt structures, agreement of3engineers,pathologist,endoscopist",
        "total_cases": 14
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR07"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O08",
      "experiment_id": "A161-R20261012-E08",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Continuous vessel versus discontinuous endoscopic appearance",
      "result": "Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.",
      "values": {
        "case_id": 9,
        "vessel_ids": [
          1,
          2,
          3,
          4,
          5,
          6
        ],
        "narrative_depth_change_um": 20,
        "narrative_status": "approximately contextual path-depth change, not allTable3values20"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR08"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure5;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O09",
      "experiment_id": "A161-R20261012-E09",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Case9 vessel1 measured depth/caliber",
      "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "values": {
        "case_id": 9,
        "vessel_no": 1,
        "depth_um": 28.0,
        "caliber_um": 10.0,
        "value_type": "exact_table_value"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR09"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O10",
      "experiment_id": "A161-R20261012-E10",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Case9 vessel2 measured depth/caliber",
      "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "values": {
        "case_id": 9,
        "vessel_no": 2,
        "depth_um": 108.9,
        "caliber_um": 6.2,
        "value_type": "exact_table_value"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR10"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O11",
      "experiment_id": "A161-R20261012-E11",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Case9 vessel3 measured depth/caliber",
      "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "values": {
        "case_id": 9,
        "vessel_no": 3,
        "depth_um": 20.3,
        "caliber_um": 15.1,
        "value_type": "exact_table_value"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR11"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O12",
      "experiment_id": "A161-R20261012-E12",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Case9 vessel4 measured depth/caliber",
      "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "values": {
        "case_id": 9,
        "vessel_no": 4,
        "depth_um": 35.0,
        "caliber_um": 12.1,
        "value_type": "exact_table_value"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR12"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O13",
      "experiment_id": "A161-R20261012-E13",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Case9 vessel5 measured depth/caliber",
      "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "values": {
        "case_id": 9,
        "vessel_no": 5,
        "depth_um": 54.6,
        "caliber_um": 11.1,
        "value_type": "exact_table_value"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR13"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O14",
      "experiment_id": "A161-R20261012-E14",
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "metric": "Case9 vessel6 measured depth/caliber",
      "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "values": {
        "case_id": 9,
        "vessel_no": 6,
        "depth_um": 32.3,
        "caliber_um": 11.1,
        "value_type": "exact_table_value"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR14"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O15",
      "experiment_id": "A161-R20261012-E15",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "metric": "Case2 vessel1 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 2,
        "vessel_no": 1,
        "depth_um": 14.1,
        "caliber_um": 18.7,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR15"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O16",
      "experiment_id": "A161-R20261012-E16",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "metric": "Case2 vessel2 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 2,
        "vessel_no": 2,
        "depth_um": 22.7,
        "caliber_um": 24.5,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR16"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O17",
      "experiment_id": "A161-R20261012-E17",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "metric": "Case2 vessel3 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 2,
        "vessel_no": 3,
        "depth_um": 35.3,
        "caliber_um": 12.5,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR17"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O18",
      "experiment_id": "A161-R20261012-E18",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "metric": "Case2 vessel4 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 2,
        "vessel_no": 4,
        "depth_um": 31.1,
        "caliber_um": 10.5,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR18"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O19",
      "experiment_id": "A161-R20261012-E19",
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "metric": "Case2 vessel5 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 2,
        "vessel_no": 5,
        "depth_um": 22.7,
        "caliber_um": 10.5,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR19"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O20",
      "experiment_id": "A161-R20261012-E20",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "metric": "Case5 vessel1 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 5,
        "vessel_no": 1,
        "depth_um": 49.6,
        "caliber_um": 11.9,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR20"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O21",
      "experiment_id": "A161-R20261012-E21",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "metric": "Case5 vessel2 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 5,
        "vessel_no": 2,
        "depth_um": 52.9,
        "caliber_um": 10.5,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR21"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O22",
      "experiment_id": "A161-R20261012-E22",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "metric": "Case5 vessel3 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 5,
        "vessel_no": 3,
        "depth_um": 45.5,
        "caliber_um": 11.7,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR22"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O23",
      "experiment_id": "A161-R20261012-E23",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "metric": "Case5 vessel4 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 5,
        "vessel_no": 4,
        "depth_um": 69.0,
        "caliber_um": 12.0,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR23"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O24",
      "experiment_id": "A161-R20261012-E24",
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "metric": "Case5 vessel5 measured depth/caliber",
      "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "values": {
        "case_id": 5,
        "vessel_no": 5,
        "depth_um": 47.1,
        "caliber_um": 8.6,
        "value_type": "exact_table_value",
        "source_asset": "DEN-37-659-s005.docx"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR24"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflict_refs": []
    },
    {
      "result_id": "A161-R20261012-O25",
      "experiment_id": "A161-R20261012-E25",
      "sample_context_ids": [
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "metric": "Depth correlation with histology",
      "result": "Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.",
      "values": {
        "case_ids": [
          8,
          9,
          11,
          13
        ],
        "x": "3Ddepthµm",
        "y": "histologydepthµm",
        "slope": 0.8823,
        "intercept": 8.547,
        "R_squared": 0.9748,
        "value_type": "exact_printed_figure_annotation",
        "fresh_visual": true,
        "raw_points": null,
        "raw_points_status": "bar/scatter positions not digitized",
        "error_type": "not separately resolved forS6bars",
        "source_conflict": "A161-CF03"
      },
      "result_type": "author_reported_text_and_caption",
      "measurement_time": null,
      "measurement_time_status": "not_reported_unless_explicit_in_values",
      "artifact_ids": [
        "A161-R20261012-AR25"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "FigureS6a–c;Results matching",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F06",
          "locator": "FigureS6a–c",
          "verification": "freshvisualprintedregression"
        }
      ],
      "source_conflict_refs": [
        "A161-CF03"
      ]
    }
  ],
  "claims": [
    {
      "claim_id": "A161-R20261012-C01",
      "claim_type": "source_scoped_result_summary",
      "text": "All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.",
      "supporting_result_ids": [
        "A161-R20261012-O01"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Results first subsection; FigureS1,S2a",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C02",
      "claim_type": "source_scoped_result_summary",
      "text": "IPCL and subepithelial network visualized; surface loops narrower than drainage vein.",
      "supporting_result_ids": [
        "A161-R20261012-O02"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2a;VideoS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C03",
      "claim_type": "source_scoped_result_summary",
      "text": "Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.",
      "supporting_result_ids": [
        "A161-R20261012-O03"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c;VideoS2,S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C04",
      "claim_type": "source_scoped_result_summary",
      "text": "Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.",
      "supporting_result_ids": [
        "A161-R20261012-O04"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2d;VideoS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C05",
      "claim_type": "source_scoped_result_summary",
      "text": "Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.",
      "supporting_result_ids": [
        "A161-R20261012-O05"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3a;FigureS2;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F04",
          "locator": "FigureS2c",
          "verification": "freshvisual"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C06",
      "claim_type": "source_scoped_result_summary",
      "text": "Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.",
      "supporting_result_ids": [
        "A161-R20261012-O06"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3b;FigureS3;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F05",
          "locator": "FigureS3a–b",
          "verification": "freshvisual"
        },
        {
          "source_id": "A161-R20261012-F03",
          "locator": "Measurement of tortuosity;Statistics",
          "verification": "freshfulltext"
        }
      ],
      "source_conflict_refs": [
        "A161-CF02"
      ]
    },
    {
      "claim_id": "A161-R20261012-C07",
      "claim_type": "source_scoped_result_summary",
      "text": "Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.",
      "supporting_result_ids": [
        "A161-R20261012-O07"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C08",
      "claim_type": "source_scoped_result_summary",
      "text": "Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.",
      "supporting_result_ids": [
        "A161-R20261012-O08"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure5;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C09",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "supporting_result_ids": [
        "A161-R20261012-O09"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C10",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "supporting_result_ids": [
        "A161-R20261012-O10"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C11",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "supporting_result_ids": [
        "A161-R20261012-O11"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C12",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "supporting_result_ids": [
        "A161-R20261012-O12"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C13",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "supporting_result_ids": [
        "A161-R20261012-O13"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C14",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
      "supporting_result_ids": [
        "A161-R20261012-O14"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C15",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O15"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C16",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O16"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C17",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O17"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C18",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O18"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C19",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O19"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C20",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O20"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C21",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O21"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C22",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O22"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C23",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O23"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C24",
      "claim_type": "source_scoped_result_summary",
      "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
      "supporting_result_ids": [
        "A161-R20261012-O24"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ]
    },
    {
      "claim_id": "A161-R20261012-C25",
      "claim_type": "source_scoped_result_summary",
      "text": "Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.",
      "supporting_result_ids": [
        "A161-R20261012-O25"
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "FigureS6a–c;Results matching",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F06",
          "locator": "FigureS6a–c",
          "verification": "freshvisualprintedregression"
        }
      ],
      "source_conflict_refs": [
        "A161-CF03"
      ]
    },
    {
      "claim_id": "A161-R20261012-AX01",
      "claim_type": "author_future_prospect",
      "text": "Method may improve endoscopic interpretation/technology; larger representative series and diagnosticclassification validation remain future work.",
      "supporting_result_ids": [],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Discussion",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    }
  ],
  "relations": [
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S01"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S01"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S01"
    },
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S03"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S03"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S03"
    },
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S05"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S05"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S05"
    },
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-P001",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S07"
    },
    {
      "subject": "A161-P002",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S07"
    },
    {
      "subject": "A161-P003",
      "predicate": "applied_to_sample_context",
      "object": "A161-R20261012-S07"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S01"
    },
    {
      "subject": "A161-R20261012-S01",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S03"
    },
    {
      "subject": "A161-R20261012-S03",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S05"
    },
    {
      "subject": "A161-R20261012-S05",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S07"
    },
    {
      "subject": "A161-R20261012-S07",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR01"
    },
    {
      "subject": "A161-R20261012-AR01",
      "predicate": "supports",
      "object": "A161-R20261012-O01"
    },
    {
      "subject": "A161-R20261012-E01",
      "predicate": "has_result",
      "object": "A161-R20261012-O01"
    },
    {
      "subject": "A161-R20261012-O01",
      "predicate": "supports",
      "object": "A161-R20261012-C01"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E01"
    },
    {
      "subject": "A161-R20261012-E02",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S01"
    },
    {
      "subject": "A161-R20261012-S01",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR02"
    },
    {
      "subject": "A161-R20261012-AR02",
      "predicate": "supports",
      "object": "A161-R20261012-O02"
    },
    {
      "subject": "A161-R20261012-E02",
      "predicate": "has_result",
      "object": "A161-R20261012-O02"
    },
    {
      "subject": "A161-R20261012-O02",
      "predicate": "supports",
      "object": "A161-R20261012-C02"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E02"
    },
    {
      "subject": "A161-R20261012-E03",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S03"
    },
    {
      "subject": "A161-R20261012-S03",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR03"
    },
    {
      "subject": "A161-R20261012-AR03",
      "predicate": "supports",
      "object": "A161-R20261012-O03"
    },
    {
      "subject": "A161-R20261012-E03",
      "predicate": "has_result",
      "object": "A161-R20261012-O03"
    },
    {
      "subject": "A161-R20261012-O03",
      "predicate": "supports",
      "object": "A161-R20261012-C03"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E03"
    },
    {
      "subject": "A161-R20261012-E04",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S05"
    },
    {
      "subject": "A161-R20261012-S05",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR04"
    },
    {
      "subject": "A161-R20261012-AR04",
      "predicate": "supports",
      "object": "A161-R20261012-O04"
    },
    {
      "subject": "A161-R20261012-E04",
      "predicate": "has_result",
      "object": "A161-R20261012-O04"
    },
    {
      "subject": "A161-R20261012-O04",
      "predicate": "supports",
      "object": "A161-R20261012-C04"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E04"
    },
    {
      "subject": "A161-R20261012-E05",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S01"
    },
    {
      "subject": "A161-R20261012-S01",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR05"
    },
    {
      "subject": "A161-R20261012-E05",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR05"
    },
    {
      "subject": "A161-R20261012-AR05",
      "predicate": "supports",
      "object": "A161-R20261012-O05"
    },
    {
      "subject": "A161-R20261012-E05",
      "predicate": "has_result",
      "object": "A161-R20261012-O05"
    },
    {
      "subject": "A161-R20261012-O05",
      "predicate": "supports",
      "object": "A161-R20261012-C05"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E05"
    },
    {
      "subject": "A161-P002",
      "predicate": "used_in",
      "object": "A161-R20261012-E05"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E05"
    },
    {
      "subject": "A161-R20261012-E06",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S05"
    },
    {
      "subject": "A161-R20261012-S05",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR06"
    },
    {
      "subject": "A161-R20261012-E06",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR06"
    },
    {
      "subject": "A161-R20261012-AR06",
      "predicate": "supports",
      "object": "A161-R20261012-O06"
    },
    {
      "subject": "A161-R20261012-E06",
      "predicate": "has_result",
      "object": "A161-R20261012-O06"
    },
    {
      "subject": "A161-R20261012-O06",
      "predicate": "supports",
      "object": "A161-R20261012-C06"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E06"
    },
    {
      "subject": "A161-P002",
      "predicate": "used_in",
      "object": "A161-R20261012-E06"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E06"
    },
    {
      "subject": "A161-R20261012-E07",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR07"
    },
    {
      "subject": "A161-R20261012-E07",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR07"
    },
    {
      "subject": "A161-R20261012-E07",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR07"
    },
    {
      "subject": "A161-R20261012-E07",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S07"
    },
    {
      "subject": "A161-R20261012-S07",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR07"
    },
    {
      "subject": "A161-R20261012-AR07",
      "predicate": "supports",
      "object": "A161-R20261012-O07"
    },
    {
      "subject": "A161-R20261012-E07",
      "predicate": "has_result",
      "object": "A161-R20261012-O07"
    },
    {
      "subject": "A161-R20261012-O07",
      "predicate": "supports",
      "object": "A161-R20261012-C07"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E07"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E07"
    },
    {
      "subject": "A161-R20261012-E08",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR08"
    },
    {
      "subject": "A161-R20261012-AR08",
      "predicate": "supports",
      "object": "A161-R20261012-O08"
    },
    {
      "subject": "A161-R20261012-E08",
      "predicate": "has_result",
      "object": "A161-R20261012-O08"
    },
    {
      "subject": "A161-R20261012-O08",
      "predicate": "supports",
      "object": "A161-R20261012-C08"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E08"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E08"
    },
    {
      "subject": "A161-R20261012-E09",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR09"
    },
    {
      "subject": "A161-R20261012-AR09",
      "predicate": "supports",
      "object": "A161-R20261012-O09"
    },
    {
      "subject": "A161-R20261012-E09",
      "predicate": "has_result",
      "object": "A161-R20261012-O09"
    },
    {
      "subject": "A161-R20261012-O09",
      "predicate": "supports",
      "object": "A161-R20261012-C09"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E09"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E09"
    },
    {
      "subject": "A161-R20261012-E10",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR10"
    },
    {
      "subject": "A161-R20261012-AR10",
      "predicate": "supports",
      "object": "A161-R20261012-O10"
    },
    {
      "subject": "A161-R20261012-E10",
      "predicate": "has_result",
      "object": "A161-R20261012-O10"
    },
    {
      "subject": "A161-R20261012-O10",
      "predicate": "supports",
      "object": "A161-R20261012-C10"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E10"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E10"
    },
    {
      "subject": "A161-R20261012-E11",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR11"
    },
    {
      "subject": "A161-R20261012-AR11",
      "predicate": "supports",
      "object": "A161-R20261012-O11"
    },
    {
      "subject": "A161-R20261012-E11",
      "predicate": "has_result",
      "object": "A161-R20261012-O11"
    },
    {
      "subject": "A161-R20261012-O11",
      "predicate": "supports",
      "object": "A161-R20261012-C11"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E11"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E11"
    },
    {
      "subject": "A161-R20261012-E12",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR12"
    },
    {
      "subject": "A161-R20261012-AR12",
      "predicate": "supports",
      "object": "A161-R20261012-O12"
    },
    {
      "subject": "A161-R20261012-E12",
      "predicate": "has_result",
      "object": "A161-R20261012-O12"
    },
    {
      "subject": "A161-R20261012-O12",
      "predicate": "supports",
      "object": "A161-R20261012-C12"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E12"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E12"
    },
    {
      "subject": "A161-R20261012-E13",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR13"
    },
    {
      "subject": "A161-R20261012-AR13",
      "predicate": "supports",
      "object": "A161-R20261012-O13"
    },
    {
      "subject": "A161-R20261012-E13",
      "predicate": "has_result",
      "object": "A161-R20261012-O13"
    },
    {
      "subject": "A161-R20261012-O13",
      "predicate": "supports",
      "object": "A161-R20261012-C13"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E13"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E13"
    },
    {
      "subject": "A161-R20261012-E14",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR14"
    },
    {
      "subject": "A161-R20261012-AR14",
      "predicate": "supports",
      "object": "A161-R20261012-O14"
    },
    {
      "subject": "A161-R20261012-E14",
      "predicate": "has_result",
      "object": "A161-R20261012-O14"
    },
    {
      "subject": "A161-R20261012-O14",
      "predicate": "supports",
      "object": "A161-R20261012-C14"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E14"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E14"
    },
    {
      "subject": "A161-R20261012-E15",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR15"
    },
    {
      "subject": "A161-R20261012-AR15",
      "predicate": "supports",
      "object": "A161-R20261012-O15"
    },
    {
      "subject": "A161-R20261012-E15",
      "predicate": "has_result",
      "object": "A161-R20261012-O15"
    },
    {
      "subject": "A161-R20261012-O15",
      "predicate": "supports",
      "object": "A161-R20261012-C15"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E15"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E15"
    },
    {
      "subject": "A161-R20261012-E16",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR16"
    },
    {
      "subject": "A161-R20261012-AR16",
      "predicate": "supports",
      "object": "A161-R20261012-O16"
    },
    {
      "subject": "A161-R20261012-E16",
      "predicate": "has_result",
      "object": "A161-R20261012-O16"
    },
    {
      "subject": "A161-R20261012-O16",
      "predicate": "supports",
      "object": "A161-R20261012-C16"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E16"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E16"
    },
    {
      "subject": "A161-R20261012-E17",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR17"
    },
    {
      "subject": "A161-R20261012-AR17",
      "predicate": "supports",
      "object": "A161-R20261012-O17"
    },
    {
      "subject": "A161-R20261012-E17",
      "predicate": "has_result",
      "object": "A161-R20261012-O17"
    },
    {
      "subject": "A161-R20261012-O17",
      "predicate": "supports",
      "object": "A161-R20261012-C17"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E17"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E17"
    },
    {
      "subject": "A161-R20261012-E18",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR18"
    },
    {
      "subject": "A161-R20261012-AR18",
      "predicate": "supports",
      "object": "A161-R20261012-O18"
    },
    {
      "subject": "A161-R20261012-E18",
      "predicate": "has_result",
      "object": "A161-R20261012-O18"
    },
    {
      "subject": "A161-R20261012-O18",
      "predicate": "supports",
      "object": "A161-R20261012-C18"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E18"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E18"
    },
    {
      "subject": "A161-R20261012-E19",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S02"
    },
    {
      "subject": "A161-R20261012-S02",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR19"
    },
    {
      "subject": "A161-R20261012-AR19",
      "predicate": "supports",
      "object": "A161-R20261012-O19"
    },
    {
      "subject": "A161-R20261012-E19",
      "predicate": "has_result",
      "object": "A161-R20261012-O19"
    },
    {
      "subject": "A161-R20261012-O19",
      "predicate": "supports",
      "object": "A161-R20261012-C19"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E19"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E19"
    },
    {
      "subject": "A161-R20261012-E20",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR20"
    },
    {
      "subject": "A161-R20261012-AR20",
      "predicate": "supports",
      "object": "A161-R20261012-O20"
    },
    {
      "subject": "A161-R20261012-E20",
      "predicate": "has_result",
      "object": "A161-R20261012-O20"
    },
    {
      "subject": "A161-R20261012-O20",
      "predicate": "supports",
      "object": "A161-R20261012-C20"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E20"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E20"
    },
    {
      "subject": "A161-R20261012-E21",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR21"
    },
    {
      "subject": "A161-R20261012-AR21",
      "predicate": "supports",
      "object": "A161-R20261012-O21"
    },
    {
      "subject": "A161-R20261012-E21",
      "predicate": "has_result",
      "object": "A161-R20261012-O21"
    },
    {
      "subject": "A161-R20261012-O21",
      "predicate": "supports",
      "object": "A161-R20261012-C21"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E21"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E21"
    },
    {
      "subject": "A161-R20261012-E22",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR22"
    },
    {
      "subject": "A161-R20261012-AR22",
      "predicate": "supports",
      "object": "A161-R20261012-O22"
    },
    {
      "subject": "A161-R20261012-E22",
      "predicate": "has_result",
      "object": "A161-R20261012-O22"
    },
    {
      "subject": "A161-R20261012-O22",
      "predicate": "supports",
      "object": "A161-R20261012-C22"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E22"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E22"
    },
    {
      "subject": "A161-R20261012-E23",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR23"
    },
    {
      "subject": "A161-R20261012-AR23",
      "predicate": "supports",
      "object": "A161-R20261012-O23"
    },
    {
      "subject": "A161-R20261012-E23",
      "predicate": "has_result",
      "object": "A161-R20261012-O23"
    },
    {
      "subject": "A161-R20261012-O23",
      "predicate": "supports",
      "object": "A161-R20261012-C23"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E23"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E23"
    },
    {
      "subject": "A161-R20261012-E24",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S04"
    },
    {
      "subject": "A161-R20261012-S04",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR24"
    },
    {
      "subject": "A161-R20261012-AR24",
      "predicate": "supports",
      "object": "A161-R20261012-O24"
    },
    {
      "subject": "A161-R20261012-E24",
      "predicate": "has_result",
      "object": "A161-R20261012-O24"
    },
    {
      "subject": "A161-R20261012-O24",
      "predicate": "supports",
      "object": "A161-R20261012-C24"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E24"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E24"
    },
    {
      "subject": "A161-R20261012-E25",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S06"
    },
    {
      "subject": "A161-R20261012-S06",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR25"
    },
    {
      "subject": "A161-R20261012-E25",
      "predicate": "has_sample_context",
      "object": "A161-R20261012-S07"
    },
    {
      "subject": "A161-R20261012-S07",
      "predicate": "produces_panel_context",
      "object": "A161-R20261012-AR25"
    },
    {
      "subject": "A161-R20261012-AR25",
      "predicate": "supports",
      "object": "A161-R20261012-O25"
    },
    {
      "subject": "A161-R20261012-E25",
      "predicate": "has_result",
      "object": "A161-R20261012-O25"
    },
    {
      "subject": "A161-R20261012-O25",
      "predicate": "supports",
      "object": "A161-R20261012-C25"
    },
    {
      "subject": "A161-P001",
      "predicate": "used_in",
      "object": "A161-R20261012-E25"
    },
    {
      "subject": "A161-P002",
      "predicate": "used_in",
      "object": "A161-R20261012-E25"
    },
    {
      "subject": "A161-P003",
      "predicate": "used_in",
      "object": "A161-R20261012-E25"
    }
  ],
  "inherited_scientific_boundaries": {
    "schema_version": "source_scoped_protocol_records-1.0",
    "paper_id": "A161",
    "review_scope": "本轮核主文Methods/Table2、AppendixS1完整DOCX与3页渲染、TableS1内容，定向目视S1/S3/S6，恢复实际操作/采集/分析内容。3条来源限定记录，保留整块、组织学、内镜和器官统计分支。",
    "source_conflicts": [
      {
        "issue_id": "A161-CF01",
        "type": "source_locator_difference",
        "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
      },
      {
        "issue_id": "A161-CF02",
        "type": "source_formula_typography",
        "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
      },
      {
        "issue_id": "A161-CF03",
        "type": "source_metric_scope",
        "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
      }
    ],
    "remaining_unreviewed": [
      "主文外引13/14仅背景方法引用；本轮已有直接详细流程，不从未读引用补参数。",
      "本轮未对所有主图、其余补图和四个影片重新做结果/逐帧审阅；历史审阅不算本轮协议审阅。",
      "未取得原始光学栈、逐病例采集表、逐血管/ROI测量表；不可能确认个体参数与重算统计。"
    ],
    "missing_content_register": [
      {
        "record_id": "A161-P001",
        "missing": [
          "原固定时长/温度和处理前存档时长、组织块实际尺寸未报告。",
          "配液基准、体积、孵育中换液/混匀细节未充分；不以常用配方补写。",
          "除S2a10×/Fig.2 30×已知外，其余具体病例/面板归属、功率/pinhole/像素大小未完全报告。",
          "Table2 day列是计划阶段标签；ON保持原义，不反推小时或精确总时长。"
        ]
      },
      {
        "record_id": "A161-P002",
        "missing": [
          "组织学染色细节在本材料缺失，流程仅部分报告。",
          "不是全部器官/每幅图都采用相同切片标记；按面板及G/O匹配。"
        ]
      },
      {
        "record_id": "A161-P003",
        "missing": [
          "食管血管高度完整边界/测量细节未给；不将深度定义完全替代高度。",
          "各统计n层级、病例-血管/ROI关系、箱须定义、误差和回归实现未报。",
          "S3a排版异常与Appendix定义并列，未静默重写原图。"
        ]
      }
    ],
    "observation_conditions": [
      "固定/存档是初始状态，保存时长未明。",
      "ECi24h是处理孵育，不是透明化后的观测日期。",
      "Table2 Day1/2–17/18–20/21仅日程标注；SYTO16与CD34重叠，未据ON推精确总时长。",
      "处理完成至各次成像的等待/保存环境未单独给出。"
    ],
    "sources": [
      {
        "source_id": "F01",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/PMC12162411.1.pdf",
        "sha256": "8a70d129b986a666455e7a035c4ff6580779f3756120d960c279ff0b75842e63",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "Methods/XML direct text; primary PDF pp3–4 visual Table2/Fig1; relevant captions"
      },
      {
        "source_id": "F02",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/PMC12162411.1.xml",
        "sha256": "ebc1260e597343987940ee5ad463a1f6bbc300a50911351862e640d17a9b1353",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "Methods/XML direct text; primary PDF pp3–4 visual Table2/Fig1; relevant captions"
      },
      {
        "source_id": "F03",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g001.jpg",
        "sha256": "6ec1feb35f8f8432e934c7a732423f8739f14212baf1f7e970a5befbeec68e19",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F04",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g004.jpg",
        "sha256": "10f6a9ad864e3ab4c036b93692e10c092d9406499163e22b76b96813444fbea4",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F05",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g005.jpg",
        "sha256": "346bfa22493e745330d5c46f771b1aea23eefbe3e1f2fc66ad8ef5f53fa6f910",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F06",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g002.jpg",
        "sha256": "793a89643b634c0026cabf5c4234a34891b4e391b0d78aa67c6a5eb86287bd88",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F07",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g003.jpg",
        "sha256": "56b22f671c58186e956eb059cf826f724b234cd2623e2cea7028821ad1e0c075",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F08",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s007.tif",
        "sha256": "ce946971381764881239d939ecbbc78703f9782579ed0687fa8fff1f5a292eef",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "original TIFF converted RGB for full visual read; no digitization"
      },
      {
        "source_id": "F09",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s001.tif",
        "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F10",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s009.tif",
        "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "original TIFF converted RGB for full visual read; no digitization"
      },
      {
        "source_id": "F11",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s012.tif",
        "sha256": "cc3a8719577e910fcba74167a9f9f171dc3a6b14f8f81b8ad2ee0fe8af522d8c",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F12",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s006.tif",
        "sha256": "f6ce6511b2f8c841cd57a61219253b95c8b1ad71127969327bdab8242bd7aea1",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F13",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s002.tif",
        "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "original TIFF converted RGB for full visual read; no digitization"
      },
      {
        "source_id": "F14",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s011.docx",
        "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "DOCX full XML read +3 rendered pages visual"
      },
      {
        "source_id": "F15",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s005.docx",
        "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "DOCX full text table read; used as output scope, no method values inferred"
      },
      {
        "source_id": "F16",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s010.mp4",
        "sha256": "45fbdb579c966dd7db2bb911df95613138d22cd4b746b7fd1559d4efbada3b9c",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F17",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s008.mp4",
        "sha256": "c690dd43ef4765c1389a0d2f78f2b342f250f13b89194bb8c24050265a52abc4",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F18",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s003.mp4",
        "sha256": "6fc012d68cf526635509f863899b84c8a164ac1812c1fb63fca489277d4e38c5",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      },
      {
        "source_id": "F19",
        "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s004.mp4",
        "sha256": "ad9cd63d00492bbf2de028c945a2712199f903d7fc2d67022317faef04a94c32",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
        "this_round_read": "not_re_read_this_round"
      }
    ],
    "review_status": {
      "source_content": "saved_direct_reported_scope_with_gaps",
      "independent_audit": "pending",
      "specified_Pro": "unchanged_hold",
      "acceptance_change": false,
      "actual_execution_or_effect_validation": "not_performed"
    },
    "source_field_check_count": 138,
    "recovery_current_scope_20261010": {
      "paper_id": "A161",
      "recovery_date": "2026-10-10",
      "input_selected": "checkpoint_recovery_20261010/extracted/checkpoint/full_corpus_sources/objects/ba69c6f0d3cf8e3d791ccb88d8360bb1ba348b2bdba399e90f1899f6a2549333.json",
      "input_sha256": "ba69c6f0d3cf8e3d791ccb88d8360bb1ba348b2bdba399e90f1899f6a2549333",
      "layer": "recovered_current_scope_without_new_primary_source_verification",
      "historical_review_and_acceptance_preserved": true,
      "original_review_scope_and_check_status_semantics": "Inherited checkpoint declarations; not claims made by this recovery pass.",
      "current_work": "Inspected embedded source_raw excerpts for named issues and made only explicitly supported internal-consistency repairs. Field inventory is mechanical enumeration, not a reconstructed full scientific audit.",
      "new_primary_source_verified_fields": 0,
      "targeted_internal_checks": {},
      "prior_verified_scope_recovered_from_parent": [
        "断连前范围记录：46个附件专属字段未核；Table1病例和Table3六个sites原可核。当前未恢复表级逐项原始证据，不重建病例行或数值；46仅为继承聚合记录。"
      ],
      "aggregate_gap_counts_have_no_invented_field_mapping": true,
      "existing_source_conflicts_preserved": [
        {
          "issue_id": "A161-CF01",
          "type": "source_locator_difference",
          "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
        },
        {
          "issue_id": "A161-CF02",
          "type": "source_formula_typography",
          "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
        },
        {
          "issue_id": "A161-CF03",
          "type": "source_metric_scope",
          "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
        }
      ],
      "existing_remaining_unreviewed_preserved": [
        "主文外引13/14仅背景方法引用；本轮已有直接详细流程，不从未读引用补参数。",
        "本轮未对所有主图、其余补图和四个影片重新做结果/逐帧审阅；历史审阅不算本轮协议审阅。",
        "未取得原始光学栈、逐病例采集表、逐血管/ROI测量表；不可能确认个体参数与重算统计。"
      ],
      "online_access": "PMC request returned reCAPTCHA for A152/A154/A155/A158; retrieval stopped, no bypass or supplementary batch retrieval. Other papers not requested from blocked host.",
      "publication_approved": false
    }
  },
  "source_conflicts": [
    {
      "issue_id": "A161-CF01",
      "type": "source_locator_difference",
      "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
    },
    {
      "issue_id": "A161-CF02",
      "type": "source_formula_typography",
      "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
    },
    {
      "issue_id": "A161-CF03",
      "type": "source_metric_scope",
      "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
    }
  ],
  "legacy_mapping": {
    "preserved_evidence_links": [
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A161-E01-G01",
        "group_pointer": "/evidence_records/0/groups/0",
        "observations": [
          {
            "observation_id": "A161-E01-O01",
            "pointer": "/evidence_records/0/observations/0",
            "figure_panels": [
              "Fig.S1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.5 Results start and p.7 continuation"
              },
              {
                "source_id": "F08",
                "location": "S1全图"
              }
            ]
          },
          {
            "observation_id": "A161-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "Fig.2a–d",
              "Fig.S2a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.5 Fig.2 caption; p.7 Results"
              },
              {
                "source_id": "F04",
                "location": "Fig.2"
              },
              {
                "source_id": "F09",
                "location": "S2a"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "panel_scope": {
          "Fig.S1": "macro before/after photos; acquisition unspecified; no confocal settings inheritance",
          "Fig.2/S2a 3D": "P001 clearing/confocal branch",
          "S2a histology": "P002 branch"
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A161-E01-G02",
        "group_pointer": "/evidence_records/0/groups/1",
        "observations": [
          {
            "observation_id": "A161-E01-O01",
            "pointer": "/evidence_records/0/observations/0",
            "figure_panels": [
              "Fig.S1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.5 Results start and p.7 continuation"
              },
              {
                "source_id": "F08",
                "location": "S1全图"
              }
            ]
          },
          {
            "observation_id": "A161-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "Fig.2a–d",
              "Fig.S2a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.5 Fig.2 caption; p.7 Results"
              },
              {
                "source_id": "F04",
                "location": "Fig.2"
              },
              {
                "source_id": "F09",
                "location": "S2a"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "panel_scope": {
          "Fig.S1": "macro before/after photos; acquisition unspecified; no confocal settings inheritance",
          "Fig.2/S2a 3D": "P001 clearing/confocal branch",
          "S2a histology": "P002 branch"
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A161-E01-G03",
        "group_pointer": "/evidence_records/0/groups/2",
        "observations": [
          {
            "observation_id": "A161-E01-O01",
            "pointer": "/evidence_records/0/observations/0",
            "figure_panels": [
              "Fig.S1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.5 Results start and p.7 continuation"
              },
              {
                "source_id": "F08",
                "location": "S1全图"
              }
            ]
          },
          {
            "observation_id": "A161-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "Fig.2a–d",
              "Fig.S2a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.5 Fig.2 caption; p.7 Results"
              },
              {
                "source_id": "F04",
                "location": "Fig.2"
              },
              {
                "source_id": "F09",
                "location": "S2a"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "panel_scope": {
          "Fig.S1": "macro before/after photos; acquisition unspecified; no confocal settings inheritance",
          "Fig.2/S2a 3D": "P001 clearing/confocal branch",
          "S2a histology": "P002 branch"
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A161-E02-G01",
        "group_pointer": "/evidence_records/1/groups/0",
        "observations": [
          {
            "observation_id": "A161-E02-O01",
            "pointer": "/evidence_records/1/observations/0",
            "figure_panels": [
              "Fig.2a",
              "Video S1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp.5,7 Fig.2a"
              },
              {
                "source_id": "F04",
                "location": "Fig.2a"
              },
              {
                "source_id": "F16",
                "location": "Video S1；22帧时序抽样，0–20 s每秒及结束前0.1 s"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A161-E02-G02",
        "group_pointer": "/evidence_records/1/groups/1",
        "observations": [
          {
            "observation_id": "A161-E02-O02",
            "pointer": "/evidence_records/1/observations/1",
            "figure_panels": [
              "Fig.2b",
              "Video S2"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp.5,7 Fig.2b"
              },
              {
                "source_id": "F04",
                "location": "Fig.2b"
              },
              {
                "source_id": "F17",
                "location": "Video S2；22帧时序抽样，0–20 s每秒及结束前0.1 s"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A161-E02-G03",
        "group_pointer": "/evidence_records/1/groups/2",
        "observations": [
          {
            "observation_id": "A161-E02-O03",
            "pointer": "/evidence_records/1/observations/2",
            "figure_panels": [
              "Fig.2c",
              "Video S3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp.5,7 Fig.2c"
              },
              {
                "source_id": "F04",
                "location": "Fig.2c"
              },
              {
                "source_id": "F18",
                "location": "Video S3；22帧时序抽样，0–20 s每秒及结束前0.1 s"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A161-E02-G04",
        "group_pointer": "/evidence_records/1/groups/3",
        "observations": [
          {
            "observation_id": "A161-E02-O04",
            "pointer": "/evidence_records/1/observations/3",
            "figure_panels": [
              "Fig.2d",
              "Video S4"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp.5,7 Fig.2d"
              },
              {
                "source_id": "F04",
                "location": "Fig.2d"
              },
              {
                "source_id": "F19",
                "location": "Video S4；22帧时序抽样，0–20 s每秒及结束前0.1 s"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": null,
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A161-E03-G01",
        "group_pointer": "/evidence_records/2/groups/0",
        "observations": [
          {
            "observation_id": "A161-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "Fig.3a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 esophageal result"
              },
              {
                "source_id": "F05",
                "location": "Fig.3a"
              }
            ]
          },
          {
            "observation_id": "A161-E03-O02",
            "pointer": "/evidence_records/2/observations/1",
            "figure_panels": [
              "Fig.S2b",
              "Fig.S2c"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 and p.11 S2 caption"
              },
              {
                "source_id": "F09",
                "location": "S2b–c"
              },
              {
                "source_id": "F14",
                "location": "p.3 Statistics"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S05 (height only; measurement details incomplete)",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A161-E03-G02",
        "group_pointer": "/evidence_records/2/groups/1",
        "observations": [
          {
            "observation_id": "A161-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "Fig.3a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 esophageal result"
              },
              {
                "source_id": "F05",
                "location": "Fig.3a"
              }
            ]
          },
          {
            "observation_id": "A161-E03-O02",
            "pointer": "/evidence_records/2/observations/1",
            "figure_panels": [
              "Fig.S2b",
              "Fig.S2c"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 and p.11 S2 caption"
              },
              {
                "source_id": "F09",
                "location": "S2b–c"
              },
              {
                "source_id": "F14",
                "location": "p.3 Statistics"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S05 (height only; measurement details incomplete)",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A161-E04-G01",
        "group_pointer": "/evidence_records/3/groups/0",
        "observations": [
          {
            "observation_id": "A161-E04-O01",
            "pointer": "/evidence_records/3/observations/0",
            "figure_panels": [
              "Fig.3b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 colon Results"
              },
              {
                "source_id": "F05",
                "location": "Fig.3b"
              }
            ]
          },
          {
            "observation_id": "A161-E04-O02",
            "pointer": "/evidence_records/3/observations/1",
            "figure_panels": [
              "Fig.S3a",
              "Fig.S3b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 Results and p.11 S3 caption"
              },
              {
                "source_id": "F10",
                "location": "S3a–b"
              },
              {
                "source_id": "F14",
                "location": "pp.2–3"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S04/S05",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A161-E04-G02",
        "group_pointer": "/evidence_records/3/groups/1",
        "observations": [
          {
            "observation_id": "A161-E04-O01",
            "pointer": "/evidence_records/3/observations/0",
            "figure_panels": [
              "Fig.3b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 colon Results"
              },
              {
                "source_id": "F05",
                "location": "Fig.3b"
              }
            ]
          },
          {
            "observation_id": "A161-E04-O02",
            "pointer": "/evidence_records/3/observations/1",
            "figure_panels": [
              "Fig.S3a",
              "Fig.S3b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 Results and p.11 S3 caption"
              },
              {
                "source_id": "F10",
                "location": "S3a–b"
              },
              {
                "source_id": "F14",
                "location": "pp.2–3"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S04/S05",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A161-E05-G01",
        "group_pointer": "/evidence_records/4/groups/0",
        "observations": [
          {
            "observation_id": "A161-E05-O01",
            "pointer": "/evidence_records/4/observations/0",
            "figure_panels": [
              "Table 1",
              "Fig.4a",
              "Fig.4b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.2 Table 1; p.7 Results"
              },
              {
                "source_id": "F06",
                "location": "Fig.4"
              },
              {
                "source_id": "F01",
                "location": "pp.4–5 One-to-one correspondence and matching criteria; p.2 Tissue-block selection"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S02",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A161-E05-G02",
        "group_pointer": "/evidence_records/4/groups/1",
        "observations": [
          {
            "observation_id": "A161-E05-O01",
            "pointer": "/evidence_records/4/observations/0",
            "figure_panels": [
              "Table 1",
              "Fig.4a",
              "Fig.4b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.2 Table 1; p.7 Results"
              },
              {
                "source_id": "F06",
                "location": "Fig.4"
              },
              {
                "source_id": "F01",
                "location": "pp.4–5 One-to-one correspondence and matching criteria; p.2 Tissue-block selection"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S02",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A161-E05-G03",
        "group_pointer": "/evidence_records/4/groups/2",
        "observations": [
          {
            "observation_id": "A161-E05-O01",
            "pointer": "/evidence_records/4/observations/0",
            "figure_panels": [
              "Table 1",
              "Fig.4a",
              "Fig.4b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.2 Table 1; p.7 Results"
              },
              {
                "source_id": "F06",
                "location": "Fig.4"
              },
              {
                "source_id": "F01",
                "location": "pp.4–5 One-to-one correspondence and matching criteria; p.2 Tissue-block selection"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S02",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E06",
        "evidence_pointer": "/evidence_records/5",
        "group_id": "A161-E06-G01",
        "group_pointer": "/evidence_records/5/groups/0",
        "observations": [
          {
            "observation_id": "A161-E06-O01",
            "pointer": "/evidence_records/5/observations/0",
            "figure_panels": [
              "S4",
              "Table S1"
            ],
            "source_refs": [
              {
                "source_id": "F11",
                "location": "S4a–b"
              },
              {
                "source_id": "F15",
                "location": "Table S1 Case 2, rows 1–5"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S03",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A161-E07-G01",
        "group_pointer": "/evidence_records/6/groups/0",
        "observations": [
          {
            "observation_id": "A161-E07-O01",
            "pointer": "/evidence_records/6/observations/0",
            "figure_panels": [
              "S5",
              "Table S1"
            ],
            "source_refs": [
              {
                "source_id": "F12",
                "location": "S5a–b"
              },
              {
                "source_id": "F15",
                "location": "Table S1 Case 5, rows 1–5"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S03",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E08",
        "evidence_pointer": "/evidence_records/7",
        "group_id": "A161-E08-G01",
        "group_pointer": "/evidence_records/7/groups/0",
        "observations": [
          {
            "observation_id": "A161-E08-O01",
            "pointer": "/evidence_records/7/observations/0",
            "figure_panels": [
              "Table 3",
              "Fig.5"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.9 Table 3"
              },
              {
                "source_id": "F07",
                "location": "Fig.5 ROI 1/2"
              }
            ]
          },
          {
            "observation_id": "A161-E08-O02",
            "pointer": "/evidence_records/7/observations/1",
            "figure_panels": [
              "Fig.5",
              "Table 3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 paragraph on vessels 1–6; p.9 Table 3"
              },
              {
                "source_id": "F07",
                "location": "Fig.5"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S03",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "marker_scope": "existingG has L01 only; do not add nuclear L02 merely because commonP001 reports SYTO16."
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E08",
        "evidence_pointer": "/evidence_records/7",
        "group_id": "A161-E08-G02",
        "group_pointer": "/evidence_records/7/groups/1",
        "observations": [
          {
            "observation_id": "A161-E08-O01",
            "pointer": "/evidence_records/7/observations/0",
            "figure_panels": [
              "Table 3",
              "Fig.5"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.9 Table 3"
              },
              {
                "source_id": "F07",
                "location": "Fig.5 ROI 1/2"
              }
            ]
          },
          {
            "observation_id": "A161-E08-O02",
            "pointer": "/evidence_records/7/observations/1",
            "figure_panels": [
              "Fig.5",
              "Table 3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p.7 paragraph on vessels 1–6; p.9 Table 3"
              },
              {
                "source_id": "F07",
                "location": "Fig.5"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S03",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        },
        "marker_scope": "existingG has L01 only; do not add nuclear L02 merely because commonP001 reports SYTO16."
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E09",
        "evidence_pointer": "/evidence_records/8",
        "group_id": "A161-E09-G01",
        "group_pointer": "/evidence_records/8/groups/0",
        "observations": [
          {
            "observation_id": "A161-E09-O01",
            "pointer": "/evidence_records/8/observations/0",
            "figure_panels": [
              "Fig.S6a",
              "Fig.S6b",
              "Fig.S6c"
            ],
            "source_refs": [
              {
                "source_id": "F13",
                "location": "S6a case labels; S6b axes and regression; S6c image"
              },
              {
                "source_id": "F01",
                "location": "p.11 S6 caption"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "wholeblock_processing": "A161-P001",
          "quantitative_analysis": "A161-P003-S06",
          "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
        }
      },
      {
        "core_path": "A161_candidate/A161_evidence.json",
        "evidence_id": "A161-E09",
        "evidence_pointer": "/evidence_records/8",
        "group_id": "A161-E09-G02",
        "group_pointer": "/evidence_records/8/groups/1",
        "observations": [
          {
            "observation_id": "A161-E09-O01",
            "pointer": "/evidence_records/8/observations/0",
            "figure_panels": [
              "Fig.S6a",
              "Fig.S6b",
              "Fig.S6c"
            ],
            "source_refs": [
              {
                "source_id": "F13",
                "location": "S6a case labels; S6b axes and regression; S6c image"
              },
              {
                "source_id": "F01",
                "location": "p.11 S6 caption"
              }
            ]
          }
        ],
        "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
        "protocol_binding": {
          "record": "A161-P002",
          "measurement": "A161-P003-S06",
          "marker": "CD31 (L03)",
          "excluded": "no ECi wholeblock CD34/SYTO16/FV3000 inheritance"
        }
      }
    ],
    "original_mapping": [],
    "status": "no equivalence to lost core asserted"
  },
  "coverage_dimensions": {
    "historical_review": {
      "status": "inherited_not_reperformed",
      "path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "pointer": "/baseline",
      "exact_record": {
        "selected_core_files": {
          "evidence_json": {
            "path": "A161_candidate/A161_evidence.json",
            "sha256": "00a4d65bfe5ee26ddbc5530c979720787035b6613060ff58eca7955090cc3a0f"
          },
          "questions_json": {
            "path": "A161_candidate/A161_questions.json",
            "sha256": "16dbc4328ff4088057e133fb70f276464a3680c987c3c288dcbe266235e729e9"
          },
          "reading_md": {
            "path": "A161_candidate/A161_reading_zh.md",
            "sha256": "4066b8b125d49c1db9b545fe7ebd4f29b27f50d725bd88979d800bbde2e9d362"
          }
        },
        "existing_protocol_index": "none",
        "preserved_status": {
          "state": "held_source_reviewed_candidate_pending_specified_review",
          "not_reperformed": "No new scientific acceptance/delivery/count increment",
          "core_status_fields": {
            "record_id_status": "candidate_not_accepted_not_counted",
            "review_status": {
              "source_first_self_review": "completed for stated scope",
              "independent_review": "completed_repairs_verified_no_remaining_blocking_or_major_issue_in_nonoperational_scope",
              "structural_check": "passed",
              "bundled_skill_scripts_run": false,
              "applicable_rules": "R0–R5/R7–R8 applied to nonoperational evidence; R4 execution recovery excluded; R6 digitization not performed; RS selection support not requested",
              "self_review_repairs": [
                "按实际源图限定E01各器官与E02各视频来源",
                "移除通用ME-NBI条件继承；E09切片不继承ECi",
                "分开量化信号与HE/CD31/NBI参照信号",
                "仅30×明确硅油浸；JPG阅图副本未称无损转换"
              ],
              "structural_check_report": "review_assets/structure_check.json",
              "independent_review_report": "A161_independent_review.md",
              "independent_checks": "A161_independent_checks.json",
              "pro_acceptance": false,
              "formal_acceptance": false,
              "reviewed_scientific_snapshot_hashes": {
                "A161_reading_zh.md": "42328b8540f3640ec71fce6a3a6dd22188d60ff0130553b65b575d882e417367",
                "A161_evidence.json": "1d8bf2cde2b7dea81840d32a38ca17ffb85a82c0a7b408735733a5ebc3c4894d",
                "A161_questions.json": "bd6b647d51d0c9f9fa83c1cc8d0f9cc0ad0e6f2571c22ca0d0fa0b9821fade13"
              }
            }
          },
          "local_review_and_scope_records": [
            "A161_candidate/A161_independent_checks.json",
            "A161_candidate/A161_independent_review.md"
          ]
        },
        "originals_modified": false,
        "acceptance_or_count_changed": false,
        "runtime_integration": false,
        "upload_or_publication": false
      }
    },
    "new_main_text_relationships": "reviewed",
    "fresh_visual_review": {
      "status": "performed_limited",
      "assets": [
        "DEN-37-659-s001.tif",
        "DEN-37-659-s009.tif",
        "DEN-37-659-s002.tif"
      ],
      "scope": "FiguresS2/S3/S6 axes/significance/formula and S6exact printed regression; not numericalbar digitization"
    },
    "specified_Pro_gate": "unchanged_hold",
    "parent_review": "pending",
    "raw_reanalysis": "not_performed_not_required_for_literature_review"
  },
  "sample_count_semantics": {
    "nodes_are": "context_classes_not_individual_specimens",
    "count_nodes_as_n": false,
    "cross_result_individual_overlap": "only_explicit_source_mapping_used"
  },
  "limitations": [
    "All5main figures,Tables1–3,6supplementary figures,TableS1 and4video-described anatomical contexts covered. Figure1workflow is context, not an independent experiment.",
    "Fresh fulltextXML, AppendixS1 andTableS1 originalDOCX read; S2/S3/S6 originalTIFFs inspected for axes, printed equation/significance and metric identity.",
    "Fourteen case labels and10/14matching outcome retained. Esophagus3/3,stomach2/4,colorectum5/7, including4failed cases; no inflated denominator from vessels/ROIs.",
    "All16published vessel depth/caliber pairs preserved exactly:6case9Table3,5case2and5case5TableS1.",
    "S6four-case regression y=0.8823x+8.547,R²=0.9748 is depth-only. SSLcases11/13 enter histology comparison despite failedendoscopy matching.",
    "CD34directAlexa647 andSYTO16 are separated fromsectionCD31/D2-40/H&E. Nuclear blue pseudocolor is notSYTO16emission identity.",
    "All3inherited source conflicts preserved. S3formula typo and boxplot representation remain distinct fromAppendixmean±SD test description.",
    "Projection thickness150/250µm, opticalzsteps0.8/4.2µm and imaging reach~350µm are not tissue dimensions.",
    "Matching is manualmultiobserver correspondence withlandmark selection; no blindeddiagnostic accuracy,sensitivity/specificity or clinical superiority validation is inferred.",
    "High-resolution30×small field and failurewith uniform/poorlandmarks retained; rawmeasurements and acquiredstacks not recomputed."
  ]
}
```

## 完整当前P对象（角色与限制原样保留）

```json

{
  "schema_version": "source_scoped_protocol_records-1.0",
  "paper_id": "A161",
  "title": "Three-dimensional optically cleared tissue imaging for analyzing endoscopic images of gastrointestinal neoplasms (with video)",
  "doi": "10.1111/den.15000",
  "baseline": {
    "selected_core_files": {
      "evidence_json": {
        "path": "A161_candidate/A161_evidence.json",
        "sha256": "00a4d65bfe5ee26ddbc5530c979720787035b6613060ff58eca7955090cc3a0f"
      },
      "questions_json": {
        "path": "A161_candidate/A161_questions.json",
        "sha256": "16dbc4328ff4088057e133fb70f276464a3680c987c3c288dcbe266235e729e9"
      },
      "reading_md": {
        "path": "A161_candidate/A161_reading_zh.md",
        "sha256": "4066b8b125d49c1db9b545fe7ebd4f29b27f50d725bd88979d800bbde2e9d362"
      }
    },
    "existing_protocol_index": "none",
    "preserved_status": {
      "state": "held_source_reviewed_candidate_pending_specified_review",
      "not_reperformed": "No new scientific acceptance/delivery/count increment",
      "core_status_fields": {
        "record_id_status": "candidate_not_accepted_not_counted",
        "review_status": {
          "source_first_self_review": "completed for stated scope",
          "independent_review": "completed_repairs_verified_no_remaining_blocking_or_major_issue_in_nonoperational_scope",
          "structural_check": "passed",
          "bundled_skill_scripts_run": false,
          "applicable_rules": "R0–R5/R7–R8 applied to nonoperational evidence; R4 execution recovery excluded; R6 digitization not performed; RS selection support not requested",
          "self_review_repairs": [
            "按实际源图限定E01各器官与E02各视频来源",
            "移除通用ME-NBI条件继承；E09切片不继承ECi",
            "分开量化信号与HE/CD31/NBI参照信号",
            "仅30×明确硅油浸；JPG阅图副本未称无损转换"
          ],
          "structural_check_report": "review_assets/structure_check.json",
          "independent_review_report": "A161_independent_review.md",
          "independent_checks": "A161_independent_checks.json",
          "pro_acceptance": false,
          "formal_acceptance": false,
          "reviewed_scientific_snapshot_hashes": {
            "A161_reading_zh.md": "42328b8540f3640ec71fce6a3a6dd22188d60ff0130553b65b575d882e417367",
            "A161_evidence.json": "1d8bf2cde2b7dea81840d32a38ca17ffb85a82c0a7b408735733a5ebc3c4894d",
            "A161_questions.json": "bd6b647d51d0c9f9fa83c1cc8d0f9cc0ad0e6f2571c22ca0d0fa0b9821fade13"
          }
        }
      },
      "local_review_and_scope_records": [
        "A161_candidate/A161_independent_checks.json",
        "A161_candidate/A161_independent_review.md"
      ]
    },
    "originals_modified": false,
    "acceptance_or_count_changed": false,
    "runtime_integration": false,
    "upload_or_publication": false
  },
  "review_scope": "本轮核主文Methods/Table2、AppendixS1完整DOCX与3页渲染、TableS1内容，定向目视S1/S3/S6，恢复实际操作/采集/分析内容。3条来源限定记录，保留整块、组织学、内镜和器官统计分支。",
  "protocol_records": [
    {
      "record_id": "A161-P001",
      "record_type": "reported_workflow_with_explicit_unreported_details",
      "title": {
        "value": "食管、胃与结直肠FFPE组织块的整块标记、ECi透明化与共聚焦三维采集",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF p.4, Tissue-block processing"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "恢复本文Table2与AppendixS1直接给出的处理条件及重叠标记时间；不套用切片成像设置。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF p.4, Tissue-block processing"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "人食管/胃ESD、结肠EMR取得；10% buffered formalin固定并石蜡包埋；共14例，器官/病种适用范围保留原核心。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF p.2, Human specimens"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "存档FFPE块，经内镜和切除组织图定位选块，组织学连续切片先取出，随后整块处理。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "ECi透明化块的CD34与核染三维图像",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF p.4, Tissue-block processing"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "已固定并石蜡包埋的组织；10% buffered formalin固定史（具体时长/温度未报）",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.2, Human specimens"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "Xylene、100/70/50% ethanol、PBS",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.4, Table 2"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "Citrate pH6 S2369；PBS T900；TritonX100 T9284；BSA013-27054；CD34–Alexa647 QBend10/FAB7227R；SYTO16S7578；ECi112372",
          "source_refs": [
            {
              "source_id": "F14",
              "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "FV3000、UPLSAPO10x/UPLSAPO30x SIR；Imaris",
          "source_refs": [
            {
              "source_id": "F14",
              "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "选择与脱蜡",
          "steps": [
            {
              "step_id": "A161-P001-S01",
              "display_order": 1,
              "action": {
                "value": "选择同时具备白光、NBI、ME-NBI和切除组织体视图的材料；内镜医师和病理医师据图选择包含ROI的组织块。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF pp.2,4, Tissue-block selection"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {},
              "notes": {
                "value": "该选择限定本文分析样本；不推断随机或连续入组。组织学切片支路见P002。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF pp.2,4, Tissue-block selection"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A161-P001-S02",
              "display_order": 2,
              "action": {
                "value": "从石蜡块切出组织，刀片去除多余石蜡，并以paraffin block trimmer加热。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  },
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "cut_out": {
                  "value": "RT, 5 min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "trimmer": {
                  "value": "62 °C, 5 min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "刀片去除多余蜡来自Appendix S1；切出与trimmer先后按Table2，不补块尺寸或刀片型号。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A161-P001-S03",
              "display_order": 3,
              "action": {
                "value": "以二甲苯连续两轮脱蜡。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "first_xylene": {
                  "value": "60 °C, 90 min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "second_xylene": {
                  "value": "60 °C, 90 min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "两个独立列出的xylene段保留；不因同试剂合并丢失重复。体积和换液方式未报告。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A161-P001-S04",
              "display_order": 4,
              "action": {
                "value": "依序乙醇复水，最后PBS过夜。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "ordered_series": {
                  "value": [
                    "100% ethanol, RT, 60 min",
                    "70% ethanol, RT, 60 min",
                    "50% ethanol, RT, 60 min",
                    "PBS, RT, overnight"
                  ],
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "percentage_basis": {
                  "value": "表中未说明v/v或w/v；100%表示所报使用浓度，不推产品纯度",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": null,
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "抗原修复与通透封闭",
          "steps": [
            {
              "step_id": "A161-P001-S05",
              "display_order": 5,
              "action": {
                "value": "在柠檬酸抗原修复液中加热。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "buffer": {
                  "value": "Dako Target Retrieval Solution Citrate pH6, S2369; Agilent",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "pH": {
                  "value": "6",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "95 °C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "30 min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": null,
              "legacy_P_or_row": null
            },
            {
              "step_id": "A161-P001-S06",
              "display_order": 6,
              "action": {
                "value": "在通透/封闭液中过夜。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "composition": {
                  "value": "PBS (T900, Takara Bio) +0.25% Triton X-100 (T9284,Sigma-Aldrich) +1% BSA (013-27054,FUJIFILM Wako)；仅组成整理，%基准与加料/定容细节未报告",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "4 °C",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "overnight",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": null,
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "重叠整块染色",
          "steps": [
            {
              "step_id": "A161-P001-S07",
              "display_order": 7,
              "action": {
                "value": "以直接荧光偶联CD34抗体作整块免疫染色。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "antibody": {
                  "value": "Alexa647-CD34 monoclonal; cloneQBend10; FAB7227R; R&D Systems",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "dilution": {
                  "value": "1/100",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "4 °C",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "14 days",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "工作液是否与通透封闭液完全相同、体积、洗液更换和震荡条件未明确，不自动继承。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            },
            {
              "step_id": "A161-P001-S08",
              "display_order": 8,
              "action": {
                "value": "抗体孵育开始7天后加入SYTO16核染；其7天染色与CD34最后7天重叠。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "nuclear_stain": {
                  "value": "SYTO16 (S7578; Invitrogen)",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "dilution": {
                  "value": "1/1000",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "addition_time": {
                  "value": "7 days after initiation of antibody incubation",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "SYTO16_temperature": {
                  "value": "4 °C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "SYTO16_duration": {
                  "value": "7 days",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "不是CD34完成14天后再串行染7天；不把两者累加为21天。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "染后清洗与脱水",
          "steps": [
            {
              "step_id": "A161-P001-S09",
              "display_order": 9,
              "action": {
                "value": "以PBS清洗，随后依次乙醇脱水。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "ordered_series": {
                  "value": [
                    "PBS,4 °C,6 h",
                    "50% ethanol,4 °C,12 h",
                    "70% ethanol,4 °C,12 h",
                    "100% ethanol,4 °C,12 h"
                  ],
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "percentage_basis": {
                  "value": "未单标v/v或w/v",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "各段体积及是否有内部换液未报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Table 2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "ECi折射率匹配",
          "steps": [
            {
              "step_id": "A161-P001-S10",
              "display_order": 10,
              "action": {
                "value": "将组织在ethyl cinnamate中孵育透明化。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "reagent": {
                  "value": "ethyl cinnamate (112372; Sigma-Aldrich)",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "duration": {
                  "value": "24 h（Table2写1day）",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "room temperature",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "gentle shaking",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "light": {
                  "value": "dark",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "温度/轻摇/避光在Appendix明确修饰ECi段；不扩展给此前所有段。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "清除组织共聚焦采集",
          "steps": [
            {
              "step_id": "A161-P001-S11",
              "display_order": 11,
              "action": {
                "value": "用倒置FV3000共聚焦系统采集光学切片。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "instrument": {
                  "value": "FV3000; Evident",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "objective_branch_10x": {
                  "value": "UPLSAPO10x; z-step4.2 µm",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "objective_branch_30x": {
                  "value": "UPLSAPO30x SIR silicone immersion; z-step0.8 µm",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "nuclear_channel": {
                  "value": "SYTO16 excitation488 nm; detection500–540 nm variable barrier filter",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "vessel_channel": {
                  "value": "Alexa647-CD34 excitation640 nm; detection650–750 nm variable barrier filter",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "acquisition_temperature": {
                  "value": "RT",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "acquisition_duration": {
                  "value": "1–2 h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Table 2"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "known_panel_objectives": {
                  "value": "Fig.S2a三维全层图（不含其配对HE图）：10×；Fig.2核/血管图：30×，作者报告可见深度约350µm。其他逐病例/面板选择未充分报告。",
                  "source_raw": "all layers ... using a10× objective lens (Fig.S2a); captured to a depth of~350µm ... using a30× objective lens (Fig.2)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.7 Results > 3D reconstructed images of optically cleared noncancerous gastrointestinal tissues"
                    }
                  ],
                  "check_status": "verified_against_primary_source",
                  "read_basis": "this_round_primary_PDF_text_and_visual"
                }
              },
              "notes": {
                "value": "Fig.S2a三维全层图（不含HE）明确10×；Fig.2明确30×与约350µm成像深度。其他病例/面板使用分支未完全列出；不将全部图继承同一z-step。曝光/功率/pinhole/像素采样及成像腔配液未报。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "三维重建",
          "steps": [
            {
              "step_id": "A161-P001-S12",
              "display_order": 12,
              "action": {
                "value": "用Imaris重建光学切片，以top-view对应内镜、side-view对应组织学平面。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Tissue-block processing"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "software": {
                  "value": "Imaris (Bitplane AG), version not reported",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Tissue-block processing"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "view_definitions": {
                  "value": "原文描述top-view from direction parallel to mucosal plane；side-view from vertical cross-sectional direction",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.4, Tissue-block processing"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "保留作者视向词及图示用途；不根据惯常几何替换原文parallel/vertical措辞。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.4, Tissue-block processing"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [
        {
          "case_id": "CD34_SYTO16_overlap",
          "description": {
            "value": "SYTO16加入节点是CD34开始后第7天；两种标记同于14天抗体孵育的后半段。",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "temporal_relation": {
            "parent_step": "A161-P001-S07",
            "nested_step": "A161-P001-S08",
            "offset_days": 7,
            "nested_duration_days": 7,
            "parent_duration_days": 14
          }
        },
        {
          "case_id": "10x_or_30x_acquisition",
          "description": {
            "value": "10×/4.2µm 与30×/0.8µm为不同采集配置；本来源不能把某配置无条件赋给全部病例/面板。 已知例外：S2a的三维全层图为10×（同面板配对HE图不继承），Fig.2为30×；其余面板选择未完全列明。",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Imaging and analysis of 3D reconstructed images; rendered pp.2"
              },
              {
                "source_id": "F01",
                "locator": "PDF p.7 Results: whole-layer3D image Fig.S2a10× and Fig.2 30×"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "per_case_selection": "not_fully_reported"
        },
        {
          "case_id": "Fig2_display_and_known_objective",
          "description": {
            "value": "Fig.2的显示厚度与已报告成像深度不同；相应器官支路分别保存。",
            "source_raw": "Top-view thickness250µm esophagus;150µm stomach,colon; side-view thickness150µm;30×;~350µm",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF pp.5,7 Fig.2 caption and Results"
              }
            ],
            "check_status": "verified_against_primary_source",
            "read_basis": "this_round_primary_PDF_text_and_visual"
          },
          "panel_scope": {
            "value": {
              "Fig.2a": {
                "organ": "esophagus",
                "top_view_display_thickness_um": 250,
                "side_view_display_thickness_um": 150
              },
              "Fig.2b/c": {
                "organ": "stomach upper/lower",
                "top_view_display_thickness_um": 150,
                "side_view_display_thickness_um": 150
              },
              "Fig.2d": {
                "organ": "colon",
                "top_view_display_thickness_um": 150,
                "side_view_display_thickness_um": 150
              }
            },
            "source_raw": "Top-view thickness250µm esophagus;150µm stomach,colon; side-view thickness150µm;30×;~350µm",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF pp.5,7 Fig.2 caption and Results"
              }
            ],
            "check_status": "verified_against_primary_caption"
          },
          "meaning": "显示slab厚度；不是实体组织厚度、通用采集范围或z-step。",
          "known_objective": "30×",
          "reported_imaging_depth": "~350µm"
        }
      ],
      "reported_precedence": {
        "edges": [
          [
            "A161-P001-S01",
            "A161-P001-S02"
          ],
          [
            "A161-P001-S02",
            "A161-P001-S03"
          ],
          [
            "A161-P001-S03",
            "A161-P001-S04"
          ],
          [
            "A161-P001-S04",
            "A161-P001-S05"
          ],
          [
            "A161-P001-S05",
            "A161-P001-S06"
          ],
          [
            "A161-P001-S06",
            "A161-P001-S07"
          ],
          [
            "A161-P001-S08",
            "A161-P001-S09"
          ],
          [
            "A161-P001-S09",
            "A161-P001-S10"
          ],
          [
            "A161-P001-S10",
            "A161-P001-S11"
          ],
          [
            "A161-P001-S11",
            "A161-P001-S12"
          ]
        ],
        "overlap": {
          "step": "A161-P001-S08",
          "within": "A161-P001-S07",
          "offset": "7days",
          "ends_with": "S07 at14days"
        },
        "before_whole_block_processing": "P002 serial histology sections are obtained before processing the remaining block",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "Table2 and Tissue-block selection"
          },
          {
            "source_id": "F14",
            "locator": "Appendix S1, Tissue-block processing for 3D reconstructed images; rendered pp.1–2"
          }
        ]
      },
      "missing_information": [
        "原固定时长/温度和处理前存档时长、组织块实际尺寸未报告。",
        "配液基准、体积、孵育中换液/混匀细节未充分；不以常用配方补写。",
        "除S2a10×/Fig.2 30×已知外，其余具体病例/面板归属、功率/pinhole/像素大小未完全报告。",
        "Table2 day列是计划阶段标签；ON保持原义，不反推小时或精确总时长。"
      ],
      "source_conflicts": [],
      "review_status": "source_checked_direct_reported_scope; independent_audit_pending"
    },
    {
      "record_id": "A161-P002",
      "record_type": "partial_histology_and_reported_slide_imaging",
      "title": {
        "value": "比较用组织切片的染色入口、全片扫描与测量",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "保留二维组织学分支，避免与整块CD34/共聚焦路线混淆。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "所选FFPE块的连续组织切片；H&E、CD31或podoplanin支路。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "选定FFPE组织块",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "组织学切片图像及VS200 ASW测量",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "H&E；anti-CD31 JC70；antipodoplanin D2-40；Roche Diagnostics",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF pp.2,4, Tissue-block selection"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "VS200、UPLXAPO20x、VS200 ASW",
          "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
          "source_refs": [
            {
              "source_id": "F14",
              "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "切片与染色参考",
          "steps": [
            {
              "step_id": "A161-P002-S01",
              "display_order": 1,
              "action": {
                "value": "对所选组织块连续切片，作H&E和免疫染色。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF pp.2,4, Tissue-block selection"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "histology_stains": {
                  "value": "hematoxylin and eosin",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "CD31": {
                  "value": "anti-CD31; cloneJC70; Roche Diagnostics",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "podoplanin": {
                  "value": "antipodoplanin; cloneD2-40; Roche Diagnostics",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.2,4, Tissue-block selection"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "切片厚度、染色稀释、修复、显色和孵育参数未给；仅方法入口，不制造完整组织学SOP。不要把CD34–Alexa647整块条件继承到CD31/D2-40切片。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF pp.2,4, Tissue-block selection"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "二维切片扫描",
          "steps": [
            {
              "step_id": "A161-P002-S02",
              "display_order": 2,
              "action": {
                "value": "用全玻片扫描系统与20×物镜采集组织切片图。",
                "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "scanner": {
                  "value": "VS200; Evident Corporation",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "objective": {
                  "value": "20× UPLXAPO20x; Evident",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "不继承FV3000、10×/30×光学层扫描或SYTO16设置。",
                "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "二维切片测量",
          "steps": [
            {
              "step_id": "A161-P002-S03",
              "display_order": 3,
              "action": {
                "value": "用VS200 ASW软件对切片图进行测量分析。",
                "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "software": {
                  "value": "VS200 ASW; Evident",
                  "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "逐项测量校准、血管/切片抽样数、误差及配对规则未报告。S6明确CD31组织学深度图，不自动使用D2-40作该读出。",
                "source_raw": " Tissue section images were captured using a whole-slide imaging system (VS200; Evident Corporation., Tokyo, Japan) equipped with a 20× objective lens (UPLXAPO20x; Evident Corporation). Tissue section images were subjected to measurement analysis using VS200 ASW software (Evident Corporation). ",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Imaging and analysis of tissue sections; rendered pp.1"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [],
      "reported_precedence": [
        "选块→切片染色→VS200采集→VS200 ASW测量；切片在剩余组织块整块染色/透明化前取得。"
      ],
      "missing_information": [
        "组织学染色细节在本材料缺失，流程仅部分报告。",
        "不是全部器官/每幅图都采用相同切片标记；按面板及G/O匹配。"
      ],
      "source_conflicts": [],
      "review_status": "source_checked_direct_reported_scope; independent_audit_pending"
    },
    {
      "record_id": "A161-P003",
      "record_type": "reported_matching_and_measurement_workflow_with_algorithm_gaps",
      "title": {
        "value": "内镜与三维图像匹配、血管量测及限定统计",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "分开器官匹配门槛、病例位置深度、食管高度和结肠曲折度，保持读出各自条件。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "已有ME-NBI图与清除后3D图；匹配条件及后续测量按器官/病例分开。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "已取得的内镜图及Imaris三维重建",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "人工对应关系、血管深度/管径或限定组织形态量测",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "已有EVISX1/GIF-XZ1200或CF-XZ1200内镜图",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.2, Human specimens"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "Imaris或ImageJ",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDF p.5, Measurement of vessel depth and caliber"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "Minitab21.4.2",
          "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
          "source_refs": [
            {
              "source_id": "F14",
              "locator": "Appendix S1, Statistical analysis; rendered pp.3"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "内镜影像上下文",
          "steps": [
            {
              "step_id": "A161-P003-S01",
              "display_order": 1,
              "action": {
                "value": "使用既存内镜图作为匹配输入；保留原采集设备和器官分支倍数。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.2, Human specimens"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "device": {
                  "value": "EVIS X1 (Olympus Medical Systems) with GIF-XZ1200 or CF-XZ1200",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.2, Human specimens"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "esophagus_stomach_magnification": {
                  "value": "70×–80×",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.2, Human specimens"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "colon_magnification": {
                  "value": "70×–100×",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.2, Human specimens"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "这是本文已有影像的采集上下文，不是对受试者重新进行内镜操作的指南。具体型号逐病例分配未报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.2, Human specimens"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "人工一对一匹配",
          "steps": [
            {
              "step_id": "A161-P003-S02",
              "display_order": 2,
              "action": {
                "value": "由三名非医疗工程师比较血管/隐窝形状和相对位置，选出相应区域，再由病理医师及内镜医师确认。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "minimum_structures": {
                  "value": "at least5",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "esophagus_criterion": {
                  "value": "至少5条血管形状与相对位置相符",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "stomach_colon_criterion": {
                  "value": "血管与隐窝合计至少5个结构相符",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "observer_rule": {
                  "value": "3 engineers +1 pathologist +1 endoscopist；5人任一不同意即未匹配",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "人工匹配标准，不等于自动配准或诊断准确率；没有额外构造评分阈值。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "成功匹配ROI的深度/管径",
          "steps": [
            {
              "step_id": "A161-P003-S03",
              "display_order": 3,
              "action": {
                "value": "仅在实现一对一对应的病例，以side-view测血管距黏膜表面的深度及管径；ROI选择覆盖ME-NBI外观不同的血管。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.5, Measurement of vessel depth and caliber"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "software": {
                  "value": "Imaris or ImageJ (NIH)",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.5, Measurement of vessel depth and caliber"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "measurements": {
                  "value": "vessel depth from mucosal surface and caliber",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.5, Measurement of vessel depth and caliber"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "measurement_view": {
                  "value": "side-view",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDF p.5, Measurement of vessel depth and caliber"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "病例2、5的五个编号位置见S4/S5/TableS1；病例9两个ROI位置见Fig.5/Table3；不把它们合并成同一组样本。管径轴向、边界选择与逐ROI重复规则未给。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.5, Measurement of vessel depth and caliber"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "结肠曲折度分支",
          "steps": [
            {
              "step_id": "A161-P003-S04",
              "display_order": 4,
              "action": {
                "value": "从黏膜表面至200µm深处追踪血管，每40µm标记；D0定义为浅表血管向深层分支处，求标记点间总距离与D0到200µm最短距离之比。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "range": {
                  "value": "surface to200 µm",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "marking_interval": {
                  "value": "40 µm",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "origin": {
                  "value": "D0: superficial vessel branches into deeper layers",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "ratio_definition": {
                  "value": "sum of distances between successive marks / shortest distance D0–D200",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "ratio_figure_note": {
                  "value": "S3a分母D0–200；图上连续段D0–40、D40–80、D80–120、D120–160、D160–200；公式第二项排版4位置与下标有异。",
                  "source_raw": "D0–40; D40–80; D80–120; D120–160; D160–200; D0–200",
                  "source_refs": [
                    {
                      "source_id": "F10",
                      "locator": "Supplementary Fig.S3a original TIFF"
                    }
                  ],
                  "check_status": "verified_against_primary_figure"
                }
              },
              "notes": {
                "value": "仅绑定结肠腺瘤/非腺瘤曲折度比较，不能将40µm当所有共聚焦z-step。S3a公式第二项字形上下标排版异常，图内各段明确含D40–80；本字段采用Appendix连续标记描述与图示分段，不宣称印刷公式无歧义。",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "组织类型限定的统计",
          "steps": [
            {
              "step_id": "A161-P003-S05",
              "display_order": 5,
              "action": {
                "value": "食管非癌/癌的血管高度、结肠非腺瘤/腺瘤的血管曲折度使用两样本t检验。",
                "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "software": {
                  "value": "Minitab v21.4.2",
                  "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "test": {
                  "value": "two-sample t-test",
                  "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "summary": {
                  "value": "mean (± standard deviation) vessel heights; mean vessel tortuosity as stated",
                  "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "significance": {
                  "value": "p<0.05",
                  "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                  "source_refs": [
                    {
                      "source_id": "F14",
                      "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "来源未给所有比较的配对/独立层级或单/双侧，不自行填双侧；S2n10/S3n3层级未明。S3b为箱形图，箱须定义不能改成SD。",
                "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
                "source_refs": [
                  {
                    "source_id": "F14",
                    "locator": "Appendix S1, Statistical analysis; rendered pp.3"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "三维与组织学深度比较分支",
          "steps": [
            {
              "step_id": "A161-P003-S06",
              "display_order": 6,
              "action": {
                "value": "对结肠病例8、9、11、13显示各病例3D与组织学平均血管深度，并作二者关系图。",
                "source_raw": "Cases8,9,11,13; mean vessel depths;3D;Histology(CD31);Depth3D;Depthhistology",
                "source_refs": [
                  {
                    "source_id": "F13",
                    "locator": "Supplementary Fig.S6a–c original TIFF and F01 p.11 caption"
                  }
                ],
                "check_status": "verified_against_primary_figure"
              },
              "parameters": {
                "case_scope": {
                  "value": "8/9 adenoma;11/13 sessile serrated lesion",
                  "source_raw": "Case8,9: Adenoma;11,13: Sessile serrated lesion",
                  "source_refs": [
                    {
                      "source_id": "F13",
                      "locator": "S6a original TIFF labels"
                    }
                  ],
                  "check_status": "verified_against_primary_figure"
                },
                "modalities": {
                  "value": "3D compared with Histology(CD31)",
                  "source_raw": "3D;Histology(CD31)",
                  "source_refs": [
                    {
                      "source_id": "F13",
                      "locator": "S6a,c original TIFF"
                    }
                  ],
                  "check_status": "verified_against_primary_figure"
                },
                "axes": {
                  "value": "x:Depth,3D(µm);y:Depth,histology(µm)",
                  "source_raw": "Depth,3D(µm);Depth,histology(µm)",
                  "source_refs": [
                    {
                      "source_id": "F13",
                      "locator": "S6b original TIFF axes"
                    }
                  ],
                  "check_status": "verified_against_primary_figure"
                }
              },
              "notes": {
                "value": "具体回归软件/模型调用、每病例血管数/配对规则和误差类型未报告。仅源图支持深度，不能扩展成管径相关性步骤。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDF p.5, Measurement of vessel depth and caliber"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [
        {
          "case_id": "esophagus_height",
          "description": {
            "value": "食管非癌/癌血管高度仅作为Appendix指定统计分支；没有完整逐血管测高规则。",
            "source_raw": " The mean (± standard deviation) heights of vessels in non-cancerous and cancerous tissues in the esophagus, and the mean tortuosity of vessel in non-adenoma and adenoma tissue in the colon, were determined using a two-sample t-test with Minitab Software (version 21.4.2; PA, USA), with a level of significance of p < 0.05. ",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Statistical analysis; rendered pp.3"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "evidence_ids": [
            "A161-E03"
          ],
          "step_ids": [
            "A161-P003-S05"
          ]
        },
        {
          "case_id": "colon_tortuosity",
          "description": {
            "value": "结肠曲折度采用200µm范围、40µm标记，仅对应E04。",
            "source_refs": [
              {
                "source_id": "F14",
                "locator": "Appendix S1, Measurement of tortuosity; rendered pp.2–3"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "evidence_ids": [
            "A161-E04"
          ],
          "step_ids": [
            "A161-P003-S04",
            "A161-P003-S05"
          ]
        },
        {
          "case_id": "matched_case_depth_caliber",
          "description": {
            "value": "先成功匹配，再测相应ROI深度/管径；器官病例独立。",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDF p.5, Measurement of vessel depth and caliber"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          "evidence_ids": [
            "A161-E06",
            "A161-E07",
            "A161-E08"
          ],
          "step_ids": [
            "A161-P003-S02",
            "A161-P003-S03"
          ]
        },
        {
          "case_id": "paired_modalities_colon_depth",
          "description": {
            "value": "S6结肠3D与CD31切片深度比较，组织学图像走P002。",
            "source_raw": "3D;Histology(CD31)",
            "source_refs": [
              {
                "source_id": "F13",
                "locator": "S6a–c"
              }
            ],
            "check_status": "verified_against_primary_figure"
          },
          "evidence_ids": [
            "A161-E09"
          ],
          "step_ids": [
            "A161-P003-S06"
          ]
        }
      ],
      "reported_precedence": [
        "S01既存图→S02人工匹配→S03匹配成功病例的ROI量测。",
        "S04结肠曲折度与食管高度是独立形态比较，不要求先经S02内镜一对一成功。",
        "S06病例3D/组织学深度关系为独立比较，不把所有S03量测串到S06。"
      ],
      "missing_information": [
        "食管血管高度完整边界/测量细节未给；不将深度定义完全替代高度。",
        "各统计n层级、病例-血管/ROI关系、箱须定义、误差和回归实现未报。",
        "S3a排版异常与Appendix定义并列，未静默重写原图。"
      ],
      "source_conflicts": [],
      "review_status": "source_checked_direct_reported_scope; independent_audit_pending"
    }
  ],
  "legacy_mapping": [],
  "source_conflicts": [
    {
      "issue_id": "A161-CF01",
      "type": "source_locator_difference",
      "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
    },
    {
      "issue_id": "A161-CF02",
      "type": "source_formula_typography",
      "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
    },
    {
      "issue_id": "A161-CF03",
      "type": "source_metric_scope",
      "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
    }
  ],
  "remaining_unreviewed": [
    "主文外引13/14仅背景方法引用；本轮已有直接详细流程，不从未读引用补参数。",
    "本轮未对所有主图、其余补图和四个影片重新做结果/逐帧审阅；历史审阅不算本轮协议审阅。",
    "未取得原始光学栈、逐病例采集表、逐血管/ROI测量表；不可能确认个体参数与重算统计。"
  ],
  "missing_content_register": [
    {
      "record_id": "A161-P001",
      "missing": [
        "原固定时长/温度和处理前存档时长、组织块实际尺寸未报告。",
        "配液基准、体积、孵育中换液/混匀细节未充分；不以常用配方补写。",
        "除S2a10×/Fig.2 30×已知外，其余具体病例/面板归属、功率/pinhole/像素大小未完全报告。",
        "Table2 day列是计划阶段标签；ON保持原义，不反推小时或精确总时长。"
      ]
    },
    {
      "record_id": "A161-P002",
      "missing": [
        "组织学染色细节在本材料缺失，流程仅部分报告。",
        "不是全部器官/每幅图都采用相同切片标记；按面板及G/O匹配。"
      ]
    },
    {
      "record_id": "A161-P003",
      "missing": [
        "食管血管高度完整边界/测量细节未给；不将深度定义完全替代高度。",
        "各统计n层级、病例-血管/ROI关系、箱须定义、误差和回归实现未报。",
        "S3a排版异常与Appendix定义并列，未静默重写原图。"
      ]
    }
  ],
  "observation_conditions": [
    "固定/存档是初始状态，保存时长未明。",
    "ECi24h是处理孵育，不是透明化后的观测日期。",
    "Table2 Day1/2–17/18–20/21仅日程标注；SYTO16与CD34重叠，未据ON推精确总时长。",
    "处理完成至各次成像的等待/保存环境未单独给出。"
  ],
  "evidence_links": [
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A161-E01-G01",
      "group_pointer": "/evidence_records/0/groups/0",
      "observations": [
        {
          "observation_id": "A161-E01-O01",
          "pointer": "/evidence_records/0/observations/0",
          "figure_panels": [
            "Fig.S1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.5 Results start and p.7 continuation"
            },
            {
              "source_id": "F08",
              "location": "S1全图"
            }
          ]
        },
        {
          "observation_id": "A161-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "Fig.2a–d",
            "Fig.S2a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.5 Fig.2 caption; p.7 Results"
            },
            {
              "source_id": "F04",
              "location": "Fig.2"
            },
            {
              "source_id": "F09",
              "location": "S2a"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "panel_scope": {
        "Fig.S1": "macro before/after photos; acquisition unspecified; no confocal settings inheritance",
        "Fig.2/S2a 3D": "P001 clearing/confocal branch",
        "S2a histology": "P002 branch"
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A161-E01-G02",
      "group_pointer": "/evidence_records/0/groups/1",
      "observations": [
        {
          "observation_id": "A161-E01-O01",
          "pointer": "/evidence_records/0/observations/0",
          "figure_panels": [
            "Fig.S1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.5 Results start and p.7 continuation"
            },
            {
              "source_id": "F08",
              "location": "S1全图"
            }
          ]
        },
        {
          "observation_id": "A161-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "Fig.2a–d",
            "Fig.S2a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.5 Fig.2 caption; p.7 Results"
            },
            {
              "source_id": "F04",
              "location": "Fig.2"
            },
            {
              "source_id": "F09",
              "location": "S2a"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "panel_scope": {
        "Fig.S1": "macro before/after photos; acquisition unspecified; no confocal settings inheritance",
        "Fig.2/S2a 3D": "P001 clearing/confocal branch",
        "S2a histology": "P002 branch"
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A161-E01-G03",
      "group_pointer": "/evidence_records/0/groups/2",
      "observations": [
        {
          "observation_id": "A161-E01-O01",
          "pointer": "/evidence_records/0/observations/0",
          "figure_panels": [
            "Fig.S1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.5 Results start and p.7 continuation"
            },
            {
              "source_id": "F08",
              "location": "S1全图"
            }
          ]
        },
        {
          "observation_id": "A161-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "Fig.2a–d",
            "Fig.S2a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.5 Fig.2 caption; p.7 Results"
            },
            {
              "source_id": "F04",
              "location": "Fig.2"
            },
            {
              "source_id": "F09",
              "location": "S2a"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "panel_scope": {
        "Fig.S1": "macro before/after photos; acquisition unspecified; no confocal settings inheritance",
        "Fig.2/S2a 3D": "P001 clearing/confocal branch",
        "S2a histology": "P002 branch"
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A161-E02-G01",
      "group_pointer": "/evidence_records/1/groups/0",
      "observations": [
        {
          "observation_id": "A161-E02-O01",
          "pointer": "/evidence_records/1/observations/0",
          "figure_panels": [
            "Fig.2a",
            "Video S1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp.5,7 Fig.2a"
            },
            {
              "source_id": "F04",
              "location": "Fig.2a"
            },
            {
              "source_id": "F16",
              "location": "Video S1；22帧时序抽样，0–20 s每秒及结束前0.1 s"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A161-E02-G02",
      "group_pointer": "/evidence_records/1/groups/1",
      "observations": [
        {
          "observation_id": "A161-E02-O02",
          "pointer": "/evidence_records/1/observations/1",
          "figure_panels": [
            "Fig.2b",
            "Video S2"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp.5,7 Fig.2b"
            },
            {
              "source_id": "F04",
              "location": "Fig.2b"
            },
            {
              "source_id": "F17",
              "location": "Video S2；22帧时序抽样，0–20 s每秒及结束前0.1 s"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A161-E02-G03",
      "group_pointer": "/evidence_records/1/groups/2",
      "observations": [
        {
          "observation_id": "A161-E02-O03",
          "pointer": "/evidence_records/1/observations/2",
          "figure_panels": [
            "Fig.2c",
            "Video S3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp.5,7 Fig.2c"
            },
            {
              "source_id": "F04",
              "location": "Fig.2c"
            },
            {
              "source_id": "F18",
              "location": "Video S3；22帧时序抽样，0–20 s每秒及结束前0.1 s"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A161-E02-G04",
      "group_pointer": "/evidence_records/1/groups/3",
      "observations": [
        {
          "observation_id": "A161-E02-O04",
          "pointer": "/evidence_records/1/observations/3",
          "figure_panels": [
            "Fig.2d",
            "Video S4"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp.5,7 Fig.2d"
            },
            {
              "source_id": "F04",
              "location": "Fig.2d"
            },
            {
              "source_id": "F19",
              "location": "Video S4；22帧时序抽样，0–20 s每秒及结束前0.1 s"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": null,
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A161-E03-G01",
      "group_pointer": "/evidence_records/2/groups/0",
      "observations": [
        {
          "observation_id": "A161-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "Fig.3a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 esophageal result"
            },
            {
              "source_id": "F05",
              "location": "Fig.3a"
            }
          ]
        },
        {
          "observation_id": "A161-E03-O02",
          "pointer": "/evidence_records/2/observations/1",
          "figure_panels": [
            "Fig.S2b",
            "Fig.S2c"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 and p.11 S2 caption"
            },
            {
              "source_id": "F09",
              "location": "S2b–c"
            },
            {
              "source_id": "F14",
              "location": "p.3 Statistics"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S05 (height only; measurement details incomplete)",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A161-E03-G02",
      "group_pointer": "/evidence_records/2/groups/1",
      "observations": [
        {
          "observation_id": "A161-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "Fig.3a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 esophageal result"
            },
            {
              "source_id": "F05",
              "location": "Fig.3a"
            }
          ]
        },
        {
          "observation_id": "A161-E03-O02",
          "pointer": "/evidence_records/2/observations/1",
          "figure_panels": [
            "Fig.S2b",
            "Fig.S2c"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 and p.11 S2 caption"
            },
            {
              "source_id": "F09",
              "location": "S2b–c"
            },
            {
              "source_id": "F14",
              "location": "p.3 Statistics"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S05 (height only; measurement details incomplete)",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A161-E04-G01",
      "group_pointer": "/evidence_records/3/groups/0",
      "observations": [
        {
          "observation_id": "A161-E04-O01",
          "pointer": "/evidence_records/3/observations/0",
          "figure_panels": [
            "Fig.3b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 colon Results"
            },
            {
              "source_id": "F05",
              "location": "Fig.3b"
            }
          ]
        },
        {
          "observation_id": "A161-E04-O02",
          "pointer": "/evidence_records/3/observations/1",
          "figure_panels": [
            "Fig.S3a",
            "Fig.S3b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 Results and p.11 S3 caption"
            },
            {
              "source_id": "F10",
              "location": "S3a–b"
            },
            {
              "source_id": "F14",
              "location": "pp.2–3"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S04/S05",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A161-E04-G02",
      "group_pointer": "/evidence_records/3/groups/1",
      "observations": [
        {
          "observation_id": "A161-E04-O01",
          "pointer": "/evidence_records/3/observations/0",
          "figure_panels": [
            "Fig.3b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 colon Results"
            },
            {
              "source_id": "F05",
              "location": "Fig.3b"
            }
          ]
        },
        {
          "observation_id": "A161-E04-O02",
          "pointer": "/evidence_records/3/observations/1",
          "figure_panels": [
            "Fig.S3a",
            "Fig.S3b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 Results and p.11 S3 caption"
            },
            {
              "source_id": "F10",
              "location": "S3a–b"
            },
            {
              "source_id": "F14",
              "location": "pp.2–3"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S04/S05",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "mixed_modality_scope": "Fig.3 and S2 include histology/endoscopy context as applicable; only 3D panels inheritP001. Histology followsP002; existing sample/marker IDs not changed."
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A161-E05-G01",
      "group_pointer": "/evidence_records/4/groups/0",
      "observations": [
        {
          "observation_id": "A161-E05-O01",
          "pointer": "/evidence_records/4/observations/0",
          "figure_panels": [
            "Table 1",
            "Fig.4a",
            "Fig.4b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.2 Table 1; p.7 Results"
            },
            {
              "source_id": "F06",
              "location": "Fig.4"
            },
            {
              "source_id": "F01",
              "location": "pp.4–5 One-to-one correspondence and matching criteria; p.2 Tissue-block selection"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S02",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A161-E05-G02",
      "group_pointer": "/evidence_records/4/groups/1",
      "observations": [
        {
          "observation_id": "A161-E05-O01",
          "pointer": "/evidence_records/4/observations/0",
          "figure_panels": [
            "Table 1",
            "Fig.4a",
            "Fig.4b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.2 Table 1; p.7 Results"
            },
            {
              "source_id": "F06",
              "location": "Fig.4"
            },
            {
              "source_id": "F01",
              "location": "pp.4–5 One-to-one correspondence and matching criteria; p.2 Tissue-block selection"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S02",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A161-E05-G03",
      "group_pointer": "/evidence_records/4/groups/2",
      "observations": [
        {
          "observation_id": "A161-E05-O01",
          "pointer": "/evidence_records/4/observations/0",
          "figure_panels": [
            "Table 1",
            "Fig.4a",
            "Fig.4b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.2 Table 1; p.7 Results"
            },
            {
              "source_id": "F06",
              "location": "Fig.4"
            },
            {
              "source_id": "F01",
              "location": "pp.4–5 One-to-one correspondence and matching criteria; p.2 Tissue-block selection"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S02",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E06",
      "evidence_pointer": "/evidence_records/5",
      "group_id": "A161-E06-G01",
      "group_pointer": "/evidence_records/5/groups/0",
      "observations": [
        {
          "observation_id": "A161-E06-O01",
          "pointer": "/evidence_records/5/observations/0",
          "figure_panels": [
            "S4",
            "Table S1"
          ],
          "source_refs": [
            {
              "source_id": "F11",
              "location": "S4a–b"
            },
            {
              "source_id": "F15",
              "location": "Table S1 Case 2, rows 1–5"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S03",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A161-E07-G01",
      "group_pointer": "/evidence_records/6/groups/0",
      "observations": [
        {
          "observation_id": "A161-E07-O01",
          "pointer": "/evidence_records/6/observations/0",
          "figure_panels": [
            "S5",
            "Table S1"
          ],
          "source_refs": [
            {
              "source_id": "F12",
              "location": "S5a–b"
            },
            {
              "source_id": "F15",
              "location": "Table S1 Case 5, rows 1–5"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S03",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E08",
      "evidence_pointer": "/evidence_records/7",
      "group_id": "A161-E08-G01",
      "group_pointer": "/evidence_records/7/groups/0",
      "observations": [
        {
          "observation_id": "A161-E08-O01",
          "pointer": "/evidence_records/7/observations/0",
          "figure_panels": [
            "Table 3",
            "Fig.5"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.9 Table 3"
            },
            {
              "source_id": "F07",
              "location": "Fig.5 ROI 1/2"
            }
          ]
        },
        {
          "observation_id": "A161-E08-O02",
          "pointer": "/evidence_records/7/observations/1",
          "figure_panels": [
            "Fig.5",
            "Table 3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 paragraph on vessels 1–6; p.9 Table 3"
            },
            {
              "source_id": "F07",
              "location": "Fig.5"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S03",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "marker_scope": "existingG has L01 only; do not add nuclear L02 merely because commonP001 reports SYTO16."
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E08",
      "evidence_pointer": "/evidence_records/7",
      "group_id": "A161-E08-G02",
      "group_pointer": "/evidence_records/7/groups/1",
      "observations": [
        {
          "observation_id": "A161-E08-O01",
          "pointer": "/evidence_records/7/observations/0",
          "figure_panels": [
            "Table 3",
            "Fig.5"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.9 Table 3"
            },
            {
              "source_id": "F07",
              "location": "Fig.5 ROI 1/2"
            }
          ]
        },
        {
          "observation_id": "A161-E08-O02",
          "pointer": "/evidence_records/7/observations/1",
          "figure_panels": [
            "Fig.5",
            "Table 3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p.7 paragraph on vessels 1–6; p.9 Table 3"
            },
            {
              "source_id": "F07",
              "location": "Fig.5"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S03",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      },
      "marker_scope": "existingG has L01 only; do not add nuclear L02 merely because commonP001 reports SYTO16."
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E09",
      "evidence_pointer": "/evidence_records/8",
      "group_id": "A161-E09-G01",
      "group_pointer": "/evidence_records/8/groups/0",
      "observations": [
        {
          "observation_id": "A161-E09-O01",
          "pointer": "/evidence_records/8/observations/0",
          "figure_panels": [
            "Fig.S6a",
            "Fig.S6b",
            "Fig.S6c"
          ],
          "source_refs": [
            {
              "source_id": "F13",
              "location": "S6a case labels; S6b axes and regression; S6c image"
            },
            {
              "source_id": "F01",
              "location": "p.11 S6 caption"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "wholeblock_processing": "A161-P001",
        "quantitative_analysis": "A161-P003-S06",
        "limitations": "FV3000 and fluorescent settings only for3D branch; histology/ME-NBI panels retain P002/P003-S01. No paper-wide objective/zstep choice."
      }
    },
    {
      "core_path": "A161_candidate/A161_evidence.json",
      "evidence_id": "A161-E09",
      "evidence_pointer": "/evidence_records/8",
      "group_id": "A161-E09-G02",
      "group_pointer": "/evidence_records/8/groups/1",
      "observations": [
        {
          "observation_id": "A161-E09-O01",
          "pointer": "/evidence_records/8/observations/0",
          "figure_panels": [
            "Fig.S6a",
            "Fig.S6b",
            "Fig.S6c"
          ],
          "source_refs": [
            {
              "source_id": "F13",
              "location": "S6a case labels; S6b axes and regression; S6c image"
            },
            {
              "source_id": "F01",
              "location": "p.11 S6 caption"
            }
          ]
        }
      ],
      "binding_basis": "按E/G/O及实际模态/标记分支匹配；全篇方法表不是逐图逐样本实施证明。",
      "protocol_binding": {
        "record": "A161-P002",
        "measurement": "A161-P003-S06",
        "marker": "CD31 (L03)",
        "excluded": "no ECi wholeblock CD34/SYTO16/FV3000 inheritance"
      }
    }
  ],
  "sources": [
    {
      "source_id": "F01",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/PMC12162411.1.pdf",
      "sha256": "8a70d129b986a666455e7a035c4ff6580779f3756120d960c279ff0b75842e63",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "Methods/XML direct text; primary PDF pp3–4 visual Table2/Fig1; relevant captions"
    },
    {
      "source_id": "F02",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/PMC12162411.1.xml",
      "sha256": "ebc1260e597343987940ee5ad463a1f6bbc300a50911351862e640d17a9b1353",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "Methods/XML direct text; primary PDF pp3–4 visual Table2/Fig1; relevant captions"
    },
    {
      "source_id": "F03",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g001.jpg",
      "sha256": "6ec1feb35f8f8432e934c7a732423f8739f14212baf1f7e970a5befbeec68e19",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F04",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g004.jpg",
      "sha256": "10f6a9ad864e3ab4c036b93692e10c092d9406499163e22b76b96813444fbea4",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F05",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g005.jpg",
      "sha256": "346bfa22493e745330d5c46f771b1aea23eefbe3e1f2fc66ad8ef5f53fa6f910",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F06",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g002.jpg",
      "sha256": "793a89643b634c0026cabf5c4234a34891b4e391b0d78aa67c6a5eb86287bd88",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F07",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-g003.jpg",
      "sha256": "56b22f671c58186e956eb059cf826f724b234cd2623e2cea7028821ad1e0c075",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F08",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s007.tif",
      "sha256": "ce946971381764881239d939ecbbc78703f9782579ed0687fa8fff1f5a292eef",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "original TIFF converted RGB for full visual read; no digitization"
    },
    {
      "source_id": "F09",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s001.tif",
      "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F10",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s009.tif",
      "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "original TIFF converted RGB for full visual read; no digitization"
    },
    {
      "source_id": "F11",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s012.tif",
      "sha256": "cc3a8719577e910fcba74167a9f9f171dc3a6b14f8f81b8ad2ee0fe8af522d8c",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F12",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s006.tif",
      "sha256": "f6ce6511b2f8c841cd57a61219253b95c8b1ad71127969327bdab8242bd7aea1",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F13",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s002.tif",
      "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "original TIFF converted RGB for full visual read; no digitization"
    },
    {
      "source_id": "F14",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s011.docx",
      "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "DOCX full XML read +3 rendered pages visual"
    },
    {
      "source_id": "F15",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s005.docx",
      "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "DOCX full text table read; used as output scope, no method values inferred"
    },
    {
      "source_id": "F16",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s010.mp4",
      "sha256": "45fbdb579c966dd7db2bb911df95613138d22cd4b746b7fd1559d4efbada3b9c",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F17",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s008.mp4",
      "sha256": "c690dd43ef4765c1389a0d2f78f2b342f250f13b89194bb8c24050265a52abc4",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F18",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s003.mp4",
      "sha256": "6fc012d68cf526635509f863899b84c8a164ac1812c1fb63fca489277d4e38c5",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    },
    {
      "source_id": "F19",
      "path": "candidate_research_next_20261008h/PMC12162411/originals/DEN-37-659-s004.mp4",
      "sha256": "ad9cd63d00492bbf2de028c945a2712199f903d7fc2d67022317faef04a94c32",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12162411/",
      "this_round_read": "not_re_read_this_round"
    }
  ],
  "review_status": {
    "source_content": "saved_direct_reported_scope_with_gaps",
    "independent_audit": "pending",
    "specified_Pro": "unchanged_hold",
    "acceptance_change": false,
    "actual_execution_or_effect_validation": "not_performed"
  },
  "source_field_check_count": 138,
  "recovery_current_scope_20261010": {
    "paper_id": "A161",
    "recovery_date": "2026-10-10",
    "input_selected": "checkpoint_recovery_20261010/extracted/checkpoint/full_corpus_sources/objects/ba69c6f0d3cf8e3d791ccb88d8360bb1ba348b2bdba399e90f1899f6a2549333.json",
    "input_sha256": "ba69c6f0d3cf8e3d791ccb88d8360bb1ba348b2bdba399e90f1899f6a2549333",
    "layer": "recovered_current_scope_without_new_primary_source_verification",
    "historical_review_and_acceptance_preserved": true,
    "original_review_scope_and_check_status_semantics": "Inherited checkpoint declarations; not claims made by this recovery pass.",
    "current_work": "Inspected embedded source_raw excerpts for named issues and made only explicitly supported internal-consistency repairs. Field inventory is mechanical enumeration, not a reconstructed full scientific audit.",
    "new_primary_source_verified_fields": 0,
    "targeted_internal_checks": {},
    "prior_verified_scope_recovered_from_parent": [
      "断连前范围记录：46个附件专属字段未核；Table1病例和Table3六个sites原可核。当前未恢复表级逐项原始证据，不重建病例行或数值；46仅为继承聚合记录。"
    ],
    "aggregate_gap_counts_have_no_invented_field_mapping": true,
    "existing_source_conflicts_preserved": [
      {
        "issue_id": "A161-CF01",
        "type": "source_locator_difference",
        "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
      },
      {
        "issue_id": "A161-CF02",
        "type": "source_formula_typography",
        "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
      },
      {
        "issue_id": "A161-CF03",
        "type": "source_metric_scope",
        "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
      }
    ],
    "existing_remaining_unreviewed_preserved": [
      "主文外引13/14仅背景方法引用；本轮已有直接详细流程，不从未读引用补参数。",
      "本轮未对所有主图、其余补图和四个影片重新做结果/逐帧审阅；历史审阅不算本轮协议审阅。",
      "未取得原始光学栈、逐病例采集表、逐血管/ROI测量表；不可能确认个体参数与重算统计。"
    ],
    "online_access": "PMC request returned reCAPTCHA for A152/A154/A155/A158; retrieval stopped, no bypass or supplementary batch retrieval. Other papers not requested from blocked host.",
    "publication_approved": false
  }
}
```

## 当前问题对象（非expert gold）

```json

{
  "paper_id": "A161",
  "version": "2026-10-12-question-projection.1",
  "source_core": "A161_reconstructed_evidence.json",
  "source_core_version": "2026-10-12-source-reconstruction.1",
  "source_core_sha256": "1f1010a6cf464cfd29ba64f5e6d15e4b96c6183f35e22b0f7c4e7c7d114b5323",
  "expert_gold": false,
  "not_model_scoring_or_expert_adjudication": true,
  "projection_scope": "All current results and claims, with source/protocol/sample/conflict links; no new scientific facts and no restoration of historical question IDs.",
  "results_covered": 25,
  "claims_covered": 26,
  "administrative_approval": "unchanged; this projection confers no scientific acceptance or Pro approval",
  "questions": [
    {
      "question_id": "A161-R20261012-Q001",
      "question": "该研究对“Clearing and imaging reach”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E01",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O01",
          "text": "All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.",
          "original_result": {
            "result_id": "A161-R20261012-O01",
            "experiment_id": "A161-R20261012-E01",
            "sample_context_ids": [
              "A161-R20261012-S01",
              "A161-R20261012-S02",
              "A161-R20261012-S03",
              "A161-R20261012-S04",
              "A161-R20261012-S05",
              "A161-R20261012-S06",
              "A161-R20261012-S07"
            ],
            "metric": "Clearing and imaging reach",
            "result": "All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.",
            "values": {
              "reported_depth_um": 350,
              "approximate": true,
              "objective": 30,
              "wholemount_labels": [
                "CD34-AF647",
                "SYTO16"
              ]
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR01"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Results first subsection; FigureS1,S2a",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C01",
          "claim_type": "source_scoped_result_summary",
          "text": "All reported paraffin blocks cleared;10× images cover resected layers,30× reaches approximately350µm. This does not establish universal complete cell detection.",
          "supporting_result_ids": [
            "A161-R20261012-O01"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Results first subsection; FigureS1,S2a",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S01",
        "A161-R20261012-S02",
        "A161-R20261012-S03",
        "A161-R20261012-S04",
        "A161-R20261012-S05",
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "actual_protocol_ids": [
        "A161-P001"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Results first subsection; FigureS1,S2a",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q002",
      "question": "该研究对“Noncancerous esophageal vessels”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E02",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O02",
          "text": "IPCL and subepithelial network visualized; surface loops narrower than drainage vein.",
          "original_result": {
            "result_id": "A161-R20261012-O02",
            "experiment_id": "A161-R20261012-E02",
            "sample_context_ids": [
              "A161-R20261012-S01"
            ],
            "metric": "Noncancerous esophageal vessels",
            "result": "IPCL and subepithelial network visualized; surface loops narrower than drainage vein.",
            "values": {
              "surface_loop_caliber_um": 10,
              "drainage_vein_caliber_um": 50,
              "approximate": true
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR02"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Figure2a;VideoS1",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C02",
          "claim_type": "source_scoped_result_summary",
          "text": "IPCL and subepithelial network visualized; surface loops narrower than drainage vein.",
          "supporting_result_ids": [
            "A161-R20261012-O02"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Figure2a;VideoS1",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S01"
      ],
      "actual_protocol_ids": [
        "A161-P001"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2a;VideoS1",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q003",
      "question": "该研究对“Noncancerous gastric regional architecture”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E03",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O03",
          "text": "Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.",
          "original_result": {
            "result_id": "A161-R20261012-O03",
            "experiment_id": "A161-R20261012-E03",
            "sample_context_ids": [
              "A161-R20261012-S03"
            ],
            "metric": "Noncancerous gastric regional architecture",
            "result": "Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.",
            "values": null,
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR03"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Figure2b–c;VideoS2,S3",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C03",
          "claim_type": "source_scoped_result_summary",
          "text": "Upper stomach has polygonal capillary loops around pits; lower stomach has ridge-like surface and coiled capillaries.",
          "supporting_result_ids": [
            "A161-R20261012-O03"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Figure2b–c;VideoS2,S3",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S03"
      ],
      "actual_protocol_ids": [
        "A161-P001"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c;VideoS2,S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q004",
      "question": "该研究对“Noncancerous colon architecture”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E04",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O04",
          "text": "Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.",
          "original_result": {
            "result_id": "A161-R20261012-O04",
            "experiment_id": "A161-R20261012-E04",
            "sample_context_ids": [
              "A161-R20261012-S05"
            ],
            "metric": "Noncancerous colon architecture",
            "result": "Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.",
            "values": null,
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR04"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Figure2d;VideoS4",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C04",
          "claim_type": "source_scoped_result_summary",
          "text": "Honeycomb microvessels surround crypts, with ascending/descending vessels of different calibers.",
          "supporting_result_ids": [
            "A161-R20261012-O04"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Figure2d;VideoS4",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S05"
      ],
      "actual_protocol_ids": [
        "A161-P001"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2d;VideoS4",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q005",
      "question": "该研究对“Esophageal cancer vascular changes”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E05",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O05",
          "text": "Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.",
          "original_result": {
            "result_id": "A161-R20261012-O05",
            "experiment_id": "A161-R20261012-E05",
            "sample_context_ids": [
              "A161-R20261012-S01",
              "A161-R20261012-S02"
            ],
            "metric": "Esophageal cancer vascular changes",
            "result": "Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.",
            "values": {
              "height_test": "two-sample t-test",
              "height_p": "<0.05",
              "caption_n": 10,
              "n_unit": "not explicitly identified in caption; not10patients",
              "summary": "mean ±SD perAppendixS1",
              "means": null,
              "means_status": "not digitized",
              "fresh_visual": "S2panelc star/axis checked"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR05"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Figure3a;FigureS2;AppendixS1",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F04",
                "locator": "FigureS2c",
                "verification": "freshvisual"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C05",
          "claim_type": "source_scoped_result_summary",
          "text": "Cancer-associated looped vessels are more dilated/tortuous and taller than noncancerous examples; quantified comparison directly supports height.",
          "supporting_result_ids": [
            "A161-R20261012-O05"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Figure3a;FigureS2;AppendixS1",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F04",
              "locator": "FigureS2c",
              "verification": "freshvisual"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S01",
        "A161-R20261012-S02"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P002",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3a;FigureS2;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F04",
          "locator": "FigureS2c",
          "verification": "freshvisual"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q006",
      "question": "该研究对“Colon adenoma morphology/tortuosity”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E06",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O06",
          "text": "Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.",
          "original_result": {
            "result_id": "A161-R20261012-O06",
            "experiment_id": "A161-R20261012-E06",
            "sample_context_ids": [
              "A161-R20261012-S05",
              "A161-R20261012-S06"
            ],
            "metric": "Colon adenoma morphology/tortuosity",
            "result": "Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.",
            "values": {
              "tortuosity_p": "<0.05",
              "test": "two-sample t-test perAppendix",
              "caption_n": 3,
              "n_unit": "not explicitly resolved",
              "metric": "sum of path segments at40µm depth intervals to200µm divided by shortestD0–D200 distance",
              "source_formula_conflict": "A161-CF02",
              "display": "S3boxplot, not converted to mean±SD points",
              "fresh_visual": "formula typography and boxplot checked"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR06"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Figure3b;FigureS3;AppendixS1",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F05",
                "locator": "FigureS3a–b",
                "verification": "freshvisual"
              },
              {
                "source_id": "A161-R20261012-F03",
                "locator": "Measurement of tortuosity;Statistics",
                "verification": "freshfulltext"
              }
            ],
            "source_conflict_refs": [
              "A161-CF02"
            ]
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C06",
          "claim_type": "source_scoped_result_summary",
          "text": "Adenoma crypt openings are oval/nonuniform rather than round/uniform. Vessels are dilated and more tortuous; displayed significance applies to tortuosity.",
          "supporting_result_ids": [
            "A161-R20261012-O06"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Figure3b;FigureS3;AppendixS1",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F05",
              "locator": "FigureS3a–b",
              "verification": "freshvisual"
            },
            {
              "source_id": "A161-R20261012-F03",
              "locator": "Measurement of tortuosity;Statistics",
              "verification": "freshfulltext"
            }
          ],
          "source_conflict_refs": [
            "A161-CF02"
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S05",
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P002",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure3b;FigureS3;AppendixS1",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F05",
          "locator": "FigureS3a–b",
          "verification": "freshvisual"
        },
        {
          "source_id": "A161-R20261012-F03",
          "locator": "Measurement of tortuosity;Statistics",
          "verification": "freshfulltext"
        }
      ],
      "source_conflicts": [
        {
          "issue_id": "A161-CF02",
          "type": "source_formula_typography",
          "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
        }
      ],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q007",
      "question": "该研究对“Case-level one-to-one matching”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E07",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O07",
          "text": "Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.",
          "original_result": {
            "result_id": "A161-R20261012-O07",
            "experiment_id": "A161-R20261012-E07",
            "sample_context_ids": [
              "A161-R20261012-S02",
              "A161-R20261012-S04",
              "A161-R20261012-S06",
              "A161-R20261012-S07"
            ],
            "metric": "Case-level one-to-one matching",
            "result": "Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.",
            "values": {
              "esophagus": {
                "success": 3,
                "total": 3
              },
              "stomach": {
                "success": 2,
                "total": 4
              },
              "colorectum": {
                "success": 5,
                "total": 7
              },
              "matched_case_ids": [
                1,
                2,
                3,
                4,
                5,
                8,
                9,
                10,
                12,
                14
              ],
              "unmatched_case_ids": [
                6,
                7,
                11,
                13
              ],
              "criterion": "at least5 vessel/crypt structures, agreement of3engineers,pathologist,endoscopist",
              "total_cases": 14
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR07"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table1;Figure4;Results matching",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C07",
          "claim_type": "source_scoped_result_summary",
          "text": "Matching succeeds in3/3esophageal,2/4gastric and5/7colorectal cases. Gastric cases6/7 andSSL cases11/13 fail. Failed matching does not imply failed tissue clearing.",
          "supporting_result_ids": [
            "A161-R20261012-O07"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table1;Figure4;Results matching",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S02",
        "A161-R20261012-S04",
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q008",
      "question": "该研究对“Continuous vessel versus discontinuous endoscopic appearance”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E08",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O08",
          "text": "Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.",
          "original_result": {
            "result_id": "A161-R20261012-O08",
            "experiment_id": "A161-R20261012-E08",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Continuous vessel versus discontinuous endoscopic appearance",
            "result": "Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.",
            "values": {
              "case_id": 9,
              "vessel_ids": [
                1,
                2,
                3,
                4,
                5,
                6
              ],
              "narrative_depth_change_um": 20,
              "narrative_status": "approximately contextual path-depth change, not allTable3values20"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR08"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Figure5;Results matching",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C08",
          "claim_type": "source_scoped_result_summary",
          "text": "Vessels1–3 appear disconnected endoscopically but traced vessels continue deeper than100µm;4–6 contrast changes with path depth. Table3 single sampled depths must not be treated as full trajectories.",
          "supporting_result_ids": [
            "A161-R20261012-O08"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Figure5;Results matching",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure5;Results matching",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q009",
      "question": "该研究对“Case9 vessel1 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E09",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O09",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "original_result": {
            "result_id": "A161-R20261012-O09",
            "experiment_id": "A161-R20261012-E09",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Case9 vessel1 measured depth/caliber",
            "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
            "values": {
              "case_id": 9,
              "vessel_no": 1,
              "depth_um": 28.0,
              "caliber_um": 10.0,
              "value_type": "exact_table_value"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR09"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table3;Figure5",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C09",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "supporting_result_ids": [
            "A161-R20261012-O09"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table3;Figure5",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q010",
      "question": "该研究对“Case9 vessel2 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E10",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O10",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "original_result": {
            "result_id": "A161-R20261012-O10",
            "experiment_id": "A161-R20261012-E10",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Case9 vessel2 measured depth/caliber",
            "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
            "values": {
              "case_id": 9,
              "vessel_no": 2,
              "depth_um": 108.9,
              "caliber_um": 6.2,
              "value_type": "exact_table_value"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR10"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table3;Figure5",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C10",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "supporting_result_ids": [
            "A161-R20261012-O10"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table3;Figure5",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q011",
      "question": "该研究对“Case9 vessel3 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E11",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O11",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "original_result": {
            "result_id": "A161-R20261012-O11",
            "experiment_id": "A161-R20261012-E11",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Case9 vessel3 measured depth/caliber",
            "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
            "values": {
              "case_id": 9,
              "vessel_no": 3,
              "depth_um": 20.3,
              "caliber_um": 15.1,
              "value_type": "exact_table_value"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR11"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table3;Figure5",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C11",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "supporting_result_ids": [
            "A161-R20261012-O11"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table3;Figure5",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q012",
      "question": "该研究对“Case9 vessel4 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E12",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O12",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "original_result": {
            "result_id": "A161-R20261012-O12",
            "experiment_id": "A161-R20261012-E12",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Case9 vessel4 measured depth/caliber",
            "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
            "values": {
              "case_id": 9,
              "vessel_no": 4,
              "depth_um": 35.0,
              "caliber_um": 12.1,
              "value_type": "exact_table_value"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR12"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table3;Figure5",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C12",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "supporting_result_ids": [
            "A161-R20261012-O12"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table3;Figure5",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q013",
      "question": "该研究对“Case9 vessel5 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E13",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O13",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "original_result": {
            "result_id": "A161-R20261012-O13",
            "experiment_id": "A161-R20261012-E13",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Case9 vessel5 measured depth/caliber",
            "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
            "values": {
              "case_id": 9,
              "vessel_no": 5,
              "depth_um": 54.6,
              "caliber_um": 11.1,
              "value_type": "exact_table_value"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR13"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table3;Figure5",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C13",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "supporting_result_ids": [
            "A161-R20261012-O13"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table3;Figure5",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q014",
      "question": "该研究对“Case9 vessel6 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E14",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O14",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "original_result": {
            "result_id": "A161-R20261012-O14",
            "experiment_id": "A161-R20261012-E14",
            "sample_context_ids": [
              "A161-R20261012-S06"
            ],
            "metric": "Case9 vessel6 measured depth/caliber",
            "result": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
            "values": {
              "case_id": 9,
              "vessel_no": 6,
              "depth_um": 32.3,
              "caliber_um": 11.1,
              "value_type": "exact_table_value"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR14"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "Table3;Figure5",
                "verification": "publisher_text_inspected_20261012"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C14",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact reported3Dmeasurement at the designated ROI; no raw trajectory or repeated-measure uncertainty supplied.",
          "supporting_result_ids": [
            "A161-R20261012-O14"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Table3;Figure5",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table3;Figure5",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q015",
      "question": "该研究对“Case2 vessel1 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E15",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O15",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O15",
            "experiment_id": "A161-R20261012-E15",
            "sample_context_ids": [
              "A161-R20261012-S02"
            ],
            "metric": "Case2 vessel1 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 2,
              "vessel_no": 1,
              "depth_um": 14.1,
              "caliber_um": 18.7,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR15"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS4",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C15",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O15"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS4",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q016",
      "question": "该研究对“Case2 vessel2 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E16",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O16",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O16",
            "experiment_id": "A161-R20261012-E16",
            "sample_context_ids": [
              "A161-R20261012-S02"
            ],
            "metric": "Case2 vessel2 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 2,
              "vessel_no": 2,
              "depth_um": 22.7,
              "caliber_um": 24.5,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR16"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS4",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C16",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O16"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS4",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q017",
      "question": "该研究对“Case2 vessel3 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E17",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O17",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O17",
            "experiment_id": "A161-R20261012-E17",
            "sample_context_ids": [
              "A161-R20261012-S02"
            ],
            "metric": "Case2 vessel3 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 2,
              "vessel_no": 3,
              "depth_um": 35.3,
              "caliber_um": 12.5,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR17"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS4",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C17",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O17"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS4",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q018",
      "question": "该研究对“Case2 vessel4 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E18",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O18",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O18",
            "experiment_id": "A161-R20261012-E18",
            "sample_context_ids": [
              "A161-R20261012-S02"
            ],
            "metric": "Case2 vessel4 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 2,
              "vessel_no": 4,
              "depth_um": 31.1,
              "caliber_um": 10.5,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR18"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS4",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C18",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O18"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS4",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q019",
      "question": "该研究对“Case2 vessel5 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E19",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O19",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O19",
            "experiment_id": "A161-R20261012-E19",
            "sample_context_ids": [
              "A161-R20261012-S02"
            ],
            "metric": "Case2 vessel5 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 2,
              "vessel_no": 5,
              "depth_um": 22.7,
              "caliber_um": 10.5,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR19"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS4",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C19",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O19"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS4",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S02"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS4",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q020",
      "question": "该研究对“Case5 vessel1 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E20",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O20",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O20",
            "experiment_id": "A161-R20261012-E20",
            "sample_context_ids": [
              "A161-R20261012-S04"
            ],
            "metric": "Case5 vessel1 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 5,
              "vessel_no": 1,
              "depth_um": 49.6,
              "caliber_um": 11.9,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR20"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS5",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C20",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O20"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS5",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q021",
      "question": "该研究对“Case5 vessel2 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E21",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O21",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O21",
            "experiment_id": "A161-R20261012-E21",
            "sample_context_ids": [
              "A161-R20261012-S04"
            ],
            "metric": "Case5 vessel2 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 5,
              "vessel_no": 2,
              "depth_um": 52.9,
              "caliber_um": 10.5,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR21"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS5",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C21",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O21"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS5",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q022",
      "question": "该研究对“Case5 vessel3 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E22",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O22",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O22",
            "experiment_id": "A161-R20261012-E22",
            "sample_context_ids": [
              "A161-R20261012-S04"
            ],
            "metric": "Case5 vessel3 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 5,
              "vessel_no": 3,
              "depth_um": 45.5,
              "caliber_um": 11.7,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR22"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS5",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C22",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O22"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS5",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q023",
      "question": "该研究对“Case5 vessel4 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E23",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O23",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O23",
            "experiment_id": "A161-R20261012-E23",
            "sample_context_ids": [
              "A161-R20261012-S04"
            ],
            "metric": "Case5 vessel4 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 5,
              "vessel_no": 4,
              "depth_um": 69.0,
              "caliber_um": 12.0,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR23"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS5",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C23",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O23"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS5",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q024",
      "question": "该研究对“Case5 vessel5 measured depth/caliber”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E24",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O24",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "original_result": {
            "result_id": "A161-R20261012-O24",
            "experiment_id": "A161-R20261012-E24",
            "sample_context_ids": [
              "A161-R20261012-S04"
            ],
            "metric": "Case5 vessel5 measured depth/caliber",
            "result": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
            "values": {
              "case_id": 5,
              "vessel_no": 5,
              "depth_um": 47.1,
              "caliber_um": 8.6,
              "value_type": "exact_table_value",
              "source_asset": "DEN-37-659-s005.docx"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR24"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "TableS1;FigureS5",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F02",
                "locator": "TableS1 case/vessel row as in values",
                "verification": "freshoriginalDOCXtable_cells_read"
              }
            ],
            "source_conflict_refs": []
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C24",
          "claim_type": "source_scoped_result_summary",
          "text": "Exact original supplementary table3Dmeasurement; vessel count is not patient count.",
          "supporting_result_ids": [
            "A161-R20261012-O24"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "TableS1;FigureS5",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F02",
              "locator": "TableS1 case/vessel row as in values",
              "verification": "freshoriginalDOCXtable_cells_read"
            }
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S04"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "TableS1;FigureS5",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F02",
          "locator": "TableS1 case/vessel row as in values",
          "verification": "freshoriginalDOCXtable_cells_read"
        }
      ],
      "source_conflicts": [],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q025",
      "question": "该研究对“Depth correlation with histology”报告了什么？样本、方法、量值与限制分别是什么？",
      "question_role": "source_scoped_reading_projection_not_expert_gold",
      "experiment_id": "A161-R20261012-E25",
      "answer_components": [
        {
          "result_id": "A161-R20261012-O25",
          "text": "Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.",
          "original_result": {
            "result_id": "A161-R20261012-O25",
            "experiment_id": "A161-R20261012-E25",
            "sample_context_ids": [
              "A161-R20261012-S06",
              "A161-R20261012-S07"
            ],
            "metric": "Depth correlation with histology",
            "result": "Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.",
            "values": {
              "case_ids": [
                8,
                9,
                11,
                13
              ],
              "x": "3Ddepthµm",
              "y": "histologydepthµm",
              "slope": 0.8823,
              "intercept": 8.547,
              "R_squared": 0.9748,
              "value_type": "exact_printed_figure_annotation",
              "fresh_visual": true,
              "raw_points": null,
              "raw_points_status": "bar/scatter positions not digitized",
              "error_type": "not separately resolved forS6bars",
              "source_conflict": "A161-CF03"
            },
            "result_type": "author_reported_text_and_caption",
            "measurement_time": null,
            "measurement_time_status": "not_reported_unless_explicit_in_values",
            "artifact_ids": [
              "A161-R20261012-AR25"
            ],
            "source_refs": [
              {
                "source_id": "A161-R20261012-F01",
                "locator": "FigureS6a–c;Results matching",
                "verification": "publisher_text_inspected_20261012"
              },
              {
                "source_id": "A161-R20261012-F06",
                "locator": "FigureS6a–c",
                "verification": "freshvisualprintedregression"
              }
            ],
            "source_conflict_refs": [
              "A161-CF03"
            ]
          }
        }
      ],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-C25",
          "claim_type": "source_scoped_result_summary",
          "text": "Four case-level mean vessel depths correlate across3DandCD31histology. This plot directly supports depth only; no caliber regression is recovered.",
          "supporting_result_ids": [
            "A161-R20261012-O25"
          ],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "FigureS6a–c;Results matching",
              "verification": "publisher_text_inspected_20261012"
            },
            {
              "source_id": "A161-R20261012-F06",
              "locator": "FigureS6a–c",
              "verification": "freshvisualprintedregression"
            }
          ],
          "source_conflict_refs": [
            "A161-CF03"
          ]
        }
      ],
      "sample_context_ids": [
        "A161-R20261012-S06",
        "A161-R20261012-S07"
      ],
      "actual_protocol_ids": [
        "A161-P001",
        "A161-P002",
        "A161-P003"
      ],
      "method_scope_note": "仅列当前E明确used_in关联；样本级available_assay_branch不据此变成每个标本均执行的步骤。空列表不代表无方法，而表示该结果没有直接协议关联。",
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "FigureS6a–c;Results matching",
          "verification": "publisher_text_inspected_20261012"
        },
        {
          "source_id": "A161-R20261012-F06",
          "locator": "FigureS6a–c",
          "verification": "freshvisualprintedregression"
        }
      ],
      "source_conflicts": [
        {
          "issue_id": "A161-CF03",
          "type": "source_metric_scope",
          "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
        }
      ],
      "paper_limitations_ref": "/limitations",
      "expert_gold": false
    },
    {
      "question_id": "A161-R20261012-Q026",
      "question": "作者提出了什么解释、限制或前景，其证据身份是什么？",
      "question_role": "author_statement_projection_not_new_observation_not_expert_gold",
      "answer_components": [],
      "supporting_claims": [
        {
          "claim_id": "A161-R20261012-AX01",
          "claim_type": "author_future_prospect",
          "text": "Method may improve endoscopic interpretation/technology; larger representative series and diagnosticclassification validation remain future work.",
          "supporting_result_ids": [],
          "source_refs": [
            {
              "source_id": "A161-R20261012-F01",
              "locator": "Discussion",
              "verification": "publisher_text_inspected_20261012"
            }
          ]
        }
      ],
      "sample_context_ids": [],
      "actual_protocol_ids": [],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Discussion",
          "verification": "publisher_text_inspected_20261012"
        }
      ],
      "expert_gold": false
    }
  ],
  "sample_context_registry": [
    {
      "sample_id": "A161-R20261012-S01",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human esophageal noncancerous tissue adjacent to resected neoplasms; FFPE block",
      "signals": "wholemount directly conjugated CD34-AF647 vessels andSYTO16 nuclei; comparator sections CD31, D2-40/H&E are distinct",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figures2a,3a; Methods",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S02",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human esophageal squamous cell carcinoma FFPE contexts; published cases1–3",
      "signals": "CD34-AF647 vessels;SYTO16 nuclei; histology/CD31 comparison separately",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1; Figures3a,4a;S2/S4",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S03",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human noncancerous upper/lower stomach FFPE contexts",
      "signals": "CD34-AF647 andSYTO16",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figure2b–c",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S04",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human gastric neoplasm FFPE contexts; cases4–7, adenoma/adenocarcinoma specified perTable1",
      "signals": "CD34-AF647 andSYTO16",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figure4;S5",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S05",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human nonadenoma colon FFPE context",
      "signals": "CD34-AF647 andSYTO16;CD31 sections separate",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Figures2d,3b;S3",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S06",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human colorectal adenoma/adenocarcinoma FFPE contexts;cases8,9,10,12,14",
      "signals": "CD34-AF647 andSYTO16",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;Figures3b,4,5;Table3;S6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    },
    {
      "sample_id": "A161-R20261012-S07",
      "sample_identity_level": "context_class_not_individual",
      "sample": "Human sessile serrated lesion FFPE contexts;cases11,13, failed endoscopic one-to-one matching but present indepth comparison",
      "signals": "CD34-AF647 wholemount;CD31 histology comparison",
      "reported_n": null,
      "n_status": "only_panel_specific_counts_in_results",
      "measurement_elapsed_time": null,
      "measurement_elapsed_time_status": "not_reported",
      "protocol_uses": [
        {
          "protocol_id": "A161-P001",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P002",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        },
        {
          "protocol_id": "A161-P003",
          "scope": "declared_branch_only",
          "binding_role": "available_assay_branch_for_this_context;not_all_steps_executed_on_every_specimen"
        }
      ],
      "source_refs": [
        {
          "source_id": "A161-R20261012-F01",
          "locator": "Table1;FigureS6",
          "verification": "publisher_text_inspected_20261012"
        }
      ]
    }
  ],
  "protocol_registry": [
    {
      "protocol_id": "A161-P001",
      "title": {
        "value": "食管、胃与结直肠FFPE组织块的整块标记、ECi透明化与共聚焦三维采集",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF p.4, Tissue-block processing"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "source_pointer": "/protocol_records/0",
      "source_sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "complete_record_location": "source_core/protocols"
    },
    {
      "protocol_id": "A161-P002",
      "title": {
        "value": "比较用组织切片的染色入口、全片扫描与测量",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.2,4, Tissue-block selection"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "source_pointer": "/protocol_records/1",
      "source_sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "complete_record_location": "source_core/protocols"
    },
    {
      "protocol_id": "A161-P003",
      "title": {
        "value": "内镜与三维图像匹配、血管量测及限定统计",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDF pp.4–5, One-to-one correspondence and matching criteria"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "source_record_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "source_pointer": "/protocol_records/2",
      "source_sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "complete_record_location": "source_core/protocols"
    }
  ],
  "source_registry": [
    {
      "source_id": "A161-R20261012-F01",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/fullTextXML",
      "local_extracts": [
        {
          "path": "sources/DEN-37-659-s001.tif",
          "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937"
        },
        {
          "path": "sources/DEN-37-659-s001.tif.png",
          "sha256": "4f9470733a480c948d8595657f18d3cedb02cefb3a0f13a0b155d7d2c27470b7"
        },
        {
          "path": "sources/DEN-37-659-s002.tif",
          "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da"
        },
        {
          "path": "sources/DEN-37-659-s002.tif.png",
          "sha256": "6835483e1dbc457e0417741409282ded7caf97cc9e98549862a5997bf345928f"
        },
        {
          "path": "sources/DEN-37-659-s005.docx",
          "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48"
        },
        {
          "path": "sources/DEN-37-659-s005.txt",
          "sha256": "39e59cbca96e1cbcf983634e542da88a222b4d934919ffb645f091b4aaa11b0b"
        },
        {
          "path": "sources/DEN-37-659-s006.tif",
          "sha256": "f6ce6511b2f8c841cd57a61219253b95c8b1ad71127969327bdab8242bd7aea1"
        },
        {
          "path": "sources/DEN-37-659-s007.tif",
          "sha256": "ce946971381764881239d939ecbbc78703f9782579ed0687fa8fff1f5a292eef"
        },
        {
          "path": "sources/DEN-37-659-s009.tif",
          "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91"
        },
        {
          "path": "sources/DEN-37-659-s009.tif.png",
          "sha256": "8767f8ce285b4cfab1be642e13b12743bd86c0fa4d4a910be8e3f0779c6768b2"
        },
        {
          "path": "sources/DEN-37-659-s011.docx",
          "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b"
        },
        {
          "path": "sources/DEN-37-659-s011.txt",
          "sha256": "1e64b7b8f0ceda3efa5266f2e2c0059aafd90bc8cad2516e374fdc31cda43a31"
        },
        {
          "path": "sources/DEN-37-659-s012.tif",
          "sha256": "cc3a8719577e910fcba74167a9f9f171dc3a6b14f8f81b8ad2ee0fe8af522d8c"
        },
        {
          "path": "sources/article_readable.txt",
          "sha256": "af1c70390cd8053a86afb1fa66bfbad07133a7f26ff2e5492bdd00def679cec0"
        },
        {
          "path": "sources/europepmc.xml",
          "sha256": "4776fdfe21f6ea816556832302c9cb258b846013765848d417242be40a239e59"
        },
        {
          "path": "sources/fetch_DEN-37-659-s005.docx.json",
          "sha256": "d00ff06f2eb8345ff864529341a948f3b64af7f6ae6a6683d4ae2832c372c1ad"
        },
        {
          "path": "sources/fetch_DEN-37-659-s011.docx.json",
          "sha256": "940eb641c01da07f39168262fe6d36280281d23240edfa037003a35d636d1d9c"
        },
        {
          "path": "sources/inherited_source_excerpts.json",
          "sha256": "9402335b2043938bf7258b3eaffab36d062cf5e3df986204e0a6c235daa1fb83"
        },
        {
          "path": "sources/retrieval.json",
          "sha256": "6fb3e85d2fe9b1697eec9aa3d0036bc74d19e3120a3bda0a5150b62fb72c4bd9"
        },
        {
          "path": "sources/supplement_retrieval.json",
          "sha256": "6f1e2481a1bee3295ebbf57158a4ecf8219e839561775adeff59fd3a2c826d4c"
        },
        {
          "path": "sources/supplements.zip",
          "sha256": "2ddced6570c58c8c96d17b9dce71fb8a156be09f732859734dac0160f7a1a4c6"
        }
      ],
      "inspection": "Full articleXML, AppendixS1,TableS1; FiguresS2/S3/S6 visually checked; other figure/movie coverage inherited."
    },
    {
      "source_id": "A161-R20261012-F02",
      "local_path": "sources/DEN-37-659-s005.docx",
      "sha256": "b1062537a197cc2cef3521ad0274794831771aece3b051032ce8eb91fb8e6f48",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "TableS1 full10vessel depth/caliber rows"
    },
    {
      "source_id": "A161-R20261012-F03",
      "local_path": "sources/DEN-37-659-s011.docx",
      "sha256": "9371a56f9d671e4a0db1441c9b07051ee861b0f842cf3edd990f5f29df1cae3b",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "AppendixS1fulltext"
    },
    {
      "source_id": "A161-R20261012-F04",
      "local_path": "sources/DEN-37-659-s001.tif",
      "sha256": "f2905f2f3b490007f5ea94da1f4f310b213f6bb74fb8e0ace9ba300503529937",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS2limitedvisual"
    },
    {
      "source_id": "A161-R20261012-F05",
      "local_path": "sources/DEN-37-659-s009.tif",
      "sha256": "22e3ca0f0e63af8d37e0b2b7d2fe2ec48f44f855de70e2ad33efc9d60cc1be91",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS3limitedvisual"
    },
    {
      "source_id": "A161-R20261012-F06",
      "local_path": "sources/DEN-37-659-s002.tif",
      "sha256": "87e834e275effec58155adff03f03bb940d9528b2ac6e1f67d833ebc79b3d2da",
      "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12162411/supplementaryFiles",
      "inspection": "FigureS6limitedvisual"
    }
  ],
  "paper_limitations": [
    "All5main figures,Tables1–3,6supplementary figures,TableS1 and4video-described anatomical contexts covered. Figure1workflow is context, not an independent experiment.",
    "Fresh fulltextXML, AppendixS1 andTableS1 originalDOCX read; S2/S3/S6 originalTIFFs inspected for axes, printed equation/significance and metric identity.",
    "Fourteen case labels and10/14matching outcome retained. Esophagus3/3,stomach2/4,colorectum5/7, including4failed cases; no inflated denominator from vessels/ROIs.",
    "All16published vessel depth/caliber pairs preserved exactly:6case9Table3,5case2and5case5TableS1.",
    "S6four-case regression y=0.8823x+8.547,R²=0.9748 is depth-only. SSLcases11/13 enter histology comparison despite failedendoscopy matching.",
    "CD34directAlexa647 andSYTO16 are separated fromsectionCD31/D2-40/H&E. Nuclear blue pseudocolor is notSYTO16emission identity.",
    "All3inherited source conflicts preserved. S3formula typo and boxplot representation remain distinct fromAppendixmean±SD test description.",
    "Projection thickness150/250µm, opticalzsteps0.8/4.2µm and imaging reach~350µm are not tissue dimensions.",
    "Matching is manualmultiobserver correspondence withlandmark selection; no blindeddiagnostic accuracy,sensitivity/specificity or clinical superiority validation is inferred.",
    "High-resolution30×small field and failurewith uniform/poorlandmarks retained; rawmeasurements and acquiredstacks not recomputed."
  ],
  "coverage_dimensions": {
    "historical_review": {
      "status": "inherited_not_reperformed",
      "path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A161/protocol_records.json",
      "sha256": "296ab12d85590af06991cf2fceba6802c5d375f43e6f7b085a4d8e1efdf2b5a4",
      "pointer": "/baseline",
      "exact_record": {
        "selected_core_files": {
          "evidence_json": {
            "path": "A161_candidate/A161_evidence.json",
            "sha256": "00a4d65bfe5ee26ddbc5530c979720787035b6613060ff58eca7955090cc3a0f"
          },
          "questions_json": {
            "path": "A161_candidate/A161_questions.json",
            "sha256": "16dbc4328ff4088057e133fb70f276464a3680c987c3c288dcbe266235e729e9"
          },
          "reading_md": {
            "path": "A161_candidate/A161_reading_zh.md",
            "sha256": "4066b8b125d49c1db9b545fe7ebd4f29b27f50d725bd88979d800bbde2e9d362"
          }
        },
        "existing_protocol_index": "none",
        "preserved_status": {
          "state": "held_source_reviewed_candidate_pending_specified_review",
          "not_reperformed": "No new scientific acceptance/delivery/count increment",
          "core_status_fields": {
            "record_id_status": "candidate_not_accepted_not_counted",
            "review_status": {
              "source_first_self_review": "completed for stated scope",
              "independent_review": "completed_repairs_verified_no_remaining_blocking_or_major_issue_in_nonoperational_scope",
              "structural_check": "passed",
              "bundled_skill_scripts_run": false,
              "applicable_rules": "R0–R5/R7–R8 applied to nonoperational evidence; R4 execution recovery excluded; R6 digitization not performed; RS selection support not requested",
              "self_review_repairs": [
                "按实际源图限定E01各器官与E02各视频来源",
                "移除通用ME-NBI条件继承；E09切片不继承ECi",
                "分开量化信号与HE/CD31/NBI参照信号",
                "仅30×明确硅油浸；JPG阅图副本未称无损转换"
              ],
              "structural_check_report": "review_assets/structure_check.json",
              "independent_review_report": "A161_independent_review.md",
              "independent_checks": "A161_independent_checks.json",
              "pro_acceptance": false,
              "formal_acceptance": false,
              "reviewed_scientific_snapshot_hashes": {
                "A161_reading_zh.md": "42328b8540f3640ec71fce6a3a6dd22188d60ff0130553b65b575d882e417367",
                "A161_evidence.json": "1d8bf2cde2b7dea81840d32a38ca17ffb85a82c0a7b408735733a5ebc3c4894d",
                "A161_questions.json": "bd6b647d51d0c9f9fa83c1cc8d0f9cc0ad0e6f2571c22ca0d0fa0b9821fade13"
              }
            }
          },
          "local_review_and_scope_records": [
            "A161_candidate/A161_independent_checks.json",
            "A161_candidate/A161_independent_review.md"
          ]
        },
        "originals_modified": false,
        "acceptance_or_count_changed": false,
        "runtime_integration": false,
        "upload_or_publication": false
      }
    },
    "new_main_text_relationships": "reviewed",
    "fresh_visual_review": {
      "status": "performed_limited",
      "assets": [
        "DEN-37-659-s001.tif",
        "DEN-37-659-s009.tif",
        "DEN-37-659-s002.tif"
      ],
      "scope": "FiguresS2/S3/S6 axes/significance/formula and S6exact printed regression; not numericalbar digitization"
    },
    "specified_Pro_gate": "unchanged_hold",
    "parent_review": "pending",
    "raw_reanalysis": "not_performed_not_required_for_literature_review"
  },
  "all_source_conflicts": [
    {
      "issue_id": "A161-CF01",
      "type": "source_locator_difference",
      "detail": "AppendixS1的ECi句引用Table1；正式主文流程表实际为Table2。内容按各来源位置保留。"
    },
    {
      "issue_id": "A161-CF02",
      "type": "source_formula_typography",
      "detail": "S3a公式第二段4的上下标排版异常，图内明确D40–80；采用Appendix40µm间隔的连续距离和/最短距离描述，保留印刷差异。"
    },
    {
      "issue_id": "A161-CF03",
      "type": "source_metric_scope",
      "detail": "正文提深度/管径相关；S6可见数据只支持深度。保留E09范围；不新建管径回归。"
    }
  ]
}
```
