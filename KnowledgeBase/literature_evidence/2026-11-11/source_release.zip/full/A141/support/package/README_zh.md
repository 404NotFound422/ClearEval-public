# A141 固定植物胚珠三维形态与拓扑证据 最终验收版

论文：Topological analysis of 3D digital ovules identifies cellular patterns associated with ovule shape diversity。DOI：10.1242/dev.202590。

本轮完成全文科学内容、6张主图、4张主表，以及正式9页补充PDF中4张补图和7张补表的实读与派生抽取。R1及R2修订快照保持冻结；独立R2、R3、R4和8组26条修订差异回核均通过。验收详见final_acceptance.json。原库保持不动，也未公开发布。

## 主要结论和适用范围

本研究使用固定、ClearSee透明及双染的C. hirsuta Oxford胚珠构建细胞分辨率三维图谱，与A. thaliana Col-0既有图谱比较。成熟3-VI C. hirsuta的平均总体积约比A. thaliana大34%，细胞数约多14%。拓扑、细胞体积变异和层特异的形态特征与胚珠形状相关。研究不包含透明法性能对照、荧光保留百分比或清除前后尺寸保真度评价，因此这些形态结果不能作为ClearSee性能指标。

真实荧光路径是SR2200细胞壁染色和TO-PRO-3细胞核染色。组织标签、细胞体积/增长热图中的多色均为分析伪彩，不能按颜色数计作成像通道。pWUS及ATML1是引用背景，不能作为本篇C.hirsuta新增报告通道。

固定胚珠各发育阶段属于不同样本队列。相邻阶段的百分比变化来自队列均值，不是同一胚珠实时增长。约2小时/z-stack表示从成像到分割标注数字胚珠的工作流程，不含完整制样时长。ClearSee初次处理的原文为至少overnight至2–3天；不把overnight擅自换算成固定小时。

## 必须保留的来源冲突

- 正文说144个C.hirsuta数字胚珠，Table1逐阶段n相加为145，官方BioStudies也明确145；三项来源并存，仍不抹去正文144。植株重复数未报告。
- Fig1C成熟七细胞八核胚囊的原图标3-V，图注写3-VI。
- 正文及主图的组织差异起点/阴性概述，与正式补表S2的若干P值不一致；尤其内珠被3-III P=.0011及珠柄多个阶段P<.05。
- 补表S3的两项A.thaliana P=.0003，与正文“所有至多.0001”不一致。
- 正文合点体积相对增长持续高于细胞数增长的说法存在Fig4印刷数值反例。
- 物镜型号的XML、出版方Methods与BioStudies均有anterior-posteriorO异常；63×、NA1.30、甘油浸数值可读，但未擅自修复型号。

## 数据使用

record.json与record_final.json为已验收版本；record_R1.json及record_R2.json为历史冻结快照。最终包以final_manifest.json为文件校验依据；历史R1/R2完整包与原冻结manifest保留在工作目录，不混作最终文件manifest。main_table_values.csv和supplement_table_values.csv保存主表/正式补表明确数值；stagewise_heatmaps.csv保存Fig4及Fig6C的印刷百分数。primordium_divisions.csv将原基数、有丝分裂图像数和细胞层计数分开。所有派生记录附来源编号与具体位置，source_locator_index.json可定位正文XPath及其哈希。

3457为ii1′层被检查细胞数；另检查ii1细胞但总数未报。62为该分析中胚珠数，70为分裂图像数，不能互作独立植株重复。早期原基分裂分析另含44个C.hirsuta原基与62个A.thaliana原基，共106个原基、166个分裂图像。

没有精确数字的点图/曲线不人工估出数值；未运行原始图谱或拓扑代码。R4实际只读官方BioStudies元数据及作者当前仓库三份统计脚本，其证据层级与论文主文分开。正式补充PDF与历史记录哈希一致，历史accepted manuscript转录不替代正式版本。已成功缓存的全文未重复下载，缺失媒体才从官方来源获取；首次URL拼接404与后续正确URL200均留有记录。

交付只应打包本目录派生JSON/CSV和中文说明，排除private_sources、private_review_sources、源图片/PDF、全文文本、渲染图、作者源代码原件与任何原始视频。

## 独立复核后修订

样本欠分割限制的阶段已改为2-II至2-V，最多5个未修正欠分割细胞。1-I至2-I及3-I至3-IV的所选胚珠无明显分割错误；3-V/3-VI只对孢子体组织作此保证。

Fig4两个物种各三个早期胚囊过渡所印刷的0仍原样保存。它们早于或跨越3-I胚囊建立，前一阶段可比基线及零值处理未说明，故单列为printed_zero_baseline_not_established，不能当作由正常相邻阶段公式验证的零增长。

官方BioStudies说明部分图像栈包含附着同一雌蕊片段的多个胚珠。图像栈、样本ID、单胚珠、花与独立植株不是同一统计单位，分析应留意嵌套依赖；独立植株数仍未知。BioStudies还明确PlantSeg边界预测之后使用GASP，但未补齐版本/模型及全部参数。

当前作者NADO代码的ordinary bootstrap设置为：整体胚珠及跨物种组织10,000次，早期原基层100,000次，同物种合点与外珠被对照10,000次。三份已读脚本未见显式set.seed，不能推断整个环境没有种子。当前代码快照未执行，也不能证明发表时实际运行配置；GitHub提交信息接口限流后已停止该路径，文件哈希用于标识快照。

## 验收与历史材料

最终差异回核确认26条修订全部应用，主表、补表与热图的明确数值未改。review_R2_R4_findings.json、review_revision_requests.json、review_notes_zh.md及revision_response_R2.json记录首轮提出问题和作者返修的历史状态；最终状态以final_acceptance.json和当前record.json为准。

最终归档只收派生JSON、CSV和说明，不含两处私有源缓存、作者原始代码、全文、原图、PDF或视频。
