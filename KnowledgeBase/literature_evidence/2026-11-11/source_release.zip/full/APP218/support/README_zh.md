# APP218｜猪耳蜗 BoneClear 应用证据

论文：Ontogeny of cellular organization and LGR5 expression in porcine cochlea revealed using tissue clearing and 3D imaging（iScience，2022）。DOI：10.1016/j.isci.2022.104695；PMCID：PMC9294204。

## 这个包能回答什么
- 既有猪耳蜗样本在 E38、E53、E80、P0、P60、P120 的发育阶段与分析样本量。
- 完整耳蜗的固定后处理、BoneClear、免疫标记、成像条件及分阶段时间。
- MYO7a、anti-GFP、SOX2、TO-PRO3 的证据身份，以及仅列资源表的 PGP9.5。
- 细胞位置、毛细胞长度/数量和 LGR5 相关 reporter 信号的结果、对照、限制、来源定位与原文冲突。

范围止于既有样本证据；不展开动物模型构建、动物手术或试剂制造采购。旧库未覆盖改写。

## 最容易误读的四点
1. LGR5 读出来自现成 LGR5-H2B-GFP reporter，经 anti-GFP 检测；不是直接 anti-LGR5 免疫染色，也不证明内源 GFP 荧光被保留。核定位属于 H2B-GFP，不代表 LGR5 受体定位于核内。
2. 文中的 2、5、50 μm 是数字切片/显示厚度。没有单独的实体薄片透明流程，也不能据此填入光片采集 z 步长。
3. LGR5 正文/图注频率为 40/100/700/2000/10000/20000 Hz，但 Fig6B/7B 实际图标签为 40/100/500/1000/10000/20000 Hz。保留两套证据，不强制统一。毛细胞长度另有 100/500/2000/5000/10000/20000 Hz 系列，不应混入 LGR5 系列。
4. 耳蜗数不等于独立动物数；[Mendeley V1公开说明](https://data.mendeley.com/datasets/vdw3757cxv/1)明确写 P60 四个耳蜗来自两只猪，V3/Excel内容未核实。膜长追踪和 P0 毛细胞计数的结果与方法样本量不一致。补图 S1B 每龄仅一个耳蜗，每部位三次测量，不能写成三只动物。

## 时间的使用边界
- 标记后脱水、DCM、DBE 三段相加为 56–92 h，只是局部处理时间。
- 从一抗开始至二抗后末次清洗结束：浸泡分支 13–15 天，泵辅助分支 7 天；二者是替代分支。
- 固定后全部有数值的处理阶段合计：浸泡 445–649 h，泵辅助 301–457 h，均另加四个未定义时长的 overnight。它们是可核算的部分和，不是作者报告的完整流程实测耗时；不含取材、转移等待、成像和分析。
- 脱钙 2–7 天依年龄而变；文章没有给各年龄的精确日数。胎儿样本“可跳过”一句紧接去除周边骨结构，不据此断定无需脱钙。

## 结果强度
整耳蜗透明及免疫信号可见有图像支持。细胞身份主要按几何位置和 MYO7a 行列推断，猪支持细胞特异标记未获验证；OPC 未单列，基底 DC12 可混入毛细胞信号。Table S1 位置效应须按年龄/细胞组分别读取；P120 的 GER/ISC 不显著。Table S2 的 IPC 年龄效应不显著，其余组有年龄效应，但不等于每个位置均单调下降。持续强阳性的 HS 也不等于统计上恒定。

没有补填荧光保留率、透明度透射率、收缩率、成像耗时、存储寿命、TO-PRO3 浓度/时间或原始数据中未核实的数值。表达分布不构成此研究已经证明再生能力。

## 文件说明
- record.json：最终结构化证据；record_R1/R2/R3.json：冻结及修订快照。R1 的全阶段部分和曾多计 100 h，已在 R2 修正；引用数值请使用 record.json 和 timing.csv。
- protocol_steps.csv、timing.csv：源文条件与时间；计算值明确标为派生。
- samples.csv、analysis_cohorts.csv：动物来源组与具体分析耳蜗组分开。
- markers.csv、secondary_antibodies.csv、stage_marker_readout_crosswalk.csv：标记身份、兼容性等级、各年龄实际使用证据及不能推断之处。
- results.csv、controls.csv、frequency_series.csv：结果、对照、不同测量系列。
- supp_tableS1_derived.csv、supp_tableS2_derived.csv：补表的统计结果整理，不是原始单细胞数据重分析。
- source_conflicts.csv、unknowns.csv：不能靠猜测填平的差异与缺口。
- reading_log.csv、query_log.csv、source_asset_manifest.csv：实际阅读范围、补缺查询及源文件指纹。
- validation.json、review_rounds.json：结构/计算核查及独立审阅状态。

源文可从公开 Europe PMC 获取：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC9294204/fullTextXML 。补充图表公开来源：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC9294204/supplementaryFiles 。本交付包只含派生数据及说明，不包含原文、原图、PDF、视频或原始数据表。
