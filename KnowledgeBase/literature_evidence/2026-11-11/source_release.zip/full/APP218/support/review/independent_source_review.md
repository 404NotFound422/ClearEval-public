# APP218 独立源审阅（2026-10-19 UTC）

审核者：review_cochlea_application。此记录为独立源核读，尚不代表对提取稿的最终通过。

## 实际读取范围
- 主文XML：PMC9294204.xml；完整结果、讨论限制、STAR Methods、资源表和全部图注。
- Europe PMC开放包由提取者获取后共享：gr1–gr7.jpg逐图目视；mmc1.pdf第2–9页逐页渲染目视，覆盖S1–S6和表S1/S2。
- mmc2–5.mp4用ffprobe检查长度6.043478/15.133333/7.466667/21.973067秒；每秒采样1帧联系表目视。属于全时长稀疏抽帧，不宣称连续播放或逐帧检查。前三视频支持P0顶/中/底三维组织，S4演示跨z-plane点选测长，不新增统计量。

## 独立发现并已交作者修订
1. LGR5频率：结果文字及Fig6/7图注、S4为40/100/700/2000/10000/20000 Hz；实际Fig6B横轴、Fig7B表及Mendeley V1描述为40/100/500/1000/10000/20000 Hz。不得静默统一，应双列并标未解决。
2. 毛细胞长度是另一系列：Fig4B/S2D实际图例100/500/2000/5000/10000/20000 Hz。故37.5±4.0 μm at 500 Hz不与LGR5频率集直接比较。图中P0/P60/P120而caption Fig4 N3 P60/P120，S2 N4 P60/P120；不能自行分配每龄样本数。
3. 基膜追踪结果N=4/15/4/11（E80/P0/P60/P120），方法N=4/15/6/13；P0毛细胞计数结果N12、方法N15。保留分析层差异，不填补排除原因。
4. S1B为每龄一耳蜗，顶/中/底各3测量。P=.0003较小隧道；高度部位效应P=.0264。不能写3只动物。
5. Mendeley V1描述P60为4耳蜗来自2猪。论文图注常写N4 animals，方法/表S2明确4 cochleae per age，独立动物数未解决。
6. TableS1：E80位置效应仅GER/ISC、IBC、IPHC显著；P0/P60为GER/ISC、DC12、HS；P120仅DC12、HS（GER/ISC P=.1392）。不能将表注older ISC significant概括成每龄均显著。
7. TableS2：IPC年龄效应P=.7373不显著；其余六类年龄效应显著。频率主效应仅GER/ISC及HSC显著；交互仅GER/ISC显著。总体下降不意味着全部细胞显著下降。
8. LGR5 readout为既有H2B-GFP reporter的anti-GFP核信号，不是直接抗LGR5蛋白，也不证明再生功能；位置赋型无已验证猪细胞特异标记。OPC未单列且基底DC12可混HC。
9. E53 SOX2明确S1A；ToPro3用于P0图5、E80 S1C和P0 S1D。PGP9.5仅资源表，未发现可对应结果图的应用证据。
10. Key resources Prism9.2 vs stats9.5；Mendeley引用v3 vs Methods v1。不得静默统一。

## 真实补缺查询（非模拟）
- web.open https://pmc.ncbi.nlm.nih.gov/articles/PMC9294204/ 返回Checking browser/reCAPTCHA；停止该路，不完成挑战、不重复。
- web.search 精确DOI+supplemental和vdw3757cxv LGR5：查到Mendeley官方V1条目。https://data.mendeley.com/datasets/vdw3757cxv/1 描述频率500/1000、P60四耳蜗来自两猪，提供Data.xlsx 221KB。此为数据集描述，不等同已核Excel内容。
- web.open https://data.mendeley.com/datasets/vdw3757cxv/3 返回工具Internal Error。未以此证明V3内容。
- 旧出版社403路径未请求。

## 边界
仅已制备耳蜗组织的透明化、标记、成像、定量及结果。未增加reporter构建、动物操作、制备或采购。派生包不应携带上述大体积原文/图/视频。
