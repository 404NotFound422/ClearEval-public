# 胰腺清透综述：已验收的纯派生证据包

论文：Pancreas Optical Clearing and 3-D Microscopy in Health and Diabetes（2021）。DOI：10.3389/fendo.2021.644826；PMID：33981285。

## 验收结论

独立复核通过。请以 final_acceptance.json 为最终签收状态；其签收严格绑定 record_R2.json 的 SHA-256。冻结作者文件仍保留当时“等待回核”的状态文字，没有改写；本签收侧文件说明这些历史状态已被后续验收取代。

已完整核验本综述科学正文、7幅主图、2张表、补充图注DOCX两页及5个视频的全部连续帧接触表。表格字段审查4907项；两项绑定返修均关闭。修订回核120项、225处差异以及17张CSV的6068字段全部通过。原有科学值、未知值和14项源冲突均保持不变。

## 使用顺序

1. record_R2.json：结构化主记录；各 *_R2.csv 为对应扁平表。JSON null及CSV空白代表未报告/未知，不是零。
2. README_中文_R2.md：作者冻结说明，包含科学边界及连接规则；其待审状态是历史快照。
3. final_acceptance.json、independent_review_report.json：最终签收、阅读覆盖、逐项回核和实际补缺查询。
4. field_audit_final.csv、csv_consistency_final.json、time_fluorescence_audit.csv：字段、表间一致性、时间与荧光审查。
5. revision_diff_R2.json、R2_frozen_manifest.json及校验文件：修订和完整性追踪。

## 必须保留的边界

- 所有科学条目都是secondary。本包只完成这一篇综述及其补充；109篇参考文献仅核对身份，原始研究全文实读数为0。
- Table2的抗体成败/弱信号仅适用于文中人胰腺PACT测试情境。24行拆成26个试剂变体，不增计实验，也不能计算实验成功率；样本数、重复数和定量强度未知。
- Fig6 A/B为正常小叶，C/D为距PDAC病灶2 cm处的萎缩小叶；跨条件同供者和配对关系未知。
- 成像条件必须按figure_panel_ids和field_applicability连接，不能由sample_id自动继承。I04仅绑定Fig3D/Video2；I07仅绑定Fig7B/Video5。未报告的面板参数保持未知。
- 补充Video1切片数、Video3光学分类及总深度等源冲突未解决，保留原值和冲突记录。视频帧数/播放时间不是采集层数或实验耗时。
- 未确定逐例清透总耗时、定量内源荧光保留率、半衰期或方法排名。培养时长、动物年龄、解剖距离和成像栈深度各有自己的量纲角色。

本包仅含派生数据和审查文件。原文XML/HTML/PDF、原图、补充DOCX、影片及接触表均未收入。来源清单中的私有相对路径仅用于溯源，不表示这些文件已附带。

官方全文：https://www.frontiersin.org/journals/endocrinology/articles/10.3389/fendo.2021.644826/full
