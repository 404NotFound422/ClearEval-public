# A144 完整无损阅读投影

本阅读稿逐字段呈现当前完整核心、当前P与问题；不新增科学摘要、不代表expert gold、Pro或出版批准。原短阅读稿和审阅报告保留为独立伴随文件。

## 当前完整科学核心

```json

{
  "schema_version": "reconstructed-research-evidence-1.0",
  "paper_id": "A144",
  "version": "2026-10-12-source-reconstruction.1",
  "title": "Age-related epithelial defects limit thymic function and regeneration",
  "doi": "10.1038/s41590-024-01915-9",
  "status": "scientific_reconstruction_complete_for_published_accessible_evidence_pending_final_delta",
  "not_historical_hash_restoration": true,
  "frozen_originals_modified": false,
  "publication_approved": false,
  "declared_scope": "13历史主题的新来源限定证据，成像/流式与组学/模型支持分开；Fig4j和Fig5g–k数值/部分结果仍待恢复。",
  "source_files": [
    {
      "source_id": "A144-R20261012-F01",
      "path": "sources/primary_extract.json",
      "sha256": "7d3dc7d6f660eebc5813a6daead6bb45d67a15709b1447c12cf44bbc088e5ea3",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed_primary_text_read;partial_extract;not_original_PDF_or_fresh_visual_review"
    },
    {
      "source_id": "A144-R20261012-F02",
      "path": "sources/results_extract.json",
      "sha256": "925bf6f4d0912d5b18dfba151eb5fac4e9b90999e536ae839cb228cf209dec75",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed_primary_text_read;partial_extract;not_original_PDF_or_fresh_visual_review"
    },
    {
      "source_id": "A144-R20261012-F03",
      "path": "sources/thymus_emt.json",
      "sha256": "6df294e0d4fddfa38f416153b4990ab0dc23bc4eb84f74b6ab0a6854c58b0623",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed_primary_text_read;partial_extract;not_original_PDF_or_fresh_visual_review"
    },
    {
      "source_id": "A144-R20261012-F04",
      "path": "sources/thymus_foxn1.json",
      "sha256": "91f5f2fe42df2bd45ceeab798a6d7cfe0a0a390178407780cbe1040b484ffff0",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed_primary_text_read;partial_extract;not_original_PDF_or_fresh_visual_review"
    },
    {
      "source_id": "A144-R20261012-F05",
      "path": "sources/thymus_signaling.json",
      "sha256": "f829b1d88d331343182e6bb1263dd1c16015c181a4f19d0ae5a02c64cb5988e1",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed_primary_text_read;partial_extract;not_original_PDF_or_fresh_visual_review"
    },
    {
      "source_id": "A144-R20261012-HF01",
      "path": "sources/embedded_author_source_blocks.json",
      "sha256": "58eda1ed5a5b5f0e0e5581ce2d52fd2cff0cf9e713c6f9d25a4684cc4cbf3c62",
      "inspection": "all source_raw excerpts preserved with original precise pointers; inherited primary-source verification only"
    },
    {
      "source_id": "A144-R20261012-X07",
      "path": "sources/author_correction_20260313.json",
      "sha256": "bbfe20d92d992f2322fb720a46784a7df239e8d618a7fd2de9799f41d7194e80",
      "url": "https://www.nature.com/articles/s41590-026-02489-4",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X08",
      "path": "sources/detail_81241.json",
      "sha256": "1aaa79bad53a347256164a23fdaf401e0b4980669f9cda0808695533d7181341",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X09",
      "path": "sources/detail_AKT.json",
      "sha256": "a6121ccbd314895d700f47d9589a01ebd85ec30bee7a8de645a0a6c889b51bbd",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X10",
      "path": "sources/fig4j_fig6e_results.json",
      "sha256": "e2b6e44cdb13ab2c34ad337d0a5b01fda68f6c7ce449ee2651b12a389db5b3b0",
      "url": "https://www.nature.com/articles/s41590-024-01915-9",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X11",
      "path": "sources/focused_extract.json",
      "sha256": "85efde585ee85971d491f0f0665fabbc73b0977034ae64bc6c3378042fae6744",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X12",
      "path": "sources/thymus_cellstates.json",
      "sha256": "85efde585ee85971d491f0f0665fabbc73b0977034ae64bc6c3378042fae6744",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X13",
      "path": "sources/thymus_regeneration.json",
      "sha256": "85efde585ee85971d491f0f0665fabbc73b0977034ae64bc6c3378042fae6744",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-X14",
      "path": "sources/thymus_structure.json",
      "sha256": "85efde585ee85971d491f0f0665fabbc73b0977034ae64bc6c3378042fae6744",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "indexed primary text; not image read"
    },
    {
      "source_id": "A144-R20261012-FIG5GK-TEXT",
      "path": "sources/fig5gk_results_targeted_read.json",
      "sha256": "c17b8479ebf042d39cf0651b8959ff4ddc65029350e475ffbf0e7ddbdca6ed78",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11362016/",
      "inspection": "fresh source-specific primary Results text"
    },
    {
      "source_id": "A144-FIG5-ORIGINAL-IMAGE",
      "path": "sources/Fig5_original.png",
      "sha256": "fef60f6aaec2de6ce8bbdd6f3845227232abd748c8a2274e9bb50aea3bc5aa27",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig5_HTML.png",
      "inspection": "actual image viewed 2026-10-12; root public asset retrieval; authors plotted labels, not digitization"
    },
    {
      "source_id": "A144-FRESH-A144_ED7_corrected",
      "path": "sources/A144_ED7_corrected.jpg",
      "sha256": "3d4f60d081e147adc61c8e5a2507a77a4c84bded75c3826ef7172015fd619c2d",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig14_ESM.jpg",
      "inspection": "fresh original artwork independently viewed"
    },
    {
      "source_id": "A144-FRESH-A144_Fig6",
      "path": "sources/A144_Fig6.png",
      "sha256": "ad8adf091f37e966483ad04df5deb6d20753fb5781011830c2f330c1a254afb2",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig6_HTML.png",
      "inspection": "fresh original artwork independently viewed"
    },
    {
      "source_id": "A144-FRESH-A144_Fig7",
      "path": "sources/A144_Fig7.png",
      "sha256": "f5d137f19eed62685f4a95687b664011217e75a9c22cc04d62ea14f124684b45",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig7_HTML.png",
      "inspection": "fresh original artwork independently viewed"
    },
    {
      "source_id": "A144-FRESH-A144_source_full",
      "path": "sources/A144_source_full.html",
      "sha256": "44568916d0af3f93a2a605445239dc71e4b3b6b232488b09f95bca9eaf4450eb",
      "url": "https://www.nature.com/articles/s41590-024-01915-9",
      "inspection": "fresh complete official text/captions read"
    },
    {
      "source_id": "A144-FRESH-A144_correction_source_full",
      "path": "sources/A144_correction_source_full.html",
      "sha256": "68bc4a1002e29d4d9b677e9bed98d45ded1c2745e2bde9657f6d517281074090",
      "url": "https://www.nature.com/articles/s41590-026-02489-4",
      "inspection": "fresh complete official text/captions read"
    },
    {
      "source_id": "A144-REMAINING-ARTWORK-REPORT",
      "path": "sources/remaining_artwork_read_report.json",
      "sha256": "70a045f449590ab362134fc835d2839d2b3e1130d09aeb7f75c2ac5335767d89",
      "inspection": "independent actual remaining main/extended artwork read; exact scoped findings/n/annotations"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_ED7_original",
      "path": "sources/A144_ED7_original.pdf",
      "sha256": "316e96fcc087ae22c48a8d9ceea2e73155c672e6cee569b96a2cd132d04e3e16",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-026-02489-4/MediaObjects/41590_2026_2489_MOESM1_ESM.pdf",
      "inspection": "ED7 original PDF page2 rendered and viewed"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_Fig5",
      "path": "sources/A144_Fig5.png",
      "sha256": "fef60f6aaec2de6ce8bbdd6f3845227232abd748c8a2274e9bb50aea3bc5aa27",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig5_HTML.png",
      "inspection": "view_image actual artwork read"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig1_HTML",
      "path": "sources/A144_41590_2024_1915_Fig1_HTML.png",
      "sha256": "a6bb7f5122528f9267d3b84a62a79713da1c5f7d712d2091735806e8b6bd74c0",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig1_HTML.png",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig2_HTML",
      "path": "sources/A144_41590_2024_1915_Fig2_HTML.png",
      "sha256": "dde4d2522f3c4aa814df8137f708ec7f2526700815513aa2e8bd875d6857648a",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig2_HTML.png",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig3_HTML",
      "path": "sources/A144_41590_2024_1915_Fig3_HTML.png",
      "sha256": "1f608a4b0cbd552166196a590caadc7150ee5f1e5bf97ebddd9ffbb2f256512c",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig3_HTML.png",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig4_HTML",
      "path": "sources/A144_41590_2024_1915_Fig4_HTML.png",
      "sha256": "5e2ef3d543e9c22a32878b3b2bc9ecb5c17656d00fad68495e3aa0aff6605a62",
      "url": "https://media.springernature.com/full/springer-static/image/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig4_HTML.png",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig8_ESM",
      "path": "sources/A144_41590_2024_1915_Fig8_ESM.jpg",
      "sha256": "be7d501a0f292de79d30dbc6be992277f42e17acb3519d43ce4c1e2012333c16",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig8_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig9_ESM",
      "path": "sources/A144_41590_2024_1915_Fig9_ESM.jpg",
      "sha256": "3ca4e15b5b13bf6822b5d97ab9ad9147f1e24d04cedd6bf18f2b67b6da342610",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig9_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig10_ESM",
      "path": "sources/A144_41590_2024_1915_Fig10_ESM.jpg",
      "sha256": "59237c43896fd9bfd9d4886788475104fd6bb8837de988d574a2a6b6bb12a3f5",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig10_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig11_ESM",
      "path": "sources/A144_41590_2024_1915_Fig11_ESM.jpg",
      "sha256": "2e6f72fc482a2048faeeb2dadb7cecd705146da3290d022c318e0168fd60504f",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig11_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig12_ESM",
      "path": "sources/A144_41590_2024_1915_Fig12_ESM.jpg",
      "sha256": "09147c4958cec7ad42a537d06ed9c71a234236a9949053baa5f86de7b80860c2",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig12_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig13_ESM",
      "path": "sources/A144_41590_2024_1915_Fig13_ESM.jpg",
      "sha256": "04be85759a34a8f2163033b3e765ace6cb98186ea98821b4b23d3a12bafb5394",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig13_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig15_ESM",
      "path": "sources/A144_41590_2024_1915_Fig15_ESM.jpg",
      "sha256": "fc352e1d94cd492d249baf1cdd3131de823c6f1c703826bb0c8ac4347d54f12d",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig15_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig16_ESM",
      "path": "sources/A144_41590_2024_1915_Fig16_ESM.jpg",
      "sha256": "784dd9277bf9f6b986547a9fd314db49b2aecd90ba6c627e885e41e7ebeb9220",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig16_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-ADDITIONAL-A144_41590_2024_1915_Fig17_ESM",
      "path": "sources/A144_41590_2024_1915_Fig17_ESM.jpg",
      "sha256": "5137a9a8d45314872a9ba16e48b4653b3eefd1f80c963d90dea7060a67d72a3a",
      "url": "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_Fig17_ESM.jpg",
      "inspection": "Independent view_image actual artwork review; complete main/ED pass"
    },
    {
      "source_id": "A144-SUPP-5",
      "path": "sources/A144_41590_2024_1915_MOESM5_ESM.mp4",
      "sha256": "fb6a3b0ddaa358053b19003db0e3caa000cf65dcf82af3ea86be367ca69953e2",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM5_ESM.mp4",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-6",
      "path": "sources/A144_41590_2024_1915_MOESM6_ESM.mp4",
      "sha256": "a539b71de08d5d7e0ce4fc62b6a8d538d272504b3105b943e69c8ccb2500295c",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM6_ESM.mp4",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-1",
      "path": "sources/A144_41590_2024_1915_MOESM1_ESM.pdf",
      "sha256": "0646ac1b2f9dab5e621b74ecfb53a90a6813e8220587e165cb0a604260978da3",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM1_ESM.pdf",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-8",
      "path": "sources/A144_41590_2024_1915_MOESM8_ESM.mp4",
      "sha256": "dfc43cadf531080a0941c440b0b5fbc64087b1244a64e947e3fb9033c0e2cc13",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM8_ESM.mp4",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-4",
      "path": "sources/A144_41590_2024_1915_MOESM4_ESM.mp4",
      "sha256": "e0abb82ed32c71cea553849de156cc744a0b92961ce73b33f815fc0d00049ac5",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM4_ESM.mp4",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-2",
      "path": "sources/A144_41590_2024_1915_MOESM2_ESM.pdf",
      "sha256": "af1c4b3831ad58e48d9574a45d9f794b1cb114e6b13da9b32f3712aee25548aa",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM2_ESM.pdf",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-9",
      "path": "sources/A144_41590_2024_1915_MOESM9_ESM.xlsx",
      "sha256": "42d7e01edd4c7aefb57b80099b0f7fccb56c6327769ffd48cffe2335939f10bb",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM9_ESM.xlsx",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-7",
      "path": "sources/A144_41590_2024_1915_MOESM7_ESM.mov",
      "sha256": "fb6af9e3232ad187e9c71a0d0e82029939d85b1a55c8d31c284184fb171567e0",
      "url": "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41590-024-01915-9/MediaObjects/41590_2024_1915_MOESM7_ESM.mov",
      "inspection": "official source; scope from supplement read report: staticPDF fully read, workbook directory/targetrows only, videos20sampledframes only"
    },
    {
      "source_id": "A144-SUPP-READ",
      "path": "sources/A144_supplement_read_report.json",
      "sha256": "a6d6f2e1faeda8d5f6c98c766bf61b2f17285d454c60210294e0c6ff447a5aec",
      "inspection": "independent exact source read; not full raw-sequencing reanalysis"
    },
    {
      "source_id": "A144-WORKBOOK-HEADERS",
      "path": "sources/A144_workbook_source_read.json",
      "sha256": "dfbc49889718bf16ce9f206e12ba8d2127026b3158b79025a1bad885bf1f796a",
      "inspection": "independent exact source read; not full raw-sequencing reanalysis"
    },
    {
      "source_id": "A144-WORKBOOK-TARGETROWS",
      "path": "sources/A144_workbook_targeted_results_read.json",
      "sha256": "6b8522b7c60ede1d8071b15b538c67edcef6b9c7b7da08efd52ccf71f491cb37",
      "inspection": "independent exact source read; not full raw-sequencing reanalysis"
    }
  ],
  "protocols": [
    {
      "protocol_id": "A144-P001",
      "record": {
        "record_id": "A144-P001",
        "record_type": "reported_clearing_workflow_with_unreported_antibody_incubations",
        "title": {
          "value": "小鼠胸腺整叶/厚片透明和免疫荧光",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec15"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "整理常规胸腺透明/标记、形态量化及流式直接步骤；转录组算法另列本轮未合并范围。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec15"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "论文既有报告鼠及年龄/损伤队列；整叶用于光片，固定后200µm片用于共聚焦",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec15"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "待固定胸腺组织",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec15"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "EasyIndex中全透明组织",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec15"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "PFA、PBS、acrylamide/azo-initiator、N2、SDS/sodiumsulfite、BSA/TritonX/normalserum、EasyIndex",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp15 XML#Sec15"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "value": "Table13免疫荧光材料，未给稀释；与流式Table12分开",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p7"
              }
            ],
            "check_status": "verified_against_primary_supplement"
          }
        ],
        "sections": [
          {
            "title": "固定与厚片分支",
            "steps": [
              {
                "step_id": "A144-P001-S01",
                "display_order": 1,
                "action": {
                  "value": "PBS/PFA灌流后取胸腺后固定，共聚焦分支制片。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "perfusion": {
                    "value": "PBS→4%PFA",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "postfix": {
                    "value": "4%PFA，4h，4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "confocal_sections": {
                    "value": "LeicaVT1000S，200µm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "whole_lobe": {
                    "value": "光片保留wholelobe",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "人FFPE不是此流程的适用样本；组织取得后操作不重新编谱系模型构建/损伤执行。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "水凝胶",
            "steps": [
              {
                "step_id": "A144-P001-S02",
                "display_order": 2,
                "action": {
                  "value": "浸单体液，氮气除氧后聚合。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "monomer": {
                    "value": "4%acrylamide+0.25%(w/v)azo-initiator inPBS；4°Covernight",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "deoxygenation": {
                    "value": "vacuumtube，nitrogenbubble15min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "polymerization": {
                    "value": "37°C，3h，gentlerotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "azo-initiator原文未写具体VA型号，不能按其他文章改成VA044。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "透明与去SDS",
            "steps": [
              {
                "step_id": "A144-P001-S03",
                "display_order": 3,
                "action": {
                  "value": "清除至半透明，再按所列顺序每轮一小时洗。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "clear": {
                    "value": "8%SDS+50mMsodiumsulfite inPBS；37°C，untilsemitransparent",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "wash1": {
                    "value": "1%SDS+0.5%TritonX/PBS，1×1h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "wash2": {
                    "value": "1%BSA+0.5%TritonX/PBS，2×1h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "wash3": {
                    "value": "4%normalserum+1%BSA+0.3%TritonX/PBS，2×1h",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "agitation": {
                    "value": "washrotation",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "清除精确时长及洗涤温度未报；不是全部5洗都继承37°C。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "免疫荧光",
            "steps": [
              {
                "step_id": "A144-P001-S04",
                "display_order": 4,
                "action": {
                  "value": "在blockingbuffer中配抗体并染色，随后PBS/Triton洗。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "primaries": {
                    "value": "panCK Z0622；K5 poly19055；K8/18 TROMA1；K14 EPR17350；AIRE5H12；DCLK1LS-C100746；UEA1B-1065。",
                    "source_refs": [
                      {
                        "source_id": "F03",
                        "locator": "41590_2024_1915_MOESM1_ESM.pdf p7"
                      }
                    ],
                    "check_status": "verified_against_primary_supplement"
                  },
                  "secondaries": {
                    "value": "AF647donkeyantiRabbit A31573；AF647goatantiRat A-21247；AF647streptavidinS21374。",
                    "source_refs": [
                      {
                        "source_id": "F03",
                        "locator": "41590_2024_1915_MOESM1_ESM.pdf p7"
                      }
                    ],
                    "check_status": "verified_against_primary_supplement"
                  },
                  "diluent": {
                    "value": "4%normalserum+1%BSA+0.3%TritonX/PBS",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "afterwash": {
                    "value": "PBS+0.3%TritonX",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "Table13只有身份/供应商/目录，无稀释列；正文“dilutions indicated below”未实际提供。染色时长/温度/重复/体积也未报；不把Table12流式稀释搬来。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "匹配",
            "steps": [
              {
                "step_id": "A144-P001-S05",
                "display_order": 5,
                "action": {
                  "value": "置EasyIndex至全透明后成像。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "medium": {
                    "value": "EasyIndex，RI1.46",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "condition": {
                    "value": "RT，untilfullytransparent",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec15"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "时长/体积/逐样本总处理周期未报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [],
        "reported_precedence": [
          "固定→共聚焦片或整叶分支→monomer/聚合→清除/5轮洗→染色/末洗→EasyIndex；没有来源支持的完整抗体时间表。"
        ],
        "missing_information": [
          "免疫荧光稀释、孵育时长/温度、normalserum种属、洗液体积/温度、clear与match精确时长未报。"
        ],
        "review_status": "source_checked_declared_tissue_and_direct_flow_scope;independent_review_pending"
      },
      "verification_scope": "historical_source_checked_author_record_inherited; embedded source_raw retained; not claimed fresh verification of every field"
    },
    {
      "protocol_id": "A144-P002",
      "record": {
        "record_id": "A144-P002",
        "record_type": "reported_imaging_and_cross_lobe_estimation",
        "title": {
          "value": "左右叶分工的胸腺采集、区域体积和TEC数量估计",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar1"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar2"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar4"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar5"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar6"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "整理常规胸腺透明/标记、形态量化及流式直接步骤；转录组算法另列本轮未合并范围。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar1"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar2"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar4"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar5"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar6"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "左叶共聚焦厚片用于density；右叶wholelobe光片用于volume；既有报告信号按源图分配",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar1"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar2"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar4"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar5"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar6"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "已处理切片与wholelobe",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar1"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar2"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar4"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar5"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar6"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "区域体积/TEC密度及右叶数量推算",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar1"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar2"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar4"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar5"
            },
            {
              "source_id": "F01",
              "locator": "PDFp16 XML#FPar6"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "LSM880/Z.1、Imaris9.7.1、ImageJ2.3.0/1.53f",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp15 XML#FPar1"
              },
              {
                "source_id": "F01",
                "locator": "PDFp15 XML#FPar2"
              },
              {
                "source_id": "F01",
                "locator": "PDFp15 XML#FPar3"
              },
              {
                "source_id": "F01",
                "locator": "PDFp15 XML#FPar4"
              }
            ],
            "check_status": "verified_against_primary_source"
          }
        ],
        "sections": [
          {
            "title": "分别采集",
            "steps": [
              {
                "step_id": "A144-P002-S01",
                "display_order": 1,
                "action": {
                  "value": "按组织尺度使用对应设备/采样并处理显示。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar1"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar2"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "confocal": {
                    "value": "ZeissLSM880，PlanApochromat25×/0.8multi-immersion；voxelXY0.22µm/Z2µm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar1"
                      },
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar2"
                      },
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "lightsheet": {
                    "value": "ZeissZ.1，ECPlanNeofluar5×/0.16；XY0.915µm/Z约4.9µm；dual-side按maximumintensityfuse",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar1"
                      },
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar2"
                      },
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "display": {
                    "value": "Imaris9.7.1；tissuesectionROI显示10µmZprojection",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar1"
                      },
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar2"
                      },
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar3"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "10µm是显示投影厚度，不是物理200µm片或2µm采集步长；激光/曝光未报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar1"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar2"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar3"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "区域体积",
            "steps": [
              {
                "step_id": "A144-P002-S02",
                "display_order": 2,
                "action": {
                  "value": "从各信号构建表面并求皮质差值。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "total": {
                    "value": "右整叶tdTomatochannel生成lobesurface",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "medulla": {
                    "value": "GFP高密度及Krt14+，GFP+K14合并",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "HD_TEC": {
                    "value": "压紧GFP+TEC，仅GFPchannel",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "pipeline": {
                    "value": "ImageJ2.3.0/1.53f；2Dmedian→3DGaussian→2Dminmax按强度阈值binarization→extractsurface",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "cortex": {
                    "value": "total−medulla−HDvolume",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#FPar4"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "滤波核/阈值值及区域重叠处理未报；不同核报告鼠和tdTomato分配按队列，不把全部marker当单一样本。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "TEC核及density",
            "steps": [
              {
                "step_id": "A144-P002-S03",
                "display_order": 3,
                "action": {
                  "value": "在共聚焦厚片中Spot识别核，再依据带符号距离分类并求密度。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "detection": {
                    "value": "Imarisspot；先filtertotalTECspots",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "medullary_HD": {
                    "value": "到指定surface最短距离≤0µm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "subcapsular": {
                    "value": "到sectionedge最短距离≥−25µm（保留原不等号/符号）",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "cTEC": {
                    "value": "remaining spots",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "density": {
                    "value": "对应subsetnumber/regionvolume",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar5"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "负值符号约定/交叠优先级未充分给出，不改成无符号25µm或把切片边缘当整个器官表面。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "右叶TEC数",
            "steps": [
              {
                "step_id": "A144-P002-S04",
                "display_order": 4,
                "action": {
                  "value": "以左叶厚片平均density乘右叶光片volume，得到右叶各subset核数。",
                  "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "formula": {
                    "value": "meanleftlobeconfocaldensity × rightlobelightsheetvolume",
                    "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "role": {
                    "value": "跨叶推算，不是右叶逐个核直接计数",
                    "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp16 XML#FPar6"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "每个动物两叶对应/片层抽样、估计不确定性未全列。",
                  "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar6"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [],
        "reported_precedence": [
          "各叶采集→右体积/左密度独立测量→乘积估计；步骤展示不改变左右叶来源。"
        ],
        "missing_information": [
          "数值分割参数、图像质量排除、左右叶匹配和density抽样规则未完整报告。"
        ],
        "review_status": "source_checked_declared_tissue_and_direct_flow_scope;independent_review_pending"
      },
      "verification_scope": "historical_source_checked_author_record_inherited; embedded source_raw retained; not claimed fresh verification of every field"
    },
    {
      "protocol_id": "A144-P003",
      "record": {
        "record_id": "A144-P003",
        "record_type": "reported_flow_procedure_with_source_complete_material_and_gate_tables;unreported_conditions_retained",
        "title": {
          "value": "分离细胞、流式及KGF-pAKT独立测量",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec14"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "purpose": {
          "value": "整理常规胸腺透明/标记、形态量化及流式直接步骤；转录组算法另列本轮未合并范围。",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec14"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "applicability": {
          "value": "新鲜胸腺细胞悬液；不使用P001固定透明组织",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec14"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "start_state": {
          "value": "胸腺组织",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec14"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "end_state": {
          "value": "分选细胞或流式读出",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec14"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        "materials": [
          {
            "value": "RPMI、两种消化液、filters、CD45microbeads/LScolumns、ACK、BSA、FACS/FlowJo",
            "source_refs": [
              {
                "source_id": "F01",
                "locator": "PDFp15 XML#Sec14"
              }
            ],
            "check_status": "verified_against_primary_source"
          },
          {
            "material": {
              "value": "CD45",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=30-F11; Fluorochrome=PerCP-Cy5.5; Vendor=Biolegend; Cat#=103132; Lot#=B363634; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD45",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=30-F11; Fluorochrome=PE-CF594; Vendor=BD; Cat#=562420; Lot#=0013784; Dilution=1/300",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD45",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=30-F11; Fluorochrome=BUV615; Vendor=BD; Cat#=751170; Lot#=not reported; Dilution=1/300",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD31",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=390; Fluorochrome=PerCP-Cy5.5; Vendor=Biolegend; Cat#=102420; Lot#=B247171; Dilution=1/1300",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "TER119",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=TER-119; Fluorochrome=PerCP-Cy5.5; Vendor=Biolegend; Cat#=116228; Lot#=B356105; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "TER119",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=TER-119; Fluorochrome=BUV563; Vendor=BD; Cat#=741257; Lot#=2265032; Dilution=1/500",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "TER119",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=TER-119; Fluorochrome=PE-Cy5.5; Vendor=Invitrogen; Cat#=35-5921-82; Lot#=not reported; Dilution=1/650",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "MHCII",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=M5/114.15.2; Fluorochrome=BV421; Vendor=Biolegend; Cat#=107631; Lot#=B360795; Dilution=1/300",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "MHCII",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=M5/114.15.2; Fluorochrome=BV711; Vendor=Biolegend; Cat#=107631; Lot#=B377900; Dilution=1/400",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "MHCII",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=M5/114.15.2; Fluorochrome=APC-e780; Vendor=Invitrogen; Cat#=47-5321-82; Lot#=not reported; Dilution=1/2000",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "EpCAM",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=G8.8; Fluorochrome=APC-Cy7; Vendor=Biolegend; Cat#=118218; Lot#=B393333; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "EpCAM",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=G8.8; Fluorochrome=PerCP-e710; Vendor=Invitrogen; Cat#=46-5791-82; Lot#=4278076; Dilution=1/400",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "Ly51",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=6C3; Fluorochrome=PE-Cy7; Vendor=Biolegend; Cat#=108313; Lot#=B215053; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "Ly51",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=6C3; Fluorochrome=PE; Vendor=Invitrogen; Cat#=12-5891-83; Lot#=4300066; Dilution=1/1000",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "Ly51",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=6C3; Fluorochrome=Alexa647; Vendor=Biolegend; Cat#=108312; Lot#=B222435; Dilution=1/400",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDGFRa",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=APA5; Fluorochrome=BUV737; Vendor=BD; Cat#=741789; Lot#=3228775; Dilution=1/200",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDGFRa",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=APA5; Fluorochrome=Alexa594; Vendor=Invitrogen; Cat#=14-1401-82; Lot#=not reported; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDGFRa",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=APA5; Fluorochrome=BV750; Vendor=BD; Cat#=747220; Lot#=not reported; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDGFRb",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=APB5; Fluorochrome=SB600; Vendor=Invitrogen; Cat#=63-1402-80; Lot#=not reported; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD104",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=346-11A; Fluorochrome=PE-Cy7; Vendor=Biolegend; Cat#=123615; Lot#=B343426; Dilution=1/200",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD104",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=346-11A; Fluorochrome=BV711; Vendor=BD; Cat#=743082; Lot#=not reported; Dilution=1/150",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "L1CAM",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=555; Fluorochrome=PE; Vendor=RD system; Cat#=AAYQ0223061; Lot#=FAB5674P; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "Ly6D",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=49-H4; Fluorochrome=eFluor450; Vendor=eBio; Cat#=48-597480; Lot#=2020836; Dilution=1/200",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDPN",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=8.1.1; Fluorochrome=APC-Fire750; Vendor=Biolegend; Cat#=127425; Lot#=B313124; Dilution=1/200",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDPN",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=8.1.1; Fluorochrome=BUV805; Vendor=BD custom; Cat#=624287; Lot#=not reported; Dilution=1/650",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDPN",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=8.1.1; Fluorochrome=Purified; Vendor=Biolegend; Cat#=127402; Lot#=B219285; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "PDPN-associated secondary row",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Alexa647 in Clone column; Fluorochrome=Anti-IgG in Fluorochrome column; Vendor=Invitrogen; Cat#=A-21451; Lot#=2527971; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD26",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=H194-112; Fluorochrome=BUV737; Vendor=BD; Cat#=741729; Lot#=not reported; Dilution=1/20",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD62P",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=RB40.34; Fluorochrome=BV480; Vendor=BD; Cat#=746249; Lot#=not reported; Dilution=1/300",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD309",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Avas12a; Fluorochrome=BUV661; Vendor=BD; Cat#=741571; Lot#=not reported; Dilution=1/50",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "CD9",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=KMC8; Fluorochrome=BUV563; Vendor=BD; Cat#=741270; Lot#=not reported; Dilution=1/50",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "Claudin-3",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Polyclonal; Fluorochrome=Purified; Vendor=Invitrogen; Cat#=34-1700; Lot#=Y1376567; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "Anti-Rabbit",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Secondary; Fluorochrome=APC; Vendor=Invitrogen; Cat#=A31573; Lot#=1786284; Dilution=1/400",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "UEA1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Lectin; Fluorochrome=Fitc; Vendor=VectorLabs; Cat#=FL-1061; Lot#=ZC0426; Dilution=1/1000",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "UEA1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Lectin; Fluorochrome=Biotin; Vendor=VectorLabs; Cat#=B1065; Lot#=ZD0810; Dilution=1/200",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "UEA1-associated streptavidin row",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Lectin merged table cell; Fluorochrome=Strep-BV605; Vendor=Biolegend; Cat#=405229; Lot#=B387251; Dilution=1/1000",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "pAKT",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=Polyclonal; Fluorochrome=Pac Blue; Vendor=Cell Signaling; Cat#=68035S; Lot#=1; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "FOXN1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=2/41; Fluorochrome=Alexa647; Vendor=Gift; Cat#=N/A; Lot#=N/A; Dilution=not reported",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "DCLK1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=aa690-720; Fluorochrome=BV421; Vendor=Lsbio; Cat#=LSC100746; Lot#=134142; Dilution=1/1000",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "GP2",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=2F11-C3; Fluorochrome=Alexa594; Vendor=MBL; Cat#=D278-3; Lot#=010; Dilution=1/100",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          },
          {
            "material": {
              "value": "GFP",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "reported_specification": {
              "value": "Clone=GFP-1020; Fluorochrome=Dylight488; Vendor=Aves; Cat#=GFP-1020; Lot#=GFP3717982; Dilution=1/1000",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
          }
        ],
        "sections": [
          {
            "title": "分离",
            "steps": [
              {
                "step_id": "A144-P003-S01",
                "display_order": 1,
                "action": {
                  "value": "机械碎化和所列酶液消化，分轮收上清并过滤离心。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "pieces": {
                    "value": "1–2mm",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "bufferA": {
                    "value": "RPMI+10%FCS+62.5µm mL−1 liberaseTM+0.4mg/mL DNaseI（µm/mL原印）",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "bufferB": {
                    "value": "RPMI+25mMHEPES+20µg/µL DNase1+1mg/mL collagenase/dispase",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "collect": {
                    "value": "incubations间取上清，100µmfilter；400g5min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "temperature": {
                    "value": "本节allsteps4°C unlessindicated",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "两种buffer为替代；消化轮次/时长缺失，异常单位不改；4°C是原文总括，消化实际特例未报。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "测序用分选",
            "steps": [
              {
                "step_id": "A144-P003-S02",
                "display_order": 2,
                "action": {
                  "value": "CD45去除后红细胞裂解、表面染色并分选，重新悬液。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "CD45": {
                    "value": "antiMouseCD45microbeads，MACSLScolumn，manufacturerprotocol未读",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "RBC": {
                    "value": "ACKlysis，参数未报",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "stain": {
                    "value": "antibodycocktail15min4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "sort": {
                    "value": "BDAriaII，100µmnozzle；RPMI+2%BSA收集",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "resuspend": {
                    "value": "400g5min→PBS+0.04%BSA",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  }
                },
                "notes": {
                  "value": "完整panel随目的变化；Table11/12作为材料/门控来源而非自动统一成一个cocktail。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "流式及门控",
            "steps": [
              {
                "step_id": "A144-P003-S03",
                "display_order": 3,
                "action": {
                  "value": "按源表中subsets/panels读取表面/细胞内信号。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "platform": {
                    "value": "FortessaX50或SymphonyA6；FACSDiva；FlowJo",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "source_panels": {
                    "value": "完整23项Table11门控定义见本记录cases；材料与稀释见materials中Table12的41条逐行原列记录。",
                    "source_refs": [
                      {
                        "source_id": "F03",
                        "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                      }
                    ],
                    "check_status": "verified_against_original_table_text_and_image"
                  },
                  "panel_boundary": {
                    "value": "Table11按figure指定门控；Table12列材料变体，但未给每个图完整荧光组合/串色补偿。不能将全部41条同时混合作单一cocktail。",
                    "source_refs": [
                      {
                        "source_id": "F03",
                        "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                      }
                    ],
                    "check_status": "verified_against_original_table_text_and_image"
                  }
                },
                "notes": {
                  "value": "该记录是partial，不把已存在Table12数值说成原文未报；其余门控/稀释保持source-reference待细化。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "KGF/pAKT子实验",
            "steps": [
              {
                "step_id": "A144-P003-S04",
                "display_order": 4,
                "action": {
                  "value": "CD45去除细胞接受短KGF刺激，固定通透并同时染胞内/外抗原。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "parameters": {
                  "KGF": {
                    "value": "recombinantmouseKGF100ng/mL，5min",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "fix": {
                    "value": "1.6%PFA，37°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "perm": {
                    "value": "90%methanol，4°C",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "wash": {
                    "value": "彻底去methanol后intracellular/extracellular同时染",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "PDFp15 XML#Sec14"
                      }
                    ],
                    "check_status": "verified_against_primary_source"
                  },
                  "pAKT_material": {
                    "value": "Table12 pAKT polyclonalPacificBlue，CellSignaling68035S，lot1，1/100。",
                    "source_refs": [
                      {
                        "source_id": "F03",
                        "locator": "41590_2024_1915_MOESM1_ESM.pdf p6"
                      }
                    ],
                    "check_status": "verified_against_primary_supplement"
                  }
                },
                "notes": {
                  "value": "固定/甲醇时长和刺激温度未特例给出，保留总括4°C来源及缺项，不补常用37°C刺激。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "source_scope_limited"
                },
                "legacy_P_or_row": null
              }
            ]
          },
          {
            "title": "直接流式读出",
            "steps": [
              {
                "step_id": "A144-P003-S05",
                "display_order": 5,
                "action": {
                  "value": "按各图的细胞群和时间定义输出计数、恢复指数或pAKT配对MFI。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "Fig5a–d caption PDFp9"
                    }
                  ],
                  "check_status": "verified_against_original_figure_caption"
                },
                "parameters": {
                  "Fig5b": {
                    "value": "对应时间总cellularity/同龄steady-statecellularity；细胞计数仪/完整计数方法未给。",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "Fig5b caption"
                      }
                    ],
                    "check_status": "verified_against_original_figure_caption"
                  },
                  "Fig5d": {
                    "value": "前7天各群体恢复曲线算AUC；agingindex=agedAUC/youngAUC。具体积分算法未给。",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "Fig5d caption"
                      }
                    ],
                    "check_status": "verified_against_original_figure_caption"
                  },
                  "Fig6e": {
                    "value": "KGF前后pAKT MFI配对，n6thymuses/individualmice，two-tailedpairedt-test；MFI的mean/median展开未给。",
                    "source_refs": [
                      {
                        "source_id": "F01",
                        "locator": "Fig6e originalimage andcaption"
                      }
                    ],
                    "check_status": "verified_against_original_figure_caption"
                  }
                },
                "notes": {
                  "value": "基线归一与AUC比值是不同读出；pAKT流式不赋RNA表达量或wholemount IF参数。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "Fig6e caption"
                    }
                  ],
                  "check_status": "verified_against_original_figure_caption"
                },
                "legacy_P_or_row": null
              }
            ]
          }
        ],
        "cases": [
          {
            "case_id": "gate_EC",
            "description": {
              "value": "EC: Live TER119− CD45− CD31+ PDGFRa−；Table11 figure scope=ExtFig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_Fibroblast",
            "description": {
              "value": "Fibroblast: Live TER119− CD45− CD31− PDGFRa+；Table11 figure scope=ExtFig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_mTEC",
            "description": {
              "value": "mTEC: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo；Table11 figure scope=ExtFig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_cTEC",
            "description": {
              "value": "cTEC: Live TER119− CD45− EpCAM+ MHCII+ UEA1lo Ly51hi；Table11 figure scope=ExtFig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_mTEC1",
            "description": {
              "value": "mTEC1: Live TER119− CD45− EpCAM+ MHCIIlo UEA1hi Ly51lo L1CAM− CD104+；Table11 figure scope=Fig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_mTEC2",
            "description": {
              "value": "mTEC2: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo L1CAM− CD104− Ly6D−；Table11 figure scope=Fig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_mTEC3",
            "description": {
              "value": "mTEC3: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo L1CAM− CD104− Ly6D+；Table11 figure scope=Fig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_TECtuft",
            "description": {
              "value": "TECtuft: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo L1CAM+；Table11 figure scope=Fig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_DN-TEC",
            "description": {
              "value": "DN-TEC: Live TER119− CD45− EpCAM+ MHCII+ UEA1− Ly51−；Table11 figure scope=Fig1",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_aaTEC1",
            "description": {
              "value": "aaTEC1: Live TER119− CD45− PDGFRa− CD31− EpCAM+ MHCII+ UEA1− Ly51− Claudin-3+；Table11 figure scope=Fig1j/ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_aaTEC2",
            "description": {
              "value": "aaTEC2: Live TER119− CD45− EpCAM− MHCII+ PDPN+ PDGFRa−；Table11 figure scope=Fig1j/ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_capFB",
            "description": {
              "value": "capFB: Live TER119− CD45− CD31− PDGFRa+ CD26+ PDPN+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_medFB",
            "description": {
              "value": "medFB: Live TER119− CD45− CD31− PDGFRa+ CD26− PDPN+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_intFB",
            "description": {
              "value": "intFB: Live TER119− CD45− CD31− PDGFRa+ PDPN−；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_aEC",
            "description": {
              "value": "aEC: Live TER119− CD45− CD31+ PDGFRa− CD309− CD62P−；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_capEC",
            "description": {
              "value": "capEC: Live TER119− CD45− CD31+ PDGFRa− CD309+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_vEC",
            "description": {
              "value": "vEC: Live TER119− CD45− CD31+ PDGFRa− CD309− CD62P+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_Pericyte",
            "description": {
              "value": "Pericyte: Live TER119− CD45− CD31− PDGFRb+ Ly51+ CD9+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_vSMC",
            "description": {
              "value": "vSMC: Live TER119− CD45− CD31− PDGFRb+ Ly51− CD9+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_Mesothelial",
            "description": {
              "value": "Mesothelial: Live TER119− CD45− CD31− PDGFRb− CD9+ PDPN+；Table11 figure scope=ED4",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_Tuft_Cell",
            "description": {
              "value": "Tuft Cell: Live TER119− CD45− EpCAM+ UEA1hi Ly51lo GFP+ DCLK1+ Ly6Dlo/−；Table11 figure scope=ED7 Foxn1nTnG",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_Corneocyte",
            "description": {
              "value": "Corneocyte: Live TER119− CD45− EpCAM+ UEA1hi Ly51lo GFP+ DCLK1− Ly6D+；Table11 figure scope=ED7 Foxn1nTnG",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          },
          {
            "case_id": "gate_M_cell",
            "description": {
              "value": "M cell: Live TER119− CD45− EpCAM+ UEA1hi Ly51lo GFP+ GP2+ Ly6Dlo/−；Table11 figure scope=ED7 Foxn1nTnG",
              "source_refs": [
                {
                  "source_id": "F03",
                  "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                }
              ],
              "check_status": "verified_against_original_table_text_and_image"
            },
            "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
          }
        ],
        "reported_precedence": [
          "组织分离→CD45去除/ACK/分选链用于测序；KGF-pAKT为另一读出支路，不将固定甲醇加入活细胞RNA分选。"
        ],
        "missing_information": [
          "分离液单位疑点、消化时程、厂家MACS具体流程与每图完整荧光组合/补偿/数字门阈值未报。",
          "FOXN1 Table12稀释为空；Table13 IF稀释也缺；流式稀释不迁移到wholemount。",
          "Table12少数列/标注疑点保留：MHCII两荧光同cat107631、L1CAM Cat#/Lot#角色可疑、PDPN二抗行列名位置及A31573流式APC/IF-AF647名称差异。"
        ],
        "review_status": "source_checked_declared_tissue_and_direct_flow_scope;independent_review_pending"
      },
      "verification_scope": "historical_source_checked_author_record_inherited; embedded source_raw retained; not claimed fresh verification of every field"
    }
  ],
  "experiments": [
    {
      "experiment_id": "A144-R20261012-E01",
      "title": "年龄相关细胞亚群改变",
      "sample_class_ids": [
        "A144-R20261012-G01",
        "A144-R20261012-G02",
        "A144-R20261012-G03",
        "A144-R20261012-G39",
        "A144-R20261012-G46",
        "A144-R20261012-G47",
        "A144-R20261012-G48",
        "A144-R20261012-G51",
        "A144-R20261012-G52"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E01"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results stromal compartments; Fig1; ED4",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1/ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results single-cell cohorts; Fig1",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED2/3",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1g",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1k",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED1",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E02",
      "title": "整叶高密度TEC区域",
      "sample_class_ids": [
        "A144-R20261012-G04",
        "A144-R20261012-G05",
        "A144-R20261012-G06"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E02"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters; Fig2a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-SUPP-4",
          "locator": "Video1 sampled labels",
          "verification": "fresh sampled frames; supports spatial illustration only, not exact cohort age reconciliation"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2c; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2c",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E03",
      "title": "空间转录与固定免疫对应",
      "sample_class_ids": [
        "A144-R20261012-G07",
        "A144-R20261012-G08"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E03"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2d–f; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table3 current workbook versus publisherdescription",
          "verification": "actual worksheet headings/signature size read"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E04",
      "title": "既有报告体系中的TEC来源",
      "sample_class_ids": [
        "A144-R20261012-G09",
        "A144-R20261012-G10",
        "A144-R20261012-G11",
        "A144-R20261012-G49",
        "A144-R20261012-G57"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E04"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3a–e; Results lineage",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3f,g; Discussion lineage caveat",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results Fig3e tdTom reporter integration",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3b/c/d",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED5a",
          "verification": "fresh actual ExtendedData artwork/caption independently read"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E05",
      "title": "HD区及人体参照",
      "sample_class_ids": [
        "A144-R20261012-G12",
        "A144-R20261012-G13",
        "A144-R20261012-G14"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E05"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3h–k; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-7",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n",
          "applicable_sample_ids": [
            "A144-R20261012-G12"
          ],
          "supports_scope": "mouse representative spatial exclusion only; not human tissue or exact depletion fraction"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results human TEC paragraph",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3h–k/ED5d–f",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E06",
      "title": "年龄相关通路背景",
      "sample_class_ids": [
        "A144-R20261012-G15",
        "A144-R20261012-G16"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E06"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4a; Discussion; Table5 description",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results age-dependent programs; low-cTEC technical caveat",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table4-cTEC exact target cells/headers",
          "verification": "fresh targeted original rows read"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E07",
      "title": "aaTEC功能表达与部分EMT",
      "sample_class_ids": [
        "A144-R20261012-G17",
        "A144-R20261012-G18",
        "A144-R20261012-G19",
        "A144-R20261012-G36",
        "A144-R20261012-G37",
        "A144-R20261012-G41",
        "A144-R20261012-G42",
        "A144-R20261012-G43",
        "A144-R20261012-G44",
        "A144-R20261012-G45",
        "A144-R20261012-G50"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E07"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table6-aaTEC1 negative row8/aaTEC2 positive row4",
          "verification": "fresh targeted original rows read"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4c–g",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-X07",
          "locator": "Author Correction DOI10.1038/s41590-026-02489-4",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7a corrected Mouse1/2/3 panels",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7b",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7b",
          "verification": "fresh complete official text/captions read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7c",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7c",
          "verification": "fresh complete official text/captions read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7d",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption d",
          "verification": "fresh complete official text/captions read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7e",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption e",
          "verification": "fresh complete official text/captions read"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4f/g/ED8a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E08",
      "title": "基线配体受体推断与蛋白支路",
      "sample_class_ids": [
        "A144-R20261012-G20",
        "A144-R20261012-G21"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E08"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4h,i; Discussion sink interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig4j caption and Results",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4j",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E09",
      "title": "年轻与老年损伤后恢复",
      "sample_class_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23",
        "A144-R20261012-G40",
        "A144-R20261012-G53"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E09"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Fig5a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5a caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Fig5c,d; ED9; Results",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5d–f caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5d axis label",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; ExtendedData9b",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Extended Data9a",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E10",
      "title": "损伤后老年HD区三维量化",
      "sample_class_ids": [
        "A144-R20261012-G24",
        "A144-R20261012-G25",
        "A144-R20261012-G56"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E10"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5e/f,12mo male right-lobe atday28; original author caption retained",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5e/f; printed P labels and direction",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-8",
          "locator": "Video4 five-source mapping, four distributed frames",
          "verification": "fresh sampled movie artwork read"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "video_findings4",
          "verification": "official caption versus actual frames"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E11",
      "title": "损伤后亚群转录时间序列",
      "sample_class_ids": [
        "A144-R20261012-G26",
        "A144-R20261012-G27",
        "A144-R20261012-G54",
        "A144-R20261012-G55"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E11"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results epithelial developmental program after injury; Fig5g–i",
          "verification": "fresh primary text read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure1",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure1",
          "verification": "fresh rendered official supplementary PDF read"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure2",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure2",
          "verification": "fresh rendered official supplementary PDF read"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E12",
      "title": "再生信号与竞争解释",
      "sample_class_ids": [
        "A144-R20261012-G29",
        "A144-R20261012-G30",
        "A144-R20261012-G31",
        "A144-R20261012-G35"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E12"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results regeneration signaling; Fig6a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-9",
          "locator": "Tables7–10 cTEC/intFB/medFB day4/day7 versusday1",
          "verification": "fresh targeted original workbook rows read"
        },
        {
          "source_id": "A144-WORKBOOK-TARGETROWS",
          "locator": "all selected rows retain Excel positions",
          "verification": "independent targeted cell audit"
        },
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig6c–e; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig6e",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_Fig6",
          "locator": "Fig6e",
          "verification": "fresh original artwork independently viewed"
        }
      ]
    },
    {
      "experiment_id": "A144-R20261012-E13",
      "title": "FOXN1降低与aaTEC关联",
      "sample_class_ids": [
        "A144-R20261012-G32",
        "A144-R20261012-G33",
        "A144-R20261012-G34",
        "A144-R20261012-G38"
      ],
      "independence": "analytical_component_not_independent_biological_replicate",
      "historical_component_correspondence": [
        "A144-E13"
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-5",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        },
        {
          "source_id": "A144-SUPP-6",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED10",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    }
  ],
  "samples": [
    {
      "sample_id": "A144-R20261012-G01",
      "group_id": "A144-R20261012-G01",
      "experiment_id": "A144-R20261012-E01",
      "label": "2月稳态",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅直接流式门控计数；scRNA独立来源"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results stromal compartments; Fig1; ED4",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1/ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G02",
      "group_id": "A144-R20261012-G02",
      "experiment_id": "A144-R20261012-E01",
      "label": "18月稳态",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅直接流式门控计数；scRNA独立来源"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results stromal compartments; Fig1; ED4",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1/ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G03",
      "group_id": "A144-R20261012-G03",
      "experiment_id": "A144-R20261012-E01",
      "label": "年龄流式系列",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅直接流式门控计数；scRNA独立来源"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results stromal compartments; Fig1; ED4",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1/ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G04",
      "group_id": "A144-R20261012-G04",
      "experiment_id": "A144-R20261012-E02",
      "label": "2月代表图及定量",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters; Fig2a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-SUPP-4",
          "locator": "Video1 sampled labels",
          "verification": "fresh sampled frames; supports spatial illustration only, not exact cohort age reconciliation"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2c; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2c",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G05",
      "group_id": "A144-R20261012-G05",
      "experiment_id": "A144-R20261012-E02",
      "label": "老年代表图：caption24月、artwork18mo+（未决）",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters; Fig2a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-SUPP-4",
          "locator": "Video1 sampled labels",
          "verification": "fresh sampled frames; supports spatial illustration only, not exact cohort age reconciliation"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G06",
      "group_id": "A144-R20261012-G06",
      "experiment_id": "A144-R20261012-E02",
      "label": "18月定量",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2c; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2c",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G07",
      "group_id": "A144-R20261012-G07",
      "experiment_id": "A144-R20261012-E03",
      "label": "2/18月Visium数据",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2d–f; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table3 current workbook versus publisherdescription",
          "verification": "actual worksheet headings/signature size read"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G08",
      "group_id": "A144-R20261012-G08",
      "experiment_id": "A144-R20261012-E03",
      "label": "12–18月HD区免疫图",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定免疫支路"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应图像；Visium独立来源"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2d–f; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table3 current workbook versus publisherdescription",
          "verification": "actual worksheet headings/signature size read"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G09",
      "group_id": "A144-R20261012-G09",
      "experiment_id": "A144-R20261012-E04",
      "label": "年轻/老年Foxn1nTnG报告体系",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅流式GFP、EpCAM/claudin3/PDPN表型"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3a–e; Results lineage",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G10",
      "group_id": "A144-R20261012-G10",
      "experiment_id": "A144-R20261012-E04",
      "label": "20月Foxn1tdTom转录数据",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results Fig3e tdTom reporter integration",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G11",
      "group_id": "A144-R20261012-G11",
      "experiment_id": "A144-R20261012-E04",
      "label": "2/18月计算轨迹",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3f,g; Discussion lineage caveat",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G12",
      "group_id": "A144-R20261012-G12",
      "experiment_id": "A144-R20261012-E05",
      "label": "老年小鼠aaTEC相关区域",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3h–k; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-7",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n",
          "applicable_sample_ids": [
            "A144-R20261012-G12"
          ],
          "supports_scope": "mouse representative spatial exclusion only; not human tissue or exact depletion fraction"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G13",
      "group_id": "A144-R20261012-G13",
      "experiment_id": "A144-R20261012-E05",
      "label": "50岁人胸腺独立切片",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3h–k; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results human TEC paragraph",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3h–k/ED5d–f",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G14",
      "group_id": "A144-R20261012-G14",
      "experiment_id": "A144-R20261012-E05",
      "label": "既有人TEC转录集",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3h–k; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results human TEC paragraph",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3h–k/ED5d–f",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G15",
      "group_id": "A144-R20261012-G15",
      "experiment_id": "A144-R20261012-E06",
      "label": "2月同亚群",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4a; Discussion; Table5 description",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results age-dependent programs; low-cTEC technical caveat",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table4-cTEC exact target cells/headers",
          "verification": "fresh targeted original rows read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G16",
      "group_id": "A144-R20261012-G16",
      "experiment_id": "A144-R20261012-E06",
      "label": "18月同亚群",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4a; Discussion; Table5 description",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results age-dependent programs; low-cTEC technical caveat",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table4-cTEC exact target cells/headers",
          "verification": "fresh targeted original rows read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G17",
      "group_id": "A144-R20261012-G17",
      "experiment_id": "A144-R20261012-E07",
      "label": "老年aaTEC1",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table6-aaTEC1 negative row8/aaTEC2 positive row4",
          "verification": "fresh targeted original rows read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G18",
      "group_id": "A144-R20261012-G18",
      "experiment_id": "A144-R20261012-E07",
      "label": "老年aaTEC2",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table6-aaTEC1 negative row8/aaTEC2 positive row4",
          "verification": "fresh targeted original rows read"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4c–g",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G19",
      "group_id": "A144-R20261012-G19",
      "experiment_id": "A144-R20261012-E07",
      "label": "对应TEC及medFB比较群",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4c–g",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G20",
      "group_id": "A144-R20261012-G20",
      "experiment_id": "A144-R20261012-E08",
      "label": "2月/18月CellChat群",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4h,i; Discussion sink interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G21",
      "group_id": "A144-R20261012-G21",
      "experiment_id": "A144-R20261012-E08",
      "label": "2/12/18月雌性C57BL/6蛋白测定，各组n5",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": {
        "per_age": 5,
        "ages_months": [
          2,
          12,
          18
        ]
      },
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig4j caption and Results",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4j",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G22",
      "group_id": "A144-R20261012-G22",
      "experiment_id": "A144-R20261012-E09",
      "label": "1–2月/2月",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅已采集数据的细胞计数；不重建损伤操作"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Fig5a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5a caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Fig5c,d; ED9; Results",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5d–f caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5d axis label",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; ExtendedData9b",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G23",
      "group_id": "A144-R20261012-G23",
      "experiment_id": "A144-R20261012-E09",
      "label": "18月/18+月",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅已采集数据的细胞计数；不重建损伤操作"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Fig5a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5a caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Fig5c,d; ED9; Results",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5d–f caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5d axis label",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; ExtendedData9b",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G24",
      "group_id": "A144-R20261012-G24",
      "experiment_id": "A144-R20261012-E10",
      "label": "12月雄鼠稳态组织学",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5e/f,12mo male right-lobe atday28; original author caption retained",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5e/f; printed P labels and direction",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G25",
      "group_id": "A144-R20261012-G25",
      "experiment_id": "A144-R20261012-E10",
      "label": "12月雄鼠既有损伤后28日右叶组织学",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5e/f,12mo male right-lobe atday28; original author caption retained",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5e/f; printed P labels and direction",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G26",
      "group_id": "A144-R20261012-G26",
      "experiment_id": "A144-R20261012-E11",
      "label": "2月各时点",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [
        {
          "published_timepoints_days": [
            0,
            1,
            4,
            7
          ],
          "readout": "scRNA composition and RNA velocity",
          "not_animal_n": true
        }
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results epithelial developmental program after injury; Fig5g–i",
          "verification": "fresh primary text read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure1",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure1",
          "verification": "fresh rendered official supplementary PDF read"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G27",
      "group_id": "A144-R20261012-G27",
      "experiment_id": "A144-R20261012-E11",
      "label": "18月各时点",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [
        {
          "published_timepoints_days": [
            0,
            1,
            4,
            7
          ],
          "readout": "scRNA composition and RNA velocity",
          "not_animal_n": true
        }
      ],
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results epithelial developmental program after injury; Fig5g–i",
          "verification": "fresh primary text read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure1",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure1",
          "verification": "fresh rendered official supplementary PDF read"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G28",
      "group_id": "A144-R20261012-G28",
      "experiment_id": "A144-R20261012-E11",
      "label": "旧Fig5g下bulk支路不适用；新SuppFig2验证由独立G54/G55表示",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [],
      "status": "superseded_for_Fig5g_scope; separate newSupplementFig2 branch now directly sourced",
      "replacement_group_ids": [
        "A144-R20261012-G54",
        "A144-R20261012-G55"
      ]
    },
    {
      "sample_id": "A144-R20261012-G29",
      "group_id": "A144-R20261012-G29",
      "experiment_id": "A144-R20261012-E12",
      "label": "年轻4/7日相对1日",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results regeneration signaling; Fig6a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-9",
          "locator": "Tables7–10 cTEC/intFB/medFB day4/day7 versusday1",
          "verification": "fresh targeted original workbook rows read"
        },
        {
          "source_id": "A144-WORKBOOK-TARGETROWS",
          "locator": "all selected rows retain Excel positions",
          "verification": "independent targeted cell audit"
        },
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig6c–e; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G30",
      "group_id": "A144-R20261012-G30",
      "experiment_id": "A144-R20261012-E12",
      "label": "老年4/7日相对1日",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results regeneration signaling; Fig6a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-9",
          "locator": "Tables7–10 cTEC/intFB/medFB day4/day7 versusday1",
          "verification": "fresh targeted original workbook rows read"
        },
        {
          "source_id": "A144-WORKBOOK-TARGETROWS",
          "locator": "all selected rows retain Excel positions",
          "verification": "independent targeted cell audit"
        },
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig6c–e; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G31",
      "group_id": "A144-R20261012-G31",
      "experiment_id": "A144-R20261012-E12",
      "label": "相应CellChat比较",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig6c–e; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G32",
      "group_id": "A144-R20261012-G32",
      "experiment_id": "A144-R20261012-E13",
      "label": "老年TEC各状态",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G33",
      "group_id": "A144-R20261012-G33",
      "experiment_id": "A144-R20261012-E13",
      "label": "6月既有Foxn1低功能模型及对照",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED10",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G34",
      "group_id": "A144-R20261012-G34",
      "experiment_id": "A144-R20261012-E13",
      "label": "FOXN1流式蛋白",
      "sample_identity_level": "condition_class_not_individual",
      "initial_state": "see explicit sample label and stable P applicability; no per-panel undocumented state assumed",
      "biological_n": null,
      "n_status": "not_assigned_from_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅FOXN1蛋白流式，不扩为模型构建"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G35",
      "group_id": "A144-R20261012-G35",
      "experiment_id": "A144-R20261012-E12",
      "label": "18月雌性胸腺KGF响应pAKT流式配对比较；cTEC/mTEC/aaTEC/FB",
      "sample_identity_level": "explicit_source_cohort_not_individual",
      "initial_state": "published fixed endpoint or assay result only",
      "biological_n": 6,
      "n_status": "source_specific_not_condition_count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published pAKT flow endpoint only"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig6e",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_Fig6",
          "locator": "Fig6e",
          "verification": "fresh original artwork independently viewed"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G36",
      "group_id": "A144-R20261012-G36",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7a旧版右侧3区域来自同一老年报告鼠",
      "sample_identity_level": "explicit_source_cohort_not_individual",
      "initial_state": "published fixed endpoint or assay result only",
      "biological_n": 1,
      "n_status": "source_specific_not_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-X07",
          "locator": "Author Correction DOI10.1038/s41590-026-02489-4",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7a corrected Mouse1/2/3 panels",
          "verification": "fresh original artwork independently viewed"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G37",
      "group_id": "A144-R20261012-G37",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7a修正版3只不同老年报告鼠",
      "sample_identity_level": "explicit_source_cohort_not_individual",
      "initial_state": "published fixed endpoint or assay result only",
      "biological_n": 3,
      "n_status": "source_specific_not_condition_count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-X07",
          "locator": "Author Correction DOI10.1038/s41590-026-02489-4",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7a corrected Mouse1/2/3 panels",
          "verification": "fresh original artwork independently viewed"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G38",
      "group_id": "A144-R20261012-G38",
      "experiment_id": "A144-R20261012-E13",
      "label": "FOXN1计算诱导/抑制和分化轨迹数据",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-5",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        },
        {
          "source_id": "A144-SUPP-6",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G39",
      "group_id": "A144-R20261012-G39",
      "experiment_id": "A144-R20261012-E01",
      "label": "2月/18月CD45−基质单细胞数据集，共22932细胞；非动物n",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results single-cell cohorts; Fig1",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED2/3",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G40",
      "group_id": "A144-R20261012-G40",
      "experiment_id": "A144-R20261012-E09",
      "label": "ED9a年轻/老年损伤后组织学比较；独立非流式支路",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Extended Data9a",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G41",
      "group_id": "A144-R20261012-G41",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7b 2月常规mTEC拟态细胞数量",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7b",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7b",
          "verification": "fresh complete official text/captions read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G42",
      "group_id": "A144-R20261012-G42",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7b/c 18月常规mTEC拟态细胞数量",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7b",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7b",
          "verification": "fresh complete official text/captions read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7c",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7c",
          "verification": "fresh complete official text/captions read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G43",
      "group_id": "A144-R20261012-G43",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7c 18月DN-TEC拟态细胞数量",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7c",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7c",
          "verification": "fresh complete official text/captions read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G44",
      "group_id": "A144-R20261012-G44",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7d各TEC子群Aire/Foxn1转录feature plots",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7d",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption d",
          "verification": "fresh complete official text/captions read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G45",
      "group_id": "A144-R20261012-G45",
      "experiment_id": "A144-R20261012-E07",
      "label": "ED7e 12月Foxn1nTnG既有AIRE组织图",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7e",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption e",
          "verification": "fresh complete official text/captions read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G46",
      "group_id": "A144-R20261012-G46",
      "experiment_id": "A144-R20261012-E01",
      "label": "Fig1g 2月细分TEC流式计数",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1g",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G47",
      "group_id": "A144-R20261012-G47",
      "experiment_id": "A144-R20261012-E01",
      "label": "Fig1g 18月+细分TEC流式计数",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1g",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G48",
      "group_id": "A144-R20261012-G48",
      "experiment_id": "A144-R20261012-E01",
      "label": "Fig1j/k C57BL/6 2/12/18月混合男女独立流式年龄系列",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1k",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G49",
      "group_id": "A144-R20261012-G49",
      "experiment_id": "A144-R20261012-E04",
      "label": "Fig3b/c/d Foxn1报告鼠标记流式：不同panel n分别列示",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3b/c/d",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G50",
      "group_id": "A144-R20261012-G50",
      "experiment_id": "A144-R20261012-E07",
      "label": "Fig4f/g及ED8a aaTEC与常规TEC转录功能基因比较",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4f/g/ED8a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G51",
      "group_id": "A144-R20261012-G51",
      "experiment_id": "A144-R20261012-E01",
      "label": "ED1年龄胸腺整体/宽门控背景（各端点独立范围）",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED1",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G52",
      "group_id": "A144-R20261012-G52",
      "experiment_id": "A144-R20261012-E01",
      "label": "ED4 2/18月非上皮基质流式及独立DN-TEC年龄计数",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G53",
      "group_id": "A144-R20261012-G53",
      "experiment_id": "A144-R20261012-E09",
      "label": "ED9b 2/18月每day0/1/4/7流式跨龄比较",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G54",
      "group_id": "A144-R20261012-G54",
      "experiment_id": "A144-R20261012-E11",
      "label": "SuppFig2 CD45− bulk RNA biological replicates atday0/1/4/7",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure2",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure2",
          "verification": "fresh rendered official supplementary PDF read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G55",
      "group_id": "A144-R20261012-G55",
      "experiment_id": "A144-R20261012-E11",
      "label": "SuppFig2 averaged scRNA technical replicates, exact technical n unreported",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure2",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure2",
          "verification": "fresh rendered official supplementary PDF read"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G56",
      "group_id": "A144-R20261012-G56",
      "experiment_id": "A144-R20261012-E10",
      "label": "Video4独立代表图：画面18月day21，caption12月day28，身份未统一",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-SUPP-8",
          "locator": "Video4 five-source mapping, four distributed frames",
          "verification": "fresh sampled movie artwork read"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "video_findings4",
          "verification": "official caption versus actual frames"
        }
      ]
    },
    {
      "sample_id": "A144-R20261012-G57",
      "group_id": "A144-R20261012-G57",
      "experiment_id": "A144-R20261012-E04",
      "label": "ED5a11周Foxn1报告体系与非报告对照特异性验证",
      "sample_identity_level": "specific_comparison_condition_not_individual",
      "initial_state": "published existing sample/data; source-limited",
      "biological_n": null,
      "n_status": "see result-specific reported_n; not condition count",
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "only named published reporter-validation flow readout; no20month transcript branch"
        }
      ],
      "observation_conditions": [],
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED5a",
          "verification": "fresh actual ExtendedData artwork/caption independently read"
        }
      ]
    }
  ],
  "results": [
    {
      "result_id": "A144-R20261012-O01",
      "experiment_id": "A144-R20261012-E01",
      "sample_class_ids": [
        "A144-R20261012-G01",
        "A144-R20261012-G02",
        "A144-R20261012-G03"
      ],
      "metric": "亚群变化",
      "reported_result": "2月/18月单细胞比较中老龄出现aaTEC1/2及early-prog增加；此设计不定位首次出现年龄。独立年龄流式显示aaTEC在12月已增多。基质各亚群频率/数量变化异质，详见新增主Fig1及ED1/4端点。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results stromal compartments; Fig1; ED4",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1/ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR01"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O02",
      "experiment_id": "A144-R20261012-E01",
      "sample_class_ids": [
        "A144-R20261012-G39"
      ],
      "metric": "采样层级",
      "reported_result": "单细胞集22932个CD45−细胞是细胞数，不是动物n；与流式计数分开。 ED2 FB13240/EC1661/TEC6175，ED3整合297988/上皮205625，均为注释数据细胞数。",
      "numeric_values": [
        {
          "value": 22932,
          "unit": "cells",
          "not_animal_n": true
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results single-cell cohorts; Fig1",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED2/3",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR02"
      ],
      "record_type": "reported_observation",
      "metric_kind": "quantitative",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O03",
      "experiment_id": "A144-R20261012-E02",
      "sample_class_ids": [
        "A144-R20261012-G04",
        "A144-R20261012-G05"
      ],
      "metric": "三维组织结构",
      "reported_result": "年轻髓质互连，老年呈孤立岛及髓周高密度TEC带。 Fig2a老年代表图实际标18mo+，caption称24mo male，年龄来源范围不一致，不能强行统一。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters; Fig2a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-SUPP-4",
          "locator": "Video1 sampled labels",
          "verification": "fresh sampled frames; supports spatial illustration only, not exact cohort age reconciliation"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR03"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-FIG2A-AGE",
          "artwork": "18mo+",
          "caption": "24mo male representative",
          "resolution": "retain source-specific representative age discrepancy; quantitative18month branch remains separate"
        },
        {
          "conflict_id": "A144-VIDEO1-AGE",
          "video_labels": "2mo/18mo",
          "video_caption": "female reporter",
          "Fig2b_caption": "24mo old representative",
          "resolution": "separate source specimen/age labels retained, not forcibly matched"
        }
      ]
    },
    {
      "result_id": "A144-R20261012-O04",
      "experiment_id": "A144-R20261012-E02",
      "sample_class_ids": [
        "A144-R20261012-G04",
        "A144-R20261012-G06"
      ],
      "metric": "体积与细胞估计",
      "reported_result": "Fig2c老龄相对年轻：总体积↓P=.07、皮质体积↓.08、cTEC数量↓.07均未显著；髓质体积↓.002、mTEC数量↓.0008；HD体积↑.009、HD细胞数↑.004。n3/年龄，mean±SEM、unpaired t；不把趋势全称显著下降。",
      "numeric_values": [
        {
          "endpoint": "total_volume",
          "direction": "down",
          "P": 0.07,
          "significant": false
        },
        {
          "endpoint": "cortex_volume",
          "direction": "down",
          "P": 0.08,
          "significant": false
        },
        {
          "endpoint": "cTEC_count",
          "direction": "down",
          "P": 0.07,
          "significant": false
        },
        {
          "endpoint": "medulla_volume",
          "direction": "down",
          "P": 0.002,
          "significant": true
        },
        {
          "endpoint": "mTEC_count",
          "direction": "down",
          "P": 0.0008,
          "significant": true
        },
        {
          "endpoint": "HD_volume",
          "direction": "up",
          "P": 0.009,
          "significant": true
        },
        {
          "endpoint": "HD_count",
          "direction": "up",
          "P": 0.004,
          "significant": true
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2c; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2c",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "statistics": {
        "error": "SEM",
        "test": "unpaired t"
      },
      "numeric_values_status": "figure point values not extracted",
      "artifact_ids": [
        "A144-R20261012-AR04"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [],
      "reported_n": {
        "value": 3,
        "per": "age",
        "unit": "biological_replicates"
      }
    },
    {
      "result_id": "A144-R20261012-O05",
      "experiment_id": "A144-R20261012-E03",
      "sample_class_ids": [
        "A144-R20261012-G07",
        "A144-R20261012-G08"
      ],
      "metric": "空间匹配",
      "reported_result": "老年aaTEC签名聚集在髓质相关区域；HD中多K5+、部分K8+、K14−，claudin3可标记。 Workbook Table3当前aaTEC1/2 top20签名各20基因，官网补件描述top30/top10，来源定义差异保留。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2d–f; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table3 current workbook versus publisherdescription",
          "verification": "actual worksheet headings/signature size read"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR05"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-TABLE3-SIGNATURE-SIZE",
          "workbook": "tabs top20, aaTEC1/2 signatures contain20genes",
          "web_description": "top30/top10 descriptions",
          "resolution": "source definitions preserved, not silently interchangeable"
        }
      ],
      "source_table_rows": [
        {
          "sheet": "Table 3 - top 20 (visium)",
          "source_rows": [
            {
              "C1": "SUBSETS",
              "D1": "MOUSE GENES",
              "E1": "",
              "F1": "",
              "G1": "",
              "H1": "",
              "I1": "",
              "J1": "",
              "K1": "",
              "L1": "",
              "M1": "",
              "N1": "",
              "O1": "",
              "P1": "",
              "Q1": "",
              "R1": "",
              "S1": "",
              "T1": "",
              "U1": "",
              "V1": "",
              "W1": ""
            },
            {
              "C2": "",
              "D2": "",
              "E2": "",
              "F2": "",
              "G2": "",
              "H2": "",
              "I2": "",
              "J2": "",
              "K2": "",
              "L2": "",
              "M2": "",
              "N2": "",
              "O2": "",
              "P2": "",
              "Q2": "",
              "R2": "",
              "S2": "",
              "T2": "",
              "U2": "",
              "V2": "",
              "W2": ""
            },
            {
              "A3": "SUBSET SIGNATURE GENES",
              "B3": "Within TEC",
              "C3": "aaTEC1_sign  ",
              "D3": "Zbtb20",
              "E3": "Cd81",
              "F3": "Trpm3",
              "G3": "Gstm1",
              "H3": "Slc16a11",
              "I3": "Btg1",
              "J3": "BC006965",
              "K3": "Cldn3",
              "L3": "Gsta4",
              "M3": "S100a11",
              "N3": "Ly6e",
              "O3": "Cdk19",
              "P3": "Slc9a3r1",
              "Q3": "Ifi27l2a",
              "R3": "Aldoc",
              "S3": "Wfdc18",
              "T3": "Phlda1",
              "U3": "Fam107a",
              "V3": "Gsn",
              "W3": "Anxa2"
            },
            {
              "A4": "",
              "B4": "",
              "C4": "aaTEC2_sign  ",
              "D4": "Csmd1",
              "E4": "Zeb2",
              "F4": "Mgp",
              "G4": "Gsn",
              "H4": "Zbtb20",
              "I4": "Ndrg2",
              "J4": "Serpine2",
              "K4": "Cd81",
              "L4": "Fxyd1",
              "M4": "Laptm4a",
              "N4": "Gpx3",
              "O4": "Socs3",
              "P4": "Igfbp7",
              "Q4": "Airn",
              "R4": "Lgals1",
              "S4": "Fos",
              "T4": "Prrx1",
              "U4": "Prkg1",
              "V4": "Sparc",
              "W4": "Junb"
            },
            {
              "A5": "",
              "B5": "",
              "C5": "cTEC_sign  ",
              "D5": "Ctsl",
              "E5": "Cstb",
              "F5": "Cxcl12",
              "G5": "Prss16",
              "H5": "Krt18",
              "I5": "Gas6",
              "J5": "Pltp",
              "K5": "Slc46a2",
              "L5": "Ndufa11",
              "M5": "Tbata",
              "N5": "Ccl25",
              "O5": "Psmb11",
              "P5": "Tmem131l",
              "Q5": "Nlgn1",
              "R5": "Prxl2b",
              "S5": "Pax1",
              "T5": "Wnt4",
              "U5": "Dpp6",
              "V5": "Psmb9",
              "W5": "Bnip3l"
            },
            {
              "A6": "",
              "B6": "",
              "C6": "early_Pr",
              "D6": "Apoe",
              "E6": "Itm2b",
              "F6": "Dcn",
              "G6": "Gas6",
              "H6": "Gas1",
              "I6": "Rbms3",
              "J6": "Laptm4a",
              "K6": "Ctsl",
              "L6": "Cpne8",
              "M6": "Mir100hg",
              "N6": "Gas5",
              "O6": "Cst3",
              "P6": "Ly6a",
              "Q6": "Ifitm3",
              "R6": "Kazald1",
              "S6": "Mir99ahg",
              "T6": "Ifitm2",
              "U6": "Plpp3",
              "V6": "Oat",
              "W6": "Auts2"
            },
            {
              "A7": "",
              "B7": "",
              "C7": "mTEC1_sign  ",
              "D7": "Ccl21a",
              "E7": "Krt14",
              "F7": "Krt5",
              "G7": "Ifitm3",
              "H7": "Apoe",
              "I7": "Tpm2",
              "J7": "Cald1",
              "K7": "Ifi27l2a",
              "L7": "Ifitm2",
              "M7": "Krt17",
              "N7": "Nxn",
              "O7": "Ctsl",
              "P7": "Eya4",
              "Q7": "Rbms3",
              "R7": "Perp",
              "S7": "Ly6a",
              "T7": "Igfbp4",
              "U7": "Sult5a1",
              "V7": "Map1lc3a",
              "W7": "Ank3"
            },
            {
              "A8": "",
              "B8": "",
              "C8": "mTECprol_sign  ",
              "D8": "H2afz",
              "E8": "Stmn1",
              "F8": "Ran",
              "G8": "Eif5a",
              "H8": "Hmgb2",
              "I8": "Ube2s",
              "J8": "Ybx1",
              "K8": "Phgdh",
              "L8": "Ptma",
              "M8": "Selenoh",
              "N8": "Ppia",
              "O8": "Tubb5",
              "P8": "Nme1",
              "Q8": "Pfn1",
              "R8": "Ranbp1",
              "S8": "Hmgn2",
              "T8": "Hnrnpa1",
              "U8": "Rbm3",
              "V8": "Cks1b",
              "W8": "Banf1"
            },
            {
              "A9": "",
              "B9": "",
              "C9": "mTEC2_sign  ",
              "D9": "Srgn",
              "E9": "Ubd",
              "F9": "Cd52",
              "G9": "Cyba",
              "H9": "Cd74",
              "I9": "H2-Aa",
              "J9": "Syt1",
              "K9": "Csn2",
              "L9": "H2-Eb1",
              "M9": "S100a14",
              "N9": "H2-Oa",
              "O9": "H2-Eb2",
              "P9": "Hdc",
              "Q9": "Mrpl38",
              "R9": "Nfkbia",
              "S9": "Gm48239",
              "T9": "Aire",
              "U9": "Nup85",
              "V9": "Hagh",
              "W9": "Calcb"
            },
            {
              "A10": "",
              "B10": "",
              "C10": "basal_sign  ",
              "D10": "Ly6d",
              "E10": "Dmkn",
              "F10": "Spink5",
              "G10": "Fxyd3",
              "H10": "Skint3",
              "I10": "Dapl1",
              "J10": "Hspb1",
              "K10": "Sfn",
              "L10": "Tacstd2",
              "M10": "Pdzk1ip1",
              "N10": "Prdx5",
              "O10": "Oit1",
              "P10": "Cdkn2a",
              "Q10": "Perp",
              "R10": "Cdkn1a",
              "S10": "Cdkn2b",
              "T10": "Gsta4",
              "U10": "Atox1",
              "V10": "Lypd3",
              "W10": "Cst6"
            },
            {
              "A11": "",
              "B11": "",
              "C11": "tuft_sign  ",
              "D11": "Mctp1",
              "E11": "Gng13",
              "F11": "Avil",
              "G11": "Rgs13",
              "H11": "Espn",
              "I11": "Lrmp",
              "J11": "Anxa4",
              "K11": "Ltc4s",
              "L11": "Ptpn18",
              "M11": "Bmx",
              "N11": "Cystm1",
              "O11": "Ivns1abp",
              "P11": "Fyb",
              "Q11": "Ly6g6f",
              "R11": "Calm2",
              "S11": "Ethe1",
              "T11": "Reep5",
              "U11": "Lima1",
              "V11": "1810046K07Rik",
              "W11": "Abhd2"
            },
            {
              "A12": "",
              "B12": "",
              "C12": "nTEC_sign  ",
              "D12": "Ptprn2",
              "E12": "Cacna2d1",
              "F12": "Car8",
              "G12": "Scg5",
              "H12": "Stxbp5l",
              "I12": "Snap25",
              "J12": "Chga",
              "K12": "Cd9",
              "L12": "Dnajc12",
              "M12": "Ccser1",
              "N12": "Pam",
              "O12": "Camk2n1",
              "P12": "Syt7",
              "Q12": "Cacna1a",
              "R12": "Syt1",
              "S12": "Cacnb2",
              "T12": "Cystm1",
              "U12": "Fam183b",
              "V12": "Cplx2",
              "W12": "Ceacam10"
            },
            {
              "A13": "",
              "B13": "",
              "C13": "goblet_sign  ",
              "D13": "Wfdc2",
              "E13": "Cyp2f2",
              "F13": "Cxcl17",
              "G13": "Gsto1",
              "H13": "S100a11",
              "I13": "Nupr1",
              "J13": "Sorbs2",
              "K13": "Anxa3",
              "L13": "H2-K1",
              "M13": "Krt19",
              "N13": "Fxyd3",
              "O13": "Ly6d",
              "P13": "Ly6e",
              "Q13": "Serpinb11",
              "R13": "Slc12a2",
              "S13": "Anxa1",
              "T13": "Ly6a",
              "U13": "Bace2",
              "V13": "Aqp5",
              "W13": "Atp1b1"
            },
            {
              "A14": "",
              "B14": "",
              "C14": "Mlike_sign  ",
              "D14": "Ccl20",
              "E14": "Ccl9",
              "F14": "Serpinb6a",
              "G14": "Serpinb1a",
              "H14": "Tmsb4x",
              "I14": "2200002D01Rik",
              "J14": "Nostrin",
              "K14": "Ctsh",
              "L14": "Ccl6",
              "M14": "AW112010",
              "N14": "Spib",
              "O14": "Bcl2a1d",
              "P14": "Csn2",
              "Q14": "Cyp2a5",
              "R14": "Fabp1",
              "S14": "Hamp",
              "T14": "Pold1",
              "U14": "Bcl2a1b",
              "V14": "Atox1",
              "W14": "Iscu"
            },
            {
              "A15": "",
              "B15": "Within FB",
              "C15": "capsFB_sign  ",
              "D15": "Pi16",
              "E15": "Timp2",
              "F15": "Fn1",
              "G15": "Opcml",
              "H15": "Cd248",
              "I15": "Mfap5",
              "J15": "Anxa3",
              "K15": "Pcolce2",
              "L15": "Ackr3",
              "M15": "Fndc1",
              "N15": "Igfbp6",
              "O15": "Sema3c",
              "P15": "Clec3b",
              "Q15": "Creb5",
              "R15": "Smpd3",
              "S15": "Tmem100",
              "T15": "Adgrd1",
              "U15": "Ly6c1",
              "V15": "Pcsk6",
              "W15": "Nid1"
            },
            {
              "A16": "",
              "B16": "",
              "C16": "intFB_sign  ",
              "D16": "Smoc2",
              "E16": "Gpx3",
              "F16": "Penk",
              "G16": "Igf1",
              "H16": "Gas1",
              "I16": "Inmt",
              "J16": "Pcolce",
              "K16": "Lrp1",
              "L16": "Itm2a",
              "M16": "Gdf10",
              "N16": "Rbp1",
              "O16": "Fbln1",
              "P16": "Sfrp1",
              "Q16": "Slit3",
              "R16": "Svep1",
              "S16": "Auts2",
              "T16": "Lpl",
              "U16": "Celf2",
              "V16": "Serpinf1",
              "W16": "Il11ra1"
            },
            {
              "A17": "",
              "B17": "",
              "C17": "medFB_sign  ",
              "D17": "Csmd1",
              "E17": "Serpine2",
              "F17": "Enpp2",
              "G17": "Ptn",
              "H17": "Tmem176b",
              "I17": "Tmem176a",
              "J17": "B2m",
              "K17": "Ccl19",
              "L17": "Igfbp7",
              "M17": "Apod",
              "N17": "Bgn",
              "O17": "H2-D1",
              "P17": "Des",
              "Q17": "Ltc4s",
              "R17": "Lhfp",
              "S17": "Ifitm1",
              "T17": "Cd9",
              "U17": "Apoe",
              "V17": "Lsamp",
              "W17": "Ly6e"
            },
            {
              "A18": "",
              "B18": "Within EC",
              "C18": "artEC_sign  ",
              "D18": "Fbln5",
              "E18": "Stmn2",
              "F18": "Clu",
              "G18": "Sema3g",
              "H18": "Glul",
              "I18": "Tm4sf1",
              "J18": "Eps8l2",
              "K18": "Col8a1",
              "L18": "Nebl",
              "M18": "Vegfc",
              "N18": "Alpl",
              "O18": "Arl15",
              "P18": "Gja4",
              "Q18": "Edn1",
              "R18": "S100a6",
              "S18": "Mast4",
              "T18": "Sox17",
              "U18": "Pdgfd",
              "V18": "Fbln2",
              "W18": "Vim"
            },
            {
              "A19": "",
              "B19": "",
              "C19": "capEC_sign  ",
              "D19": "Gpihbp1",
              "E19": "Rgcc",
              "F19": "Fabp4",
              "G19": "Cd36",
              "H19": "Car4",
              "I19": "Mgll",
              "J19": "Cd300lg",
              "K19": "Tcf15",
              "L19": "Kdr",
              "M19": "Arhgap18",
              "N19": "Igfbp7",
              "O19": "Kank3",
              "P19": "Aqp7",
              "Q19": "Etl4",
              "R19": "Tspan13",
              "S19": "Cavin2",
              "T19": "Hspb1",
              "U19": "Ppp1r2",
              "V19": "Lims2",
              "W19": "Fabp5"
            },
            {
              "A20": "",
              "B20": "",
              "C20": "venEC_sign  ",
              "D20": "Lrg1",
              "E20": "Il6st",
              "F20": "Vwf",
              "G20": "Plvap",
              "H20": "mt-Co1",
              "I20": "Selp",
              "J20": "Spint2",
              "K20": "Pcdh7",
              "L20": "mt-Nd4",
              "M20": "2200002D01Rik",
              "N20": "Tmsb10",
              "O20": "Eef1a1",
              "P20": "mt-Co3",
              "Q20": "Bgn",
              "R20": "Pde4d",
              "S20": "mt-Atp6",
              "T20": "Aqp1",
              "U20": "Tpt1",
              "V20": "Ctla2a",
              "W20": "Ackr1"
            }
          ],
          "targeted_rows": [
            {
              "A5": "",
              "B5": "",
              "C5": "cTEC_sign  ",
              "D5": "Ctsl",
              "E5": "Cstb",
              "F5": "Cxcl12",
              "G5": "Prss16",
              "H5": "Krt18",
              "I5": "Gas6",
              "J5": "Pltp",
              "K5": "Slc46a2",
              "L5": "Ndufa11",
              "M5": "Tbata",
              "N5": "Ccl25",
              "O5": "Psmb11",
              "P5": "Tmem131l",
              "Q5": "Nlgn1",
              "R5": "Prxl2b",
              "S5": "Pax1",
              "T5": "Wnt4",
              "U5": "Dpp6",
              "V5": "Psmb9",
              "W5": "Bnip3l"
            },
            {
              "A9": "",
              "B9": "",
              "C9": "mTEC2_sign  ",
              "D9": "Srgn",
              "E9": "Ubd",
              "F9": "Cd52",
              "G9": "Cyba",
              "H9": "Cd74",
              "I9": "H2-Aa",
              "J9": "Syt1",
              "K9": "Csn2",
              "L9": "H2-Eb1",
              "M9": "S100a14",
              "N9": "H2-Oa",
              "O9": "H2-Eb2",
              "P9": "Hdc",
              "Q9": "Mrpl38",
              "R9": "Nfkbia",
              "S9": "Gm48239",
              "T9": "Aire",
              "U9": "Nup85",
              "V9": "Hagh",
              "W9": "Calcb"
            }
          ]
        },
        {
          "sheet": "Table 3 - top 20 markers (d147)",
          "source_rows": [
            {
              "C1": "SUBSETS",
              "D1": "MOUSE GENES",
              "E1": "",
              "F1": "",
              "G1": "",
              "H1": "",
              "I1": "",
              "J1": "",
              "K1": "",
              "L1": "",
              "M1": "",
              "N1": "",
              "O1": "",
              "P1": "",
              "Q1": "",
              "R1": "",
              "S1": "",
              "T1": "",
              "U1": "",
              "V1": "",
              "W1": ""
            },
            {
              "C2": "",
              "D2": "",
              "E2": "",
              "F2": "",
              "G2": "",
              "H2": "",
              "I2": "",
              "J2": "",
              "K2": "",
              "L2": "",
              "M2": "",
              "N2": "",
              "O2": "",
              "P2": "",
              "Q2": "",
              "R2": "",
              "S2": "",
              "T2": "",
              "U2": "",
              "V2": "",
              "W2": ""
            },
            {
              "A3": "SUBSET SIGNATURE GENES",
              "B3": "Within TEC",
              "C3": "aaTEC1_sign  ",
              "D3": "Zbtb20",
              "E3": "Cd81",
              "F3": "Trpm3",
              "G3": "Gstm1",
              "H3": "Slc16a11",
              "I3": "Btg1",
              "J3": "BC006965",
              "K3": "Cldn3",
              "L3": "Gsta4",
              "M3": "S100a11",
              "N3": "Ly6e",
              "O3": "Cdk19",
              "P3": "Slc9a3r1",
              "Q3": "Ifi27l2a",
              "R3": "Aldoc",
              "S3": "Wfdc18",
              "T3": "Phlda1",
              "U3": "Fam107a",
              "V3": "Gsn",
              "W3": "Anxa2"
            },
            {
              "A4": "",
              "B4": "",
              "C4": "aaTEC2_sign  ",
              "D4": "Csmd1",
              "E4": "Zeb2",
              "F4": "Mgp",
              "G4": "Gsn",
              "H4": "Zbtb20",
              "I4": "Ndrg2",
              "J4": "Serpine2",
              "K4": "Cd81",
              "L4": "Fxyd1",
              "M4": "Laptm4a",
              "N4": "Gpx3",
              "O4": "Socs3",
              "P4": "Igfbp7",
              "Q4": "Airn",
              "R4": "Lgals1",
              "S4": "Fos",
              "T4": "Prrx1",
              "U4": "Prkg1",
              "V4": "Sparc",
              "W4": "Junb"
            },
            {
              "A5": "",
              "B5": "",
              "C5": "cTEC_sign  ",
              "D5": "Ctsl",
              "E5": "Cstb",
              "F5": "Cxcl12",
              "G5": "Prss16",
              "H5": "Krt18",
              "I5": "Gas6",
              "J5": "Pltp",
              "K5": "Slc46a2",
              "L5": "Ndufa11",
              "M5": "Tbata",
              "N5": "Ccl25",
              "O5": "Psmb11",
              "P5": "Tmem131l",
              "Q5": "Nlgn1",
              "R5": "Prxl2b",
              "S5": "Pax1",
              "T5": "Wnt4",
              "U5": "Dpp6",
              "V5": "Psmb9",
              "W5": "Bnip3l"
            },
            {
              "A6": "",
              "B6": "",
              "C6": "early_Pr",
              "D6": "Apoe",
              "E6": "Itm2b",
              "F6": "Dcn",
              "G6": "Gas6",
              "H6": "Gas1",
              "I6": "Rbms3",
              "J6": "Laptm4a",
              "K6": "Ctsl",
              "L6": "Cpne8",
              "M6": "Mir100hg",
              "N6": "Gas5",
              "O6": "Cst3",
              "P6": "Ly6a",
              "Q6": "Ifitm3",
              "R6": "Kazald1",
              "S6": "Mir99ahg",
              "T6": "Ifitm2",
              "U6": "Plpp3",
              "V6": "Oat",
              "W6": "Auts2"
            },
            {
              "A7": "",
              "B7": "",
              "C7": "mTEC1_sign  ",
              "D7": "Ccl21a",
              "E7": "Krt14",
              "F7": "Krt5",
              "G7": "Ifitm3",
              "H7": "Apoe",
              "I7": "Tpm2",
              "J7": "Cald1",
              "K7": "Ifi27l2a",
              "L7": "Ifitm2",
              "M7": "Krt17",
              "N7": "Nxn",
              "O7": "Ctsl",
              "P7": "Eya4",
              "Q7": "Rbms3",
              "R7": "Perp",
              "S7": "Ly6a",
              "T7": "Igfbp4",
              "U7": "Sult5a1",
              "V7": "Map1lc3a",
              "W7": "Ank3"
            },
            {
              "A8": "",
              "B8": "",
              "C8": "mTECprol_sign  ",
              "D8": "H2afz",
              "E8": "Stmn1",
              "F8": "Ran",
              "G8": "Eif5a",
              "H8": "Hmgb2",
              "I8": "Ube2s",
              "J8": "Ybx1",
              "K8": "Phgdh",
              "L8": "Ptma",
              "M8": "Selenoh",
              "N8": "Ppia",
              "O8": "Tubb5",
              "P8": "Nme1",
              "Q8": "Pfn1",
              "R8": "Ranbp1",
              "S8": "Hmgn2",
              "T8": "Hnrnpa1",
              "U8": "Rbm3",
              "V8": "Cks1b",
              "W8": "Banf1"
            },
            {
              "A9": "",
              "B9": "",
              "C9": "mTEC2_sign  ",
              "D9": "Srgn",
              "E9": "Ubd",
              "F9": "Cd52",
              "G9": "Cyba",
              "H9": "Cd74",
              "I9": "H2-Aa",
              "J9": "Syt1",
              "K9": "Csn2",
              "L9": "H2-Eb1",
              "M9": "S100a14",
              "N9": "H2-Oa",
              "O9": "H2-Eb2",
              "P9": "Hdc",
              "Q9": "Mrpl38",
              "R9": "Nfkbia",
              "S9": "Gm48239",
              "T9": "Aire",
              "U9": "Nup85",
              "V9": "Hagh",
              "W9": "Calcb"
            },
            {
              "A10": "",
              "B10": "",
              "C10": "basal_sign  ",
              "D10": "Ly6d",
              "E10": "Dmkn",
              "F10": "Spink5",
              "G10": "Fxyd3",
              "H10": "Skint3",
              "I10": "Dapl1",
              "J10": "Hspb1",
              "K10": "Sfn",
              "L10": "Tacstd2",
              "M10": "Pdzk1ip1",
              "N10": "Prdx5",
              "O10": "Oit1",
              "P10": "Cdkn2a",
              "Q10": "Perp",
              "R10": "Cdkn1a",
              "S10": "Cdkn2b",
              "T10": "Gsta4",
              "U10": "Atox1",
              "V10": "Lypd3",
              "W10": "Cst6"
            },
            {
              "A11": "",
              "B11": "",
              "C11": "tuft_sign  ",
              "D11": "Mctp1",
              "E11": "Gng13",
              "F11": "Avil",
              "G11": "Rgs13",
              "H11": "Espn",
              "I11": "Lrmp",
              "J11": "Anxa4",
              "K11": "Ltc4s",
              "L11": "Ptpn18",
              "M11": "Bmx",
              "N11": "Cystm1",
              "O11": "Ivns1abp",
              "P11": "Fyb",
              "Q11": "Ly6g6f",
              "R11": "Calm2",
              "S11": "Ethe1",
              "T11": "Reep5",
              "U11": "Lima1",
              "V11": "1810046K07Rik",
              "W11": "Abhd2"
            },
            {
              "A12": "",
              "B12": "",
              "C12": "nTEC_sign  ",
              "D12": "Ptprn2",
              "E12": "Cacna2d1",
              "F12": "Car8",
              "G12": "Scg5",
              "H12": "Stxbp5l",
              "I12": "Snap25",
              "J12": "Chga",
              "K12": "Cd9",
              "L12": "Dnajc12",
              "M12": "Ccser1",
              "N12": "Pam",
              "O12": "Camk2n1",
              "P12": "Syt7",
              "Q12": "Cacna1a",
              "R12": "Syt1",
              "S12": "Cacnb2",
              "T12": "Cystm1",
              "U12": "Fam183b",
              "V12": "Cplx2",
              "W12": "Ceacam10"
            },
            {
              "A13": "",
              "B13": "",
              "C13": "goblet_sign  ",
              "D13": "Wfdc2",
              "E13": "Cyp2f2",
              "F13": "Cxcl17",
              "G13": "Gsto1",
              "H13": "S100a11",
              "I13": "Nupr1",
              "J13": "Sorbs2",
              "K13": "Anxa3",
              "L13": "H2-K1",
              "M13": "Krt19",
              "N13": "Fxyd3",
              "O13": "Ly6d",
              "P13": "Ly6e",
              "Q13": "Serpinb11",
              "R13": "Slc12a2",
              "S13": "Anxa1",
              "T13": "Ly6a",
              "U13": "Bace2",
              "V13": "Aqp5",
              "W13": "Atp1b1"
            },
            {
              "A14": "",
              "B14": "",
              "C14": "Mlike_sign  ",
              "D14": "Ccl20",
              "E14": "Ccl9",
              "F14": "Serpinb6a",
              "G14": "Serpinb1a",
              "H14": "Tmsb4x",
              "I14": "2200002D01Rik",
              "J14": "Nostrin",
              "K14": "Ctsh",
              "L14": "Ccl6",
              "M14": "AW112010",
              "N14": "Spib",
              "O14": "Bcl2a1d",
              "P14": "Csn2",
              "Q14": "Cyp2a5",
              "R14": "Fabp1",
              "S14": "Hamp",
              "T14": "Pold1",
              "U14": "Bcl2a1b",
              "V14": "Atox1",
              "W14": "Iscu"
            },
            {
              "A15": "",
              "B15": "Within FB",
              "C15": "capsFB_sign  ",
              "D15": "Pi16",
              "E15": "Timp2",
              "F15": "Fn1",
              "G15": "Opcml",
              "H15": "Cd248",
              "I15": "Mfap5",
              "J15": "Anxa3",
              "K15": "Pcolce2",
              "L15": "Ackr3",
              "M15": "Fndc1",
              "N15": "Igfbp6",
              "O15": "Sema3c",
              "P15": "Clec3b",
              "Q15": "Creb5",
              "R15": "Smpd3",
              "S15": "Tmem100",
              "T15": "Adgrd1",
              "U15": "Ly6c1",
              "V15": "Pcsk6",
              "W15": "Nid1"
            },
            {
              "A16": "",
              "B16": "",
              "C16": "intFB_sign  ",
              "D16": "Smoc2",
              "E16": "Gpx3",
              "F16": "Penk",
              "G16": "Igf1",
              "H16": "Gas1",
              "I16": "Inmt",
              "J16": "Pcolce",
              "K16": "Lrp1",
              "L16": "Itm2a",
              "M16": "Gdf10",
              "N16": "Rbp1",
              "O16": "Fbln1",
              "P16": "Sfrp1",
              "Q16": "Slit3",
              "R16": "Svep1",
              "S16": "Auts2",
              "T16": "Lpl",
              "U16": "Celf2",
              "V16": "Serpinf1",
              "W16": "Il11ra1"
            },
            {
              "A17": "",
              "B17": "",
              "C17": "medFB_sign  ",
              "D17": "Csmd1",
              "E17": "Serpine2",
              "F17": "Enpp2",
              "G17": "Ptn",
              "H17": "Tmem176b",
              "I17": "Tmem176a",
              "J17": "B2m",
              "K17": "Ccl19",
              "L17": "Igfbp7",
              "M17": "Apod",
              "N17": "Bgn",
              "O17": "H2-D1",
              "P17": "Des",
              "Q17": "Ltc4s",
              "R17": "Lhfp",
              "S17": "Ifitm1",
              "T17": "Cd9",
              "U17": "Apoe",
              "V17": "Lsamp",
              "W17": "Ly6e"
            },
            {
              "A18": "",
              "B18": "Within EC",
              "C18": "artEC_sign  ",
              "D18": "Fbln5",
              "E18": "Stmn2",
              "F18": "Clu",
              "G18": "Sema3g",
              "H18": "Glul",
              "I18": "Tm4sf1",
              "J18": "Eps8l2",
              "K18": "Col8a1",
              "L18": "Nebl",
              "M18": "Vegfc",
              "N18": "Alpl",
              "O18": "Arl15",
              "P18": "Gja4",
              "Q18": "Edn1",
              "R18": "S100a6",
              "S18": "Mast4",
              "T18": "Sox17",
              "U18": "Pdgfd",
              "V18": "Fbln2",
              "W18": "Vim"
            },
            {
              "A19": "",
              "B19": "",
              "C19": "capEC_sign  ",
              "D19": "Gpihbp1",
              "E19": "Rgcc",
              "F19": "Fabp4",
              "G19": "Cd36",
              "H19": "Car4",
              "I19": "Mgll",
              "J19": "Cd300lg",
              "K19": "Tcf15",
              "L19": "Kdr",
              "M19": "Arhgap18",
              "N19": "Igfbp7",
              "O19": "Kank3",
              "P19": "Aqp7",
              "Q19": "Etl4",
              "R19": "Tspan13",
              "S19": "Cavin2",
              "T19": "Hspb1",
              "U19": "Ppp1r2",
              "V19": "Lims2",
              "W19": "Fabp5"
            },
            {
              "A20": "",
              "B20": "",
              "C20": "venEC_sign  ",
              "D20": "Lrg1",
              "E20": "Il6st",
              "F20": "Vwf",
              "G20": "Plvap",
              "H20": "mt-Co1",
              "I20": "Selp",
              "J20": "Spint2",
              "K20": "Pcdh7",
              "L20": "mt-Nd4",
              "M20": "2200002D01Rik",
              "N20": "Tmsb10",
              "O20": "Eef1a1",
              "P20": "mt-Co3",
              "Q20": "Bgn",
              "R20": "Pde4d",
              "S20": "mt-Atp6",
              "T20": "Aqp1",
              "U20": "Tpt1",
              "V20": "Ctla2a",
              "W20": "Ackr1"
            }
          ],
          "targeted_rows": [
            {
              "A5": "",
              "B5": "",
              "C5": "cTEC_sign  ",
              "D5": "Ctsl",
              "E5": "Cstb",
              "F5": "Cxcl12",
              "G5": "Prss16",
              "H5": "Krt18",
              "I5": "Gas6",
              "J5": "Pltp",
              "K5": "Slc46a2",
              "L5": "Ndufa11",
              "M5": "Tbata",
              "N5": "Ccl25",
              "O5": "Psmb11",
              "P5": "Tmem131l",
              "Q5": "Nlgn1",
              "R5": "Prxl2b",
              "S5": "Pax1",
              "T5": "Wnt4",
              "U5": "Dpp6",
              "V5": "Psmb9",
              "W5": "Bnip3l"
            },
            {
              "A9": "",
              "B9": "",
              "C9": "mTEC2_sign  ",
              "D9": "Srgn",
              "E9": "Ubd",
              "F9": "Cd52",
              "G9": "Cyba",
              "H9": "Cd74",
              "I9": "H2-Aa",
              "J9": "Syt1",
              "K9": "Csn2",
              "L9": "H2-Eb1",
              "M9": "S100a14",
              "N9": "H2-Oa",
              "O9": "H2-Eb2",
              "P9": "Hdc",
              "Q9": "Mrpl38",
              "R9": "Nfkbia",
              "S9": "Gm48239",
              "T9": "Aire",
              "U9": "Nup85",
              "V9": "Hagh",
              "W9": "Calcb"
            }
          ]
        },
        {
          "sheet": "Table 3 - top 20 (human TEC)",
          "source_rows": [
            {
              "C1": "SUBSETS",
              "D1": "MOUSE GENES",
              "E1": "",
              "F1": "",
              "G1": "",
              "H1": "",
              "I1": "",
              "J1": "",
              "K1": "",
              "L1": "",
              "M1": "",
              "N1": "",
              "O1": "",
              "P1": "",
              "Q1": "",
              "R1": "",
              "S1": "",
              "T1": "",
              "U1": "",
              "V1": "",
              "W1": "",
              "X1": "",
              "Y1": "",
              "Z1": "",
              "AA1": "",
              "AB1": "",
              "AC1": "",
              "AD1": "",
              "AE1": "",
              "AF1": "",
              "AG1": ""
            },
            {
              "C2": "",
              "D2": "",
              "E2": "",
              "F2": "",
              "G2": "",
              "H2": "",
              "I2": "",
              "J2": "",
              "K2": "",
              "L2": "",
              "M2": "",
              "N2": "",
              "O2": "",
              "P2": "",
              "Q2": "",
              "R2": "",
              "S2": "",
              "T2": "",
              "U2": "",
              "V2": "",
              "W2": "",
              "X2": "",
              "Y2": "",
              "Z2": "",
              "AA2": "",
              "AB2": "",
              "AC2": "",
              "AD2": "",
              "AE2": "",
              "AF2": "",
              "AG2": ""
            },
            {
              "A3": "SUBSET SIGNATURE GENES",
              "B3": "Within TEC",
              "C3": "aaTEC1_sign  ",
              "D3": "Zbtb20",
              "E3": "Cd81",
              "F3": "Trpm3",
              "G3": "Gstm1",
              "H3": "Slc16a11",
              "I3": "Btg1",
              "J3": "BC006965",
              "K3": "Cldn3",
              "L3": "Gsta4",
              "M3": "S100a11",
              "N3": "Ly6e",
              "O3": "Cdk19",
              "P3": "Slc9a3r1",
              "Q3": "Ifi27l2a",
              "R3": "Aldoc",
              "S3": "Wfdc18",
              "T3": "Phlda1",
              "U3": "Fam107a",
              "V3": "Gsn",
              "W3": "Anxa2",
              "X3": "",
              "Y3": "",
              "Z3": "",
              "AA3": "",
              "AB3": "",
              "AC3": "",
              "AD3": "",
              "AE3": "",
              "AF3": "",
              "AG3": ""
            },
            {
              "A4": "",
              "B4": "",
              "C4": "aaTEC2_sign  ",
              "D4": "Csmd1",
              "E4": "Zeb2",
              "F4": "Mgp",
              "G4": "Gsn",
              "H4": "Zbtb20",
              "I4": "Ndrg2",
              "J4": "Serpine2",
              "K4": "Cd81",
              "L4": "Fxyd1",
              "M4": "Laptm4a",
              "N4": "Gpx3",
              "O4": "Socs3",
              "P4": "Igfbp7",
              "Q4": "Airn",
              "R4": "Lgals1",
              "S4": "Fos",
              "T4": "Prrx1",
              "U4": "Prkg1",
              "V4": "Sparc",
              "W4": "Junb",
              "X4": "",
              "Y4": "",
              "Z4": "",
              "AA4": "",
              "AB4": "",
              "AC4": "",
              "AD4": "",
              "AE4": "",
              "AF4": "",
              "AG4": ""
            },
            {
              "A5": "",
              "B5": "",
              "C5": "cTEC_sign  ",
              "D5": "Ctsl",
              "E5": "Cstb",
              "F5": "Cxcl12",
              "G5": "Prss16",
              "H5": "Krt18",
              "I5": "Gas6",
              "J5": "Pltp",
              "K5": "Slc46a2",
              "L5": "Ndufa11",
              "M5": "Tbata",
              "N5": "Ccl25",
              "O5": "Psmb11",
              "P5": "Tmem131l",
              "Q5": "Nlgn1",
              "R5": "Prxl2b",
              "S5": "Pax1",
              "T5": "Wnt4",
              "U5": "Dpp6",
              "V5": "Psmb9",
              "W5": "Bnip3l",
              "X5": "",
              "Y5": "",
              "Z5": "",
              "AA5": "",
              "AB5": "",
              "AC5": "",
              "AD5": "",
              "AE5": "",
              "AF5": "",
              "AG5": ""
            },
            {
              "A6": "",
              "B6": "",
              "C6": "early_Pr",
              "D6": "Apoe",
              "E6": "Itm2b",
              "F6": "Dcn",
              "G6": "Gas6",
              "H6": "Gas1",
              "I6": "Rbms3",
              "J6": "Laptm4a",
              "K6": "Ctsl",
              "L6": "Cpne8",
              "M6": "Mir100hg",
              "N6": "Gas5",
              "O6": "Cst3",
              "P6": "Ly6a",
              "Q6": "Ifitm3",
              "R6": "Kazald1",
              "S6": "Mir99ahg",
              "T6": "Ifitm2",
              "U6": "Plpp3",
              "V6": "Oat",
              "W6": "Auts2",
              "X6": "",
              "Y6": "",
              "Z6": "",
              "AA6": "",
              "AB6": "",
              "AC6": "",
              "AD6": "",
              "AE6": "",
              "AF6": "",
              "AG6": ""
            },
            {
              "A7": "",
              "B7": "",
              "C7": "mTEC1_sign  ",
              "D7": "Ccl21a",
              "E7": "Krt14",
              "F7": "Krt5",
              "G7": "Ifitm3",
              "H7": "Apoe",
              "I7": "Tpm2",
              "J7": "Cald1",
              "K7": "Ifi27l2a",
              "L7": "Ifitm2",
              "M7": "Krt17",
              "N7": "Nxn",
              "O7": "Ctsl",
              "P7": "Eya4",
              "Q7": "Rbms3",
              "R7": "Perp",
              "S7": "Ly6a",
              "T7": "Igfbp4",
              "U7": "Sult5a1",
              "V7": "Map1lc3a",
              "W7": "Ank3",
              "X7": "",
              "Y7": "",
              "Z7": "",
              "AA7": "",
              "AB7": "",
              "AC7": "",
              "AD7": "",
              "AE7": "",
              "AF7": "",
              "AG7": ""
            },
            {
              "A8": "",
              "B8": "",
              "C8": "mTECprol_sign  ",
              "D8": "H2afz",
              "E8": "Stmn1",
              "F8": "Ran",
              "G8": "Eif5a",
              "H8": "Hmgb2",
              "I8": "Ube2s",
              "J8": "Ybx1",
              "K8": "Phgdh",
              "L8": "Ptma",
              "M8": "Selenoh",
              "N8": "Ppia",
              "O8": "Tubb5",
              "P8": "Nme1",
              "Q8": "Pfn1",
              "R8": "Ranbp1",
              "S8": "Hmgn2",
              "T8": "Hnrnpa1",
              "U8": "Rbm3",
              "V8": "Cks1b",
              "W8": "Banf1",
              "X8": "",
              "Y8": "",
              "Z8": "",
              "AA8": "",
              "AB8": "",
              "AC8": "",
              "AD8": "",
              "AE8": "",
              "AF8": "",
              "AG8": ""
            },
            {
              "A9": "",
              "B9": "",
              "C9": "mTEC2_sign  ",
              "D9": "Srgn",
              "E9": "Ubd",
              "F9": "Cd52",
              "G9": "Cyba",
              "H9": "Cd74",
              "I9": "H2-Aa",
              "J9": "Syt1",
              "K9": "Csn2",
              "L9": "H2-Eb1",
              "M9": "S100a14",
              "N9": "H2-Oa",
              "O9": "H2-Eb2",
              "P9": "Hdc",
              "Q9": "Mrpl38",
              "R9": "Nfkbia",
              "S9": "Gm48239",
              "T9": "Aire",
              "U9": "Nup85",
              "V9": "Hagh",
              "W9": "Calcb",
              "X9": "",
              "Y9": "",
              "Z9": "",
              "AA9": "",
              "AB9": "",
              "AC9": "",
              "AD9": "",
              "AE9": "",
              "AF9": "",
              "AG9": ""
            },
            {
              "A10": "",
              "B10": "",
              "C10": "basal_sign  ",
              "D10": "Ly6d",
              "E10": "Dmkn",
              "F10": "Spink5",
              "G10": "Fxyd3",
              "H10": "Skint3",
              "I10": "Dapl1",
              "J10": "Hspb1",
              "K10": "Sfn",
              "L10": "Tacstd2",
              "M10": "Pdzk1ip1",
              "N10": "Prdx5",
              "O10": "Oit1",
              "P10": "Cdkn2a",
              "Q10": "Perp",
              "R10": "Cdkn1a",
              "S10": "Cdkn2b",
              "T10": "Gsta4",
              "U10": "Atox1",
              "V10": "Lypd3",
              "W10": "Cst6",
              "X10": "",
              "Y10": "",
              "Z10": "",
              "AA10": "",
              "AB10": "",
              "AC10": "",
              "AD10": "",
              "AE10": "",
              "AF10": "",
              "AG10": ""
            },
            {
              "A11": "",
              "B11": "",
              "C11": "tuft_sign  ",
              "D11": "Mctp1",
              "E11": "Gng13",
              "F11": "Avil",
              "G11": "Rgs13",
              "H11": "Espn",
              "I11": "Lrmp",
              "J11": "Anxa4",
              "K11": "Ltc4s",
              "L11": "Ptpn18",
              "M11": "Bmx",
              "N11": "Cystm1",
              "O11": "Ivns1abp",
              "P11": "Fyb",
              "Q11": "Ly6g6f",
              "R11": "Calm2",
              "S11": "Ethe1",
              "T11": "Reep5",
              "U11": "Lima1",
              "V11": "1810046K07Rik",
              "W11": "Abhd2",
              "X11": "",
              "Y11": "",
              "Z11": "",
              "AA11": "",
              "AB11": "",
              "AC11": "",
              "AD11": "",
              "AE11": "",
              "AF11": "",
              "AG11": ""
            },
            {
              "A12": "",
              "B12": "",
              "C12": "nTEC_sign  ",
              "D12": "Ptprn2",
              "E12": "Cacna2d1",
              "F12": "Car8",
              "G12": "Scg5",
              "H12": "Stxbp5l",
              "I12": "Snap25",
              "J12": "Chga",
              "K12": "Cd9",
              "L12": "Dnajc12",
              "M12": "Ccser1",
              "N12": "Pam",
              "O12": "Camk2n1",
              "P12": "Syt7",
              "Q12": "Cacna1a",
              "R12": "Syt1",
              "S12": "Cacnb2",
              "T12": "Cystm1",
              "U12": "Fam183b",
              "V12": "Cplx2",
              "W12": "Ceacam10",
              "X12": "",
              "Y12": "",
              "Z12": "",
              "AA12": "",
              "AB12": "",
              "AC12": "",
              "AD12": "",
              "AE12": "",
              "AF12": "",
              "AG12": ""
            },
            {
              "A13": "",
              "B13": "",
              "C13": "goblet_sign  ",
              "D13": "Wfdc2",
              "E13": "Cyp2f2",
              "F13": "Cxcl17",
              "G13": "Gsto1",
              "H13": "S100a11",
              "I13": "Nupr1",
              "J13": "Sorbs2",
              "K13": "Anxa3",
              "L13": "H2-K1",
              "M13": "Krt19",
              "N13": "Fxyd3",
              "O13": "Ly6d",
              "P13": "Ly6e",
              "Q13": "Serpinb11",
              "R13": "Slc12a2",
              "S13": "Anxa1",
              "T13": "Ly6a",
              "U13": "Bace2",
              "V13": "Aqp5",
              "W13": "Atp1b1",
              "X13": "",
              "Y13": "",
              "Z13": "",
              "AA13": "",
              "AB13": "",
              "AC13": "",
              "AD13": "",
              "AE13": "",
              "AF13": "",
              "AG13": ""
            },
            {
              "A14": "",
              "B14": "",
              "C14": "Mlike_sign  ",
              "D14": "Ccl20",
              "E14": "Ccl9",
              "F14": "Serpinb6a",
              "G14": "Serpinb1a",
              "H14": "Tmsb4x",
              "I14": "2200002D01Rik",
              "J14": "Nostrin",
              "K14": "Ctsh",
              "L14": "Ccl6",
              "M14": "AW112010",
              "N14": "Spib",
              "O14": "Bcl2a1d",
              "P14": "Csn2",
              "Q14": "Cyp2a5",
              "R14": "Fabp1",
              "S14": "Hamp",
              "T14": "Pold1",
              "U14": "Bcl2a1b",
              "V14": "Atox1",
              "W14": "Iscu",
              "X14": "",
              "Y14": "",
              "Z14": "",
              "AA14": "",
              "AB14": "",
              "AC14": "",
              "AD14": "",
              "AE14": "",
              "AF14": "",
              "AG14": ""
            },
            {
              "A15": "",
              "B15": "Within FB",
              "C15": "capsFB_sign  ",
              "D15": "Pi16",
              "E15": "Timp2",
              "F15": "Fn1",
              "G15": "Opcml",
              "H15": "Cd248",
              "I15": "Mfap5",
              "J15": "Anxa3",
              "K15": "Pcolce2",
              "L15": "Ackr3",
              "M15": "Fndc1",
              "N15": "Igfbp6",
              "O15": "Sema3c",
              "P15": "Clec3b",
              "Q15": "Creb5",
              "R15": "Smpd3",
              "S15": "Tmem100",
              "T15": "Adgrd1",
              "U15": "Ly6c1",
              "V15": "Pcsk6",
              "W15": "Nid1",
              "X15": "",
              "Y15": "",
              "Z15": "",
              "AA15": "",
              "AB15": "",
              "AC15": "",
              "AD15": "",
              "AE15": "",
              "AF15": "",
              "AG15": ""
            },
            {
              "A16": "",
              "B16": "",
              "C16": "intFB_sign  ",
              "D16": "Smoc2",
              "E16": "Gpx3",
              "F16": "Penk",
              "G16": "Igf1",
              "H16": "Gas1",
              "I16": "Inmt",
              "J16": "Pcolce",
              "K16": "Lrp1",
              "L16": "Itm2a",
              "M16": "Gdf10",
              "N16": "Rbp1",
              "O16": "Fbln1",
              "P16": "Sfrp1",
              "Q16": "Slit3",
              "R16": "Svep1",
              "S16": "Auts2",
              "T16": "Lpl",
              "U16": "Celf2",
              "V16": "Serpinf1",
              "W16": "Il11ra1",
              "X16": "",
              "Y16": "",
              "Z16": "",
              "AA16": "",
              "AB16": "",
              "AC16": "",
              "AD16": "",
              "AE16": "",
              "AF16": "",
              "AG16": ""
            },
            {
              "A17": "",
              "B17": "",
              "C17": "medFB_sign  ",
              "D17": "Csmd1",
              "E17": "Serpine2",
              "F17": "Enpp2",
              "G17": "Ptn",
              "H17": "Tmem176b",
              "I17": "Tmem176a",
              "J17": "B2m",
              "K17": "Ccl19",
              "L17": "Igfbp7",
              "M17": "Apod",
              "N17": "Bgn",
              "O17": "H2-D1",
              "P17": "Des",
              "Q17": "Ltc4s",
              "R17": "Lhfp",
              "S17": "Ifitm1",
              "T17": "Cd9",
              "U17": "Apoe",
              "V17": "Lsamp",
              "W17": "Ly6e",
              "X17": "",
              "Y17": "",
              "Z17": "",
              "AA17": "",
              "AB17": "",
              "AC17": "",
              "AD17": "",
              "AE17": "",
              "AF17": "",
              "AG17": ""
            },
            {
              "A18": "",
              "B18": "Within EC",
              "C18": "artEC_sign  ",
              "D18": "Fbln5",
              "E18": "Stmn2",
              "F18": "Clu",
              "G18": "Sema3g",
              "H18": "Glul",
              "I18": "Tm4sf1",
              "J18": "Eps8l2",
              "K18": "Col8a1",
              "L18": "Nebl",
              "M18": "Vegfc",
              "N18": "Alpl",
              "O18": "Arl15",
              "P18": "Gja4",
              "Q18": "Edn1",
              "R18": "S100a6",
              "S18": "Mast4",
              "T18": "Sox17",
              "U18": "Pdgfd",
              "V18": "Fbln2",
              "W18": "Vim",
              "X18": "",
              "Y18": "",
              "Z18": "",
              "AA18": "",
              "AB18": "",
              "AC18": "",
              "AD18": "",
              "AE18": "",
              "AF18": "",
              "AG18": ""
            },
            {
              "A19": "",
              "B19": "",
              "C19": "capEC_sign  ",
              "D19": "Gpihbp1",
              "E19": "Rgcc",
              "F19": "Fabp4",
              "G19": "Cd36",
              "H19": "Car4",
              "I19": "Mgll",
              "J19": "Cd300lg",
              "K19": "Tcf15",
              "L19": "Kdr",
              "M19": "Arhgap18",
              "N19": "Igfbp7",
              "O19": "Kank3",
              "P19": "Aqp7",
              "Q19": "Etl4",
              "R19": "Tspan13",
              "S19": "Cavin2",
              "T19": "Hspb1",
              "U19": "Ppp1r2",
              "V19": "Lims2",
              "W19": "Fabp5",
              "X19": "",
              "Y19": "",
              "Z19": "",
              "AA19": "",
              "AB19": "",
              "AC19": "",
              "AD19": "",
              "AE19": "",
              "AF19": "",
              "AG19": ""
            },
            {
              "A20": "",
              "B20": "",
              "C20": "venEC_sign  ",
              "D20": "Lrg1",
              "E20": "Il6st",
              "F20": "Vwf",
              "G20": "Plvap",
              "H20": "mt-Co1",
              "I20": "Selp",
              "J20": "Spint2",
              "K20": "Pcdh7",
              "L20": "mt-Nd4",
              "M20": "2200002D01Rik",
              "N20": "Tmsb10",
              "O20": "Eef1a1",
              "P20": "mt-Co3",
              "Q20": "Bgn",
              "R20": "Pde4d",
              "S20": "mt-Atp6",
              "T20": "Aqp1",
              "U20": "Tpt1",
              "V20": "Ctla2a",
              "W20": "Ackr1",
              "X20": "",
              "Y20": "",
              "Z20": "",
              "AA20": "",
              "AB20": "",
              "AC20": "",
              "AD20": "",
              "AE20": "",
              "AF20": "",
              "AG20": ""
            },
            {
              "A21": "",
              "B21": "",
              "C21": "",
              "D21": "",
              "E21": "",
              "F21": "",
              "G21": "",
              "H21": "",
              "I21": "",
              "J21": "",
              "K21": "",
              "L21": "",
              "M21": "",
              "N21": "",
              "O21": "",
              "P21": "",
              "Q21": "",
              "R21": "",
              "S21": "",
              "T21": "",
              "U21": "",
              "V21": "",
              "W21": "",
              "X21": "",
              "Y21": "",
              "Z21": "",
              "AA21": "",
              "AB21": "",
              "AC21": "",
              "AD21": "",
              "AE21": "",
              "AF21": "",
              "AG21": ""
            },
            {
              "C23": "SUBSETS",
              "D23": "HUMAN ORTHOLOGUE GENES",
              "E23": "",
              "F23": "",
              "G23": "",
              "H23": "",
              "I23": "",
              "J23": "",
              "K23": "",
              "L23": "",
              "M23": "",
              "N23": "",
              "O23": "",
              "P23": "",
              "Q23": "",
              "R23": "",
              "S23": "",
              "T23": "",
              "U23": "",
              "V23": "",
              "W23": "",
              "X23": "",
              "Y23": "",
              "Z23": "",
              "AA23": "",
              "AB23": "",
              "AC23": "",
              "AD23": "",
              "AE23": "",
              "AF23": "",
              "AG23": ""
            },
            {
              "A24": "",
              "B24": "",
              "C24": "",
              "D24": "",
              "E24": "",
              "F24": "",
              "G24": "",
              "H24": "",
              "I24": "",
              "J24": "",
              "K24": "",
              "L24": "",
              "M24": "",
              "N24": "",
              "O24": "",
              "P24": "",
              "Q24": "",
              "R24": "",
              "S24": "",
              "T24": "",
              "U24": "",
              "V24": "",
              "W24": "",
              "X24": "",
              "Y24": "",
              "Z24": "",
              "AA24": "",
              "AB24": "",
              "AC24": "",
              "AD24": "",
              "AE24": "",
              "AF24": "",
              "AG24": ""
            },
            {
              "A25": "SUBSET SIGNATURE GENES",
              "B25": "Within TEC",
              "C25": "aaTEC1_sign  ",
              "D25": "ZBTB20",
              "E25": "CD81",
              "F25": "TRPM3",
              "G25": "GSTM1",
              "H25": "SLC16A11",
              "I25": "BTG1",
              "J25": "---------------",
              "K25": "CLDN3",
              "L25": "GSTA4",
              "M25": "S100A11",
              "N25": "LY6E",
              "O25": "CDK19",
              "P25": "SLC9A3R1",
              "Q25": "IFI27",
              "R25": "ALDOC",
              "S25": "---------------",
              "T25": "PHLDA1",
              "U25": "FAM107A",
              "V25": "GSN",
              "W25": "ANXA2"
            },
            {
              "A26": "",
              "B26": "",
              "C26": "aaTEC2_sign  ",
              "D26": "CSMD1",
              "E26": "ZEB2",
              "F26": "MGP",
              "G26": "GSN",
              "H26": "ZBTB20",
              "I26": "NDRG2",
              "J26": "SERPINE2",
              "K26": "CD81",
              "L26": "FXYD1",
              "M26": "LAPTM4A",
              "N26": "GPX3",
              "O26": "SOCS3",
              "P26": "IGFBP7",
              "Q26": "AIRN",
              "R26": "LGALS1",
              "S26": "FOS",
              "T26": "PRRX1",
              "U26": "PRKG1",
              "V26": "SPARC",
              "W26": "JUNB"
            },
            {
              "A27": "",
              "B27": "",
              "C27": "cTEC_sign  ",
              "D27": "CTSL",
              "E27": "CSTB",
              "F27": "CXCL12",
              "G27": "PRSS16",
              "H27": "KRT18",
              "I27": "GAS6",
              "J27": "PLTP",
              "K27": "SLC46A2",
              "L27": "NDUFA11",
              "M27": "TBATA",
              "N27": "CCL25",
              "O27": "PSMB11",
              "P27": "TMEM131L",
              "Q27": "NLGN1",
              "R27": "FAM213B",
              "S27": "PAX1",
              "T27": "WNT4",
              "U27": "DPP6",
              "V27": "PSMB9",
              "W27": "BNIP3L"
            },
            {
              "A28": "",
              "B28": "",
              "C28": "early_Pr",
              "D28": "APOE",
              "E28": "ITM2B",
              "F28": "DCN",
              "G28": "GAS6",
              "H28": "GAS1",
              "I28": "RBMS3",
              "J28": "LAPTM4A",
              "K28": "CTSL",
              "L28": "CPNE8",
              "M28": "MIR100HG",
              "N28": "GAS5",
              "O28": "CST3",
              "P28": "---------------",
              "Q28": "IFITM3",
              "R28": "KAZALD1",
              "S28": "MIR99AHG",
              "T28": "IFITM2",
              "U28": "PLPP3",
              "V28": "OAT",
              "W28": "AUTS2"
            },
            {
              "A29": "",
              "B29": "",
              "C29": "mTEC1_sign  ",
              "D29": "CCL21A",
              "E29": "KRT14",
              "F29": "KRT5",
              "G29": "IFITM3",
              "H29": "APOE",
              "I29": "TPM2",
              "J29": "CALD1",
              "K29": "IFI27",
              "L29": "IFITM2",
              "M29": "KRT17",
              "N29": "NXN",
              "O29": "CTSL",
              "P29": "EYA4",
              "Q29": "RBMS3",
              "R29": "PERP",
              "S29": "---------------",
              "T29": "IGFBP4",
              "U29": "---------------",
              "V29": "MAP1LC3A",
              "W29": "ANK3"
            },
            {
              "A30": "",
              "B30": "",
              "C30": "mTECprol_sign  ",
              "D30": "H2AFZ",
              "E30": "STMN1",
              "F30": "RAN",
              "G30": "EIF5A",
              "H30": "HMGB2",
              "I30": "UBE2S",
              "J30": "YBX1",
              "K30": "PHGDH",
              "L30": "PTMA",
              "M30": "SELENOH",
              "N30": "PPIA",
              "O30": "TUBB",
              "P30": "NME1",
              "Q30": "PFN1",
              "R30": "RANBP1",
              "S30": "HMGN2",
              "T30": "HNRNPA1",
              "U30": "RBM3",
              "V30": "CKS1B",
              "W30": "BANF1"
            },
            {
              "A31": "",
              "B31": "",
              "C31": "mTEC2_sign  ",
              "D31": "SRGN",
              "E31": "UBD",
              "F31": "CD52",
              "G31": "CYBA",
              "H31": "CD74",
              "I31": "HLA-DQA1",
              "J31": "SYT1",
              "K31": "CSN2",
              "L31": "HLA-DRB1",
              "M31": "S100A14",
              "N31": "HLA-DOA",
              "O31": "HLA-DRB1",
              "P31": "HDC",
              "Q31": "MRPL38",
              "R31": "NFKBIA",
              "S31": "---------------",
              "T31": "AIRE",
              "U31": "NUP85",
              "V31": "HAGH",
              "W31": "CALCB"
            },
            {
              "A32": "",
              "B32": "",
              "C32": "basal_sign  ",
              "D32": "LY6D",
              "E32": "DMKN",
              "F32": "SPINK5",
              "G32": "FXYD3",
              "H32": "---------------",
              "I32": "DAPL1",
              "J32": "HSPB1",
              "K32": "SFN",
              "L32": "TACSTD2",
              "M32": "PDZK1IP1",
              "N32": "PRDX5",
              "O32": "FAM3D",
              "P32": "CDKN2A",
              "Q32": "PERP",
              "R32": "CDKN1A",
              "S32": "CDKN2B",
              "T32": "GSTA4",
              "U32": "ATOX1",
              "V32": "LYPD3",
              "W32": "CST6"
            },
            {
              "A33": "",
              "B33": "",
              "C33": "tuft_sign  ",
              "D33": "MCTP1",
              "E33": "GNG13",
              "F33": "AVIL",
              "G33": "RGS13",
              "H33": "ESPN",
              "I33": "LRMP",
              "J33": "ANXA4",
              "K33": "LTC4S",
              "L33": "PTPN18",
              "M33": "BMX",
              "N33": "CYSTM1",
              "O33": "IVNS1ABP",
              "P33": "FYB",
              "Q33": "LY6G6F",
              "R33": "CALM2",
              "S33": "ETHE1",
              "T33": "REEP5",
              "U33": "LIMA1",
              "V33": "POU2AF2",
              "W33": "ABHD2"
            },
            {
              "A34": "",
              "B34": "",
              "C34": "nTEC_sign  ",
              "D34": "PTPRN2",
              "E34": "CACNA2D1",
              "F34": "CA8",
              "G34": "SCG5",
              "H34": "STXBP5L",
              "I34": "SNAP25",
              "J34": "CHGA",
              "K34": "CD9",
              "L34": "DNAJC12",
              "M34": "CCSER1",
              "N34": "PAM",
              "O34": "CAMK2N1",
              "P34": "SYT7",
              "Q34": "CACNA1A",
              "R34": "SYT1",
              "S34": "CACNB2",
              "T34": "CYSTM1",
              "U34": "FAM183B",
              "V34": "CPLX2",
              "W34": "CEACAM10"
            },
            {
              "A35": "",
              "B35": "",
              "C35": "goblet_sign  ",
              "D35": "WFDC2",
              "E35": "CYP2F1",
              "F35": "CXCL17",
              "G35": "GSTO1",
              "H35": "S100A11",
              "I35": "NUPR1",
              "J35": "SORBS2",
              "K35": "ANXA3",
              "L35": "HLA-A",
              "M35": "KRT19",
              "N35": "FXYD3",
              "O35": "LY6D",
              "P35": "LY6E",
              "Q35": "SERPINB11",
              "R35": "SLC12A2",
              "S35": "ANXA1",
              "T35": "---------------",
              "U35": "BACE2",
              "V35": "AQP5",
              "W35": "ATP1B1"
            },
            {
              "A36": "",
              "B36": "",
              "C36": "Mlike_sign  ",
              "D36": "CCL20",
              "E36": "CCL15",
              "F36": "SERPINB6",
              "G36": "SERPINB1",
              "H36": "TMSB4X",
              "I36": "2200002D01RIK",
              "J36": "NOSTRIN",
              "K36": "CTSH",
              "L36": "CCL23",
              "M36": "---------------",
              "N36": "SPIB",
              "O36": "BCL2A1",
              "P36": "CSN2",
              "Q36": "H2RSP",
              "R36": "FABP1",
              "S36": "HAMP",
              "T36": "POLD1",
              "U36": "BCL2A1B",
              "V36": "ATOX1",
              "W36": "ISCU"
            },
            {
              "A37": "",
              "B37": "Within FB",
              "C37": "capsFB_sign  ",
              "D37": "PI16",
              "E37": "TIMP2",
              "F37": "FN1",
              "G37": "OPCML",
              "H37": "CD248",
              "I37": "MFAP5",
              "J37": "ANXA3",
              "K37": "PCOLCE2",
              "L37": "ACKR3",
              "M37": "FNDC1",
              "N37": "IGFBP6",
              "O37": "SEMA3C",
              "P37": "CLEC3B",
              "Q37": "CREB5",
              "R37": "SMPD3",
              "S37": "TMEM100",
              "T37": "ADGRD1",
              "U37": "---------------",
              "V37": "PCSK6",
              "W37": "NID1"
            },
            {
              "A38": "",
              "B38": "",
              "C38": "intFB_sign  ",
              "D38": "SMOC2",
              "E38": "GPX3",
              "F38": "PENK",
              "G38": "IGF1",
              "H38": "GAS1",
              "I38": "INMT",
              "J38": "PCOLCE",
              "K38": "LRP1",
              "L38": "ITM2A",
              "M38": "GDF10",
              "N38": "RBP1",
              "O38": "FBLN1",
              "P38": "SFRP1",
              "Q38": "SLIT3",
              "R38": "SVEP1",
              "S38": "AUTS2",
              "T38": "LPL",
              "U38": "CELF2",
              "V38": "SERPINF1",
              "W38": "IL11RA1"
            },
            {
              "A39": "",
              "B39": "",
              "C39": "medFB_sign  ",
              "D39": "CSMD1",
              "E39": "SERPINE2",
              "F39": "ENPP2",
              "G39": "PTN",
              "H39": "TMEM176B",
              "I39": "TMEM176A",
              "J39": "B2M",
              "K39": "CCL19",
              "L39": "IGFBP7",
              "M39": "APOD",
              "N39": "BGN",
              "O39": "HLA-A",
              "P39": "DES",
              "Q39": "LTC4S",
              "R39": "LHFP",
              "S39": "IFITM1",
              "T39": "CD9",
              "U39": "APOE",
              "V39": "LSAMP",
              "W39": "LY6E"
            },
            {
              "A40": "",
              "B40": "Within EC",
              "C40": "artEC_sign  ",
              "D40": "FBLN5",
              "E40": "STMN2",
              "F40": "CLU",
              "G40": "SEMA3G",
              "H40": "GLUL",
              "I40": "TM4SF1",
              "J40": "EPS8L2",
              "K40": "COL8A1",
              "L40": "NEBL",
              "M40": "VEGFC",
              "N40": "ALPL",
              "O40": "ARL15",
              "P40": "GJA4",
              "Q40": "EDN1",
              "R40": "S100A6",
              "S40": "MAST4",
              "T40": "SOX17",
              "U40": "PDGFD",
              "V40": "FBLN2",
              "W40": "VIM"
            },
            {
              "A41": "",
              "B41": "",
              "C41": "capEC_sign  ",
              "D41": "GPIHBP1",
              "E41": "RGCC",
              "F41": "FABP4",
              "G41": "CD36",
              "H41": "CA4",
              "I41": "MGLL",
              "J41": "CD300LG",
              "K41": "TCF15",
              "L41": "KDR",
              "M41": "ARHGAP18",
              "N41": "IGFBP7",
              "O41": "KANK3",
              "P41": "AQP7",
              "Q41": "KIAA1217",
              "R41": "TSPAN13",
              "S41": "CAVIN2",
              "T41": "HSPB1",
              "U41": "PPP1R2",
              "V41": "LIMS2",
              "W41": "FABP5"
            },
            {
              "A42": "",
              "B42": "",
              "C42": "venEC_sign  ",
              "D42": "LRG1",
              "E42": "IL6ST",
              "F42": "VWF",
              "G42": "PLVAP",
              "H42": "MT-CO1",
              "I42": "SELP",
              "J42": "SPINT2",
              "K42": "PCDH7",
              "L42": "MT-ND4",
              "M42": "H2RSP",
              "N42": "TMSB10",
              "O42": "EEF1A1",
              "P42": "MT-CO3",
              "Q42": "BGN",
              "R42": "PDE4D",
              "S42": "MT-ATP6",
              "T42": "AQP1",
              "U42": "TPT1",
              "V42": "---------------",
              "W42": "ACKR1"
            },
            {
              "A48": "---------------",
              "B48": "",
              "C48": "= no available orthologue",
              "D48": "",
              "E48": "",
              "F48": "",
              "G48": ""
            },
            {
              "A49": "GENE X;GENE Y",
              "B49": "",
              "C49": "= orthogue gene(s) different to the mouse annotation",
              "D49": "",
              "E49": "",
              "F49": "",
              "G49": ""
            }
          ],
          "targeted_rows": [
            {
              "A5": "",
              "B5": "",
              "C5": "cTEC_sign  ",
              "D5": "Ctsl",
              "E5": "Cstb",
              "F5": "Cxcl12",
              "G5": "Prss16",
              "H5": "Krt18",
              "I5": "Gas6",
              "J5": "Pltp",
              "K5": "Slc46a2",
              "L5": "Ndufa11",
              "M5": "Tbata",
              "N5": "Ccl25",
              "O5": "Psmb11",
              "P5": "Tmem131l",
              "Q5": "Nlgn1",
              "R5": "Prxl2b",
              "S5": "Pax1",
              "T5": "Wnt4",
              "U5": "Dpp6",
              "V5": "Psmb9",
              "W5": "Bnip3l",
              "X5": "",
              "Y5": "",
              "Z5": "",
              "AA5": "",
              "AB5": "",
              "AC5": "",
              "AD5": "",
              "AE5": "",
              "AF5": "",
              "AG5": ""
            },
            {
              "A9": "",
              "B9": "",
              "C9": "mTEC2_sign  ",
              "D9": "Srgn",
              "E9": "Ubd",
              "F9": "Cd52",
              "G9": "Cyba",
              "H9": "Cd74",
              "I9": "H2-Aa",
              "J9": "Syt1",
              "K9": "Csn2",
              "L9": "H2-Eb1",
              "M9": "S100a14",
              "N9": "H2-Oa",
              "O9": "H2-Eb2",
              "P9": "Hdc",
              "Q9": "Mrpl38",
              "R9": "Nfkbia",
              "S9": "Gm48239",
              "T9": "Aire",
              "U9": "Nup85",
              "V9": "Hagh",
              "W9": "Calcb",
              "X9": "",
              "Y9": "",
              "Z9": "",
              "AA9": "",
              "AB9": "",
              "AC9": "",
              "AD9": "",
              "AE9": "",
              "AF9": "",
              "AG9": ""
            }
          ]
        }
      ]
    },
    {
      "result_id": "A144-R20261012-O06",
      "experiment_id": "A144-R20261012-E03",
      "sample_class_ids": [
        "A144-R20261012-G07",
        "A144-R20261012-G08"
      ],
      "metric": "边界",
      "reported_result": "转录签名、流式DN-TEC和HD形态的对应为多源推断，非单一共同测量。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_inference_scope",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR06"
      ],
      "record_type": "author_interpretation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O07",
      "experiment_id": "A144-R20261012-E04",
      "sample_class_ids": [
        "A144-R20261012-G09"
      ],
      "metric": "报告谱系",
      "reported_result": "老年GFP+出现EpCAM+ DN与EpCAM−群；claudin3和PDPN分别支持aaTEC1/2标记。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3a–e; Results lineage",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR07"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O08",
      "experiment_id": "A144-R20261012-E04",
      "sample_class_ids": [
        "A144-R20261012-G11"
      ],
      "metric": "轨迹限定",
      "reported_result": "RNA velocity提示mTEC1/early-prog向aaTEC方向；不是直接逐细胞纵向追踪。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3f,g; Discussion lineage caveat",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR08"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O09",
      "experiment_id": "A144-R20261012-E05",
      "sample_class_ids": [
        "A144-R20261012-G12",
        "A144-R20261012-G13",
        "A144-R20261012-G14"
      ],
      "metric": "胸腺细胞分布",
      "reported_result": "aaTEC富集区域缺乏胸腺细胞；人体材料见相似富上皮区域。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3h–k; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-7",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n",
          "applicable_sample_ids": [
            "A144-R20261012-G12"
          ],
          "supports_scope": "mouse representative spatial exclusion only; not human tissue or exact depletion fraction"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR09"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O10",
      "experiment_id": "A144-R20261012-E05",
      "sample_class_ids": [
        "A144-R20261012-G13",
        "A144-R20261012-G14"
      ],
      "metric": "人体适用限制",
      "reported_result": "既有人数据可见aaTEC签名；claudin3/PDPN在人组织识别的有效性仍待确认。 Fig3h–k为50岁女性连续H&E/panCK/CD1a切片；ED5人整合115536 CD45−/40144TEC均为细胞数，不是患者n。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results human TEC paragraph",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3h–k/ED5d–f",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR10"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O11",
      "experiment_id": "A144-R20261012-E06",
      "sample_class_ids": [
        "A144-R20261012-G15",
        "A144-R20261012-G16"
      ],
      "metric": "分子背景",
      "reported_result": "年龄效应具有细胞谱系差异，FB中的炎症/衰老相关程序是作者主要背景解释。 Fig4a/ED6b多数群线粒体功能/代谢相关程序降低，FB免疫/抗原呈递增加，蛋白稳态变化主要限上皮；均为转录GSEA推断，不等于实际功能测定。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "independent_transcriptomic_result_reference; full pathway values not recovered",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4a; Discussion; Table5 description",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR11"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O12",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G17",
        "A144-R20261012-G18"
      ],
      "metric": "GSEA",
      "reported_result": "aaTEC1抗原呈递降低；aaTEC2 EMT特征富集。 原Table6对应aaTEC1抗原呈递row8 NES−1.8/FDRq列0，aaTEC2EMT row4 NES2.4/q0；0为作者报告精度，不解释概率为零，与图≤.0001并存。",
      "numeric_values": [
        {
          "subset": "aaTEC1",
          "pathway": "antigen processing/presentation",
          "NES": -1.8,
          "FDR": "<=.0001"
        },
        {
          "subset": "aaTEC2",
          "pathway": "EMT",
          "NES": 2.4,
          "FDR": "<=.0001"
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table6-aaTEC1 negative row8/aaTEC2 positive row4",
          "verification": "fresh targeted original rows read"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR12"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [],
      "source_table_rows": [
        {
          "sheet": "Table 6 - aaTEC1 m5 -enrichment",
          "dimension": "A1:K3876",
          "header": [
            {
              "A1": "Table: Gene sets enriched in phenotype na [plain text format]",
              "B1": "",
              "C1": "",
              "D1": "",
              "E1": "",
              "F1": "",
              "G1": "",
              "H1": "",
              "I1": "",
              "J1": "",
              "K1": ""
            },
            {
              "A2": "",
              "B2": "GS",
              "C2": "GS DETAILS",
              "D2": "SIZE",
              "E2": "ES",
              "F2": "NES",
              "G2": "NOM p-val",
              "H2": "FDR q-val",
              "I2": "FWER p-val",
              "J2": "RANK AT MAX",
              "K2": "LEADING EDGE"
            }
          ],
          "targeted_rows": [
            {
              "A8": "5",
              "B8": "GOBP_ANTIGEN_PROCESSING_AND_PRESENTATION_OF_PEPTIDE_ANTIGEN",
              "C8": "Details ...",
              "D8": "68",
              "E8": "-0.8",
              "F8": "-1.8",
              "G8": "0",
              "H8": "0",
              "I8": "0",
              "J8": "978",
              "K8": "tags=29%, list=4%, signal=30%"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 6 - aaTEC2 hm +enrichment",
          "dimension": "A1:K16",
          "header": [
            {
              "A1": "Table: Gene sets enriched in phenotype na [plain text format]",
              "B1": "",
              "C1": "",
              "D1": "",
              "E1": "",
              "F1": "",
              "G1": "",
              "H1": "",
              "I1": "",
              "J1": "",
              "K1": ""
            },
            {
              "A2": "",
              "B2": "GS",
              "C2": "GS DETAILS",
              "D2": "SIZE",
              "E2": "ES",
              "F2": "NES",
              "G2": "NOM p-val",
              "H2": "FDR q-val",
              "I2": "FWER p-val",
              "J2": "RANK AT MAX",
              "K2": "LEADING EDGE"
            }
          ],
          "targeted_rows": [
            {
              "A4": "1",
              "B4": "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION",
              "C4": "Details ...",
              "D4": "193",
              "E4": "0.74",
              "F4": "2.4",
              "G4": "0",
              "H4": "0",
              "I4": "0",
              "J4": "1810",
              "K4": "tags=56%, list=7%, signal=60%"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        }
      ]
    },
    {
      "result_id": "A144-R20261012-O13",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G18",
        "A144-R20261012-G19"
      ],
      "metric": "细胞状态",
      "reported_result": "Cdh1/Vim及8795相关基因比较支持aaTEC2介于上皮和间质之间；支持部分EMT状态，但作者未排除某些aaTEC2完全EMT；不是直接谱系转换实验。",
      "numeric_values": [
        {
          "value": 8795,
          "unit": "genes",
          "not_sample_n": true
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4c–g",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR13"
      ],
      "record_type": "reported_observation",
      "metric_kind": "quantitative",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O14",
      "experiment_id": "A144-R20261012-E08",
      "sample_class_ids": [
        "A144-R20261012-G20"
      ],
      "metric": "相互作用推断",
      "reported_result": "CellChat按受体/配体表达比较，作者认为aaTEC可吸引上皮生长信号；不是配体流量实测。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "computational_inference",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4h,i; Discussion sink interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR14"
      ],
      "record_type": "author_interpretation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O15",
      "experiment_id": "A144-R20261012-E08",
      "sample_class_ids": [
        "A144-R20261012-G21"
      ],
      "metric": "PTN/MDK蛋白量",
      "reported_result": "Fig4j蛋白量单位pg/10^6 cells：PTN 2vs12月P=.04、2vs18月.005；MDK 2vs12月NS、2vs18月.01。2/12/18月雌鼠每组n5，mean±SEM、Kruskal–Wallis+Dunn；不是全胸腺总量，不是流式/CellChat，保留MDK12月阴性。",
      "numeric_values": [
        {
          "protein": "PTN",
          "unit": "pg/10^6 cells",
          "comparisons": [
            {
              "ages_months": [
                2,
                12
              ],
              "P": 0.04
            },
            {
              "ages_months": [
                2,
                18
              ],
              "P": 0.005
            }
          ]
        },
        {
          "protein": "MDK",
          "unit": "pg/10^6 cells",
          "comparisons": [
            {
              "ages_months": [
                2,
                12
              ],
              "P": "NS"
            },
            {
              "ages_months": [
                2,
                18
              ],
              "P": 0.01
            }
          ]
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_protein_assay",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig4j caption and Results",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4j",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR15"
      ],
      "record_type": "source_note_or_unresolved_result",
      "metric_kind": "quantitative",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O16",
      "experiment_id": "A144-R20261012-E09",
      "sample_class_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23"
      ],
      "metric": "恢复时间",
      "reported_result": "年轻第28日恢复；老年约第42日才接近损伤前细胞量。",
      "numeric_values": [
        {
          "unit": "mice",
          "age_months": 2,
          "days": [
            0,
            1,
            4,
            7,
            28,
            42
          ],
          "n": [
            30,
            10,
            10,
            10,
            10,
            10
          ]
        },
        {
          "unit": "mice",
          "age_months": 18,
          "days": [
            0,
            1,
            4,
            7,
            28,
            42
          ],
          "n": [
            35,
            10,
            10,
            10,
            10,
            15
          ]
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Fig5a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5a caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        }
      ],
      "denominator": "pre-damage thymic cellularity of corresponding age",
      "artifact_ids": [
        "A144-R20261012-AR16"
      ],
      "record_type": "reported_observation",
      "metric_kind": "quantitative",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O17",
      "experiment_id": "A144-R20261012-E09",
      "sample_class_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23"
      ],
      "metric": "流式aaTEC早期再现",
      "reported_result": "流式支路：老年aaTEC在损伤后快速再现；这里只记录细胞亚群反应，不绑定组织学纤维化/钙化。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Fig5c,d; ED9; Results",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR17"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O18",
      "experiment_id": "A144-R20261012-E10",
      "sample_class_ids": [
        "A144-R20261012-G24",
        "A144-R20261012-G25"
      ],
      "metric": "绝对体积与数",
      "reported_result": "12月雄鼠既有TBI后28日右叶：叶/髓质/皮质体积下降，图上P=.01/.002/.03；aaTEC体积升高P=.004。mTEC数量下降P=.02，但cTEC数量升高P=.02，aaTEC数量升高P=.004。不能把常规TEC统一说成下降。精确柱均值未数字化。",
      "numeric_values": [
        {
          "metric": "lobe_volume",
          "direction": "down",
          "P": 0.01
        },
        {
          "metric": "medulla_volume",
          "direction": "down",
          "P": 0.002
        },
        {
          "metric": "cortex_volume",
          "direction": "down",
          "P": 0.03
        },
        {
          "metric": "aaTEC_volume",
          "direction": "up",
          "P": 0.004
        },
        {
          "metric": "mTEC_count",
          "direction": "down",
          "P": 0.02
        },
        {
          "metric": "cTEC_count",
          "direction": "up",
          "P": 0.02
        },
        {
          "metric": "aaTEC_count",
          "direction": "up",
          "P": 0.004
        }
      ],
      "measurement_time": 28,
      "measurement_time_status": "days after pre-existing injury endpoint",
      "measurement_status": "author_plotted_result_fresh_visual_confirmed_without_digitization",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5e/f,12mo male right-lobe atday28; original author caption retained",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5e/f; printed P labels and direction",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR18"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-CF03",
          "binding": "explicit_panel_or_metric_scope; historically_recorded_not_freshly_visual_verified",
          "source_conflict": {
            "id": "A144-CF03",
            "detail": "Video4已有字幕18mo/d21与说明12mo/d28冲突，仍保留旧核心，不能由统一流程消除。"
          }
        }
      ],
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O19",
      "experiment_id": "A144-R20261012-E11",
      "sample_class_ids": [
        "A144-R20261012-G26",
        "A144-R20261012-G27"
      ],
      "metric": "独立数据支路",
      "reported_result": "Fig5g–i以年龄、day0/1/4/7及基质亚群注释同一UMAP。损伤后1/4/7日58,309个CD45−细胞与22,932个day0细胞整合，共81,241；这些是细胞而不是动物n。显示嵌入/标签本身不等于亚群恢复量。 SuppFig1 QC前共93,738细胞，QC后整合81,241；细胞QC排除不等于样本排除，前后分母不混用。",
      "numeric_values": [
        {
          "value": 58309,
          "unit": "postinjury_CD45negative_cells",
          "days": [
            1,
            4,
            7
          ]
        },
        {
          "value": 22932,
          "unit": "baseline_CD45negative_cells",
          "day": 0
        },
        {
          "value": 81241,
          "unit": "integrated_cells"
        },
        {
          "pre_QC_cells": 93738,
          "not_animal_n": true
        }
      ],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "primary_text_dataset_and_fresh_figure_annotation",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results epithelial developmental program after injury; Fig5g–i",
          "verification": "fresh primary text read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure1",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure1",
          "verification": "fresh rendered official supplementary PDF read"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR19"
      ],
      "record_type": "dataset_metadata_not_independent_biological_result",
      "metric_kind": "quantitative",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O20",
      "experiment_id": "A144-R20261012-E12",
      "sample_class_ids": [
        "A144-R20261012-G29",
        "A144-R20261012-G30"
      ],
      "metric": "再生程序",
      "reported_result": "正文概述损伤后Fgf7/Fgf10/Fgf21/Bmp4及Flt3l/Kitl再生相关程序广泛上调、老龄幅度常较弱，但不能推广为每亚群每时间点均如此。再生相关基因响应依亚群/年龄/时点而异。cTEC Psmb11在老年day4/7相对day1仍显著上升（_l=1.919/2.435，FDR-adjusted _p≈8.25e−7/9.96e−12），但幅度弱于年轻_l=5.494/5.691，不能写老年Psmb11下降。Dll4年轻day4/7显著诱导_p=.01682/.004699，老年两点_p=1。Foxn1两龄day7显著上升，day4年轻_p=.24488、老年.05246均未显著；Ccl25两龄两点显著上升，Cxcl12老day4显著.000159而day7 .05840未显著。年轻intFB Kitl day4反向下降_l−.310/_p.000725，day7上升.686/.002055；老intFB Fgf7 day4/7仍上升.595/.000332及.282/.004990，老medFB Bmp4也上升.499/.02699及.955/2.65e−13。老龄不等于所有因子都不响应；原表完整目标行/坐标另存，数值按报告精度非新重算。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results regeneration signaling; Fig6a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-9",
          "locator": "Tables7–10 cTEC/intFB/medFB day4/day7 versusday1",
          "verification": "fresh targeted original workbook rows read"
        },
        {
          "source_id": "A144-WORKBOOK-TARGETROWS",
          "locator": "all selected rows retain Excel positions",
          "verification": "independent targeted cell audit"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR20"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [],
      "table_data_ref": {
        "path": "sources/A144_workbook_targeted_results_read.json",
        "sha256": "6b8522b7c60ede1d8071b15b538c67edcef6b9c7b7da08efd52ccf71f491cb37",
        "scope": "targeted cells fromTables7–10; not all129sheets reanalyzed"
      },
      "statistics": {
        "reported_column": "_p",
        "interpretation": "FDR-adjusted P per primary Methods DEG criterion≤.05",
        "logFC_column": "_l retained; no unverified fold-scale conversion"
      },
      "source_table_rows": [
        {
          "sheet": "Table 7 - intFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d4_4:intFB_n",
              "C1": "d4_4:intFB_s",
              "D1": "d4_4:intFB_l",
              "E1": "d4_4:intFB_p"
            },
            {
              "A2": "0",
              "B2": "Dcn",
              "C2": "67.420204162597656",
              "D2": "2.2825074195861821",
              "E2": "0"
            }
          ],
          "targeted_rows": [
            {
              "A104": "102",
              "B104": "Fgf10",
              "C104": "23.312576293945309",
              "D104": "2.123639822006226",
              "E104": "2.4747382253491682E-118"
            },
            {
              "A268": "266",
              "B268": "Bmp4",
              "C268": "11.779688835144039",
              "D268": "1.6235083341598511",
              "E268": "1.2366104349531119E-30"
            },
            {
              "A758": "756",
              "B758": "Fgf7",
              "C758": "3.9243426322937012",
              "D758": "0.60782504081726074",
              "E758": "6.7343706036317088E-4"
            },
            {
              "A1683": "1681",
              "B1683": "Prss16",
              "C1683": "1.107318520545959",
              "D1683": "3.507567167282104",
              "E1683": "0.98191907504444975"
            },
            {
              "A3110": "3108",
              "B3110": "Psmb11",
              "C3110": "0.20164716243743899",
              "D3110": "3.5239465236663818",
              "E3110": "1"
            },
            {
              "A3706": "3704",
              "B3706": "Foxn1",
              "C3706": "9.9866330623626709E-2",
              "D3706": "21.032882690429691",
              "E3706": "1"
            },
            {
              "A17590": "17588",
              "B17590": "Ly75",
              "C17590": "-5.3546406328678131E-2",
              "D17590": "-0.39011061191558838",
              "E17590": "1"
            },
            {
              "A18295": "18293",
              "B18295": "Dll4",
              "C18295": "-7.5379610061645508E-2",
              "D18295": "-1.6050505638122561",
              "E18295": "1"
            },
            {
              "A19171": "19169",
              "B19171": "Fezf2",
              "C19171": "-0.13168369233608249",
              "D19171": "-1.629582405090332",
              "E19171": "1"
            },
            {
              "A19725": "19723",
              "B19725": "Aire",
              "C19725": "-0.19075535237789151",
              "D19725": "-21.234502792358398",
              "E19725": "1"
            },
            {
              "A20109": "20107",
              "B20109": "Flt3l",
              "C20109": "-0.25428095459938049",
              "D20109": "0.3710116446018219",
              "E20109": "1"
            },
            {
              "A20475": "20473",
              "B20475": "Fgf21",
              "C20475": "-0.3365497887134552",
              "D20475": "-1.35902464389801",
              "E20475": "1"
            },
            {
              "A22347": "22345",
              "B22347": "Il7",
              "C22347": "-1.0057756900787349",
              "D22347": "-0.43575716018676758",
              "E22347": "1"
            },
            {
              "A23900": "23898",
              "B23900": "Ccl25",
              "C23900": "-1.9504363536834719",
              "D23900": "-0.11644810438156129",
              "E23900": "0.24204200306773041"
            },
            {
              "A24423": "24421",
              "B24423": "Enpep",
              "C24423": "-2.3576092720031738",
              "D24423": "-0.1124733164906502",
              "E24423": "9.7391663291404904E-2"
            },
            {
              "A25788": "25786",
              "B25788": "Kitl",
              "C25788": "-3.9057283401489258",
              "D25788": "-0.30991339683532709",
              "E25788": "7.2549559683139587E-4"
            },
            {
              "A27335": "27333",
              "B27335": "Cxcl12",
              "C27335": "-8.19415283203125",
              "D27335": "-0.46482521295547491",
              "E27335": "4.0066123278734387E-15"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 7 - medFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d4_5:medFB_n",
              "C1": "d4_5:medFB_s",
              "D1": "d4_5:medFB_l",
              "E1": "d4_5:medFB_p"
            },
            {
              "A2": "0",
              "B2": "Dcn",
              "C2": "39.990711212158203",
              "D2": "1.7427880764007571",
              "E2": "0"
            }
          ],
          "targeted_rows": [
            {
              "A114": "112",
              "B114": "Flt3l",
              "C114": "12.704079627990721",
              "D114": "2.2564442157745361",
              "E114": "2.611222663281839E-35"
            },
            {
              "A352": "350",
              "B352": "Fgf10",
              "C352": "5.0493063926696777",
              "D352": "1.836877226829529",
              "E352": "5.5095667832321464E-6"
            },
            {
              "A462": "460",
              "B462": "Bmp4",
              "C462": "3.730049848556519",
              "D462": "1.014898896217346",
              "E462": "1.7585743109197411E-3"
            },
            {
              "A981": "979",
              "B981": "Fgf7",
              "C981": "1.272124767303467",
              "D981": "1.3513059616088869",
              "E981": "0.89012147457900992"
            },
            {
              "A1198": "1196",
              "B1198": "Kitl",
              "C1198": "0.91713196039199829",
              "D1198": "0.80929940938949585",
              "E1198": "1"
            },
            {
              "A1540": "1538",
              "B1540": "Prss16",
              "C1540": "0.5447201132774353",
              "D1540": "24.030990600585941",
              "E1540": "1"
            },
            {
              "A2530": "2528",
              "B2530": "Psmb11",
              "C2530": "0.14497913420200351",
              "D2530": "1.885170698165894",
              "E2530": "1"
            },
            {
              "A3157": "3155",
              "B3157": "Dll4",
              "C3157": "7.2292439639568329E-2",
              "D3157": "1.2525550127029419",
              "E3157": "1"
            },
            {
              "A15520": "15518",
              "B15520": "Foxn1",
              "C15520": "-2.3834642022848129E-2",
              "D15520": "-0.62562578916549683",
              "E15520": "1"
            },
            {
              "A17254": "17252",
              "B17254": "Aire",
              "C17254": "-4.7597602009773247E-2",
              "D17254": "-0.33670014142990112",
              "E17254": "1"
            },
            {
              "A18688": "18686",
              "B18688": "Ly75",
              "C18688": "-0.1035462915897369",
              "D18688": "-1.0687296390533449",
              "E18688": "1"
            },
            {
              "A19187": "19185",
              "B19187": "Fezf2",
              "C19187": "-0.13978211581707001",
              "D19187": "-21.21689605712891",
              "E19187": "1"
            },
            {
              "A21338": "21336",
              "B21338": "Il7",
              "C21338": "-0.54454094171524048",
              "D21338": "-9.195476770401001E-2",
              "E21338": "1"
            },
            {
              "A21471": "21469",
              "B21471": "Fgf21",
              "C21471": "-0.58708488941192627",
              "D21471": "-23.631855010986332",
              "E21471": "1"
            },
            {
              "A21622": "21620",
              "B21622": "Enpep",
              "C21622": "-0.63430613279342651",
              "D21622": "0.20868505537509921",
              "E21622": "1"
            },
            {
              "A24603": "24601",
              "B24603": "Ccl25",
              "C24603": "-2.1131291389465332",
              "D24603": "-0.3869953453540802",
              "E24603": "0.20400479125243881"
            },
            {
              "A27905": "27903",
              "B27905": "Cxcl12",
              "C27905": "-9.2999544143676758",
              "D27905": "-0.79452168941497803",
              "E27905": "3.9722809852865522E-19"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 7 - cTEC",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d4_12:cTEC_n",
              "C1": "d4_12:cTEC_s",
              "D1": "d4_12:cTEC_l",
              "E1": "d4_12:cTEC_p"
            },
            {
              "A2": "0",
              "B2": "Tbata",
              "C2": "10.52055740356445",
              "D2": "6.3629546165466309",
              "E2": "1.997155955561914E-21"
            }
          ],
          "targeted_rows": [
            {
              "A3": "1",
              "B3": "Psmb11",
              "C3": "9.8305673599243164",
              "D3": "5.4941515922546387",
              "E3": "1.1953504907397129E-18"
            },
            {
              "A5": "3",
              "B5": "Prss16",
              "C5": "9.3327713012695312",
              "D5": "4.4396710395812988",
              "E5": "7.4135431726773484E-17"
            },
            {
              "A7": "5",
              "B7": "Ccl25",
              "C7": "9.0385112762451172",
              "D7": "4.9755640029907227",
              "E7": "7.6106506916125021E-16"
            },
            {
              "A44": "42",
              "B44": "Cxcl12",
              "C44": "6.0833721160888672",
              "D44": "1.71248471736908",
              "E44": "5.8337132336885738E-7"
            },
            {
              "A58": "56",
              "B58": "Ly75",
              "C58": "5.5390205383300781",
              "D58": "2.1940159797668461",
              "E58": "1.166059773504644E-5"
            },
            {
              "A113": "111",
              "B113": "Il7",
              "C113": "4.5858073234558114",
              "D113": "1.706179261207581",
              "E113": "9.2876197193953044E-4"
            },
            {
              "A212": "210",
              "B212": "Dll4",
              "C212": "3.7865889072418208",
              "D212": "4.8266863822937012",
              "E212": "1.6824819210170459E-2"
            },
            {
              "A423": "421",
              "B423": "Kitl",
              "C423": "2.8918700218200679",
              "D423": "1.765585660934448",
              "E423": "0.21337906376895099"
            },
            {
              "A456": "454",
              "B456": "Foxn1",
              "C456": "2.826810359954834",
              "D456": "0.95017474889755249",
              "E456": "0.244882446198606"
            },
            {
              "A1684": "1682",
              "B1684": "Flt3l",
              "C1684": "1.462349057197571",
              "D1684": "2.5546503067016602",
              "E1684": "1"
            },
            {
              "A1817": "1815",
              "B1817": "Enpep",
              "C1817": "1.387142539024353",
              "D1817": "1.190905690193176",
              "E1817": "1"
            },
            {
              "A5914": "5912",
              "B5914": "Bmp4",
              "C5914": "0.32947620749473572",
              "D5914": "24.75124549865723",
              "E5914": "1"
            },
            {
              "A7012": "7010",
              "B7012": "Fgf21",
              "C7012": "0.19458197057247159",
              "D7012": "0.68211609125137329",
              "E7012": "1"
            },
            {
              "A9628": "9626",
              "B9628": "Fgf10",
              "C9628": "5.491270124912262E-2",
              "D9628": "21.930328369140621",
              "E9628": "1"
            },
            {
              "A25750": "25748",
              "B25750": "Fgf7",
              "C25750": "-0.21368204057216639",
              "D25750": "-2.6370441913604741",
              "E25750": "1"
            },
            {
              "A25881": "25879",
              "B25881": "Aire",
              "C25881": "-0.2148757874965668",
              "D25881": "-4.0730476379394531",
              "E25881": "1"
            },
            {
              "A28098": "28096",
              "B28098": "Fezf2",
              "C28098": "-0.89949393272399902",
              "D28098": "-0.99402034282684326",
              "E28098": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 8 - intFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d7_4:intFB_n",
              "C1": "d7_4:intFB_s",
              "D1": "d7_4:intFB_l",
              "E1": "d7_4:intFB_p"
            },
            {
              "A2": "0",
              "B2": "Dcn",
              "C2": "65.382774353027344",
              "D2": "2.0832843780517578",
              "E2": "0"
            }
          ],
          "targeted_rows": [
            {
              "A142": "140",
              "B142": "Bmp4",
              "C142": "23.983200073242191",
              "D142": "2.3303813934326172",
              "E142": "3.262200388112031E-125"
            },
            {
              "A233": "231",
              "B233": "Fgf10",
              "C233": "18.270095825195309",
              "D233": "1.5764105319976811",
              "E233": "7.2486161965141762E-73"
            },
            {
              "A719": "717",
              "B719": "Fgf7",
              "C719": "8.1659765243530273",
              "D719": "0.79965806007385254",
              "E719": "5.6764122217721278E-15"
            },
            {
              "A1595": "1593",
              "B1595": "Kitl",
              "C1595": "3.6669235229492192",
              "D1595": "0.68584418296813965",
              "E1595": "2.0553925134160931E-3"
            },
            {
              "A1653": "1651",
              "B1653": "Flt3l",
              "C1653": "3.5104794502258301",
              "D1653": "0.68599075078964233",
              "E1653": "3.6156170088360441E-3"
            },
            {
              "A3209": "3207",
              "B3209": "Prss16",
              "C3209": "1.344456553459167",
              "D3209": "3.5605208873748779",
              "E3209": "0.78331259366127204"
            },
            {
              "A4651": "4649",
              "B4651": "Psmb11",
              "C4651": "0.56480789184570312",
              "D4651": "4.6817498207092294",
              "E4651": "1"
            },
            {
              "A6194": "6192",
              "B6194": "Foxn1",
              "C6194": "0.18296407163143161",
              "D6194": "21.4109001159668",
              "E6194": "1"
            },
            {
              "A7462": "7460",
              "B7462": "Dll4",
              "C7462": "6.6552214324474335E-2",
              "D7462": "1.121114134788513",
              "E7462": "1"
            },
            {
              "A18192": "18190",
              "B18192": "Ly75",
              "C18192": "-9.2595182359218597E-3",
              "D18192": "0.2344200611114502",
              "E18192": "1"
            },
            {
              "A19484": "19482",
              "B19484": "Ccl25",
              "C19484": "-2.0109238103032109E-2",
              "D19484": "0.26819592714309692",
              "E19484": "1"
            },
            {
              "A21699": "21697",
              "B21699": "Fezf2",
              "C21699": "-8.524390310049057E-2",
              "D21699": "-0.6648133397102356",
              "E21699": "1"
            },
            {
              "A21715": "21713",
              "B21715": "Aire",
              "C21715": "-8.6370676755905151E-2",
              "D21715": "-0.29350394010543818",
              "E21715": "1"
            },
            {
              "A23309": "23307",
              "B23309": "Fgf21",
              "C23309": "-0.30737236142158508",
              "D23309": "-1.155367374420166",
              "E23309": "1"
            },
            {
              "A24637": "24635",
              "B24637": "Il7",
              "C24637": "-0.81725466251373291",
              "D24637": "-0.46414536237716669",
              "E24637": "1"
            },
            {
              "A26748": "26746",
              "B26748": "Enpep",
              "C26748": "-3.2583916187286381",
              "D26748": "-0.42230015993118292",
              "E26748": "8.5565391629023116E-3"
            },
            {
              "A28353": "28351",
              "B28353": "Cxcl12",
              "C28353": "-15.84118175506592",
              "D28353": "-1.1106166839599609",
              "E28353": "6.7993135864904834E-55"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 8 - medFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d7_5:medFB_n",
              "C1": "d7_5:medFB_s",
              "D1": "d7_5:medFB_l",
              "E1": "d7_5:medFB_p"
            },
            {
              "A2": "0",
              "B2": "Enpp2",
              "C2": "49.117427825927727",
              "D2": "3.2227392196655269",
              "E2": "0"
            }
          ],
          "targeted_rows": [
            {
              "A75": "73",
              "B75": "Flt3l",
              "C75": "20.925729751586911",
              "D75": "2.5349290370941162",
              "E75": "3.6643263066184791E-95"
            },
            {
              "A207": "205",
              "B207": "Bmp4",
              "C207": "12.703970909118651",
              "D207": "1.711932301521301",
              "E207": "2.602221459528615E-35"
            },
            {
              "A674": "672",
              "B674": "Fgf10",
              "C674": "5.4099984169006348",
              "D674": "1.4600956439971919",
              "E674": "9.7215972999809144E-7"
            },
            {
              "A954": "952",
              "B954": "Kitl",
              "C954": "3.8689403533935551",
              "D954": "1.294370293617249",
              "E954": "1.225288312508035E-3"
            },
            {
              "A2480": "2478",
              "B2480": "Prss16",
              "C2480": "1.1766675710678101",
              "D2480": "24.520061492919918",
              "E2480": "1"
            },
            {
              "A3268": "3266",
              "B3268": "Fgf7",
              "C3268": "0.69889318943023682",
              "D3268": "0.71149426698684692",
              "E3268": "1"
            },
            {
              "A3829": "3827",
              "B3829": "Psmb11",
              "C3829": "0.48465907573699951",
              "D3829": "2.6232821941375728",
              "E3829": "1"
            },
            {
              "A5171": "5169",
              "B5171": "Dll4",
              "C5171": "0.18764720857143399",
              "D5171": "1.9065953493118291",
              "E5171": "1"
            },
            {
              "A5501": "5499",
              "B5501": "Il7",
              "C5501": "0.14177316427230829",
              "D5501": "0.33551713824272161",
              "E5501": "1"
            },
            {
              "A6770": "6768",
              "B6770": "Foxn1",
              "C6770": "4.2907565832138062E-2",
              "D6770": "1.0716172456741331",
              "E6770": "1"
            },
            {
              "A20972": "20970",
              "B20972": "Ly75",
              "C20972": "-7.0648655295372009E-2",
              "D20972": "-0.44594767689704901",
              "E20972": "1"
            },
            {
              "A20996": "20994",
              "B20996": "Fezf2",
              "C20996": "-7.372649759054184E-2",
              "D20996": "-0.17680682241916659",
              "E20996": "1"
            },
            {
              "A21085": "21083",
              "B21085": "Aire",
              "C21085": "-7.729031890630722E-2",
              "D21085": "-1.398917675018311",
              "E21085": "1"
            },
            {
              "A24023": "24021",
              "B24023": "Fgf21",
              "C24023": "-0.60038197040557861",
              "D24023": "-3.024334192276001",
              "E24023": "1"
            },
            {
              "A25087": "25085",
              "B25087": "Enpep",
              "C25087": "-1.142841696739197",
              "D25087": "-0.1754684895277023",
              "E25087": "1"
            },
            {
              "A25301": "25299",
              "B25301": "Ccl25",
              "C25301": "-1.2963187694549561",
              "D25301": "-8.7690562009811401E-2",
              "E25301": "0.96699654978832827"
            },
            {
              "A28431": "28429",
              "B28431": "Cxcl12",
              "C28431": "-15.043698310852051",
              "D28431": "-1.1741077899932859",
              "E28431": "2.3082309640760439E-49"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 8 - cTEC",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d7_12:cTEC_n",
              "C1": "d7_12:cTEC_s",
              "D1": "d7_12:cTEC_l",
              "E1": "d7_12:cTEC_p"
            },
            {
              "A2": "0",
              "B2": "Tbata",
              "C2": "11.02006244659424",
              "D2": "6.9305229187011719",
              "E2": "8.7937058124171459E-24"
            }
          ],
          "targeted_rows": [
            {
              "A3": "1",
              "B3": "Ccl25",
              "C3": "10.57965755462646",
              "D3": "6.1543974876403809",
              "E3": "5.3235775553355705E-22"
            },
            {
              "A4": "2",
              "B4": "Psmb11",
              "C4": "10.299667358398439",
              "D4": "5.6909441947937012",
              "E4": "6.776421333214201E-21"
            },
            {
              "A7": "5",
              "B7": "Prss16",
              "C7": "9.1973667144775391",
              "D7": "4.2036008834838867",
              "E7": "1.6810320330046029E-16"
            },
            {
              "A65": "63",
              "B65": "Ly75",
              "C65": "5.5957574844360352",
              "D65": "2.2425415515899658",
              "E65": "7.8945981813429372E-6"
            },
            {
              "A99": "97",
              "B99": "Il7",
              "C99": "5.0063433647155762",
              "D99": "1.830702066421509",
              "E99": "1.3568551688647511E-4"
            },
            {
              "A113": "111",
              "B113": "Cxcl12",
              "C113": "4.913994312286377",
              "D113": "1.342160105705261",
              "E113": "1.958634304739213E-4"
            },
            {
              "A205": "203",
              "B205": "Dll4",
              "C205": "4.1100802421569824",
              "D205": "4.7091245651245117",
              "E205": "4.6991932499470092E-3"
            },
            {
              "A207": "205",
              "B207": "Foxn1",
              "C207": "4.103825569152832",
              "D207": "1.3107237815856929",
              "E207": "4.7690096804186609E-3"
            },
            {
              "A501": "499",
              "B501": "Kitl",
              "C501": "3.1181566715240479",
              "D501": "1.729833245277405",
              "E501": "9.2120809897674419E-2"
            },
            {
              "A1161": "1159",
              "B1161": "Flt3l",
              "C1161": "2.2325634956359859",
              "D1161": "2.995363712310791",
              "E1161": "0.57409169401537952"
            },
            {
              "A2040": "2038",
              "B2040": "Fezf2",
              "C2040": "1.6398377418518071",
              "D2040": "1.366274952888489",
              "E2040": "1"
            },
            {
              "A2680": "2678",
              "B2680": "Enpep",
              "C2680": "1.351385235786438",
              "D2680": "1.0583368539810181",
              "E2680": "1"
            },
            {
              "A3475": "3473",
              "B3475": "Fgf21",
              "C3475": "1.077281713485718",
              "D3475": "2.2829828262329102",
              "E3475": "1"
            },
            {
              "A8666": "8664",
              "B8666": "Bmp4",
              "C8666": "0.16924507915973661",
              "D8666": "23.83329010009766",
              "E8666": "1"
            },
            {
              "A9314": "9312",
              "B9314": "Fgf10",
              "C9314": "0.1184715554118156",
              "D9314": "23.474935531616211",
              "E9314": "1"
            },
            {
              "A25193": "25191",
              "B25193": "Aire",
              "C25193": "-3.016977570950985E-2",
              "D25193": "-0.39228960871696472",
              "E25193": "1"
            },
            {
              "A26370": "26368",
              "B26370": "Fgf7",
              "C26370": "-0.19647146761417389",
              "D26370": "-2.3184759616851811",
              "E26370": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 9 - intFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d4_4:intFB_n",
              "C1": "d4_4:intFB_s",
              "D1": "d4_4:intFB_l",
              "E1": "d4_4:intFB_p"
            },
            {
              "A2": "0",
              "B2": "Tpt1",
              "C2": "24.478067398071289",
              "D2": "1.0782486200332639",
              "E2": "9.0919104389703594E-129"
            }
          ],
          "targeted_rows": [
            {
              "A387": "385",
              "B387": "Cxcl12",
              "C387": "5.7602834701538086",
              "D387": "0.69490969181060791",
              "E387": "4.5900850125089872E-7"
            },
            {
              "A764": "762",
              "B764": "Fgf7",
              "C764": "4.3962321281433114",
              "D764": "0.59465271234512329",
              "E764": "3.3231095781060318E-4"
            },
            {
              "A1616": "1614",
              "B1616": "Enpep",
              "C1616": "3.0738511085510249",
              "D1616": "0.5023687481880188",
              "E1616": "3.2244170272367298E-2"
            },
            {
              "A5640": "5638",
              "B5640": "Bmp4",
              "C5640": "1.088188052177429",
              "D5640": "0.19524575769901281",
              "E5640": "1"
            },
            {
              "A6877": "6875",
              "B6877": "Kitl",
              "C6877": "0.77042758464813232",
              "D6877": "0.12874336540699011",
              "E6877": "1"
            },
            {
              "A7065": "7063",
              "B7065": "Fgf10",
              "C7065": "0.71982342004776001",
              "D7065": "2.41951197385788E-2",
              "E7065": "1"
            },
            {
              "A8913": "8911",
              "B8913": "Il7",
              "C8913": "0.34111183881759638",
              "D8913": "-2.3739136755466461E-2",
              "E8913": "1"
            },
            {
              "A10931": "10929",
              "B10931": "Flt3l",
              "C10931": "0.1226939633488655",
              "D10931": "-9.2727832496166229E-2",
              "E10931": "1"
            },
            {
              "A11285": "11283",
              "B11285": "Psmb11",
              "C11285": "9.3575350940227509E-2",
              "D11285": "1.529169082641602",
              "E11285": "1"
            },
            {
              "A20909": "20907",
              "B20909": "Foxn1",
              "C20909": "0",
              "D20909": "0",
              "E20909": "1"
            },
            {
              "A24119": "24117",
              "B24119": "Dll4",
              "C24119": "-2.6178481057286259E-2",
              "D24119": "-0.5016319751739502",
              "E24119": "1"
            },
            {
              "A24145": "24143",
              "B24145": "Fgf21",
              "C24145": "-2.7761628851294521E-2",
              "D24145": "-8.404877781867981E-2",
              "E24145": "1"
            },
            {
              "A24211": "24209",
              "B24211": "Prss16",
              "C24211": "-2.8100874274969101E-2",
              "D24211": "-0.85640859603881836",
              "E24211": "1"
            },
            {
              "A24790": "24788",
              "B24790": "Aire",
              "C24790": "-2.9910186305642131E-2",
              "D24790": "-20.236143112182621",
              "E24790": "1"
            },
            {
              "A26609": "26607",
              "B26609": "Fezf2",
              "C26609": "-8.9730560779571533E-2",
              "D26609": "-21.978071212768551",
              "E26609": "1"
            },
            {
              "A26919": "26917",
              "B26919": "Ly75",
              "C26919": "-0.1196407452225685",
              "D26919": "-21.86992263793945",
              "E26919": "1"
            },
            {
              "A27141": "27139",
              "B27141": "Ccl25",
              "C27141": "-0.16379927098751071",
              "D27141": "-0.38993245363235468",
              "E27141": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 9 - medFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d4_5:medFB_n",
              "C1": "d4_5:medFB_s",
              "D1": "d4_5:medFB_l",
              "E1": "d4_5:medFB_p"
            },
            {
              "A2": "0",
              "B2": "Tpt1",
              "C2": "26.53144645690918",
              "D2": "1.2970631122589109",
              "E2": "2.418110465115897E-151"
            }
          ],
          "targeted_rows": [
            {
              "A277": "275",
              "B277": "Bmp4",
              "C277": "3.412790060043335",
              "D277": "0.49886485934257507",
              "E277": "2.698971010090416E-2"
            },
            {
              "A1888": "1886",
              "B1888": "Fgf10",
              "C1888": "1.021964907646179",
              "D1888": "0.51841086149215698",
              "E1888": "1"
            },
            {
              "A1944": "1942",
              "B1944": "Fgf7",
              "C1944": "1.001087427139282",
              "D1944": "0.80741286277770996",
              "E1944": "1"
            },
            {
              "A3490": "3488",
              "B3490": "Il7",
              "C3490": "0.50563371181488037",
              "D3490": "0.3231048583984375",
              "E3490": "1"
            },
            {
              "A4112": "4110",
              "B4112": "Ccl25",
              "C4112": "0.37898802757263178",
              "D4112": "0.36674901843070978",
              "E4112": "1"
            },
            {
              "A8547": "8545",
              "B8547": "Fgf21",
              "C8547": "2.60106734931469E-2",
              "D8547": "-0.2131899148225784",
              "E8547": "1"
            },
            {
              "A19853": "19851",
              "B19853": "Fezf2",
              "C19853": "-2.1136367693543431E-2",
              "D19853": "-19.028545379638668",
              "E19853": "1"
            },
            {
              "A20532": "20530",
              "B20532": "Foxn1",
              "C20532": "-2.1136367693543431E-2",
              "D20532": "-20.0870475769043",
              "E20532": "1"
            },
            {
              "A21534": "21532",
              "B21534": "Aire",
              "C21534": "-4.2272735387086868E-2",
              "D21534": "-20.64887809753418",
              "E21534": "1"
            },
            {
              "A21724": "21722",
              "B21724": "Psmb11",
              "C21724": "-4.2272735387086868E-2",
              "D21724": "-20.422084808349609",
              "E21724": "1"
            },
            {
              "A23206": "23204",
              "B23206": "Dll4",
              "C23206": "-0.1030937135219574",
              "D23206": "-0.44767469167709351",
              "E23206": "1"
            },
            {
              "A23401": "23399",
              "B23401": "Enpep",
              "C23401": "-0.1124972403049469",
              "D23401": "-1.4836740680038931E-2",
              "E23401": "1"
            },
            {
              "A23498": "23496",
              "B23498": "Prss16",
              "C23498": "-0.1216419562697411",
              "D23498": "-1.2829041481018071",
              "E23498": "1"
            },
            {
              "A24103": "24101",
              "B24103": "Kitl",
              "C24103": "-0.1702987402677536",
              "D24103": "-3.0503807589411739E-2",
              "E24103": "1"
            },
            {
              "A24154": "24152",
              "B24154": "Ly75",
              "C24154": "-0.17577694356441501",
              "D24154": "-1.021740198135376",
              "E24154": "1"
            },
            {
              "A25175": "25173",
              "B25175": "Flt3l",
              "C25175": "-0.3191160261631012",
              "D25175": "-5.4199010133743293E-2",
              "E25175": "1"
            },
            {
              "A27578": "27576",
              "B27578": "Cxcl12",
              "C27578": "-1.43787693977356",
              "D27578": "-0.13818725943565369",
              "E27578": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 9 - cTEC",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d4_12:cTEC_n",
              "C1": "d4_12:cTEC_s",
              "D1": "d4_12:cTEC_l",
              "E1": "d4_12:cTEC_p"
            },
            {
              "A2": "0",
              "B2": "Krt18",
              "C2": "10.13964176177979",
              "D2": "1.936842679977417",
              "E2": "1.059360112979514E-19"
            }
          ],
          "targeted_rows": [
            {
              "A6": "4",
              "B6": "Prss16",
              "C6": "7.9309883117675781",
              "D6": "2.3407857418060298",
              "E6": "8.9299104340081432E-12"
            },
            {
              "A7": "5",
              "B7": "Ccl25",
              "C7": "7.560025691986084",
              "D7": "2.9820878505706792",
              "E7": "1.4483446006139419E-10"
            },
            {
              "A14": "12",
              "B14": "Psmb11",
              "C14": "6.2055368423461914",
              "D14": "1.9189679622650151",
              "E14": "8.2488654955397834E-7"
            },
            {
              "A33": "31",
              "B33": "Cxcl12",
              "C33": "5.1383061408996582",
              "D33": "0.97939842939376831",
              "E33": "1.5941583170388311E-4"
            },
            {
              "A173": "171",
              "B173": "Ly75",
              "C173": "3.5983364582061772",
              "D173": "1.0633455514907839",
              "E173": "4.3848067498802018E-2"
            },
            {
              "A182": "180",
              "B182": "Foxn1",
              "C182": "3.5355579853057861",
              "D182": "1.1595290899276729",
              "E182": "5.2464634484787512E-2"
            },
            {
              "A341": "339",
              "B341": "Kitl",
              "C341": "2.9296526908874512",
              "D341": "1.255668640136719",
              "E341": "0.24178884155198321"
            },
            {
              "A925": "923",
              "B925": "Enpep",
              "C925": "2.105925559997559",
              "D925": "1.080685615539551",
              "E925": "0.96142570349495216"
            },
            {
              "A2845": "2843",
              "B2845": "Il7",
              "C2845": "1.1756658554077151",
              "D2845": "0.3279862105846405",
              "E2845": "1"
            },
            {
              "A2892": "2890",
              "B2892": "Flt3l",
              "C2892": "1.16139805316925",
              "D2892": "1.0679001808166499",
              "E2892": "1"
            },
            {
              "A4440": "4438",
              "B4440": "Bmp4",
              "C4440": "0.77616769075393677",
              "D4440": "1.6154769659042361",
              "E4440": "1"
            },
            {
              "A5698": "5696",
              "B5698": "Dll4",
              "C5698": "0.54598075151443481",
              "D5698": "0.2230536490678787",
              "E5698": "1"
            },
            {
              "A9795": "9793",
              "B9795": "Fgf10",
              "C9795": "0.102728083729744",
              "D9795": "21.84147834777832",
              "E9795": "1"
            },
            {
              "A10835": "10833",
              "B10835": "Fgf7",
              "C10835": "5.7071156799793243E-2",
              "D10835": "-0.16995957493782041",
              "E10835": "1"
            },
            {
              "A24479": "24477",
              "B24479": "Fgf21",
              "C24479": "-6.8485386669635773E-2",
              "D24479": "-1.125104546546936",
              "E24479": "1"
            },
            {
              "A26150": "26148",
              "B26150": "Fezf2",
              "C26150": "-0.1502873748540878",
              "D26150": "8.0300018191337585E-2",
              "E26150": "1"
            },
            {
              "A26663": "26661",
              "B26663": "Aire",
              "C26663": "-0.2454059720039368",
              "D26663": "-24.200250625610352",
              "E26663": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 10 - intFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d7_4:intFB_n",
              "C1": "d7_4:intFB_s",
              "D1": "d7_4:intFB_l",
              "E1": "d7_4:intFB_p"
            },
            {
              "A2": "0",
              "B2": "Tpt1",
              "C2": "33.810527801513672",
              "D2": "1.215337753295898",
              "E2": "6.6182949278996153E-247"
            }
          ],
          "targeted_rows": [
            {
              "A779": "777",
              "B779": "Cxcl12",
              "C779": "6.6681203842163086",
              "D779": "0.57618844509124756",
              "E779": "7.9251663077045086E-10"
            },
            {
              "A1474": "1472",
              "B1474": "Enpep",
              "C1474": "4.8688192367553711",
              "D1474": "0.56411659717559814",
              "E1474": "1.8920557984683149E-5"
            },
            {
              "A2578": "2576",
              "B2578": "Fgf7",
              "C2578": "3.47868800163269",
              "D2578": "0.28227829933166498",
              "E2578": "4.9904963548158092E-3"
            },
            {
              "A10034": "10032",
              "B10034": "Bmp4",
              "C10034": "0.22335219383239749",
              "D10034": "-9.6018902957439423E-2",
              "E10034": "1"
            },
            {
              "A10346": "10344",
              "B10346": "Kitl",
              "C10346": "0.18075670301914221",
              "D10346": "-9.1656945645809174E-2",
              "E10346": "1"
            },
            {
              "A11661": "11659",
              "B11661": "Prss16",
              "C11661": "6.649395078420639E-2",
              "D11661": "0.27884009480476379",
              "E11661": "1"
            },
            {
              "A12175": "12173",
              "B12175": "Psmb11",
              "C12175": "5.2885886281728738E-2",
              "D12175": "0.50063717365264893",
              "E12175": "1"
            },
            {
              "A22709": "22707",
              "B22709": "Foxn1",
              "C22709": "0",
              "D22709": "0",
              "E22709": "1"
            },
            {
              "A25077": "25075",
              "B25077": "Aire",
              "C25077": "-3.9221592247486108E-2",
              "D25077": "-20.236143112182621",
              "E25077": "1"
            },
            {
              "A25863": "25861",
              "B25863": "Ly75",
              "C25863": "-6.4638309180736542E-2",
              "D25863": "-0.88660925626754761",
              "E25863": "1"
            },
            {
              "A26263": "26261",
              "B26263": "Fgf21",
              "C26263": "-8.6962282657623291E-2",
              "D26263": "-2.0807607173919682",
              "E26263": "1"
            },
            {
              "A26561": "26559",
              "B26561": "Fezf2",
              "C26561": "-0.1176647692918777",
              "D26561": "-21.978071212768551",
              "E26561": "1"
            },
            {
              "A27027": "27025",
              "B27027": "Dll4",
              "C27027": "-0.19610795378685",
              "D27027": "-22.621883392333981",
              "E27027": "1"
            },
            {
              "A27269": "27267",
              "B27269": "Flt3l",
              "C27269": "-0.27145838737487787",
              "D27269": "-0.26418256759643549",
              "E27269": "1"
            },
            {
              "A27312": "27310",
              "B27312": "Il7",
              "C27312": "-0.28928384184837341",
              "D27312": "-0.57879000902175903",
              "E27312": "1"
            },
            {
              "A27821": "27819",
              "B27821": "Ccl25",
              "C27821": "-0.74894964694976807",
              "D27821": "-0.99502623081207275",
              "E27821": "1"
            },
            {
              "A27967": "27965",
              "B27967": "Fgf10",
              "C27967": "-1.0355343818664551",
              "D27967": "-0.2894386351108551",
              "E27967": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 10 - medFB",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d7_5:medFB_n",
              "C1": "d7_5:medFB_s",
              "D1": "d7_5:medFB_l",
              "E1": "d7_5:medFB_p"
            },
            {
              "A2": "0",
              "B2": "Tpt1",
              "C2": "32.123367309570312",
              "D2": "1.5384751558303831",
              "E2": "1.1963400258554439E-222"
            }
          ],
          "targeted_rows": [
            {
              "A85": "83",
              "B85": "Bmp4",
              "C85": "7.9514551162719727",
              "D85": "0.95506173372268677",
              "E85": "2.649979093395326E-13"
            },
            {
              "A1143": "1141",
              "B1143": "Fgf10",
              "C1143": "1.589593768119812",
              "D1143": "0.62504535913467407",
              "E1143": "1"
            },
            {
              "A2071": "2069",
              "B2071": "Fgf7",
              "C2071": "0.87593525648117065",
              "D2071": "0.67575234174728394",
              "E2071": "1"
            },
            {
              "A3713": "3711",
              "B3713": "Prss16",
              "C3713": "0.34388723969459528",
              "D3713": "1.305601239204407",
              "E3713": "1"
            },
            {
              "A7786": "7784",
              "B7786": "Fgf21",
              "C7786": "8.3462651818990707E-3",
              "D7786": "0.56444334983825684",
              "E7786": "1"
            },
            {
              "A8033": "8031",
              "B8033": "Psmb11",
              "C8033": "8.2053998485207558E-3",
              "D8033": "0.1041868329048157",
              "E8033": "1"
            },
            {
              "A8084": "8082",
              "B8084": "Dll4",
              "C8084": "4.683768842369318E-3",
              "D8084": "0.16139623522758481",
              "E8084": "1"
            },
            {
              "A18607": "18605",
              "B18607": "Foxn1",
              "C18607": "-2.3771008476614949E-2",
              "D18607": "-20.0870475769043",
              "E18607": "1"
            },
            {
              "A19815": "19813",
              "B19815": "Fezf2",
              "C19815": "-2.3771008476614949E-2",
              "D19815": "-19.028545379638668",
              "E19815": "1"
            },
            {
              "A20212": "20210",
              "B20212": "Ly75",
              "C20212": "-3.8068830966949463E-2",
              "D20212": "-0.24146409332752231",
              "E20212": "1"
            },
            {
              "A20973": "20971",
              "B20973": "Aire",
              "C20973": "-4.7542016953229897E-2",
              "D20973": "-20.64887809753418",
              "E20973": "1"
            },
            {
              "A23829": "23827",
              "B23829": "Ccl25",
              "C23829": "-0.26007243990898132",
              "D23829": "-0.2122007608413696",
              "E23829": "1"
            },
            {
              "A24252": "24250",
              "B24252": "Il7",
              "C24252": "-0.32307440042495728",
              "D24252": "-6.8967856466770172E-2",
              "E24252": "1"
            },
            {
              "A24363": "24361",
              "B24363": "Enpep",
              "C24363": "-0.34025996923446661",
              "D24363": "-0.1666896641254425",
              "E24363": "1"
            },
            {
              "A25209": "25207",
              "B25209": "Kitl",
              "C25209": "-0.51570761203765869",
              "D25209": "-0.12724208831787109",
              "E25209": "1"
            },
            {
              "A26265": "26263",
              "B26265": "Flt3l",
              "C26265": "-0.84677612781524658",
              "D26265": "-0.11805408447980879",
              "E26265": "1"
            },
            {
              "A28074": "28072",
              "B28074": "Cxcl12",
              "C28074": "-2.5819540023803711",
              "D28074": "-0.27722126245498657",
              "E28074": "0.22241519005934229"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        },
        {
          "sheet": "Table 10 - cTEC",
          "dimension": "A1:E28753",
          "header": [
            {
              "B1": "d7_12:cTEC_n",
              "C1": "d7_12:cTEC_s",
              "D1": "d7_12:cTEC_l",
              "E1": "d7_12:cTEC_p"
            },
            {
              "A2": "0",
              "B2": "Tbata",
              "C2": "11.124302864074711",
              "D2": "4.8570680618286133",
              "E2": "2.7472612368805102E-24"
            }
          ],
          "targeted_rows": [
            {
              "A4": "2",
              "B4": "Ccl25",
              "C4": "10.34247398376465",
              "D4": "4.0765895843505859",
              "E4": "2.9511892989143162E-21"
            },
            {
              "A6": "4",
              "B6": "Prss16",
              "C6": "9.7986307144165039",
              "D6": "3.0924313068389888",
              "E6": "4.6874866614818497E-19"
            },
            {
              "A11": "9",
              "B11": "Psmb11",
              "C11": "7.8139891624450684",
              "D11": "2.4346134662628169",
              "E11": "9.9564354705251938E-12"
            },
            {
              "A52": "50",
              "B52": "Ly75",
              "C52": "5.582770824432373",
              "D52": "1.488738059997559",
              "E52": "9.3233863305752613E-6"
            },
            {
              "A114": "112",
              "B114": "Foxn1",
              "C114": "4.3833942413330078",
              "D114": "1.330366969108582",
              "E114": "2.1814977010770581E-3"
            },
            {
              "A210": "208",
              "B210": "Kitl",
              "C210": "3.6213264465332031",
              "D210": "1.3804794549942021",
              "E210": "3.086852390035371E-2"
            },
            {
              "A257": "255",
              "B257": "Cxcl12",
              "C257": "3.4039609432220459",
              "D257": "0.58627444505691528",
              "E257": "5.8397549415374082E-2"
            },
            {
              "A1034": "1032",
              "B1034": "Dll4",
              "C1034": "2.012134313583374",
              "D1034": "0.78106582164764404",
              "E1034": "1"
            },
            {
              "A1374": "1372",
              "B1374": "Flt3l",
              "C1374": "1.7509521245956421",
              "D1374": "1.3202240467071531",
              "E1374": "1"
            },
            {
              "A1552": "1550",
              "B1552": "Enpep",
              "C1552": "1.6341074705123899",
              "D1552": "0.86625814437866211",
              "E1552": "1"
            },
            {
              "A10577": "10575",
              "B10577": "Il7",
              "C10577": "9.4506740570068359E-3",
              "D10577": "1.514724269509315E-2",
              "E10577": "1"
            },
            {
              "A19067": "19065",
              "B19067": "Fgf10",
              "C19067": "0",
              "D19067": "0",
              "E19067": "1"
            },
            {
              "A23688": "23686",
              "B23688": "Bmp4",
              "C23688": "-6.7013867199420929E-2",
              "D23688": "-0.566436767578125",
              "E23688": "1"
            },
            {
              "A23921": "23919",
              "B23921": "Fezf2",
              "C23921": "-9.7943350672721863E-2",
              "D23921": "0.35481533408164978",
              "E23921": "1"
            },
            {
              "A24011": "24009",
              "B24011": "Fgf21",
              "C24011": "-0.106534868478775",
              "D24011": "-0.71903479099273682",
              "E24011": "1"
            },
            {
              "A25434": "25432",
              "B25434": "Aire",
              "C25434": "-0.16152061522006991",
              "D25434": "-1.7847328186035161",
              "E25434": "1"
            },
            {
              "A26175": "26173",
              "B26175": "Fgf7",
              "C26175": "-0.25259074568748469",
              "D26175": "-24.859489440917969",
              "E26175": "1"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        }
      ]
    },
    {
      "result_id": "A144-R20261012-O21",
      "experiment_id": "A144-R20261012-E12",
      "sample_class_ids": [
        "A144-R20261012-G29",
        "A144-R20261012-G30",
        "A144-R20261012-G31"
      ],
      "metric": "受体配体推断",
      "reported_result": "FGF/BMP相关互作偏向aaTEC；受体表达/CellChat不能单独证明实际竞争性消耗。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig6c–e; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR21"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O22",
      "experiment_id": "A144-R20261012-E13",
      "sample_class_ids": [
        "A144-R20261012-G34"
      ],
      "metric": "FOXN1蛋白流式",
      "reported_result": "FOXN1蛋白在cTEC/mTEC可检出，在aaTEC1/2不明显；此O仅蛋白流式。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "author_reported_text_or_qualitative_image_description",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR22"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O23",
      "experiment_id": "A144-R20261012-E13",
      "sample_class_ids": [
        "A144-R20261012-G38"
      ],
      "metric": "FOXN1计算轨迹支持",
      "reported_result": "计算诱导/抑制FOXN1与分化轨迹相关；不是实际动物干预或蛋白流式读出。",
      "numeric_values": [],
      "measurement_time": null,
      "measurement_time_status": "developmental_or_anatomical_stage_in_group; elapsed_time_not_assumed",
      "measurement_status": "distinct_in_silico_and_existing_model_evidence_no_joint_validation",
      "statistical_unit": "not_inferred_from_group_nodes",
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-5",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        },
        {
          "source_id": "A144-SUPP-6",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        }
      ],
      "artifact_ids": [
        "A144-R20261012-AR23"
      ],
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_source_note",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O24",
      "experiment_id": "A144-R20261012-E12",
      "sample_class_ids": [
        "A144-R20261012-G35"
      ],
      "metric": "pAKT直接信号及FB阴性",
      "reported_result": "KGF响应下cTEC/mTEC/aaTEC出现pAKT反应，FB无对应反应；6只18月雌鼠独立胸腺，mean±SEM、paired t test。与CellChat计算分开。 pAKT读出时点为KGF后5 min。 Fig6e实图纵轴pAKT MFI，配对KGF−/+：cTEC P=.002、mTEC .03、aaTEC1 .03、aaTEC2 .008，FB NS。",
      "numeric_values": [
        {
          "value": 6,
          "unit": "individual_thymuses",
          "age_months": 18
        },
        {
          "metric": "pAKT_MFI",
          "subset": "cTEC",
          "P": 0.002,
          "comparison": "KGF minus versus plus, paired"
        },
        {
          "metric": "pAKT_MFI",
          "subset": "mTEC",
          "P": 0.03,
          "comparison": "KGF minus versus plus, paired"
        },
        {
          "metric": "pAKT_MFI",
          "subset": "aaTEC1",
          "P": 0.03,
          "comparison": "KGF minus versus plus, paired"
        },
        {
          "metric": "pAKT_MFI",
          "subset": "aaTEC2",
          "P": 0.008,
          "comparison": "KGF minus versus plus, paired"
        },
        {
          "metric": "pAKT_MFI",
          "subset": "FB",
          "P": "NS",
          "comparison": "KGF minus versus plus, paired"
        }
      ],
      "measurement_status": "author_reported_text",
      "statistical_unit": "source_specific; not_group_node_count",
      "source_refs": [
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig6e",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_Fig6",
          "locator": "Fig6e",
          "verification": "fresh original artwork independently viewed"
        }
      ],
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [],
      "record_type": "reported_observation",
      "metric_kind": "quantitative",
      "measurement_time": {
        "value": 5,
        "unit": "min",
        "scope": "published KGF response pAKT readout time only"
      }
    },
    {
      "result_id": "A144-R20261012-O25",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G36",
        "A144-R20261012-G37"
      ],
      "metric": "ED7a官方图版纠正",
      "reported_result": "2026-03-13作者纠正：原右图标注Mouse1/2/3实为同一鼠3区域；HTML/PDF已替换为3只不同老年报告鼠。旧版n=1鼠/3区域，新版n=3鼠，仅适用于ED7a；本轮已直接读修正图面，不外推其它结果。 本轮已取得并实读纠正后ED7a原图，右侧UEA1显示Mouse1/2/3；三只不同鼠的身份来自官方纠正声明，非从图片猜测。原版同鼠三区域与新版三鼠范围仅适用a。",
      "numeric_values": [
        {
          "value": 1,
          "unit": "mouse",
          "version": "original"
        },
        {
          "value": 3,
          "unit": "regions",
          "version": "original"
        },
        {
          "value": 3,
          "unit": "mice",
          "version": "corrected"
        }
      ],
      "measurement_status": "official correction plus fresh corrected artwork read",
      "statistical_unit": "source_specific; not_group_node_count",
      "source_refs": [
        {
          "source_id": "A144-R20261012-X07",
          "locator": "Author Correction DOI10.1038/s41590-026-02489-4",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7a corrected Mouse1/2/3 panels",
          "verification": "fresh original artwork independently viewed"
        }
      ],
      "record_type": "source_correction",
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-CF04",
          "binding": "explicit_panel_or_metric_scope; historically_recorded_not_freshly_visual_verified",
          "source_conflict": {
            "id": "A144-CF04",
            "detail": "更正后ED7版本保留；本轮不将更正附录旧图当独立实验。"
          }
        }
      ],
      "metric_kind": "quantitative",
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O26",
      "experiment_id": "A144-R20261012-E09",
      "sample_class_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23"
      ],
      "metric": "损伤早期AUC与老龄指数",
      "reported_result": "Fig5d以0–7日AUC表示早期变化，老龄指数=老年AUC/年轻AUC；每细胞类型报告n10。这里只保留年轻/老年动态支路。 图面y轴实际标Recovery index，而图注/正文用aging index；两称谓并存，不据此假设不同计算。",
      "numeric_values": [
        {
          "value": 10,
          "unit": "reported_n_per_cell_type",
          "metric": "AUC0–7d"
        }
      ],
      "measurement_status": "historical_embedded_caption_read",
      "statistical_unit": "source_specific; not_group_node_count",
      "source_refs": [
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5d–f caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5d axis label",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "conditions_are_not_replicates": true,
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-FIG5D-INDEX-NAME",
          "type": "source_terminology_difference",
          "caption": "aging index; aged AUC/young AUC",
          "actual_axis_label": "Recovery index",
          "resolution": "keep both labels; no numerical formula difference inferred"
        }
      ],
      "record_type": "reported_observation",
      "metric_kind": "quantitative"
    },
    {
      "result_id": "A144-R20261012-O27",
      "experiment_id": "A144-R20261012-E04",
      "sample_class_ids": [
        "A144-R20261012-G10"
      ],
      "metric": "tdTom转录谱系支持",
      "reported_result": "20月Foxn1tdTom报告TEC共1093细胞与18/20月WT7412细胞整合，所有TEC簇包括aaTEC1/2均检测tdTom转录，支持其既往Foxn1谱系来源。细胞数不是鼠n；独立scRNA分支不继承GFP流式。",
      "numeric_values": [
        {
          "value": 1093,
          "unit": "reporter_TEC_cells",
          "age_months": 20
        },
        {
          "value": 7412,
          "unit": "WT_cells",
          "ages_months": [
            18,
            20
          ]
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results Fig3e tdTom reporter integration",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O28",
      "experiment_id": "A144-R20261012-E13",
      "sample_class_ids": [
        "A144-R20261012-G32"
      ],
      "metric": "FOXN1转录低表达",
      "reported_result": "aaTEC1/2的Foxn1转录低表达，与蛋白结果为不同支路，不赋蛋白流式P。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O29",
      "experiment_id": "A144-R20261012-E13",
      "sample_class_ids": [
        "A144-R20261012-G33"
      ],
      "metric": "既有低功能模型结果",
      "reported_result": "6月既有Foxn1低功能模型较对照提前出现aaTEC；仅记录已发表比较，不继承FOXN1蛋白流式流程或重建模型建立。 ED10b各柱来自不同性别/年龄/模型数据，不能当完全匹配干预的定量对照。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED10",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O30",
      "experiment_id": "A144-R20261012-E06",
      "sample_class_ids": [
        "A144-R20261012-G15",
        "A144-R20261012-G16"
      ],
      "metric": "稳态cTEC基因年龄阴性",
      "reported_result": "稳态cTEC中Foxn1/Dll4/Psmb11/Prss16/Enpep/Ly75未观察到随龄表达变化；作者提示全CD45−单细胞中cTEC捕获少可能限制检测，不当等效证明。 新Table4-cTEC原_p列：Cxcl12 .0965814、Foxn1 .894045、Ccl25/Psmb11/Kitl/Dll4/Il7均1，符合这些目标无显著年龄变化；按Methods为FDR调整检验，不改为原始P。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results age-dependent programs; low-cTEC technical caveat",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table4-cTEC exact target cells/headers",
          "verification": "fresh targeted original rows read"
        }
      ],
      "applicable_source_conflicts": [],
      "source_table_rows": [
        {
          "sheet": "Table 4 - cTEC",
          "dimension": "A1:E27658",
          "header": [
            {
              "B1": "18mo_12:cTEC_n",
              "C1": "18mo_12:cTEC_s",
              "D1": "18mo_12:cTEC_l",
              "E1": "18mo_12:cTEC_p"
            },
            {
              "A2": "0",
              "B2": "Igkc",
              "C2": "7.2808656692504883",
              "D2": "4.7631030082702637",
              "E2": "4.5867050999070996E-9"
            }
          ],
          "targeted_rows": [
            {
              "A32": "30",
              "B32": "Cxcl12",
              "C32": "3.6090619564056401",
              "D32": "0.94459325075149536",
              "E32": "9.6581414154867692E-2"
            },
            {
              "A79": "77",
              "B79": "Ly75",
              "C79": "2.7613389492034912",
              "D79": "1.080039501190186",
              "E79": "0.62113621853275136"
            },
            {
              "A270": "268",
              "B270": "Ccl25",
              "C270": "1.8237812519073491",
              "D270": "0.81775695085525513",
              "E270": "1"
            },
            {
              "A290": "288",
              "B290": "Psmb11",
              "C290": "1.7881326675415039",
              "D290": "0.73920166492462158",
              "E290": "1"
            },
            {
              "A305": "303",
              "B305": "Prss16",
              "C305": "1.768169522285461",
              "D305": "0.67612153291702271",
              "E305": "1"
            },
            {
              "A462": "460",
              "B462": "Kitl",
              "C462": "1.472999215126038",
              "D462": "0.93924450874328613",
              "E462": "1"
            },
            {
              "A1564": "1562",
              "B1564": "Flt3l",
              "C1564": "0.71154564619064331",
              "D1564": "1.770009398460388",
              "E1564": "1"
            },
            {
              "A1712": "1710",
              "B1712": "Enpep",
              "C1712": "0.65807276964187622",
              "D1712": "0.87410306930541992",
              "E1712": "1"
            },
            {
              "A3086": "3084",
              "B3086": "Aire",
              "C3086": "0.34222635626792908",
              "D3086": "24.80076789855957",
              "E3086": "1"
            },
            {
              "A3600": "3598",
              "B3600": "Fgf7",
              "C3600": "0.27378109097480768",
              "D3600": "24.796342849731449",
              "E3600": "1"
            },
            {
              "A7157": "7155",
              "B7157": "Bmp4",
              "C7157": "4.2065322399139397E-2",
              "D7157": "0.70629042387008667",
              "E7157": "1"
            },
            {
              "A19667": "19665",
              "B19667": "Dll4",
              "C19667": "-2.2815089672803879E-2",
              "D19667": "-2.8606751933693889E-2",
              "E19667": "1"
            },
            {
              "A23925": "23923",
              "B23925": "Fgf10",
              "C23925": "-0.4662834107875824",
              "D23925": "-24.92961311340332",
              "E23925": "1"
            },
            {
              "A24517": "24515",
              "B24517": "Il7",
              "C24517": "-0.58249777555465698",
              "D24517": "-0.20993685722351069",
              "E24517": "1"
            },
            {
              "A27430": "27428",
              "B27430": "Foxn1",
              "C27430": "-2.548160314559937",
              "D27430": "-0.90101492404937744",
              "E27430": "0.89404492110284306"
            },
            {
              "A27507": "27505",
              "B27507": "Fgf21",
              "C27507": "-2.890386819839478",
              "D27507": "-2.673763513565063",
              "E27507": "0.4859042088283802"
            },
            {
              "A27555": "27553",
              "B27555": "Fezf2",
              "C27555": "-3.221205472946167",
              "D27555": "-1.6513335704803469",
              "E27555": "0.24348186321331641"
            }
          ],
          "scope": "actual selected original cells, not full gene-sheet reanalysis"
        }
      ]
    },
    {
      "result_id": "A144-R20261012-O31",
      "experiment_id": "A144-R20261012-E09",
      "sample_class_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23"
      ],
      "metric": "多数基质亚群早期反应阴性",
      "reported_result": "ED9b多数基质亚群早期反应未见重大年龄差异，aaTEC是例外；不以aaTEC的特殊变化替代整体基质反应。 该正文概述不排除ED9b具体时间点跨龄差异，详见新逐点O；不能把概述作所有基质时点均阴性。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; ExtendedData9b",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O32",
      "experiment_id": "A144-R20261012-E09",
      "sample_class_ids": [
        "A144-R20261012-G40"
      ],
      "metric": "损伤后组织学改变",
      "reported_result": "ED9a组织学显示老年持续纤维化/钙化等改变，年轻无相同持续改变；此比较与aaTEC流式计数、12月右叶透明成像分开，现不外推具体每组n。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Extended Data9a",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O33",
      "experiment_id": "A144-R20261012-E11",
      "sample_class_ids": [
        "A144-R20261012-G27"
      ],
      "metric": "aaTEC组成的损伤后持续性",
      "reported_result": "Fig5j表明aaTEC群在老龄胸腺损伤后仍是突出TEC组分。纵轴是TEC亚群Proportion(%)，不是绝对细胞数；图上比例未数字化，不能凭组成说绝对增加。",
      "numeric_values": [],
      "measurement_status": "published_result_and_fresh_visual_confirmed",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "applicable_source_conflicts": [],
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O34",
      "experiment_id": "A144-R20261012-E11",
      "sample_class_ids": [
        "A144-R20261012-G26"
      ],
      "metric": "年轻组RNA-velocity轨迹",
      "reported_result": "2月组day0/1/4/7的RNA-velocity推断由mTECprol走向常规mTEC2及拟态细胞谱系。箭头表示计算推断，不是同一细胞的实验追踪。",
      "numeric_values": [],
      "measurement_status": "RNA_velocity_inference_fresh_figure_seen",
      "record_type": "computational_inference",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "applicable_source_conflicts": [],
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O35",
      "experiment_id": "A144-R20261012-E11",
      "sample_class_ids": [
        "A144-R20261012-G27"
      ],
      "metric": "老龄组RNA-velocity轨迹",
      "reported_result": "18月组损伤后轨迹偏向mTEC1/earlyprog→aaTEC1/aaTEC2，而非年轻的常规mTEC2/拟态方向；为年龄分层RNA-velocity推断，不作为已证明谱系转分化。",
      "numeric_values": [],
      "measurement_status": "RNA_velocity_inference_fresh_figure_seen",
      "record_type": "computational_inference",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "applicable_source_conflicts": [],
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O36",
      "experiment_id": "A144-R20261012-E11",
      "sample_class_ids": [
        "A144-R20261012-G26",
        "A144-R20261012-G27"
      ],
      "metric": "作者的分化扰动解释",
      "reported_result": "作者据此提出aaTEC可能扰乱老龄胸腺早期分化/再生程序。该项是解释，不是额外消除实验或独立干预结果。",
      "numeric_values": [],
      "measurement_status": "author_interpretation_not_causal_validation",
      "record_type": "author_interpretation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results Fig5j/k",
          "verification": "fresh_primary_Results_read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O37",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G41",
        "A144-R20261012-G42"
      ],
      "metric": "拟态细胞年龄比较",
      "reported_result": "ED7b：2月较18月常规mTEC中Tuft及Corneocyte数量更高，各P=.0007；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。",
      "numeric_values": [
        {
          "subset": "Tuft",
          "P": 0.0007,
          "count_axis_unit": "10^3 cells"
        },
        {
          "subset": "Corneocyte",
          "P": 0.0007,
          "count_axis_unit": "10^3 cells"
        },
        {
          "subset": "M-cell",
          "P": "NS",
          "count_axis_unit": "10^3 cells"
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7b",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7b",
          "verification": "fresh complete official text/captions read"
        }
      ],
      "applicable_source_conflicts": [],
      "reported_n": {
        "2_months": 6,
        "18_months": 8
      },
      "statistics": {
        "error": "SEM",
        "test": "two-tailed Mann–Whitney within mimetic subsets"
      },
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O38",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G42",
        "A144-R20261012-G43"
      ],
      "metric": "老龄mTEC与DN-TEC比较",
      "reported_result": "ED7c：18月mTEC较DN-TEC的Tuft数量更高P=.001、Corneocyte更高P=.005；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。",
      "numeric_values": [
        {
          "subset": "Tuft",
          "P": 0.001,
          "count_axis_unit": "10^3 cells"
        },
        {
          "subset": "Corneocyte",
          "P": 0.005,
          "count_axis_unit": "10^3 cells"
        },
        {
          "subset": "M-cell",
          "P": "NS",
          "count_axis_unit": "10^3 cells"
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7c",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption ED7c",
          "verification": "fresh complete official text/captions read"
        }
      ],
      "applicable_source_conflicts": [],
      "reported_n": {
        "18_months": 8
      },
      "statistics": {
        "error": "SEM",
        "test": "two-tailed Mann–Whitney within mimetic subsets"
      },
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O39",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G44"
      ],
      "metric": "Aire/Foxn1转录支持",
      "reported_result": "ED7d展示TEC子群Aire/Foxn1表达分布，作为转录支持图，不是蛋白流式或额外生物重复。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "transcript_expression_visualization",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7d",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption d",
          "verification": "fresh complete official text/captions read"
        }
      ],
      "applicable_source_conflicts": [],
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O40",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G45"
      ],
      "metric": "AIRE组织定位支持",
      "reported_result": "ED7e 12月报告鼠AIRE在髓质可见，aaTEC/HD区图示缺乏相当AIRE信号；代表图不作细胞阳性率量化，未报告e生物n。图注比例尺50μm，实际两图30/20μm，保留不一致。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-FRESH-A144_ED7_corrected",
          "locator": "ED7e",
          "verification": "fresh original artwork independently viewed"
        },
        {
          "source_id": "A144-FRESH-A144_source_full",
          "locator": "Fig14 caption e",
          "verification": "fresh complete official text/captions read"
        }
      ],
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-ED7E-SCALE",
          "caption_scale_um": 50,
          "artwork_scale_um": {
            "medulla": 30,
            "aaTEC": 20
          },
          "resolution": "preserve source discrepancy; no geometry measurement inferred"
        }
      ],
      "reported_n": {
        "value": null,
        "status": "not_reported_for_panel_e"
      },
      "fresh_visual_review": true
    },
    {
      "result_id": "A144-R20261012-O41",
      "experiment_id": "A144-R20261012-E01",
      "sample_class_ids": [
        "A144-R20261012-G46",
        "A144-R20261012-G47"
      ],
      "metric": "细分TEC的年龄流式绝对计数",
      "reported_result": "Fig1g每年龄n10：老龄cTEC↑P=.01，mTEC1/2/3及tuft↓P=.001/.0001/.0001/.0001，DN-TEC↑.003。细分门控与ED1宽门控不能混成同一cTEC结论；Fig1f另为scaled频率变化，不当绝对数。",
      "numeric_values": [
        {
          "subset": "cTEC",
          "direction": "up",
          "P": 0.01
        },
        {
          "subset": "mTEC1",
          "direction": "down",
          "P": 0.001
        },
        {
          "subset": "mTEC2",
          "direction": "down",
          "P": 0.0001
        },
        {
          "subset": "mTEC3",
          "direction": "down",
          "P": 0.0001
        },
        {
          "subset": "TECtuft",
          "direction": "down",
          "P": 0.0001
        },
        {
          "subset": "DN-TEC",
          "direction": "up",
          "P": 0.003
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1g",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": [],
      "reported_n": {
        "value": 10,
        "per": "age",
        "ages_months": [
          "2",
          "18+"
        ]
      }
    },
    {
      "result_id": "A144-R20261012-O42",
      "experiment_id": "A144-R20261012-E01",
      "sample_class_ids": [
        "A144-R20261012-G48"
      ],
      "metric": "aaTEC中龄已增加的年龄系列",
      "reported_result": "Fig1j/k 2/12/18月各年龄合并男女总n依次15/10/13，图以符号区分性别，aaTEC1/2在12月已增加。计数和Frequency(10^-5)为不同纵轴，不改作百分比；比较仅2vs12与2vs18，没有12vs18检验。",
      "numeric_values": [
        {
          "ages_months": [
            2,
            12,
            18
          ],
          "n": [
            15,
            10,
            13
          ],
          "sex": "mixed male/female; plotted individually",
          "comparisons": "2vs12 and2vs18, no12vs18",
          "aaTEC1_count_p": [
            0.0001,
            0.0001
          ],
          "aaTEC2_count_p": [
            0.007,
            0.003
          ],
          "aaTEC1_frequency_p": [
            0.0001,
            0.0001
          ],
          "aaTEC2_frequency_p": [
            0.0003,
            0.0014
          ],
          "frequency_axis": "Frequency (10^-5), not percent"
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1k",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": [],
      "reported_n": {
        "ages_months": [
          2,
          12,
          18
        ],
        "n": [
          15,
          10,
          13
        ],
        "sex": "male/female"
      }
    },
    {
      "result_id": "A144-R20261012-O43",
      "experiment_id": "A144-R20261012-E04",
      "sample_class_ids": [
        "A144-R20261012-G49"
      ],
      "metric": "aaTEC标记表型的流式支持",
      "reported_result": "Fig3b claudin3+比例aaTEC>mTEC P=.03（n4鼠）；3c在GFP+EpCAM−内PDPN+比例PDGFRα−高于α+ P=.03（n4）。2月c明确No data，不能作年轻阴性。3d报告鼠aaTEC1/2老龄计数↑P=.04/.01，2月n6、18月n4，不能借Fig1k C57BL/6 n。",
      "numeric_values": [
        "Cldn3+ fraction aaTEC>mTEC P=.03,n4mice.",
        "PDPN+ fraction GFP+EpCAM− PDGFRalpha− >alpha+ P=.03,n4;young No data is missing not negative.",
        "Reporter aaTEC1/2 old counts higher P=.04/.01;2mo n6,18mo n4,distinct fromFig1k."
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3b/c/d",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O44",
      "experiment_id": "A144-R20261012-E07",
      "sample_class_ids": [
        "A144-R20261012-G50"
      ],
      "metric": "aaTEC功能相关转录表达低下",
      "reported_result": "aaTEC中Dll4/Psmb11/Kitl/Ccl25/Cxcl12/Il7低；Fezf2/Aire、关键NFκB目标及Tnfrsf11a/Ltbr/Cd40缺乏相应表达；AIRE/FEZF2依赖TRA低或无，主要见mTEC2/mTECprol。仅转录支持，不声称已做T细胞功能干预或绝对无功能。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "transcript_expression_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4f/g/ED8a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O45",
      "experiment_id": "A144-R20261012-E01",
      "sample_class_ids": [
        "A144-R20261012-G51"
      ],
      "metric": "整体退化及宽门控年龄背景",
      "reported_result": "ED1总细胞数对2月：6月NS、9月P=.03、12月.0004、19月+<.0001；皮质/髓质比对2月：6月NS、9月.004、12月NS、19月+.001。宽门控EC12月↑.002，mTEC对2月在6/9/12/19月+均下降<.0001；cTEC/FB未标比较，不能从无星称NS。不同年龄标签/量化图与代表切片保持各自范围。",
      "numeric_values": [
        {
          "a": "Total cellularity vs2mo:6mo NS,9mo .03,12mo .0004,19+<.0001.",
          "c": "Cortex/medulla ratio vs2mo:6mo NS,9mo .004,12mo NS,19+ .001. Histology age labels range2–3,6,8–9,13,19+,not identical plot rounded ages.",
          "d": "EC2vs12 higher .002;mTEC2vs6/9/12/19+ lower all<.0001;cTEC/FB no annotated comparison,do not infer statistical NS.",
          "design": "female C57BL/6;SEM individual biological replicates;one-way ANOVA Dunnett;caption no exact n."
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED1",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": [],
      "statistics": {
        "error": "SEM",
        "test": "one-way ANOVA Dunnett",
        "exact_n": "caption_not_reported"
      }
    },
    {
      "result_id": "A144-R20261012-O46",
      "experiment_id": "A144-R20261012-E01",
      "sample_class_ids": [
        "A144-R20261012-G52"
      ],
      "metric": "基质亚群年龄异质性和阴性",
      "reported_result": "ED4a–c每年龄n10：medFB老龄↑P<.0001；capsFB/intFB NS；aEC/capEC/vEC全NS；PC↑.0007、vSMC↑.003、MEC NS。d独立DN-TEC计数2vs12月.03、2vs18月+.01，2/6/9/12/18月+n14/5/15/5/18，勿借a–c n。",
      "numeric_values": [
        {
          "a": "medFB old higher<.0001;capsFB/intFB NS.",
          "b": "aEC/capEC/vEC all NS.",
          "c": "PC old higher .0007,vSMC .003,MEC NS.",
          "d": "DNTECcounts2vs12 .03,2vs18+ .01;n2/6/9/12/18+months14/5/15/5/18.",
          "design": "a–c n10each2/18months,SEM,two-sidedMannWhitney;dKruskalWallis+Dunn;gate example20months separate."
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O47",
      "experiment_id": "A144-R20261012-E09",
      "sample_class_ids": [
        "A144-R20261012-G53"
      ],
      "metric": "损伤各时间点跨龄差异和明确阴性",
      "reported_result": "ED9b每年龄/时间n10，mean±SEM、2wayANOVA+Sidak。day7 aEC/vEC老龄较高P=.005/.002；capEC全时点NS、aEC/vEC其余时点NS。intFB全时点NS；capsFB day1/4/7老龄较高.04/.01/.001；medFB day0/4/7老龄较高<.0001/.009/.0005，day1 NS。mTEC1 day0/1/7老龄较低.01/.0002/.01；mTEC2 day0/1较低<.0001/.002；mTEC3 day0/1较低.0002/<.0001；tuft day0/1/7较低<.0001/.001/.04；cTEC day0老龄较高.01，aaTEC1/2 day0***。未标注的其他点不自动判NS。",
      "numeric_values": [
        {
          "b_design": "n10/age/time0,1,4,7;meanSEM;cross-age comparisons pertime;two-wayANOVA+Sidak.",
          "b_EC": "day7aEC oldhigher .005,vEC .002;capECalltimesNS;aECday0/1/4NS;vECday0/1/4NS.",
          "b_FB": "intFBeverytimeNS;capsFBday1/4/7oldhigher .04/.01/.001;medFBday0/4/7oldhigher<.0001/.009/.0005,day1NS.",
          "b_TEC": "mTEC1day0/1/7oldlower .01/.0002/.01;mTEC2day0/1oldlower<.0001/.002;mTEC3day0/1oldlower .0002/<.0001;tuftday0/1/7oldlower<.0001/.001/.04;cTECday0oldhigher .01;aaTEC1/2day0oldhigher***. Unannotated points not automatically NS."
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED9b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "applicable_source_conflicts": [],
      "reported_n": {
        "value": 10,
        "per": "age and time",
        "ages_months": [
          2,
          18
        ],
        "days": [
          0,
          1,
          4,
          7
        ]
      }
    },
    {
      "result_id": "A144-R20261012-O48",
      "experiment_id": "A144-R20261012-E11",
      "sample_class_ids": [
        "A144-R20261012-G54",
        "A144-R20261012-G55"
      ],
      "metric": "bulk与scRNA表达一致性支持",
      "reported_result": "正式SupplementFig2比较同时间CD45−样本：横轴log10 bulk RNAseq、纵轴log10平均scRNA技术重复表达。day0四bulk生物重复R=.83/.79/.82/.79；day1三例.84/.84/.86；day4三例.83/.85/.84；day7三例.85/.83/.84，全部Pearson P<2.2e−16。scRNA技术重复精确n未在caption给出；基因点不是动物n，相关支持不证明每个稀少亚群采样无偏。",
      "numeric_values": [
        {
          "type": "Pearson association between log10 averaged scRNA technical-replicate gene expression (y) and log10 bulk biological-replicate gene expression (x),same CD45-negative/timeframe",
          "bulk_biological_replicates_per_day": {
            "0": 4,
            "1": 3,
            "4": 3,
            "7": 3
          },
          "Pearson_R": {
            "0": [
              0.83,
              0.79,
              0.82,
              0.79
            ],
            "1": [
              0.84,
              0.84,
              0.86
            ],
            "4": [
              0.83,
              0.85,
              0.84
            ],
            "7": [
              0.85,
              0.83,
              0.84
            ]
          },
          "P_all": "<2.2e-16",
          "scRNA_technical_n": "not reported in this caption",
          "limitation": "Correlation supports expression concordance,not proof of unbiased sampling of every rare subset."
        }
      ],
      "measurement_status": "author_reported_text",
      "record_type": "computational_association_support",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure2",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure2",
          "verification": "fresh rendered official supplementary PDF read"
        }
      ],
      "applicable_source_conflicts": []
    },
    {
      "result_id": "A144-R20261012-O49",
      "experiment_id": "A144-R20261012-E10",
      "sample_class_ids": [
        "A144-R20261012-G56"
      ],
      "metric": "Video4年龄/时间来源冲突",
      "reported_result": "Video4实际分散帧标18mo untreated/18mo(d21 SL-TBI)，caption却12mo baseline/day28并称associatedFig3e。保持独立代表性来源冲突，不把该影片并入O18 Fig5e/f12月day28量化或借其n。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "source_quality_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-SUPP-8",
          "locator": "Video4 five-source mapping, four distributed frames",
          "verification": "fresh sampled movie artwork read"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "video_findings4",
          "verification": "official caption versus actual frames"
        }
      ],
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-VIDEO4-AGE-TIME",
          "actual_movie": "A18mo untreated/B18mo day21 SL-TBI",
          "official_caption": "12mo baseline/day28; associatedFig3e",
          "resolution": "retain separate representative video labels/caption; not identical toFig5e/f12mo day28 quantitative branch"
        }
      ]
    },
    {
      "result_id": "A144-R20261012-O50",
      "experiment_id": "A144-R20261012-E04",
      "sample_class_ids": [
        "A144-R20261012-G57"
      ],
      "metric": "报告体系特异性的独立支持",
      "reported_result": "ED5a11周体系验证近全部TEC GFP仅Foxn1报告鼠，n2–3、两实验；代表门控百分比不作总体均值。此年轻验证支路不借作Fig3d的2/18月生物n。",
      "numeric_values": [],
      "measurement_status": "author_reported_text",
      "record_type": "reported_observation",
      "metric_kind": "qualitative_or_text",
      "conditions_are_not_replicates": true,
      "source_refs": [
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED5a",
          "verification": "fresh actual ExtendedData artwork/caption independently read"
        }
      ],
      "applicable_source_conflicts": [],
      "reported_n": {
        "range": [
          2,
          3
        ],
        "experiments": 2,
        "age_weeks": 11,
        "scope": "reported tool-validation experiment only"
      }
    }
  ],
  "artifacts": [
    {
      "artifact_id": "A144-R20261012-AR01",
      "type": "source_figure_or_text_result",
      "locator": "Results stromal compartments; Fig1; ED4",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results stromal compartments; Fig1; ED4",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig1/ED4",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 Fig1/ED4",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR02",
      "type": "source_figure_or_text_result",
      "locator": "Results single-cell cohorts; Fig1",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F02",
          "locator": "Results single-cell cohorts; Fig1",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 ED2/3",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 ED2/3",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR03",
      "type": "source_figure_or_text_result",
      "locator": "Results HD clusters; Fig2a,b",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters; Fig2a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2a",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-SUPP-4",
          "locator": "Video1 sampled labels",
          "verification": "fresh sampled frames; supports spatial illustration only, not exact cohort age reconciliation"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 Fig2a",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          },
          {
            "source_id": "A144-SUPP-4",
            "locator": "Video1 sampled labels",
            "verification": "fresh sampled frames; supports spatial illustration only, not exact cohort age reconciliation"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR04",
      "type": "source_figure_or_text_result",
      "locator": "Fig2c; Results HD clusters",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2c; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig2c",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 Fig2c",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR05",
      "type": "source_figure_or_text_result",
      "locator": "Fig2d–f; Results HD clusters",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig2d–f; Results HD clusters",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table3 current workbook versus publisherdescription",
          "verification": "actual worksheet headings/signature size read"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      },
      "table_data": {
        "rows": [
          {
            "sheet": "Table 3 - top 20 (visium)",
            "source_rows": [
              {
                "C1": "SUBSETS",
                "D1": "MOUSE GENES",
                "E1": "",
                "F1": "",
                "G1": "",
                "H1": "",
                "I1": "",
                "J1": "",
                "K1": "",
                "L1": "",
                "M1": "",
                "N1": "",
                "O1": "",
                "P1": "",
                "Q1": "",
                "R1": "",
                "S1": "",
                "T1": "",
                "U1": "",
                "V1": "",
                "W1": ""
              },
              {
                "C2": "",
                "D2": "",
                "E2": "",
                "F2": "",
                "G2": "",
                "H2": "",
                "I2": "",
                "J2": "",
                "K2": "",
                "L2": "",
                "M2": "",
                "N2": "",
                "O2": "",
                "P2": "",
                "Q2": "",
                "R2": "",
                "S2": "",
                "T2": "",
                "U2": "",
                "V2": "",
                "W2": ""
              },
              {
                "A3": "SUBSET SIGNATURE GENES",
                "B3": "Within TEC",
                "C3": "aaTEC1_sign  ",
                "D3": "Zbtb20",
                "E3": "Cd81",
                "F3": "Trpm3",
                "G3": "Gstm1",
                "H3": "Slc16a11",
                "I3": "Btg1",
                "J3": "BC006965",
                "K3": "Cldn3",
                "L3": "Gsta4",
                "M3": "S100a11",
                "N3": "Ly6e",
                "O3": "Cdk19",
                "P3": "Slc9a3r1",
                "Q3": "Ifi27l2a",
                "R3": "Aldoc",
                "S3": "Wfdc18",
                "T3": "Phlda1",
                "U3": "Fam107a",
                "V3": "Gsn",
                "W3": "Anxa2"
              },
              {
                "A4": "",
                "B4": "",
                "C4": "aaTEC2_sign  ",
                "D4": "Csmd1",
                "E4": "Zeb2",
                "F4": "Mgp",
                "G4": "Gsn",
                "H4": "Zbtb20",
                "I4": "Ndrg2",
                "J4": "Serpine2",
                "K4": "Cd81",
                "L4": "Fxyd1",
                "M4": "Laptm4a",
                "N4": "Gpx3",
                "O4": "Socs3",
                "P4": "Igfbp7",
                "Q4": "Airn",
                "R4": "Lgals1",
                "S4": "Fos",
                "T4": "Prrx1",
                "U4": "Prkg1",
                "V4": "Sparc",
                "W4": "Junb"
              },
              {
                "A5": "",
                "B5": "",
                "C5": "cTEC_sign  ",
                "D5": "Ctsl",
                "E5": "Cstb",
                "F5": "Cxcl12",
                "G5": "Prss16",
                "H5": "Krt18",
                "I5": "Gas6",
                "J5": "Pltp",
                "K5": "Slc46a2",
                "L5": "Ndufa11",
                "M5": "Tbata",
                "N5": "Ccl25",
                "O5": "Psmb11",
                "P5": "Tmem131l",
                "Q5": "Nlgn1",
                "R5": "Prxl2b",
                "S5": "Pax1",
                "T5": "Wnt4",
                "U5": "Dpp6",
                "V5": "Psmb9",
                "W5": "Bnip3l"
              },
              {
                "A6": "",
                "B6": "",
                "C6": "early_Pr",
                "D6": "Apoe",
                "E6": "Itm2b",
                "F6": "Dcn",
                "G6": "Gas6",
                "H6": "Gas1",
                "I6": "Rbms3",
                "J6": "Laptm4a",
                "K6": "Ctsl",
                "L6": "Cpne8",
                "M6": "Mir100hg",
                "N6": "Gas5",
                "O6": "Cst3",
                "P6": "Ly6a",
                "Q6": "Ifitm3",
                "R6": "Kazald1",
                "S6": "Mir99ahg",
                "T6": "Ifitm2",
                "U6": "Plpp3",
                "V6": "Oat",
                "W6": "Auts2"
              },
              {
                "A7": "",
                "B7": "",
                "C7": "mTEC1_sign  ",
                "D7": "Ccl21a",
                "E7": "Krt14",
                "F7": "Krt5",
                "G7": "Ifitm3",
                "H7": "Apoe",
                "I7": "Tpm2",
                "J7": "Cald1",
                "K7": "Ifi27l2a",
                "L7": "Ifitm2",
                "M7": "Krt17",
                "N7": "Nxn",
                "O7": "Ctsl",
                "P7": "Eya4",
                "Q7": "Rbms3",
                "R7": "Perp",
                "S7": "Ly6a",
                "T7": "Igfbp4",
                "U7": "Sult5a1",
                "V7": "Map1lc3a",
                "W7": "Ank3"
              },
              {
                "A8": "",
                "B8": "",
                "C8": "mTECprol_sign  ",
                "D8": "H2afz",
                "E8": "Stmn1",
                "F8": "Ran",
                "G8": "Eif5a",
                "H8": "Hmgb2",
                "I8": "Ube2s",
                "J8": "Ybx1",
                "K8": "Phgdh",
                "L8": "Ptma",
                "M8": "Selenoh",
                "N8": "Ppia",
                "O8": "Tubb5",
                "P8": "Nme1",
                "Q8": "Pfn1",
                "R8": "Ranbp1",
                "S8": "Hmgn2",
                "T8": "Hnrnpa1",
                "U8": "Rbm3",
                "V8": "Cks1b",
                "W8": "Banf1"
              },
              {
                "A9": "",
                "B9": "",
                "C9": "mTEC2_sign  ",
                "D9": "Srgn",
                "E9": "Ubd",
                "F9": "Cd52",
                "G9": "Cyba",
                "H9": "Cd74",
                "I9": "H2-Aa",
                "J9": "Syt1",
                "K9": "Csn2",
                "L9": "H2-Eb1",
                "M9": "S100a14",
                "N9": "H2-Oa",
                "O9": "H2-Eb2",
                "P9": "Hdc",
                "Q9": "Mrpl38",
                "R9": "Nfkbia",
                "S9": "Gm48239",
                "T9": "Aire",
                "U9": "Nup85",
                "V9": "Hagh",
                "W9": "Calcb"
              },
              {
                "A10": "",
                "B10": "",
                "C10": "basal_sign  ",
                "D10": "Ly6d",
                "E10": "Dmkn",
                "F10": "Spink5",
                "G10": "Fxyd3",
                "H10": "Skint3",
                "I10": "Dapl1",
                "J10": "Hspb1",
                "K10": "Sfn",
                "L10": "Tacstd2",
                "M10": "Pdzk1ip1",
                "N10": "Prdx5",
                "O10": "Oit1",
                "P10": "Cdkn2a",
                "Q10": "Perp",
                "R10": "Cdkn1a",
                "S10": "Cdkn2b",
                "T10": "Gsta4",
                "U10": "Atox1",
                "V10": "Lypd3",
                "W10": "Cst6"
              },
              {
                "A11": "",
                "B11": "",
                "C11": "tuft_sign  ",
                "D11": "Mctp1",
                "E11": "Gng13",
                "F11": "Avil",
                "G11": "Rgs13",
                "H11": "Espn",
                "I11": "Lrmp",
                "J11": "Anxa4",
                "K11": "Ltc4s",
                "L11": "Ptpn18",
                "M11": "Bmx",
                "N11": "Cystm1",
                "O11": "Ivns1abp",
                "P11": "Fyb",
                "Q11": "Ly6g6f",
                "R11": "Calm2",
                "S11": "Ethe1",
                "T11": "Reep5",
                "U11": "Lima1",
                "V11": "1810046K07Rik",
                "W11": "Abhd2"
              },
              {
                "A12": "",
                "B12": "",
                "C12": "nTEC_sign  ",
                "D12": "Ptprn2",
                "E12": "Cacna2d1",
                "F12": "Car8",
                "G12": "Scg5",
                "H12": "Stxbp5l",
                "I12": "Snap25",
                "J12": "Chga",
                "K12": "Cd9",
                "L12": "Dnajc12",
                "M12": "Ccser1",
                "N12": "Pam",
                "O12": "Camk2n1",
                "P12": "Syt7",
                "Q12": "Cacna1a",
                "R12": "Syt1",
                "S12": "Cacnb2",
                "T12": "Cystm1",
                "U12": "Fam183b",
                "V12": "Cplx2",
                "W12": "Ceacam10"
              },
              {
                "A13": "",
                "B13": "",
                "C13": "goblet_sign  ",
                "D13": "Wfdc2",
                "E13": "Cyp2f2",
                "F13": "Cxcl17",
                "G13": "Gsto1",
                "H13": "S100a11",
                "I13": "Nupr1",
                "J13": "Sorbs2",
                "K13": "Anxa3",
                "L13": "H2-K1",
                "M13": "Krt19",
                "N13": "Fxyd3",
                "O13": "Ly6d",
                "P13": "Ly6e",
                "Q13": "Serpinb11",
                "R13": "Slc12a2",
                "S13": "Anxa1",
                "T13": "Ly6a",
                "U13": "Bace2",
                "V13": "Aqp5",
                "W13": "Atp1b1"
              },
              {
                "A14": "",
                "B14": "",
                "C14": "Mlike_sign  ",
                "D14": "Ccl20",
                "E14": "Ccl9",
                "F14": "Serpinb6a",
                "G14": "Serpinb1a",
                "H14": "Tmsb4x",
                "I14": "2200002D01Rik",
                "J14": "Nostrin",
                "K14": "Ctsh",
                "L14": "Ccl6",
                "M14": "AW112010",
                "N14": "Spib",
                "O14": "Bcl2a1d",
                "P14": "Csn2",
                "Q14": "Cyp2a5",
                "R14": "Fabp1",
                "S14": "Hamp",
                "T14": "Pold1",
                "U14": "Bcl2a1b",
                "V14": "Atox1",
                "W14": "Iscu"
              },
              {
                "A15": "",
                "B15": "Within FB",
                "C15": "capsFB_sign  ",
                "D15": "Pi16",
                "E15": "Timp2",
                "F15": "Fn1",
                "G15": "Opcml",
                "H15": "Cd248",
                "I15": "Mfap5",
                "J15": "Anxa3",
                "K15": "Pcolce2",
                "L15": "Ackr3",
                "M15": "Fndc1",
                "N15": "Igfbp6",
                "O15": "Sema3c",
                "P15": "Clec3b",
                "Q15": "Creb5",
                "R15": "Smpd3",
                "S15": "Tmem100",
                "T15": "Adgrd1",
                "U15": "Ly6c1",
                "V15": "Pcsk6",
                "W15": "Nid1"
              },
              {
                "A16": "",
                "B16": "",
                "C16": "intFB_sign  ",
                "D16": "Smoc2",
                "E16": "Gpx3",
                "F16": "Penk",
                "G16": "Igf1",
                "H16": "Gas1",
                "I16": "Inmt",
                "J16": "Pcolce",
                "K16": "Lrp1",
                "L16": "Itm2a",
                "M16": "Gdf10",
                "N16": "Rbp1",
                "O16": "Fbln1",
                "P16": "Sfrp1",
                "Q16": "Slit3",
                "R16": "Svep1",
                "S16": "Auts2",
                "T16": "Lpl",
                "U16": "Celf2",
                "V16": "Serpinf1",
                "W16": "Il11ra1"
              },
              {
                "A17": "",
                "B17": "",
                "C17": "medFB_sign  ",
                "D17": "Csmd1",
                "E17": "Serpine2",
                "F17": "Enpp2",
                "G17": "Ptn",
                "H17": "Tmem176b",
                "I17": "Tmem176a",
                "J17": "B2m",
                "K17": "Ccl19",
                "L17": "Igfbp7",
                "M17": "Apod",
                "N17": "Bgn",
                "O17": "H2-D1",
                "P17": "Des",
                "Q17": "Ltc4s",
                "R17": "Lhfp",
                "S17": "Ifitm1",
                "T17": "Cd9",
                "U17": "Apoe",
                "V17": "Lsamp",
                "W17": "Ly6e"
              },
              {
                "A18": "",
                "B18": "Within EC",
                "C18": "artEC_sign  ",
                "D18": "Fbln5",
                "E18": "Stmn2",
                "F18": "Clu",
                "G18": "Sema3g",
                "H18": "Glul",
                "I18": "Tm4sf1",
                "J18": "Eps8l2",
                "K18": "Col8a1",
                "L18": "Nebl",
                "M18": "Vegfc",
                "N18": "Alpl",
                "O18": "Arl15",
                "P18": "Gja4",
                "Q18": "Edn1",
                "R18": "S100a6",
                "S18": "Mast4",
                "T18": "Sox17",
                "U18": "Pdgfd",
                "V18": "Fbln2",
                "W18": "Vim"
              },
              {
                "A19": "",
                "B19": "",
                "C19": "capEC_sign  ",
                "D19": "Gpihbp1",
                "E19": "Rgcc",
                "F19": "Fabp4",
                "G19": "Cd36",
                "H19": "Car4",
                "I19": "Mgll",
                "J19": "Cd300lg",
                "K19": "Tcf15",
                "L19": "Kdr",
                "M19": "Arhgap18",
                "N19": "Igfbp7",
                "O19": "Kank3",
                "P19": "Aqp7",
                "Q19": "Etl4",
                "R19": "Tspan13",
                "S19": "Cavin2",
                "T19": "Hspb1",
                "U19": "Ppp1r2",
                "V19": "Lims2",
                "W19": "Fabp5"
              },
              {
                "A20": "",
                "B20": "",
                "C20": "venEC_sign  ",
                "D20": "Lrg1",
                "E20": "Il6st",
                "F20": "Vwf",
                "G20": "Plvap",
                "H20": "mt-Co1",
                "I20": "Selp",
                "J20": "Spint2",
                "K20": "Pcdh7",
                "L20": "mt-Nd4",
                "M20": "2200002D01Rik",
                "N20": "Tmsb10",
                "O20": "Eef1a1",
                "P20": "mt-Co3",
                "Q20": "Bgn",
                "R20": "Pde4d",
                "S20": "mt-Atp6",
                "T20": "Aqp1",
                "U20": "Tpt1",
                "V20": "Ctla2a",
                "W20": "Ackr1"
              }
            ],
            "targeted_rows": [
              {
                "A5": "",
                "B5": "",
                "C5": "cTEC_sign  ",
                "D5": "Ctsl",
                "E5": "Cstb",
                "F5": "Cxcl12",
                "G5": "Prss16",
                "H5": "Krt18",
                "I5": "Gas6",
                "J5": "Pltp",
                "K5": "Slc46a2",
                "L5": "Ndufa11",
                "M5": "Tbata",
                "N5": "Ccl25",
                "O5": "Psmb11",
                "P5": "Tmem131l",
                "Q5": "Nlgn1",
                "R5": "Prxl2b",
                "S5": "Pax1",
                "T5": "Wnt4",
                "U5": "Dpp6",
                "V5": "Psmb9",
                "W5": "Bnip3l"
              },
              {
                "A9": "",
                "B9": "",
                "C9": "mTEC2_sign  ",
                "D9": "Srgn",
                "E9": "Ubd",
                "F9": "Cd52",
                "G9": "Cyba",
                "H9": "Cd74",
                "I9": "H2-Aa",
                "J9": "Syt1",
                "K9": "Csn2",
                "L9": "H2-Eb1",
                "M9": "S100a14",
                "N9": "H2-Oa",
                "O9": "H2-Eb2",
                "P9": "Hdc",
                "Q9": "Mrpl38",
                "R9": "Nfkbia",
                "S9": "Gm48239",
                "T9": "Aire",
                "U9": "Nup85",
                "V9": "Hagh",
                "W9": "Calcb"
              }
            ]
          },
          {
            "sheet": "Table 3 - top 20 markers (d147)",
            "source_rows": [
              {
                "C1": "SUBSETS",
                "D1": "MOUSE GENES",
                "E1": "",
                "F1": "",
                "G1": "",
                "H1": "",
                "I1": "",
                "J1": "",
                "K1": "",
                "L1": "",
                "M1": "",
                "N1": "",
                "O1": "",
                "P1": "",
                "Q1": "",
                "R1": "",
                "S1": "",
                "T1": "",
                "U1": "",
                "V1": "",
                "W1": ""
              },
              {
                "C2": "",
                "D2": "",
                "E2": "",
                "F2": "",
                "G2": "",
                "H2": "",
                "I2": "",
                "J2": "",
                "K2": "",
                "L2": "",
                "M2": "",
                "N2": "",
                "O2": "",
                "P2": "",
                "Q2": "",
                "R2": "",
                "S2": "",
                "T2": "",
                "U2": "",
                "V2": "",
                "W2": ""
              },
              {
                "A3": "SUBSET SIGNATURE GENES",
                "B3": "Within TEC",
                "C3": "aaTEC1_sign  ",
                "D3": "Zbtb20",
                "E3": "Cd81",
                "F3": "Trpm3",
                "G3": "Gstm1",
                "H3": "Slc16a11",
                "I3": "Btg1",
                "J3": "BC006965",
                "K3": "Cldn3",
                "L3": "Gsta4",
                "M3": "S100a11",
                "N3": "Ly6e",
                "O3": "Cdk19",
                "P3": "Slc9a3r1",
                "Q3": "Ifi27l2a",
                "R3": "Aldoc",
                "S3": "Wfdc18",
                "T3": "Phlda1",
                "U3": "Fam107a",
                "V3": "Gsn",
                "W3": "Anxa2"
              },
              {
                "A4": "",
                "B4": "",
                "C4": "aaTEC2_sign  ",
                "D4": "Csmd1",
                "E4": "Zeb2",
                "F4": "Mgp",
                "G4": "Gsn",
                "H4": "Zbtb20",
                "I4": "Ndrg2",
                "J4": "Serpine2",
                "K4": "Cd81",
                "L4": "Fxyd1",
                "M4": "Laptm4a",
                "N4": "Gpx3",
                "O4": "Socs3",
                "P4": "Igfbp7",
                "Q4": "Airn",
                "R4": "Lgals1",
                "S4": "Fos",
                "T4": "Prrx1",
                "U4": "Prkg1",
                "V4": "Sparc",
                "W4": "Junb"
              },
              {
                "A5": "",
                "B5": "",
                "C5": "cTEC_sign  ",
                "D5": "Ctsl",
                "E5": "Cstb",
                "F5": "Cxcl12",
                "G5": "Prss16",
                "H5": "Krt18",
                "I5": "Gas6",
                "J5": "Pltp",
                "K5": "Slc46a2",
                "L5": "Ndufa11",
                "M5": "Tbata",
                "N5": "Ccl25",
                "O5": "Psmb11",
                "P5": "Tmem131l",
                "Q5": "Nlgn1",
                "R5": "Prxl2b",
                "S5": "Pax1",
                "T5": "Wnt4",
                "U5": "Dpp6",
                "V5": "Psmb9",
                "W5": "Bnip3l"
              },
              {
                "A6": "",
                "B6": "",
                "C6": "early_Pr",
                "D6": "Apoe",
                "E6": "Itm2b",
                "F6": "Dcn",
                "G6": "Gas6",
                "H6": "Gas1",
                "I6": "Rbms3",
                "J6": "Laptm4a",
                "K6": "Ctsl",
                "L6": "Cpne8",
                "M6": "Mir100hg",
                "N6": "Gas5",
                "O6": "Cst3",
                "P6": "Ly6a",
                "Q6": "Ifitm3",
                "R6": "Kazald1",
                "S6": "Mir99ahg",
                "T6": "Ifitm2",
                "U6": "Plpp3",
                "V6": "Oat",
                "W6": "Auts2"
              },
              {
                "A7": "",
                "B7": "",
                "C7": "mTEC1_sign  ",
                "D7": "Ccl21a",
                "E7": "Krt14",
                "F7": "Krt5",
                "G7": "Ifitm3",
                "H7": "Apoe",
                "I7": "Tpm2",
                "J7": "Cald1",
                "K7": "Ifi27l2a",
                "L7": "Ifitm2",
                "M7": "Krt17",
                "N7": "Nxn",
                "O7": "Ctsl",
                "P7": "Eya4",
                "Q7": "Rbms3",
                "R7": "Perp",
                "S7": "Ly6a",
                "T7": "Igfbp4",
                "U7": "Sult5a1",
                "V7": "Map1lc3a",
                "W7": "Ank3"
              },
              {
                "A8": "",
                "B8": "",
                "C8": "mTECprol_sign  ",
                "D8": "H2afz",
                "E8": "Stmn1",
                "F8": "Ran",
                "G8": "Eif5a",
                "H8": "Hmgb2",
                "I8": "Ube2s",
                "J8": "Ybx1",
                "K8": "Phgdh",
                "L8": "Ptma",
                "M8": "Selenoh",
                "N8": "Ppia",
                "O8": "Tubb5",
                "P8": "Nme1",
                "Q8": "Pfn1",
                "R8": "Ranbp1",
                "S8": "Hmgn2",
                "T8": "Hnrnpa1",
                "U8": "Rbm3",
                "V8": "Cks1b",
                "W8": "Banf1"
              },
              {
                "A9": "",
                "B9": "",
                "C9": "mTEC2_sign  ",
                "D9": "Srgn",
                "E9": "Ubd",
                "F9": "Cd52",
                "G9": "Cyba",
                "H9": "Cd74",
                "I9": "H2-Aa",
                "J9": "Syt1",
                "K9": "Csn2",
                "L9": "H2-Eb1",
                "M9": "S100a14",
                "N9": "H2-Oa",
                "O9": "H2-Eb2",
                "P9": "Hdc",
                "Q9": "Mrpl38",
                "R9": "Nfkbia",
                "S9": "Gm48239",
                "T9": "Aire",
                "U9": "Nup85",
                "V9": "Hagh",
                "W9": "Calcb"
              },
              {
                "A10": "",
                "B10": "",
                "C10": "basal_sign  ",
                "D10": "Ly6d",
                "E10": "Dmkn",
                "F10": "Spink5",
                "G10": "Fxyd3",
                "H10": "Skint3",
                "I10": "Dapl1",
                "J10": "Hspb1",
                "K10": "Sfn",
                "L10": "Tacstd2",
                "M10": "Pdzk1ip1",
                "N10": "Prdx5",
                "O10": "Oit1",
                "P10": "Cdkn2a",
                "Q10": "Perp",
                "R10": "Cdkn1a",
                "S10": "Cdkn2b",
                "T10": "Gsta4",
                "U10": "Atox1",
                "V10": "Lypd3",
                "W10": "Cst6"
              },
              {
                "A11": "",
                "B11": "",
                "C11": "tuft_sign  ",
                "D11": "Mctp1",
                "E11": "Gng13",
                "F11": "Avil",
                "G11": "Rgs13",
                "H11": "Espn",
                "I11": "Lrmp",
                "J11": "Anxa4",
                "K11": "Ltc4s",
                "L11": "Ptpn18",
                "M11": "Bmx",
                "N11": "Cystm1",
                "O11": "Ivns1abp",
                "P11": "Fyb",
                "Q11": "Ly6g6f",
                "R11": "Calm2",
                "S11": "Ethe1",
                "T11": "Reep5",
                "U11": "Lima1",
                "V11": "1810046K07Rik",
                "W11": "Abhd2"
              },
              {
                "A12": "",
                "B12": "",
                "C12": "nTEC_sign  ",
                "D12": "Ptprn2",
                "E12": "Cacna2d1",
                "F12": "Car8",
                "G12": "Scg5",
                "H12": "Stxbp5l",
                "I12": "Snap25",
                "J12": "Chga",
                "K12": "Cd9",
                "L12": "Dnajc12",
                "M12": "Ccser1",
                "N12": "Pam",
                "O12": "Camk2n1",
                "P12": "Syt7",
                "Q12": "Cacna1a",
                "R12": "Syt1",
                "S12": "Cacnb2",
                "T12": "Cystm1",
                "U12": "Fam183b",
                "V12": "Cplx2",
                "W12": "Ceacam10"
              },
              {
                "A13": "",
                "B13": "",
                "C13": "goblet_sign  ",
                "D13": "Wfdc2",
                "E13": "Cyp2f2",
                "F13": "Cxcl17",
                "G13": "Gsto1",
                "H13": "S100a11",
                "I13": "Nupr1",
                "J13": "Sorbs2",
                "K13": "Anxa3",
                "L13": "H2-K1",
                "M13": "Krt19",
                "N13": "Fxyd3",
                "O13": "Ly6d",
                "P13": "Ly6e",
                "Q13": "Serpinb11",
                "R13": "Slc12a2",
                "S13": "Anxa1",
                "T13": "Ly6a",
                "U13": "Bace2",
                "V13": "Aqp5",
                "W13": "Atp1b1"
              },
              {
                "A14": "",
                "B14": "",
                "C14": "Mlike_sign  ",
                "D14": "Ccl20",
                "E14": "Ccl9",
                "F14": "Serpinb6a",
                "G14": "Serpinb1a",
                "H14": "Tmsb4x",
                "I14": "2200002D01Rik",
                "J14": "Nostrin",
                "K14": "Ctsh",
                "L14": "Ccl6",
                "M14": "AW112010",
                "N14": "Spib",
                "O14": "Bcl2a1d",
                "P14": "Csn2",
                "Q14": "Cyp2a5",
                "R14": "Fabp1",
                "S14": "Hamp",
                "T14": "Pold1",
                "U14": "Bcl2a1b",
                "V14": "Atox1",
                "W14": "Iscu"
              },
              {
                "A15": "",
                "B15": "Within FB",
                "C15": "capsFB_sign  ",
                "D15": "Pi16",
                "E15": "Timp2",
                "F15": "Fn1",
                "G15": "Opcml",
                "H15": "Cd248",
                "I15": "Mfap5",
                "J15": "Anxa3",
                "K15": "Pcolce2",
                "L15": "Ackr3",
                "M15": "Fndc1",
                "N15": "Igfbp6",
                "O15": "Sema3c",
                "P15": "Clec3b",
                "Q15": "Creb5",
                "R15": "Smpd3",
                "S15": "Tmem100",
                "T15": "Adgrd1",
                "U15": "Ly6c1",
                "V15": "Pcsk6",
                "W15": "Nid1"
              },
              {
                "A16": "",
                "B16": "",
                "C16": "intFB_sign  ",
                "D16": "Smoc2",
                "E16": "Gpx3",
                "F16": "Penk",
                "G16": "Igf1",
                "H16": "Gas1",
                "I16": "Inmt",
                "J16": "Pcolce",
                "K16": "Lrp1",
                "L16": "Itm2a",
                "M16": "Gdf10",
                "N16": "Rbp1",
                "O16": "Fbln1",
                "P16": "Sfrp1",
                "Q16": "Slit3",
                "R16": "Svep1",
                "S16": "Auts2",
                "T16": "Lpl",
                "U16": "Celf2",
                "V16": "Serpinf1",
                "W16": "Il11ra1"
              },
              {
                "A17": "",
                "B17": "",
                "C17": "medFB_sign  ",
                "D17": "Csmd1",
                "E17": "Serpine2",
                "F17": "Enpp2",
                "G17": "Ptn",
                "H17": "Tmem176b",
                "I17": "Tmem176a",
                "J17": "B2m",
                "K17": "Ccl19",
                "L17": "Igfbp7",
                "M17": "Apod",
                "N17": "Bgn",
                "O17": "H2-D1",
                "P17": "Des",
                "Q17": "Ltc4s",
                "R17": "Lhfp",
                "S17": "Ifitm1",
                "T17": "Cd9",
                "U17": "Apoe",
                "V17": "Lsamp",
                "W17": "Ly6e"
              },
              {
                "A18": "",
                "B18": "Within EC",
                "C18": "artEC_sign  ",
                "D18": "Fbln5",
                "E18": "Stmn2",
                "F18": "Clu",
                "G18": "Sema3g",
                "H18": "Glul",
                "I18": "Tm4sf1",
                "J18": "Eps8l2",
                "K18": "Col8a1",
                "L18": "Nebl",
                "M18": "Vegfc",
                "N18": "Alpl",
                "O18": "Arl15",
                "P18": "Gja4",
                "Q18": "Edn1",
                "R18": "S100a6",
                "S18": "Mast4",
                "T18": "Sox17",
                "U18": "Pdgfd",
                "V18": "Fbln2",
                "W18": "Vim"
              },
              {
                "A19": "",
                "B19": "",
                "C19": "capEC_sign  ",
                "D19": "Gpihbp1",
                "E19": "Rgcc",
                "F19": "Fabp4",
                "G19": "Cd36",
                "H19": "Car4",
                "I19": "Mgll",
                "J19": "Cd300lg",
                "K19": "Tcf15",
                "L19": "Kdr",
                "M19": "Arhgap18",
                "N19": "Igfbp7",
                "O19": "Kank3",
                "P19": "Aqp7",
                "Q19": "Etl4",
                "R19": "Tspan13",
                "S19": "Cavin2",
                "T19": "Hspb1",
                "U19": "Ppp1r2",
                "V19": "Lims2",
                "W19": "Fabp5"
              },
              {
                "A20": "",
                "B20": "",
                "C20": "venEC_sign  ",
                "D20": "Lrg1",
                "E20": "Il6st",
                "F20": "Vwf",
                "G20": "Plvap",
                "H20": "mt-Co1",
                "I20": "Selp",
                "J20": "Spint2",
                "K20": "Pcdh7",
                "L20": "mt-Nd4",
                "M20": "2200002D01Rik",
                "N20": "Tmsb10",
                "O20": "Eef1a1",
                "P20": "mt-Co3",
                "Q20": "Bgn",
                "R20": "Pde4d",
                "S20": "mt-Atp6",
                "T20": "Aqp1",
                "U20": "Tpt1",
                "V20": "Ctla2a",
                "W20": "Ackr1"
              }
            ],
            "targeted_rows": [
              {
                "A5": "",
                "B5": "",
                "C5": "cTEC_sign  ",
                "D5": "Ctsl",
                "E5": "Cstb",
                "F5": "Cxcl12",
                "G5": "Prss16",
                "H5": "Krt18",
                "I5": "Gas6",
                "J5": "Pltp",
                "K5": "Slc46a2",
                "L5": "Ndufa11",
                "M5": "Tbata",
                "N5": "Ccl25",
                "O5": "Psmb11",
                "P5": "Tmem131l",
                "Q5": "Nlgn1",
                "R5": "Prxl2b",
                "S5": "Pax1",
                "T5": "Wnt4",
                "U5": "Dpp6",
                "V5": "Psmb9",
                "W5": "Bnip3l"
              },
              {
                "A9": "",
                "B9": "",
                "C9": "mTEC2_sign  ",
                "D9": "Srgn",
                "E9": "Ubd",
                "F9": "Cd52",
                "G9": "Cyba",
                "H9": "Cd74",
                "I9": "H2-Aa",
                "J9": "Syt1",
                "K9": "Csn2",
                "L9": "H2-Eb1",
                "M9": "S100a14",
                "N9": "H2-Oa",
                "O9": "H2-Eb2",
                "P9": "Hdc",
                "Q9": "Mrpl38",
                "R9": "Nfkbia",
                "S9": "Gm48239",
                "T9": "Aire",
                "U9": "Nup85",
                "V9": "Hagh",
                "W9": "Calcb"
              }
            ]
          },
          {
            "sheet": "Table 3 - top 20 (human TEC)",
            "source_rows": [
              {
                "C1": "SUBSETS",
                "D1": "MOUSE GENES",
                "E1": "",
                "F1": "",
                "G1": "",
                "H1": "",
                "I1": "",
                "J1": "",
                "K1": "",
                "L1": "",
                "M1": "",
                "N1": "",
                "O1": "",
                "P1": "",
                "Q1": "",
                "R1": "",
                "S1": "",
                "T1": "",
                "U1": "",
                "V1": "",
                "W1": "",
                "X1": "",
                "Y1": "",
                "Z1": "",
                "AA1": "",
                "AB1": "",
                "AC1": "",
                "AD1": "",
                "AE1": "",
                "AF1": "",
                "AG1": ""
              },
              {
                "C2": "",
                "D2": "",
                "E2": "",
                "F2": "",
                "G2": "",
                "H2": "",
                "I2": "",
                "J2": "",
                "K2": "",
                "L2": "",
                "M2": "",
                "N2": "",
                "O2": "",
                "P2": "",
                "Q2": "",
                "R2": "",
                "S2": "",
                "T2": "",
                "U2": "",
                "V2": "",
                "W2": "",
                "X2": "",
                "Y2": "",
                "Z2": "",
                "AA2": "",
                "AB2": "",
                "AC2": "",
                "AD2": "",
                "AE2": "",
                "AF2": "",
                "AG2": ""
              },
              {
                "A3": "SUBSET SIGNATURE GENES",
                "B3": "Within TEC",
                "C3": "aaTEC1_sign  ",
                "D3": "Zbtb20",
                "E3": "Cd81",
                "F3": "Trpm3",
                "G3": "Gstm1",
                "H3": "Slc16a11",
                "I3": "Btg1",
                "J3": "BC006965",
                "K3": "Cldn3",
                "L3": "Gsta4",
                "M3": "S100a11",
                "N3": "Ly6e",
                "O3": "Cdk19",
                "P3": "Slc9a3r1",
                "Q3": "Ifi27l2a",
                "R3": "Aldoc",
                "S3": "Wfdc18",
                "T3": "Phlda1",
                "U3": "Fam107a",
                "V3": "Gsn",
                "W3": "Anxa2",
                "X3": "",
                "Y3": "",
                "Z3": "",
                "AA3": "",
                "AB3": "",
                "AC3": "",
                "AD3": "",
                "AE3": "",
                "AF3": "",
                "AG3": ""
              },
              {
                "A4": "",
                "B4": "",
                "C4": "aaTEC2_sign  ",
                "D4": "Csmd1",
                "E4": "Zeb2",
                "F4": "Mgp",
                "G4": "Gsn",
                "H4": "Zbtb20",
                "I4": "Ndrg2",
                "J4": "Serpine2",
                "K4": "Cd81",
                "L4": "Fxyd1",
                "M4": "Laptm4a",
                "N4": "Gpx3",
                "O4": "Socs3",
                "P4": "Igfbp7",
                "Q4": "Airn",
                "R4": "Lgals1",
                "S4": "Fos",
                "T4": "Prrx1",
                "U4": "Prkg1",
                "V4": "Sparc",
                "W4": "Junb",
                "X4": "",
                "Y4": "",
                "Z4": "",
                "AA4": "",
                "AB4": "",
                "AC4": "",
                "AD4": "",
                "AE4": "",
                "AF4": "",
                "AG4": ""
              },
              {
                "A5": "",
                "B5": "",
                "C5": "cTEC_sign  ",
                "D5": "Ctsl",
                "E5": "Cstb",
                "F5": "Cxcl12",
                "G5": "Prss16",
                "H5": "Krt18",
                "I5": "Gas6",
                "J5": "Pltp",
                "K5": "Slc46a2",
                "L5": "Ndufa11",
                "M5": "Tbata",
                "N5": "Ccl25",
                "O5": "Psmb11",
                "P5": "Tmem131l",
                "Q5": "Nlgn1",
                "R5": "Prxl2b",
                "S5": "Pax1",
                "T5": "Wnt4",
                "U5": "Dpp6",
                "V5": "Psmb9",
                "W5": "Bnip3l",
                "X5": "",
                "Y5": "",
                "Z5": "",
                "AA5": "",
                "AB5": "",
                "AC5": "",
                "AD5": "",
                "AE5": "",
                "AF5": "",
                "AG5": ""
              },
              {
                "A6": "",
                "B6": "",
                "C6": "early_Pr",
                "D6": "Apoe",
                "E6": "Itm2b",
                "F6": "Dcn",
                "G6": "Gas6",
                "H6": "Gas1",
                "I6": "Rbms3",
                "J6": "Laptm4a",
                "K6": "Ctsl",
                "L6": "Cpne8",
                "M6": "Mir100hg",
                "N6": "Gas5",
                "O6": "Cst3",
                "P6": "Ly6a",
                "Q6": "Ifitm3",
                "R6": "Kazald1",
                "S6": "Mir99ahg",
                "T6": "Ifitm2",
                "U6": "Plpp3",
                "V6": "Oat",
                "W6": "Auts2",
                "X6": "",
                "Y6": "",
                "Z6": "",
                "AA6": "",
                "AB6": "",
                "AC6": "",
                "AD6": "",
                "AE6": "",
                "AF6": "",
                "AG6": ""
              },
              {
                "A7": "",
                "B7": "",
                "C7": "mTEC1_sign  ",
                "D7": "Ccl21a",
                "E7": "Krt14",
                "F7": "Krt5",
                "G7": "Ifitm3",
                "H7": "Apoe",
                "I7": "Tpm2",
                "J7": "Cald1",
                "K7": "Ifi27l2a",
                "L7": "Ifitm2",
                "M7": "Krt17",
                "N7": "Nxn",
                "O7": "Ctsl",
                "P7": "Eya4",
                "Q7": "Rbms3",
                "R7": "Perp",
                "S7": "Ly6a",
                "T7": "Igfbp4",
                "U7": "Sult5a1",
                "V7": "Map1lc3a",
                "W7": "Ank3",
                "X7": "",
                "Y7": "",
                "Z7": "",
                "AA7": "",
                "AB7": "",
                "AC7": "",
                "AD7": "",
                "AE7": "",
                "AF7": "",
                "AG7": ""
              },
              {
                "A8": "",
                "B8": "",
                "C8": "mTECprol_sign  ",
                "D8": "H2afz",
                "E8": "Stmn1",
                "F8": "Ran",
                "G8": "Eif5a",
                "H8": "Hmgb2",
                "I8": "Ube2s",
                "J8": "Ybx1",
                "K8": "Phgdh",
                "L8": "Ptma",
                "M8": "Selenoh",
                "N8": "Ppia",
                "O8": "Tubb5",
                "P8": "Nme1",
                "Q8": "Pfn1",
                "R8": "Ranbp1",
                "S8": "Hmgn2",
                "T8": "Hnrnpa1",
                "U8": "Rbm3",
                "V8": "Cks1b",
                "W8": "Banf1",
                "X8": "",
                "Y8": "",
                "Z8": "",
                "AA8": "",
                "AB8": "",
                "AC8": "",
                "AD8": "",
                "AE8": "",
                "AF8": "",
                "AG8": ""
              },
              {
                "A9": "",
                "B9": "",
                "C9": "mTEC2_sign  ",
                "D9": "Srgn",
                "E9": "Ubd",
                "F9": "Cd52",
                "G9": "Cyba",
                "H9": "Cd74",
                "I9": "H2-Aa",
                "J9": "Syt1",
                "K9": "Csn2",
                "L9": "H2-Eb1",
                "M9": "S100a14",
                "N9": "H2-Oa",
                "O9": "H2-Eb2",
                "P9": "Hdc",
                "Q9": "Mrpl38",
                "R9": "Nfkbia",
                "S9": "Gm48239",
                "T9": "Aire",
                "U9": "Nup85",
                "V9": "Hagh",
                "W9": "Calcb",
                "X9": "",
                "Y9": "",
                "Z9": "",
                "AA9": "",
                "AB9": "",
                "AC9": "",
                "AD9": "",
                "AE9": "",
                "AF9": "",
                "AG9": ""
              },
              {
                "A10": "",
                "B10": "",
                "C10": "basal_sign  ",
                "D10": "Ly6d",
                "E10": "Dmkn",
                "F10": "Spink5",
                "G10": "Fxyd3",
                "H10": "Skint3",
                "I10": "Dapl1",
                "J10": "Hspb1",
                "K10": "Sfn",
                "L10": "Tacstd2",
                "M10": "Pdzk1ip1",
                "N10": "Prdx5",
                "O10": "Oit1",
                "P10": "Cdkn2a",
                "Q10": "Perp",
                "R10": "Cdkn1a",
                "S10": "Cdkn2b",
                "T10": "Gsta4",
                "U10": "Atox1",
                "V10": "Lypd3",
                "W10": "Cst6",
                "X10": "",
                "Y10": "",
                "Z10": "",
                "AA10": "",
                "AB10": "",
                "AC10": "",
                "AD10": "",
                "AE10": "",
                "AF10": "",
                "AG10": ""
              },
              {
                "A11": "",
                "B11": "",
                "C11": "tuft_sign  ",
                "D11": "Mctp1",
                "E11": "Gng13",
                "F11": "Avil",
                "G11": "Rgs13",
                "H11": "Espn",
                "I11": "Lrmp",
                "J11": "Anxa4",
                "K11": "Ltc4s",
                "L11": "Ptpn18",
                "M11": "Bmx",
                "N11": "Cystm1",
                "O11": "Ivns1abp",
                "P11": "Fyb",
                "Q11": "Ly6g6f",
                "R11": "Calm2",
                "S11": "Ethe1",
                "T11": "Reep5",
                "U11": "Lima1",
                "V11": "1810046K07Rik",
                "W11": "Abhd2",
                "X11": "",
                "Y11": "",
                "Z11": "",
                "AA11": "",
                "AB11": "",
                "AC11": "",
                "AD11": "",
                "AE11": "",
                "AF11": "",
                "AG11": ""
              },
              {
                "A12": "",
                "B12": "",
                "C12": "nTEC_sign  ",
                "D12": "Ptprn2",
                "E12": "Cacna2d1",
                "F12": "Car8",
                "G12": "Scg5",
                "H12": "Stxbp5l",
                "I12": "Snap25",
                "J12": "Chga",
                "K12": "Cd9",
                "L12": "Dnajc12",
                "M12": "Ccser1",
                "N12": "Pam",
                "O12": "Camk2n1",
                "P12": "Syt7",
                "Q12": "Cacna1a",
                "R12": "Syt1",
                "S12": "Cacnb2",
                "T12": "Cystm1",
                "U12": "Fam183b",
                "V12": "Cplx2",
                "W12": "Ceacam10",
                "X12": "",
                "Y12": "",
                "Z12": "",
                "AA12": "",
                "AB12": "",
                "AC12": "",
                "AD12": "",
                "AE12": "",
                "AF12": "",
                "AG12": ""
              },
              {
                "A13": "",
                "B13": "",
                "C13": "goblet_sign  ",
                "D13": "Wfdc2",
                "E13": "Cyp2f2",
                "F13": "Cxcl17",
                "G13": "Gsto1",
                "H13": "S100a11",
                "I13": "Nupr1",
                "J13": "Sorbs2",
                "K13": "Anxa3",
                "L13": "H2-K1",
                "M13": "Krt19",
                "N13": "Fxyd3",
                "O13": "Ly6d",
                "P13": "Ly6e",
                "Q13": "Serpinb11",
                "R13": "Slc12a2",
                "S13": "Anxa1",
                "T13": "Ly6a",
                "U13": "Bace2",
                "V13": "Aqp5",
                "W13": "Atp1b1",
                "X13": "",
                "Y13": "",
                "Z13": "",
                "AA13": "",
                "AB13": "",
                "AC13": "",
                "AD13": "",
                "AE13": "",
                "AF13": "",
                "AG13": ""
              },
              {
                "A14": "",
                "B14": "",
                "C14": "Mlike_sign  ",
                "D14": "Ccl20",
                "E14": "Ccl9",
                "F14": "Serpinb6a",
                "G14": "Serpinb1a",
                "H14": "Tmsb4x",
                "I14": "2200002D01Rik",
                "J14": "Nostrin",
                "K14": "Ctsh",
                "L14": "Ccl6",
                "M14": "AW112010",
                "N14": "Spib",
                "O14": "Bcl2a1d",
                "P14": "Csn2",
                "Q14": "Cyp2a5",
                "R14": "Fabp1",
                "S14": "Hamp",
                "T14": "Pold1",
                "U14": "Bcl2a1b",
                "V14": "Atox1",
                "W14": "Iscu",
                "X14": "",
                "Y14": "",
                "Z14": "",
                "AA14": "",
                "AB14": "",
                "AC14": "",
                "AD14": "",
                "AE14": "",
                "AF14": "",
                "AG14": ""
              },
              {
                "A15": "",
                "B15": "Within FB",
                "C15": "capsFB_sign  ",
                "D15": "Pi16",
                "E15": "Timp2",
                "F15": "Fn1",
                "G15": "Opcml",
                "H15": "Cd248",
                "I15": "Mfap5",
                "J15": "Anxa3",
                "K15": "Pcolce2",
                "L15": "Ackr3",
                "M15": "Fndc1",
                "N15": "Igfbp6",
                "O15": "Sema3c",
                "P15": "Clec3b",
                "Q15": "Creb5",
                "R15": "Smpd3",
                "S15": "Tmem100",
                "T15": "Adgrd1",
                "U15": "Ly6c1",
                "V15": "Pcsk6",
                "W15": "Nid1",
                "X15": "",
                "Y15": "",
                "Z15": "",
                "AA15": "",
                "AB15": "",
                "AC15": "",
                "AD15": "",
                "AE15": "",
                "AF15": "",
                "AG15": ""
              },
              {
                "A16": "",
                "B16": "",
                "C16": "intFB_sign  ",
                "D16": "Smoc2",
                "E16": "Gpx3",
                "F16": "Penk",
                "G16": "Igf1",
                "H16": "Gas1",
                "I16": "Inmt",
                "J16": "Pcolce",
                "K16": "Lrp1",
                "L16": "Itm2a",
                "M16": "Gdf10",
                "N16": "Rbp1",
                "O16": "Fbln1",
                "P16": "Sfrp1",
                "Q16": "Slit3",
                "R16": "Svep1",
                "S16": "Auts2",
                "T16": "Lpl",
                "U16": "Celf2",
                "V16": "Serpinf1",
                "W16": "Il11ra1",
                "X16": "",
                "Y16": "",
                "Z16": "",
                "AA16": "",
                "AB16": "",
                "AC16": "",
                "AD16": "",
                "AE16": "",
                "AF16": "",
                "AG16": ""
              },
              {
                "A17": "",
                "B17": "",
                "C17": "medFB_sign  ",
                "D17": "Csmd1",
                "E17": "Serpine2",
                "F17": "Enpp2",
                "G17": "Ptn",
                "H17": "Tmem176b",
                "I17": "Tmem176a",
                "J17": "B2m",
                "K17": "Ccl19",
                "L17": "Igfbp7",
                "M17": "Apod",
                "N17": "Bgn",
                "O17": "H2-D1",
                "P17": "Des",
                "Q17": "Ltc4s",
                "R17": "Lhfp",
                "S17": "Ifitm1",
                "T17": "Cd9",
                "U17": "Apoe",
                "V17": "Lsamp",
                "W17": "Ly6e",
                "X17": "",
                "Y17": "",
                "Z17": "",
                "AA17": "",
                "AB17": "",
                "AC17": "",
                "AD17": "",
                "AE17": "",
                "AF17": "",
                "AG17": ""
              },
              {
                "A18": "",
                "B18": "Within EC",
                "C18": "artEC_sign  ",
                "D18": "Fbln5",
                "E18": "Stmn2",
                "F18": "Clu",
                "G18": "Sema3g",
                "H18": "Glul",
                "I18": "Tm4sf1",
                "J18": "Eps8l2",
                "K18": "Col8a1",
                "L18": "Nebl",
                "M18": "Vegfc",
                "N18": "Alpl",
                "O18": "Arl15",
                "P18": "Gja4",
                "Q18": "Edn1",
                "R18": "S100a6",
                "S18": "Mast4",
                "T18": "Sox17",
                "U18": "Pdgfd",
                "V18": "Fbln2",
                "W18": "Vim",
                "X18": "",
                "Y18": "",
                "Z18": "",
                "AA18": "",
                "AB18": "",
                "AC18": "",
                "AD18": "",
                "AE18": "",
                "AF18": "",
                "AG18": ""
              },
              {
                "A19": "",
                "B19": "",
                "C19": "capEC_sign  ",
                "D19": "Gpihbp1",
                "E19": "Rgcc",
                "F19": "Fabp4",
                "G19": "Cd36",
                "H19": "Car4",
                "I19": "Mgll",
                "J19": "Cd300lg",
                "K19": "Tcf15",
                "L19": "Kdr",
                "M19": "Arhgap18",
                "N19": "Igfbp7",
                "O19": "Kank3",
                "P19": "Aqp7",
                "Q19": "Etl4",
                "R19": "Tspan13",
                "S19": "Cavin2",
                "T19": "Hspb1",
                "U19": "Ppp1r2",
                "V19": "Lims2",
                "W19": "Fabp5",
                "X19": "",
                "Y19": "",
                "Z19": "",
                "AA19": "",
                "AB19": "",
                "AC19": "",
                "AD19": "",
                "AE19": "",
                "AF19": "",
                "AG19": ""
              },
              {
                "A20": "",
                "B20": "",
                "C20": "venEC_sign  ",
                "D20": "Lrg1",
                "E20": "Il6st",
                "F20": "Vwf",
                "G20": "Plvap",
                "H20": "mt-Co1",
                "I20": "Selp",
                "J20": "Spint2",
                "K20": "Pcdh7",
                "L20": "mt-Nd4",
                "M20": "2200002D01Rik",
                "N20": "Tmsb10",
                "O20": "Eef1a1",
                "P20": "mt-Co3",
                "Q20": "Bgn",
                "R20": "Pde4d",
                "S20": "mt-Atp6",
                "T20": "Aqp1",
                "U20": "Tpt1",
                "V20": "Ctla2a",
                "W20": "Ackr1",
                "X20": "",
                "Y20": "",
                "Z20": "",
                "AA20": "",
                "AB20": "",
                "AC20": "",
                "AD20": "",
                "AE20": "",
                "AF20": "",
                "AG20": ""
              },
              {
                "A21": "",
                "B21": "",
                "C21": "",
                "D21": "",
                "E21": "",
                "F21": "",
                "G21": "",
                "H21": "",
                "I21": "",
                "J21": "",
                "K21": "",
                "L21": "",
                "M21": "",
                "N21": "",
                "O21": "",
                "P21": "",
                "Q21": "",
                "R21": "",
                "S21": "",
                "T21": "",
                "U21": "",
                "V21": "",
                "W21": "",
                "X21": "",
                "Y21": "",
                "Z21": "",
                "AA21": "",
                "AB21": "",
                "AC21": "",
                "AD21": "",
                "AE21": "",
                "AF21": "",
                "AG21": ""
              },
              {
                "C23": "SUBSETS",
                "D23": "HUMAN ORTHOLOGUE GENES",
                "E23": "",
                "F23": "",
                "G23": "",
                "H23": "",
                "I23": "",
                "J23": "",
                "K23": "",
                "L23": "",
                "M23": "",
                "N23": "",
                "O23": "",
                "P23": "",
                "Q23": "",
                "R23": "",
                "S23": "",
                "T23": "",
                "U23": "",
                "V23": "",
                "W23": "",
                "X23": "",
                "Y23": "",
                "Z23": "",
                "AA23": "",
                "AB23": "",
                "AC23": "",
                "AD23": "",
                "AE23": "",
                "AF23": "",
                "AG23": ""
              },
              {
                "A24": "",
                "B24": "",
                "C24": "",
                "D24": "",
                "E24": "",
                "F24": "",
                "G24": "",
                "H24": "",
                "I24": "",
                "J24": "",
                "K24": "",
                "L24": "",
                "M24": "",
                "N24": "",
                "O24": "",
                "P24": "",
                "Q24": "",
                "R24": "",
                "S24": "",
                "T24": "",
                "U24": "",
                "V24": "",
                "W24": "",
                "X24": "",
                "Y24": "",
                "Z24": "",
                "AA24": "",
                "AB24": "",
                "AC24": "",
                "AD24": "",
                "AE24": "",
                "AF24": "",
                "AG24": ""
              },
              {
                "A25": "SUBSET SIGNATURE GENES",
                "B25": "Within TEC",
                "C25": "aaTEC1_sign  ",
                "D25": "ZBTB20",
                "E25": "CD81",
                "F25": "TRPM3",
                "G25": "GSTM1",
                "H25": "SLC16A11",
                "I25": "BTG1",
                "J25": "---------------",
                "K25": "CLDN3",
                "L25": "GSTA4",
                "M25": "S100A11",
                "N25": "LY6E",
                "O25": "CDK19",
                "P25": "SLC9A3R1",
                "Q25": "IFI27",
                "R25": "ALDOC",
                "S25": "---------------",
                "T25": "PHLDA1",
                "U25": "FAM107A",
                "V25": "GSN",
                "W25": "ANXA2"
              },
              {
                "A26": "",
                "B26": "",
                "C26": "aaTEC2_sign  ",
                "D26": "CSMD1",
                "E26": "ZEB2",
                "F26": "MGP",
                "G26": "GSN",
                "H26": "ZBTB20",
                "I26": "NDRG2",
                "J26": "SERPINE2",
                "K26": "CD81",
                "L26": "FXYD1",
                "M26": "LAPTM4A",
                "N26": "GPX3",
                "O26": "SOCS3",
                "P26": "IGFBP7",
                "Q26": "AIRN",
                "R26": "LGALS1",
                "S26": "FOS",
                "T26": "PRRX1",
                "U26": "PRKG1",
                "V26": "SPARC",
                "W26": "JUNB"
              },
              {
                "A27": "",
                "B27": "",
                "C27": "cTEC_sign  ",
                "D27": "CTSL",
                "E27": "CSTB",
                "F27": "CXCL12",
                "G27": "PRSS16",
                "H27": "KRT18",
                "I27": "GAS6",
                "J27": "PLTP",
                "K27": "SLC46A2",
                "L27": "NDUFA11",
                "M27": "TBATA",
                "N27": "CCL25",
                "O27": "PSMB11",
                "P27": "TMEM131L",
                "Q27": "NLGN1",
                "R27": "FAM213B",
                "S27": "PAX1",
                "T27": "WNT4",
                "U27": "DPP6",
                "V27": "PSMB9",
                "W27": "BNIP3L"
              },
              {
                "A28": "",
                "B28": "",
                "C28": "early_Pr",
                "D28": "APOE",
                "E28": "ITM2B",
                "F28": "DCN",
                "G28": "GAS6",
                "H28": "GAS1",
                "I28": "RBMS3",
                "J28": "LAPTM4A",
                "K28": "CTSL",
                "L28": "CPNE8",
                "M28": "MIR100HG",
                "N28": "GAS5",
                "O28": "CST3",
                "P28": "---------------",
                "Q28": "IFITM3",
                "R28": "KAZALD1",
                "S28": "MIR99AHG",
                "T28": "IFITM2",
                "U28": "PLPP3",
                "V28": "OAT",
                "W28": "AUTS2"
              },
              {
                "A29": "",
                "B29": "",
                "C29": "mTEC1_sign  ",
                "D29": "CCL21A",
                "E29": "KRT14",
                "F29": "KRT5",
                "G29": "IFITM3",
                "H29": "APOE",
                "I29": "TPM2",
                "J29": "CALD1",
                "K29": "IFI27",
                "L29": "IFITM2",
                "M29": "KRT17",
                "N29": "NXN",
                "O29": "CTSL",
                "P29": "EYA4",
                "Q29": "RBMS3",
                "R29": "PERP",
                "S29": "---------------",
                "T29": "IGFBP4",
                "U29": "---------------",
                "V29": "MAP1LC3A",
                "W29": "ANK3"
              },
              {
                "A30": "",
                "B30": "",
                "C30": "mTECprol_sign  ",
                "D30": "H2AFZ",
                "E30": "STMN1",
                "F30": "RAN",
                "G30": "EIF5A",
                "H30": "HMGB2",
                "I30": "UBE2S",
                "J30": "YBX1",
                "K30": "PHGDH",
                "L30": "PTMA",
                "M30": "SELENOH",
                "N30": "PPIA",
                "O30": "TUBB",
                "P30": "NME1",
                "Q30": "PFN1",
                "R30": "RANBP1",
                "S30": "HMGN2",
                "T30": "HNRNPA1",
                "U30": "RBM3",
                "V30": "CKS1B",
                "W30": "BANF1"
              },
              {
                "A31": "",
                "B31": "",
                "C31": "mTEC2_sign  ",
                "D31": "SRGN",
                "E31": "UBD",
                "F31": "CD52",
                "G31": "CYBA",
                "H31": "CD74",
                "I31": "HLA-DQA1",
                "J31": "SYT1",
                "K31": "CSN2",
                "L31": "HLA-DRB1",
                "M31": "S100A14",
                "N31": "HLA-DOA",
                "O31": "HLA-DRB1",
                "P31": "HDC",
                "Q31": "MRPL38",
                "R31": "NFKBIA",
                "S31": "---------------",
                "T31": "AIRE",
                "U31": "NUP85",
                "V31": "HAGH",
                "W31": "CALCB"
              },
              {
                "A32": "",
                "B32": "",
                "C32": "basal_sign  ",
                "D32": "LY6D",
                "E32": "DMKN",
                "F32": "SPINK5",
                "G32": "FXYD3",
                "H32": "---------------",
                "I32": "DAPL1",
                "J32": "HSPB1",
                "K32": "SFN",
                "L32": "TACSTD2",
                "M32": "PDZK1IP1",
                "N32": "PRDX5",
                "O32": "FAM3D",
                "P32": "CDKN2A",
                "Q32": "PERP",
                "R32": "CDKN1A",
                "S32": "CDKN2B",
                "T32": "GSTA4",
                "U32": "ATOX1",
                "V32": "LYPD3",
                "W32": "CST6"
              },
              {
                "A33": "",
                "B33": "",
                "C33": "tuft_sign  ",
                "D33": "MCTP1",
                "E33": "GNG13",
                "F33": "AVIL",
                "G33": "RGS13",
                "H33": "ESPN",
                "I33": "LRMP",
                "J33": "ANXA4",
                "K33": "LTC4S",
                "L33": "PTPN18",
                "M33": "BMX",
                "N33": "CYSTM1",
                "O33": "IVNS1ABP",
                "P33": "FYB",
                "Q33": "LY6G6F",
                "R33": "CALM2",
                "S33": "ETHE1",
                "T33": "REEP5",
                "U33": "LIMA1",
                "V33": "POU2AF2",
                "W33": "ABHD2"
              },
              {
                "A34": "",
                "B34": "",
                "C34": "nTEC_sign  ",
                "D34": "PTPRN2",
                "E34": "CACNA2D1",
                "F34": "CA8",
                "G34": "SCG5",
                "H34": "STXBP5L",
                "I34": "SNAP25",
                "J34": "CHGA",
                "K34": "CD9",
                "L34": "DNAJC12",
                "M34": "CCSER1",
                "N34": "PAM",
                "O34": "CAMK2N1",
                "P34": "SYT7",
                "Q34": "CACNA1A",
                "R34": "SYT1",
                "S34": "CACNB2",
                "T34": "CYSTM1",
                "U34": "FAM183B",
                "V34": "CPLX2",
                "W34": "CEACAM10"
              },
              {
                "A35": "",
                "B35": "",
                "C35": "goblet_sign  ",
                "D35": "WFDC2",
                "E35": "CYP2F1",
                "F35": "CXCL17",
                "G35": "GSTO1",
                "H35": "S100A11",
                "I35": "NUPR1",
                "J35": "SORBS2",
                "K35": "ANXA3",
                "L35": "HLA-A",
                "M35": "KRT19",
                "N35": "FXYD3",
                "O35": "LY6D",
                "P35": "LY6E",
                "Q35": "SERPINB11",
                "R35": "SLC12A2",
                "S35": "ANXA1",
                "T35": "---------------",
                "U35": "BACE2",
                "V35": "AQP5",
                "W35": "ATP1B1"
              },
              {
                "A36": "",
                "B36": "",
                "C36": "Mlike_sign  ",
                "D36": "CCL20",
                "E36": "CCL15",
                "F36": "SERPINB6",
                "G36": "SERPINB1",
                "H36": "TMSB4X",
                "I36": "2200002D01RIK",
                "J36": "NOSTRIN",
                "K36": "CTSH",
                "L36": "CCL23",
                "M36": "---------------",
                "N36": "SPIB",
                "O36": "BCL2A1",
                "P36": "CSN2",
                "Q36": "H2RSP",
                "R36": "FABP1",
                "S36": "HAMP",
                "T36": "POLD1",
                "U36": "BCL2A1B",
                "V36": "ATOX1",
                "W36": "ISCU"
              },
              {
                "A37": "",
                "B37": "Within FB",
                "C37": "capsFB_sign  ",
                "D37": "PI16",
                "E37": "TIMP2",
                "F37": "FN1",
                "G37": "OPCML",
                "H37": "CD248",
                "I37": "MFAP5",
                "J37": "ANXA3",
                "K37": "PCOLCE2",
                "L37": "ACKR3",
                "M37": "FNDC1",
                "N37": "IGFBP6",
                "O37": "SEMA3C",
                "P37": "CLEC3B",
                "Q37": "CREB5",
                "R37": "SMPD3",
                "S37": "TMEM100",
                "T37": "ADGRD1",
                "U37": "---------------",
                "V37": "PCSK6",
                "W37": "NID1"
              },
              {
                "A38": "",
                "B38": "",
                "C38": "intFB_sign  ",
                "D38": "SMOC2",
                "E38": "GPX3",
                "F38": "PENK",
                "G38": "IGF1",
                "H38": "GAS1",
                "I38": "INMT",
                "J38": "PCOLCE",
                "K38": "LRP1",
                "L38": "ITM2A",
                "M38": "GDF10",
                "N38": "RBP1",
                "O38": "FBLN1",
                "P38": "SFRP1",
                "Q38": "SLIT3",
                "R38": "SVEP1",
                "S38": "AUTS2",
                "T38": "LPL",
                "U38": "CELF2",
                "V38": "SERPINF1",
                "W38": "IL11RA1"
              },
              {
                "A39": "",
                "B39": "",
                "C39": "medFB_sign  ",
                "D39": "CSMD1",
                "E39": "SERPINE2",
                "F39": "ENPP2",
                "G39": "PTN",
                "H39": "TMEM176B",
                "I39": "TMEM176A",
                "J39": "B2M",
                "K39": "CCL19",
                "L39": "IGFBP7",
                "M39": "APOD",
                "N39": "BGN",
                "O39": "HLA-A",
                "P39": "DES",
                "Q39": "LTC4S",
                "R39": "LHFP",
                "S39": "IFITM1",
                "T39": "CD9",
                "U39": "APOE",
                "V39": "LSAMP",
                "W39": "LY6E"
              },
              {
                "A40": "",
                "B40": "Within EC",
                "C40": "artEC_sign  ",
                "D40": "FBLN5",
                "E40": "STMN2",
                "F40": "CLU",
                "G40": "SEMA3G",
                "H40": "GLUL",
                "I40": "TM4SF1",
                "J40": "EPS8L2",
                "K40": "COL8A1",
                "L40": "NEBL",
                "M40": "VEGFC",
                "N40": "ALPL",
                "O40": "ARL15",
                "P40": "GJA4",
                "Q40": "EDN1",
                "R40": "S100A6",
                "S40": "MAST4",
                "T40": "SOX17",
                "U40": "PDGFD",
                "V40": "FBLN2",
                "W40": "VIM"
              },
              {
                "A41": "",
                "B41": "",
                "C41": "capEC_sign  ",
                "D41": "GPIHBP1",
                "E41": "RGCC",
                "F41": "FABP4",
                "G41": "CD36",
                "H41": "CA4",
                "I41": "MGLL",
                "J41": "CD300LG",
                "K41": "TCF15",
                "L41": "KDR",
                "M41": "ARHGAP18",
                "N41": "IGFBP7",
                "O41": "KANK3",
                "P41": "AQP7",
                "Q41": "KIAA1217",
                "R41": "TSPAN13",
                "S41": "CAVIN2",
                "T41": "HSPB1",
                "U41": "PPP1R2",
                "V41": "LIMS2",
                "W41": "FABP5"
              },
              {
                "A42": "",
                "B42": "",
                "C42": "venEC_sign  ",
                "D42": "LRG1",
                "E42": "IL6ST",
                "F42": "VWF",
                "G42": "PLVAP",
                "H42": "MT-CO1",
                "I42": "SELP",
                "J42": "SPINT2",
                "K42": "PCDH7",
                "L42": "MT-ND4",
                "M42": "H2RSP",
                "N42": "TMSB10",
                "O42": "EEF1A1",
                "P42": "MT-CO3",
                "Q42": "BGN",
                "R42": "PDE4D",
                "S42": "MT-ATP6",
                "T42": "AQP1",
                "U42": "TPT1",
                "V42": "---------------",
                "W42": "ACKR1"
              },
              {
                "A48": "---------------",
                "B48": "",
                "C48": "= no available orthologue",
                "D48": "",
                "E48": "",
                "F48": "",
                "G48": ""
              },
              {
                "A49": "GENE X;GENE Y",
                "B49": "",
                "C49": "= orthogue gene(s) different to the mouse annotation",
                "D49": "",
                "E49": "",
                "F49": "",
                "G49": ""
              }
            ],
            "targeted_rows": [
              {
                "A5": "",
                "B5": "",
                "C5": "cTEC_sign  ",
                "D5": "Ctsl",
                "E5": "Cstb",
                "F5": "Cxcl12",
                "G5": "Prss16",
                "H5": "Krt18",
                "I5": "Gas6",
                "J5": "Pltp",
                "K5": "Slc46a2",
                "L5": "Ndufa11",
                "M5": "Tbata",
                "N5": "Ccl25",
                "O5": "Psmb11",
                "P5": "Tmem131l",
                "Q5": "Nlgn1",
                "R5": "Prxl2b",
                "S5": "Pax1",
                "T5": "Wnt4",
                "U5": "Dpp6",
                "V5": "Psmb9",
                "W5": "Bnip3l",
                "X5": "",
                "Y5": "",
                "Z5": "",
                "AA5": "",
                "AB5": "",
                "AC5": "",
                "AD5": "",
                "AE5": "",
                "AF5": "",
                "AG5": ""
              },
              {
                "A9": "",
                "B9": "",
                "C9": "mTEC2_sign  ",
                "D9": "Srgn",
                "E9": "Ubd",
                "F9": "Cd52",
                "G9": "Cyba",
                "H9": "Cd74",
                "I9": "H2-Aa",
                "J9": "Syt1",
                "K9": "Csn2",
                "L9": "H2-Eb1",
                "M9": "S100a14",
                "N9": "H2-Oa",
                "O9": "H2-Eb2",
                "P9": "Hdc",
                "Q9": "Mrpl38",
                "R9": "Nfkbia",
                "S9": "Gm48239",
                "T9": "Aire",
                "U9": "Nup85",
                "V9": "Hagh",
                "W9": "Calcb",
                "X9": "",
                "Y9": "",
                "Z9": "",
                "AA9": "",
                "AB9": "",
                "AC9": "",
                "AD9": "",
                "AE9": "",
                "AF9": "",
                "AG9": ""
              }
            ]
          }
        ],
        "source": null,
        "kind": "published source rows, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR06",
      "type": "source_figure_or_text_result",
      "locator": "Results HD clusters interpretation",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results HD clusters interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR07",
      "type": "source_figure_or_text_result",
      "locator": "Fig3a–e; Results lineage",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3a–e; Results lineage",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 ED5a",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR08",
      "type": "source_figure_or_text_result",
      "locator": "Fig3f,g; Discussion lineage caveat",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3f,g; Discussion lineage caveat",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR09",
      "type": "source_figure_or_text_result",
      "locator": "Fig3h–k; Discussion",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig3h–k; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-7",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n",
          "applicable_sample_ids": [
            "A144-R20261012-G12"
          ],
          "supports_scope": "mouse representative spatial exclusion only; not human tissue or exact depletion fraction"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-SUPP-7",
            "locator": "four distributed movie frames",
            "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR10",
      "type": "source_figure_or_text_result",
      "locator": "Results human TEC paragraph",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results human TEC paragraph",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig3h–k/ED5d–f",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 Fig3h–k/ED5d–f",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR11",
      "type": "source_figure_or_text_result",
      "locator": "Fig4a; Discussion; Table5 description",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4a; Discussion; Table5 description",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR12",
      "type": "source_figure_or_text_result",
      "locator": "Results EMT; Fig4b",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4b",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        },
        {
          "source_id": "A144-WORKBOOK-HEADERS",
          "locator": "Table6-aaTEC1 negative row8/aaTEC2 positive row4",
          "verification": "fresh targeted original rows read"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 Fig4b",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      },
      "table_data": {
        "rows": [
          {
            "sheet": "Table 6 - aaTEC1 m5 -enrichment",
            "dimension": "A1:K3876",
            "header": [
              {
                "A1": "Table: Gene sets enriched in phenotype na [plain text format]",
                "B1": "",
                "C1": "",
                "D1": "",
                "E1": "",
                "F1": "",
                "G1": "",
                "H1": "",
                "I1": "",
                "J1": "",
                "K1": ""
              },
              {
                "A2": "",
                "B2": "GS",
                "C2": "GS DETAILS",
                "D2": "SIZE",
                "E2": "ES",
                "F2": "NES",
                "G2": "NOM p-val",
                "H2": "FDR q-val",
                "I2": "FWER p-val",
                "J2": "RANK AT MAX",
                "K2": "LEADING EDGE"
              }
            ],
            "targeted_rows": [
              {
                "A8": "5",
                "B8": "GOBP_ANTIGEN_PROCESSING_AND_PRESENTATION_OF_PEPTIDE_ANTIGEN",
                "C8": "Details ...",
                "D8": "68",
                "E8": "-0.8",
                "F8": "-1.8",
                "G8": "0",
                "H8": "0",
                "I8": "0",
                "J8": "978",
                "K8": "tags=29%, list=4%, signal=30%"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 6 - aaTEC2 hm +enrichment",
            "dimension": "A1:K16",
            "header": [
              {
                "A1": "Table: Gene sets enriched in phenotype na [plain text format]",
                "B1": "",
                "C1": "",
                "D1": "",
                "E1": "",
                "F1": "",
                "G1": "",
                "H1": "",
                "I1": "",
                "J1": "",
                "K1": ""
              },
              {
                "A2": "",
                "B2": "GS",
                "C2": "GS DETAILS",
                "D2": "SIZE",
                "E2": "ES",
                "F2": "NES",
                "G2": "NOM p-val",
                "H2": "FDR q-val",
                "I2": "FWER p-val",
                "J2": "RANK AT MAX",
                "K2": "LEADING EDGE"
              }
            ],
            "targeted_rows": [
              {
                "A4": "1",
                "B4": "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION",
                "C4": "Details ...",
                "D4": "193",
                "E4": "0.74",
                "F4": "2.4",
                "G4": "0",
                "H4": "0",
                "I4": "0",
                "J4": "1810",
                "K4": "tags=56%, list=7%, signal=60%"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          }
        ],
        "source": null,
        "kind": "published source rows, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR13",
      "type": "source_figure_or_text_result",
      "locator": "Results EMT; Fig4c–g",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results EMT; Fig4c–g",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR14",
      "type": "source_figure_or_text_result",
      "locator": "Fig4h,i; Discussion sink interpretation",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig4h,i; Discussion sink interpretation",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR15",
      "type": "source_figure_or_text_result",
      "locator": "Historical mapped Fig4j and protocol P003",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-X10",
          "locator": "Fig4j caption and Results",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        },
        {
          "source_id": "A144-REMAINING-ARTWORK-REPORT",
          "locator": "A144 Fig4j",
          "verification": "independent fresh actual artwork read; source asset hashes in manifest"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-REMAINING-ARTWORK-REPORT",
            "locator": "A144 Fig4j",
            "verification": "independent fresh actual artwork read; source asset hashes in manifest"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR16",
      "type": "source_figure_or_text_result",
      "locator": "Results repair; Fig5a,b",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Results repair; Fig5a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5a caption",
          "verification": "indexed_primary_text_or_explicit_historical_excerpt; no_fresh_visual_read"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR17",
      "type": "source_figure_or_text_result",
      "locator": "Fig5c,d; ED9; Results",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F03",
          "locator": "Fig5c,d; ED9; Results",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR18",
      "type": "source_figure_or_text_result",
      "locator": "Results repair; Fig5e,f",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-HF01",
          "locator": "HRAW013 Fig5e/f,12mo male right-lobe atday28; original author caption retained",
          "verification": "specific_existing_primary_source_rechecked_after_independent_review"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Fig5e/f; printed P labels and direction",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-FIG5-ORIGINAL-IMAGE",
            "locator": "Fig5e/f; printed P labels and direction",
            "verification": "fresh_actual_image_viewed; no_curve_digitization"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR19",
      "type": "source_figure_or_text_result",
      "locator": "Methods mapping; Fig5g–k; FigS2",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-FIG5GK-TEXT",
          "locator": "Results epithelial developmental program after injury; Fig5g–i",
          "verification": "fresh primary text read"
        },
        {
          "source_id": "A144-FIG5-ORIGINAL-IMAGE",
          "locator": "Figure5 original published image, f–k",
          "verification": "fresh_actual_image_viewed; no_curve_digitization"
        },
        {
          "source_id": "A144-SUPP-READ",
          "locator": "SupplementFigure1",
          "verification": "fresh original supplementary source read"
        },
        {
          "source_id": "A144-SUPP-1",
          "locator": "SupplementFigure1",
          "verification": "fresh rendered official supplementary PDF read"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-FIG5-ORIGINAL-IMAGE",
            "locator": "Figure5 original published image, f–k",
            "verification": "fresh_actual_image_viewed; no_curve_digitization"
          },
          {
            "source_id": "A144-SUPP-1",
            "locator": "SupplementFigure1",
            "verification": "fresh rendered official supplementary PDF read"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR20",
      "type": "source_figure_or_text_result",
      "locator": "Results regeneration signaling; Fig6a,b",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results regeneration signaling; Fig6a,b",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-9",
          "locator": "Tables7–10 cTEC/intFB/medFB day4/day7 versusday1",
          "verification": "fresh targeted original workbook rows read"
        },
        {
          "source_id": "A144-WORKBOOK-TARGETROWS",
          "locator": "all selected rows retain Excel positions",
          "verification": "independent targeted cell audit"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      },
      "table_data": {
        "rows": [
          {
            "sheet": "Table 7 - intFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d4_4:intFB_n",
                "C1": "d4_4:intFB_s",
                "D1": "d4_4:intFB_l",
                "E1": "d4_4:intFB_p"
              },
              {
                "A2": "0",
                "B2": "Dcn",
                "C2": "67.420204162597656",
                "D2": "2.2825074195861821",
                "E2": "0"
              }
            ],
            "targeted_rows": [
              {
                "A104": "102",
                "B104": "Fgf10",
                "C104": "23.312576293945309",
                "D104": "2.123639822006226",
                "E104": "2.4747382253491682E-118"
              },
              {
                "A268": "266",
                "B268": "Bmp4",
                "C268": "11.779688835144039",
                "D268": "1.6235083341598511",
                "E268": "1.2366104349531119E-30"
              },
              {
                "A758": "756",
                "B758": "Fgf7",
                "C758": "3.9243426322937012",
                "D758": "0.60782504081726074",
                "E758": "6.7343706036317088E-4"
              },
              {
                "A1683": "1681",
                "B1683": "Prss16",
                "C1683": "1.107318520545959",
                "D1683": "3.507567167282104",
                "E1683": "0.98191907504444975"
              },
              {
                "A3110": "3108",
                "B3110": "Psmb11",
                "C3110": "0.20164716243743899",
                "D3110": "3.5239465236663818",
                "E3110": "1"
              },
              {
                "A3706": "3704",
                "B3706": "Foxn1",
                "C3706": "9.9866330623626709E-2",
                "D3706": "21.032882690429691",
                "E3706": "1"
              },
              {
                "A17590": "17588",
                "B17590": "Ly75",
                "C17590": "-5.3546406328678131E-2",
                "D17590": "-0.39011061191558838",
                "E17590": "1"
              },
              {
                "A18295": "18293",
                "B18295": "Dll4",
                "C18295": "-7.5379610061645508E-2",
                "D18295": "-1.6050505638122561",
                "E18295": "1"
              },
              {
                "A19171": "19169",
                "B19171": "Fezf2",
                "C19171": "-0.13168369233608249",
                "D19171": "-1.629582405090332",
                "E19171": "1"
              },
              {
                "A19725": "19723",
                "B19725": "Aire",
                "C19725": "-0.19075535237789151",
                "D19725": "-21.234502792358398",
                "E19725": "1"
              },
              {
                "A20109": "20107",
                "B20109": "Flt3l",
                "C20109": "-0.25428095459938049",
                "D20109": "0.3710116446018219",
                "E20109": "1"
              },
              {
                "A20475": "20473",
                "B20475": "Fgf21",
                "C20475": "-0.3365497887134552",
                "D20475": "-1.35902464389801",
                "E20475": "1"
              },
              {
                "A22347": "22345",
                "B22347": "Il7",
                "C22347": "-1.0057756900787349",
                "D22347": "-0.43575716018676758",
                "E22347": "1"
              },
              {
                "A23900": "23898",
                "B23900": "Ccl25",
                "C23900": "-1.9504363536834719",
                "D23900": "-0.11644810438156129",
                "E23900": "0.24204200306773041"
              },
              {
                "A24423": "24421",
                "B24423": "Enpep",
                "C24423": "-2.3576092720031738",
                "D24423": "-0.1124733164906502",
                "E24423": "9.7391663291404904E-2"
              },
              {
                "A25788": "25786",
                "B25788": "Kitl",
                "C25788": "-3.9057283401489258",
                "D25788": "-0.30991339683532709",
                "E25788": "7.2549559683139587E-4"
              },
              {
                "A27335": "27333",
                "B27335": "Cxcl12",
                "C27335": "-8.19415283203125",
                "D27335": "-0.46482521295547491",
                "E27335": "4.0066123278734387E-15"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 7 - medFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d4_5:medFB_n",
                "C1": "d4_5:medFB_s",
                "D1": "d4_5:medFB_l",
                "E1": "d4_5:medFB_p"
              },
              {
                "A2": "0",
                "B2": "Dcn",
                "C2": "39.990711212158203",
                "D2": "1.7427880764007571",
                "E2": "0"
              }
            ],
            "targeted_rows": [
              {
                "A114": "112",
                "B114": "Flt3l",
                "C114": "12.704079627990721",
                "D114": "2.2564442157745361",
                "E114": "2.611222663281839E-35"
              },
              {
                "A352": "350",
                "B352": "Fgf10",
                "C352": "5.0493063926696777",
                "D352": "1.836877226829529",
                "E352": "5.5095667832321464E-6"
              },
              {
                "A462": "460",
                "B462": "Bmp4",
                "C462": "3.730049848556519",
                "D462": "1.014898896217346",
                "E462": "1.7585743109197411E-3"
              },
              {
                "A981": "979",
                "B981": "Fgf7",
                "C981": "1.272124767303467",
                "D981": "1.3513059616088869",
                "E981": "0.89012147457900992"
              },
              {
                "A1198": "1196",
                "B1198": "Kitl",
                "C1198": "0.91713196039199829",
                "D1198": "0.80929940938949585",
                "E1198": "1"
              },
              {
                "A1540": "1538",
                "B1540": "Prss16",
                "C1540": "0.5447201132774353",
                "D1540": "24.030990600585941",
                "E1540": "1"
              },
              {
                "A2530": "2528",
                "B2530": "Psmb11",
                "C2530": "0.14497913420200351",
                "D2530": "1.885170698165894",
                "E2530": "1"
              },
              {
                "A3157": "3155",
                "B3157": "Dll4",
                "C3157": "7.2292439639568329E-2",
                "D3157": "1.2525550127029419",
                "E3157": "1"
              },
              {
                "A15520": "15518",
                "B15520": "Foxn1",
                "C15520": "-2.3834642022848129E-2",
                "D15520": "-0.62562578916549683",
                "E15520": "1"
              },
              {
                "A17254": "17252",
                "B17254": "Aire",
                "C17254": "-4.7597602009773247E-2",
                "D17254": "-0.33670014142990112",
                "E17254": "1"
              },
              {
                "A18688": "18686",
                "B18688": "Ly75",
                "C18688": "-0.1035462915897369",
                "D18688": "-1.0687296390533449",
                "E18688": "1"
              },
              {
                "A19187": "19185",
                "B19187": "Fezf2",
                "C19187": "-0.13978211581707001",
                "D19187": "-21.21689605712891",
                "E19187": "1"
              },
              {
                "A21338": "21336",
                "B21338": "Il7",
                "C21338": "-0.54454094171524048",
                "D21338": "-9.195476770401001E-2",
                "E21338": "1"
              },
              {
                "A21471": "21469",
                "B21471": "Fgf21",
                "C21471": "-0.58708488941192627",
                "D21471": "-23.631855010986332",
                "E21471": "1"
              },
              {
                "A21622": "21620",
                "B21622": "Enpep",
                "C21622": "-0.63430613279342651",
                "D21622": "0.20868505537509921",
                "E21622": "1"
              },
              {
                "A24603": "24601",
                "B24603": "Ccl25",
                "C24603": "-2.1131291389465332",
                "D24603": "-0.3869953453540802",
                "E24603": "0.20400479125243881"
              },
              {
                "A27905": "27903",
                "B27905": "Cxcl12",
                "C27905": "-9.2999544143676758",
                "D27905": "-0.79452168941497803",
                "E27905": "3.9722809852865522E-19"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 7 - cTEC",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d4_12:cTEC_n",
                "C1": "d4_12:cTEC_s",
                "D1": "d4_12:cTEC_l",
                "E1": "d4_12:cTEC_p"
              },
              {
                "A2": "0",
                "B2": "Tbata",
                "C2": "10.52055740356445",
                "D2": "6.3629546165466309",
                "E2": "1.997155955561914E-21"
              }
            ],
            "targeted_rows": [
              {
                "A3": "1",
                "B3": "Psmb11",
                "C3": "9.8305673599243164",
                "D3": "5.4941515922546387",
                "E3": "1.1953504907397129E-18"
              },
              {
                "A5": "3",
                "B5": "Prss16",
                "C5": "9.3327713012695312",
                "D5": "4.4396710395812988",
                "E5": "7.4135431726773484E-17"
              },
              {
                "A7": "5",
                "B7": "Ccl25",
                "C7": "9.0385112762451172",
                "D7": "4.9755640029907227",
                "E7": "7.6106506916125021E-16"
              },
              {
                "A44": "42",
                "B44": "Cxcl12",
                "C44": "6.0833721160888672",
                "D44": "1.71248471736908",
                "E44": "5.8337132336885738E-7"
              },
              {
                "A58": "56",
                "B58": "Ly75",
                "C58": "5.5390205383300781",
                "D58": "2.1940159797668461",
                "E58": "1.166059773504644E-5"
              },
              {
                "A113": "111",
                "B113": "Il7",
                "C113": "4.5858073234558114",
                "D113": "1.706179261207581",
                "E113": "9.2876197193953044E-4"
              },
              {
                "A212": "210",
                "B212": "Dll4",
                "C212": "3.7865889072418208",
                "D212": "4.8266863822937012",
                "E212": "1.6824819210170459E-2"
              },
              {
                "A423": "421",
                "B423": "Kitl",
                "C423": "2.8918700218200679",
                "D423": "1.765585660934448",
                "E423": "0.21337906376895099"
              },
              {
                "A456": "454",
                "B456": "Foxn1",
                "C456": "2.826810359954834",
                "D456": "0.95017474889755249",
                "E456": "0.244882446198606"
              },
              {
                "A1684": "1682",
                "B1684": "Flt3l",
                "C1684": "1.462349057197571",
                "D1684": "2.5546503067016602",
                "E1684": "1"
              },
              {
                "A1817": "1815",
                "B1817": "Enpep",
                "C1817": "1.387142539024353",
                "D1817": "1.190905690193176",
                "E1817": "1"
              },
              {
                "A5914": "5912",
                "B5914": "Bmp4",
                "C5914": "0.32947620749473572",
                "D5914": "24.75124549865723",
                "E5914": "1"
              },
              {
                "A7012": "7010",
                "B7012": "Fgf21",
                "C7012": "0.19458197057247159",
                "D7012": "0.68211609125137329",
                "E7012": "1"
              },
              {
                "A9628": "9626",
                "B9628": "Fgf10",
                "C9628": "5.491270124912262E-2",
                "D9628": "21.930328369140621",
                "E9628": "1"
              },
              {
                "A25750": "25748",
                "B25750": "Fgf7",
                "C25750": "-0.21368204057216639",
                "D25750": "-2.6370441913604741",
                "E25750": "1"
              },
              {
                "A25881": "25879",
                "B25881": "Aire",
                "C25881": "-0.2148757874965668",
                "D25881": "-4.0730476379394531",
                "E25881": "1"
              },
              {
                "A28098": "28096",
                "B28098": "Fezf2",
                "C28098": "-0.89949393272399902",
                "D28098": "-0.99402034282684326",
                "E28098": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 8 - intFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d7_4:intFB_n",
                "C1": "d7_4:intFB_s",
                "D1": "d7_4:intFB_l",
                "E1": "d7_4:intFB_p"
              },
              {
                "A2": "0",
                "B2": "Dcn",
                "C2": "65.382774353027344",
                "D2": "2.0832843780517578",
                "E2": "0"
              }
            ],
            "targeted_rows": [
              {
                "A142": "140",
                "B142": "Bmp4",
                "C142": "23.983200073242191",
                "D142": "2.3303813934326172",
                "E142": "3.262200388112031E-125"
              },
              {
                "A233": "231",
                "B233": "Fgf10",
                "C233": "18.270095825195309",
                "D233": "1.5764105319976811",
                "E233": "7.2486161965141762E-73"
              },
              {
                "A719": "717",
                "B719": "Fgf7",
                "C719": "8.1659765243530273",
                "D719": "0.79965806007385254",
                "E719": "5.6764122217721278E-15"
              },
              {
                "A1595": "1593",
                "B1595": "Kitl",
                "C1595": "3.6669235229492192",
                "D1595": "0.68584418296813965",
                "E1595": "2.0553925134160931E-3"
              },
              {
                "A1653": "1651",
                "B1653": "Flt3l",
                "C1653": "3.5104794502258301",
                "D1653": "0.68599075078964233",
                "E1653": "3.6156170088360441E-3"
              },
              {
                "A3209": "3207",
                "B3209": "Prss16",
                "C3209": "1.344456553459167",
                "D3209": "3.5605208873748779",
                "E3209": "0.78331259366127204"
              },
              {
                "A4651": "4649",
                "B4651": "Psmb11",
                "C4651": "0.56480789184570312",
                "D4651": "4.6817498207092294",
                "E4651": "1"
              },
              {
                "A6194": "6192",
                "B6194": "Foxn1",
                "C6194": "0.18296407163143161",
                "D6194": "21.4109001159668",
                "E6194": "1"
              },
              {
                "A7462": "7460",
                "B7462": "Dll4",
                "C7462": "6.6552214324474335E-2",
                "D7462": "1.121114134788513",
                "E7462": "1"
              },
              {
                "A18192": "18190",
                "B18192": "Ly75",
                "C18192": "-9.2595182359218597E-3",
                "D18192": "0.2344200611114502",
                "E18192": "1"
              },
              {
                "A19484": "19482",
                "B19484": "Ccl25",
                "C19484": "-2.0109238103032109E-2",
                "D19484": "0.26819592714309692",
                "E19484": "1"
              },
              {
                "A21699": "21697",
                "B21699": "Fezf2",
                "C21699": "-8.524390310049057E-2",
                "D21699": "-0.6648133397102356",
                "E21699": "1"
              },
              {
                "A21715": "21713",
                "B21715": "Aire",
                "C21715": "-8.6370676755905151E-2",
                "D21715": "-0.29350394010543818",
                "E21715": "1"
              },
              {
                "A23309": "23307",
                "B23309": "Fgf21",
                "C23309": "-0.30737236142158508",
                "D23309": "-1.155367374420166",
                "E23309": "1"
              },
              {
                "A24637": "24635",
                "B24637": "Il7",
                "C24637": "-0.81725466251373291",
                "D24637": "-0.46414536237716669",
                "E24637": "1"
              },
              {
                "A26748": "26746",
                "B26748": "Enpep",
                "C26748": "-3.2583916187286381",
                "D26748": "-0.42230015993118292",
                "E26748": "8.5565391629023116E-3"
              },
              {
                "A28353": "28351",
                "B28353": "Cxcl12",
                "C28353": "-15.84118175506592",
                "D28353": "-1.1106166839599609",
                "E28353": "6.7993135864904834E-55"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 8 - medFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d7_5:medFB_n",
                "C1": "d7_5:medFB_s",
                "D1": "d7_5:medFB_l",
                "E1": "d7_5:medFB_p"
              },
              {
                "A2": "0",
                "B2": "Enpp2",
                "C2": "49.117427825927727",
                "D2": "3.2227392196655269",
                "E2": "0"
              }
            ],
            "targeted_rows": [
              {
                "A75": "73",
                "B75": "Flt3l",
                "C75": "20.925729751586911",
                "D75": "2.5349290370941162",
                "E75": "3.6643263066184791E-95"
              },
              {
                "A207": "205",
                "B207": "Bmp4",
                "C207": "12.703970909118651",
                "D207": "1.711932301521301",
                "E207": "2.602221459528615E-35"
              },
              {
                "A674": "672",
                "B674": "Fgf10",
                "C674": "5.4099984169006348",
                "D674": "1.4600956439971919",
                "E674": "9.7215972999809144E-7"
              },
              {
                "A954": "952",
                "B954": "Kitl",
                "C954": "3.8689403533935551",
                "D954": "1.294370293617249",
                "E954": "1.225288312508035E-3"
              },
              {
                "A2480": "2478",
                "B2480": "Prss16",
                "C2480": "1.1766675710678101",
                "D2480": "24.520061492919918",
                "E2480": "1"
              },
              {
                "A3268": "3266",
                "B3268": "Fgf7",
                "C3268": "0.69889318943023682",
                "D3268": "0.71149426698684692",
                "E3268": "1"
              },
              {
                "A3829": "3827",
                "B3829": "Psmb11",
                "C3829": "0.48465907573699951",
                "D3829": "2.6232821941375728",
                "E3829": "1"
              },
              {
                "A5171": "5169",
                "B5171": "Dll4",
                "C5171": "0.18764720857143399",
                "D5171": "1.9065953493118291",
                "E5171": "1"
              },
              {
                "A5501": "5499",
                "B5501": "Il7",
                "C5501": "0.14177316427230829",
                "D5501": "0.33551713824272161",
                "E5501": "1"
              },
              {
                "A6770": "6768",
                "B6770": "Foxn1",
                "C6770": "4.2907565832138062E-2",
                "D6770": "1.0716172456741331",
                "E6770": "1"
              },
              {
                "A20972": "20970",
                "B20972": "Ly75",
                "C20972": "-7.0648655295372009E-2",
                "D20972": "-0.44594767689704901",
                "E20972": "1"
              },
              {
                "A20996": "20994",
                "B20996": "Fezf2",
                "C20996": "-7.372649759054184E-2",
                "D20996": "-0.17680682241916659",
                "E20996": "1"
              },
              {
                "A21085": "21083",
                "B21085": "Aire",
                "C21085": "-7.729031890630722E-2",
                "D21085": "-1.398917675018311",
                "E21085": "1"
              },
              {
                "A24023": "24021",
                "B24023": "Fgf21",
                "C24023": "-0.60038197040557861",
                "D24023": "-3.024334192276001",
                "E24023": "1"
              },
              {
                "A25087": "25085",
                "B25087": "Enpep",
                "C25087": "-1.142841696739197",
                "D25087": "-0.1754684895277023",
                "E25087": "1"
              },
              {
                "A25301": "25299",
                "B25301": "Ccl25",
                "C25301": "-1.2963187694549561",
                "D25301": "-8.7690562009811401E-2",
                "E25301": "0.96699654978832827"
              },
              {
                "A28431": "28429",
                "B28431": "Cxcl12",
                "C28431": "-15.043698310852051",
                "D28431": "-1.1741077899932859",
                "E28431": "2.3082309640760439E-49"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 8 - cTEC",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d7_12:cTEC_n",
                "C1": "d7_12:cTEC_s",
                "D1": "d7_12:cTEC_l",
                "E1": "d7_12:cTEC_p"
              },
              {
                "A2": "0",
                "B2": "Tbata",
                "C2": "11.02006244659424",
                "D2": "6.9305229187011719",
                "E2": "8.7937058124171459E-24"
              }
            ],
            "targeted_rows": [
              {
                "A3": "1",
                "B3": "Ccl25",
                "C3": "10.57965755462646",
                "D3": "6.1543974876403809",
                "E3": "5.3235775553355705E-22"
              },
              {
                "A4": "2",
                "B4": "Psmb11",
                "C4": "10.299667358398439",
                "D4": "5.6909441947937012",
                "E4": "6.776421333214201E-21"
              },
              {
                "A7": "5",
                "B7": "Prss16",
                "C7": "9.1973667144775391",
                "D7": "4.2036008834838867",
                "E7": "1.6810320330046029E-16"
              },
              {
                "A65": "63",
                "B65": "Ly75",
                "C65": "5.5957574844360352",
                "D65": "2.2425415515899658",
                "E65": "7.8945981813429372E-6"
              },
              {
                "A99": "97",
                "B99": "Il7",
                "C99": "5.0063433647155762",
                "D99": "1.830702066421509",
                "E99": "1.3568551688647511E-4"
              },
              {
                "A113": "111",
                "B113": "Cxcl12",
                "C113": "4.913994312286377",
                "D113": "1.342160105705261",
                "E113": "1.958634304739213E-4"
              },
              {
                "A205": "203",
                "B205": "Dll4",
                "C205": "4.1100802421569824",
                "D205": "4.7091245651245117",
                "E205": "4.6991932499470092E-3"
              },
              {
                "A207": "205",
                "B207": "Foxn1",
                "C207": "4.103825569152832",
                "D207": "1.3107237815856929",
                "E207": "4.7690096804186609E-3"
              },
              {
                "A501": "499",
                "B501": "Kitl",
                "C501": "3.1181566715240479",
                "D501": "1.729833245277405",
                "E501": "9.2120809897674419E-2"
              },
              {
                "A1161": "1159",
                "B1161": "Flt3l",
                "C1161": "2.2325634956359859",
                "D1161": "2.995363712310791",
                "E1161": "0.57409169401537952"
              },
              {
                "A2040": "2038",
                "B2040": "Fezf2",
                "C2040": "1.6398377418518071",
                "D2040": "1.366274952888489",
                "E2040": "1"
              },
              {
                "A2680": "2678",
                "B2680": "Enpep",
                "C2680": "1.351385235786438",
                "D2680": "1.0583368539810181",
                "E2680": "1"
              },
              {
                "A3475": "3473",
                "B3475": "Fgf21",
                "C3475": "1.077281713485718",
                "D3475": "2.2829828262329102",
                "E3475": "1"
              },
              {
                "A8666": "8664",
                "B8666": "Bmp4",
                "C8666": "0.16924507915973661",
                "D8666": "23.83329010009766",
                "E8666": "1"
              },
              {
                "A9314": "9312",
                "B9314": "Fgf10",
                "C9314": "0.1184715554118156",
                "D9314": "23.474935531616211",
                "E9314": "1"
              },
              {
                "A25193": "25191",
                "B25193": "Aire",
                "C25193": "-3.016977570950985E-2",
                "D25193": "-0.39228960871696472",
                "E25193": "1"
              },
              {
                "A26370": "26368",
                "B26370": "Fgf7",
                "C26370": "-0.19647146761417389",
                "D26370": "-2.3184759616851811",
                "E26370": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 9 - intFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d4_4:intFB_n",
                "C1": "d4_4:intFB_s",
                "D1": "d4_4:intFB_l",
                "E1": "d4_4:intFB_p"
              },
              {
                "A2": "0",
                "B2": "Tpt1",
                "C2": "24.478067398071289",
                "D2": "1.0782486200332639",
                "E2": "9.0919104389703594E-129"
              }
            ],
            "targeted_rows": [
              {
                "A387": "385",
                "B387": "Cxcl12",
                "C387": "5.7602834701538086",
                "D387": "0.69490969181060791",
                "E387": "4.5900850125089872E-7"
              },
              {
                "A764": "762",
                "B764": "Fgf7",
                "C764": "4.3962321281433114",
                "D764": "0.59465271234512329",
                "E764": "3.3231095781060318E-4"
              },
              {
                "A1616": "1614",
                "B1616": "Enpep",
                "C1616": "3.0738511085510249",
                "D1616": "0.5023687481880188",
                "E1616": "3.2244170272367298E-2"
              },
              {
                "A5640": "5638",
                "B5640": "Bmp4",
                "C5640": "1.088188052177429",
                "D5640": "0.19524575769901281",
                "E5640": "1"
              },
              {
                "A6877": "6875",
                "B6877": "Kitl",
                "C6877": "0.77042758464813232",
                "D6877": "0.12874336540699011",
                "E6877": "1"
              },
              {
                "A7065": "7063",
                "B7065": "Fgf10",
                "C7065": "0.71982342004776001",
                "D7065": "2.41951197385788E-2",
                "E7065": "1"
              },
              {
                "A8913": "8911",
                "B8913": "Il7",
                "C8913": "0.34111183881759638",
                "D8913": "-2.3739136755466461E-2",
                "E8913": "1"
              },
              {
                "A10931": "10929",
                "B10931": "Flt3l",
                "C10931": "0.1226939633488655",
                "D10931": "-9.2727832496166229E-2",
                "E10931": "1"
              },
              {
                "A11285": "11283",
                "B11285": "Psmb11",
                "C11285": "9.3575350940227509E-2",
                "D11285": "1.529169082641602",
                "E11285": "1"
              },
              {
                "A20909": "20907",
                "B20909": "Foxn1",
                "C20909": "0",
                "D20909": "0",
                "E20909": "1"
              },
              {
                "A24119": "24117",
                "B24119": "Dll4",
                "C24119": "-2.6178481057286259E-2",
                "D24119": "-0.5016319751739502",
                "E24119": "1"
              },
              {
                "A24145": "24143",
                "B24145": "Fgf21",
                "C24145": "-2.7761628851294521E-2",
                "D24145": "-8.404877781867981E-2",
                "E24145": "1"
              },
              {
                "A24211": "24209",
                "B24211": "Prss16",
                "C24211": "-2.8100874274969101E-2",
                "D24211": "-0.85640859603881836",
                "E24211": "1"
              },
              {
                "A24790": "24788",
                "B24790": "Aire",
                "C24790": "-2.9910186305642131E-2",
                "D24790": "-20.236143112182621",
                "E24790": "1"
              },
              {
                "A26609": "26607",
                "B26609": "Fezf2",
                "C26609": "-8.9730560779571533E-2",
                "D26609": "-21.978071212768551",
                "E26609": "1"
              },
              {
                "A26919": "26917",
                "B26919": "Ly75",
                "C26919": "-0.1196407452225685",
                "D26919": "-21.86992263793945",
                "E26919": "1"
              },
              {
                "A27141": "27139",
                "B27141": "Ccl25",
                "C27141": "-0.16379927098751071",
                "D27141": "-0.38993245363235468",
                "E27141": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 9 - medFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d4_5:medFB_n",
                "C1": "d4_5:medFB_s",
                "D1": "d4_5:medFB_l",
                "E1": "d4_5:medFB_p"
              },
              {
                "A2": "0",
                "B2": "Tpt1",
                "C2": "26.53144645690918",
                "D2": "1.2970631122589109",
                "E2": "2.418110465115897E-151"
              }
            ],
            "targeted_rows": [
              {
                "A277": "275",
                "B277": "Bmp4",
                "C277": "3.412790060043335",
                "D277": "0.49886485934257507",
                "E277": "2.698971010090416E-2"
              },
              {
                "A1888": "1886",
                "B1888": "Fgf10",
                "C1888": "1.021964907646179",
                "D1888": "0.51841086149215698",
                "E1888": "1"
              },
              {
                "A1944": "1942",
                "B1944": "Fgf7",
                "C1944": "1.001087427139282",
                "D1944": "0.80741286277770996",
                "E1944": "1"
              },
              {
                "A3490": "3488",
                "B3490": "Il7",
                "C3490": "0.50563371181488037",
                "D3490": "0.3231048583984375",
                "E3490": "1"
              },
              {
                "A4112": "4110",
                "B4112": "Ccl25",
                "C4112": "0.37898802757263178",
                "D4112": "0.36674901843070978",
                "E4112": "1"
              },
              {
                "A8547": "8545",
                "B8547": "Fgf21",
                "C8547": "2.60106734931469E-2",
                "D8547": "-0.2131899148225784",
                "E8547": "1"
              },
              {
                "A19853": "19851",
                "B19853": "Fezf2",
                "C19853": "-2.1136367693543431E-2",
                "D19853": "-19.028545379638668",
                "E19853": "1"
              },
              {
                "A20532": "20530",
                "B20532": "Foxn1",
                "C20532": "-2.1136367693543431E-2",
                "D20532": "-20.0870475769043",
                "E20532": "1"
              },
              {
                "A21534": "21532",
                "B21534": "Aire",
                "C21534": "-4.2272735387086868E-2",
                "D21534": "-20.64887809753418",
                "E21534": "1"
              },
              {
                "A21724": "21722",
                "B21724": "Psmb11",
                "C21724": "-4.2272735387086868E-2",
                "D21724": "-20.422084808349609",
                "E21724": "1"
              },
              {
                "A23206": "23204",
                "B23206": "Dll4",
                "C23206": "-0.1030937135219574",
                "D23206": "-0.44767469167709351",
                "E23206": "1"
              },
              {
                "A23401": "23399",
                "B23401": "Enpep",
                "C23401": "-0.1124972403049469",
                "D23401": "-1.4836740680038931E-2",
                "E23401": "1"
              },
              {
                "A23498": "23496",
                "B23498": "Prss16",
                "C23498": "-0.1216419562697411",
                "D23498": "-1.2829041481018071",
                "E23498": "1"
              },
              {
                "A24103": "24101",
                "B24103": "Kitl",
                "C24103": "-0.1702987402677536",
                "D24103": "-3.0503807589411739E-2",
                "E24103": "1"
              },
              {
                "A24154": "24152",
                "B24154": "Ly75",
                "C24154": "-0.17577694356441501",
                "D24154": "-1.021740198135376",
                "E24154": "1"
              },
              {
                "A25175": "25173",
                "B25175": "Flt3l",
                "C25175": "-0.3191160261631012",
                "D25175": "-5.4199010133743293E-2",
                "E25175": "1"
              },
              {
                "A27578": "27576",
                "B27578": "Cxcl12",
                "C27578": "-1.43787693977356",
                "D27578": "-0.13818725943565369",
                "E27578": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 9 - cTEC",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d4_12:cTEC_n",
                "C1": "d4_12:cTEC_s",
                "D1": "d4_12:cTEC_l",
                "E1": "d4_12:cTEC_p"
              },
              {
                "A2": "0",
                "B2": "Krt18",
                "C2": "10.13964176177979",
                "D2": "1.936842679977417",
                "E2": "1.059360112979514E-19"
              }
            ],
            "targeted_rows": [
              {
                "A6": "4",
                "B6": "Prss16",
                "C6": "7.9309883117675781",
                "D6": "2.3407857418060298",
                "E6": "8.9299104340081432E-12"
              },
              {
                "A7": "5",
                "B7": "Ccl25",
                "C7": "7.560025691986084",
                "D7": "2.9820878505706792",
                "E7": "1.4483446006139419E-10"
              },
              {
                "A14": "12",
                "B14": "Psmb11",
                "C14": "6.2055368423461914",
                "D14": "1.9189679622650151",
                "E14": "8.2488654955397834E-7"
              },
              {
                "A33": "31",
                "B33": "Cxcl12",
                "C33": "5.1383061408996582",
                "D33": "0.97939842939376831",
                "E33": "1.5941583170388311E-4"
              },
              {
                "A173": "171",
                "B173": "Ly75",
                "C173": "3.5983364582061772",
                "D173": "1.0633455514907839",
                "E173": "4.3848067498802018E-2"
              },
              {
                "A182": "180",
                "B182": "Foxn1",
                "C182": "3.5355579853057861",
                "D182": "1.1595290899276729",
                "E182": "5.2464634484787512E-2"
              },
              {
                "A341": "339",
                "B341": "Kitl",
                "C341": "2.9296526908874512",
                "D341": "1.255668640136719",
                "E341": "0.24178884155198321"
              },
              {
                "A925": "923",
                "B925": "Enpep",
                "C925": "2.105925559997559",
                "D925": "1.080685615539551",
                "E925": "0.96142570349495216"
              },
              {
                "A2845": "2843",
                "B2845": "Il7",
                "C2845": "1.1756658554077151",
                "D2845": "0.3279862105846405",
                "E2845": "1"
              },
              {
                "A2892": "2890",
                "B2892": "Flt3l",
                "C2892": "1.16139805316925",
                "D2892": "1.0679001808166499",
                "E2892": "1"
              },
              {
                "A4440": "4438",
                "B4440": "Bmp4",
                "C4440": "0.77616769075393677",
                "D4440": "1.6154769659042361",
                "E4440": "1"
              },
              {
                "A5698": "5696",
                "B5698": "Dll4",
                "C5698": "0.54598075151443481",
                "D5698": "0.2230536490678787",
                "E5698": "1"
              },
              {
                "A9795": "9793",
                "B9795": "Fgf10",
                "C9795": "0.102728083729744",
                "D9795": "21.84147834777832",
                "E9795": "1"
              },
              {
                "A10835": "10833",
                "B10835": "Fgf7",
                "C10835": "5.7071156799793243E-2",
                "D10835": "-0.16995957493782041",
                "E10835": "1"
              },
              {
                "A24479": "24477",
                "B24479": "Fgf21",
                "C24479": "-6.8485386669635773E-2",
                "D24479": "-1.125104546546936",
                "E24479": "1"
              },
              {
                "A26150": "26148",
                "B26150": "Fezf2",
                "C26150": "-0.1502873748540878",
                "D26150": "8.0300018191337585E-2",
                "E26150": "1"
              },
              {
                "A26663": "26661",
                "B26663": "Aire",
                "C26663": "-0.2454059720039368",
                "D26663": "-24.200250625610352",
                "E26663": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 10 - intFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d7_4:intFB_n",
                "C1": "d7_4:intFB_s",
                "D1": "d7_4:intFB_l",
                "E1": "d7_4:intFB_p"
              },
              {
                "A2": "0",
                "B2": "Tpt1",
                "C2": "33.810527801513672",
                "D2": "1.215337753295898",
                "E2": "6.6182949278996153E-247"
              }
            ],
            "targeted_rows": [
              {
                "A779": "777",
                "B779": "Cxcl12",
                "C779": "6.6681203842163086",
                "D779": "0.57618844509124756",
                "E779": "7.9251663077045086E-10"
              },
              {
                "A1474": "1472",
                "B1474": "Enpep",
                "C1474": "4.8688192367553711",
                "D1474": "0.56411659717559814",
                "E1474": "1.8920557984683149E-5"
              },
              {
                "A2578": "2576",
                "B2578": "Fgf7",
                "C2578": "3.47868800163269",
                "D2578": "0.28227829933166498",
                "E2578": "4.9904963548158092E-3"
              },
              {
                "A10034": "10032",
                "B10034": "Bmp4",
                "C10034": "0.22335219383239749",
                "D10034": "-9.6018902957439423E-2",
                "E10034": "1"
              },
              {
                "A10346": "10344",
                "B10346": "Kitl",
                "C10346": "0.18075670301914221",
                "D10346": "-9.1656945645809174E-2",
                "E10346": "1"
              },
              {
                "A11661": "11659",
                "B11661": "Prss16",
                "C11661": "6.649395078420639E-2",
                "D11661": "0.27884009480476379",
                "E11661": "1"
              },
              {
                "A12175": "12173",
                "B12175": "Psmb11",
                "C12175": "5.2885886281728738E-2",
                "D12175": "0.50063717365264893",
                "E12175": "1"
              },
              {
                "A22709": "22707",
                "B22709": "Foxn1",
                "C22709": "0",
                "D22709": "0",
                "E22709": "1"
              },
              {
                "A25077": "25075",
                "B25077": "Aire",
                "C25077": "-3.9221592247486108E-2",
                "D25077": "-20.236143112182621",
                "E25077": "1"
              },
              {
                "A25863": "25861",
                "B25863": "Ly75",
                "C25863": "-6.4638309180736542E-2",
                "D25863": "-0.88660925626754761",
                "E25863": "1"
              },
              {
                "A26263": "26261",
                "B26263": "Fgf21",
                "C26263": "-8.6962282657623291E-2",
                "D26263": "-2.0807607173919682",
                "E26263": "1"
              },
              {
                "A26561": "26559",
                "B26561": "Fezf2",
                "C26561": "-0.1176647692918777",
                "D26561": "-21.978071212768551",
                "E26561": "1"
              },
              {
                "A27027": "27025",
                "B27027": "Dll4",
                "C27027": "-0.19610795378685",
                "D27027": "-22.621883392333981",
                "E27027": "1"
              },
              {
                "A27269": "27267",
                "B27269": "Flt3l",
                "C27269": "-0.27145838737487787",
                "D27269": "-0.26418256759643549",
                "E27269": "1"
              },
              {
                "A27312": "27310",
                "B27312": "Il7",
                "C27312": "-0.28928384184837341",
                "D27312": "-0.57879000902175903",
                "E27312": "1"
              },
              {
                "A27821": "27819",
                "B27821": "Ccl25",
                "C27821": "-0.74894964694976807",
                "D27821": "-0.99502623081207275",
                "E27821": "1"
              },
              {
                "A27967": "27965",
                "B27967": "Fgf10",
                "C27967": "-1.0355343818664551",
                "D27967": "-0.2894386351108551",
                "E27967": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 10 - medFB",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d7_5:medFB_n",
                "C1": "d7_5:medFB_s",
                "D1": "d7_5:medFB_l",
                "E1": "d7_5:medFB_p"
              },
              {
                "A2": "0",
                "B2": "Tpt1",
                "C2": "32.123367309570312",
                "D2": "1.5384751558303831",
                "E2": "1.1963400258554439E-222"
              }
            ],
            "targeted_rows": [
              {
                "A85": "83",
                "B85": "Bmp4",
                "C85": "7.9514551162719727",
                "D85": "0.95506173372268677",
                "E85": "2.649979093395326E-13"
              },
              {
                "A1143": "1141",
                "B1143": "Fgf10",
                "C1143": "1.589593768119812",
                "D1143": "0.62504535913467407",
                "E1143": "1"
              },
              {
                "A2071": "2069",
                "B2071": "Fgf7",
                "C2071": "0.87593525648117065",
                "D2071": "0.67575234174728394",
                "E2071": "1"
              },
              {
                "A3713": "3711",
                "B3713": "Prss16",
                "C3713": "0.34388723969459528",
                "D3713": "1.305601239204407",
                "E3713": "1"
              },
              {
                "A7786": "7784",
                "B7786": "Fgf21",
                "C7786": "8.3462651818990707E-3",
                "D7786": "0.56444334983825684",
                "E7786": "1"
              },
              {
                "A8033": "8031",
                "B8033": "Psmb11",
                "C8033": "8.2053998485207558E-3",
                "D8033": "0.1041868329048157",
                "E8033": "1"
              },
              {
                "A8084": "8082",
                "B8084": "Dll4",
                "C8084": "4.683768842369318E-3",
                "D8084": "0.16139623522758481",
                "E8084": "1"
              },
              {
                "A18607": "18605",
                "B18607": "Foxn1",
                "C18607": "-2.3771008476614949E-2",
                "D18607": "-20.0870475769043",
                "E18607": "1"
              },
              {
                "A19815": "19813",
                "B19815": "Fezf2",
                "C19815": "-2.3771008476614949E-2",
                "D19815": "-19.028545379638668",
                "E19815": "1"
              },
              {
                "A20212": "20210",
                "B20212": "Ly75",
                "C20212": "-3.8068830966949463E-2",
                "D20212": "-0.24146409332752231",
                "E20212": "1"
              },
              {
                "A20973": "20971",
                "B20973": "Aire",
                "C20973": "-4.7542016953229897E-2",
                "D20973": "-20.64887809753418",
                "E20973": "1"
              },
              {
                "A23829": "23827",
                "B23829": "Ccl25",
                "C23829": "-0.26007243990898132",
                "D23829": "-0.2122007608413696",
                "E23829": "1"
              },
              {
                "A24252": "24250",
                "B24252": "Il7",
                "C24252": "-0.32307440042495728",
                "D24252": "-6.8967856466770172E-2",
                "E24252": "1"
              },
              {
                "A24363": "24361",
                "B24363": "Enpep",
                "C24363": "-0.34025996923446661",
                "D24363": "-0.1666896641254425",
                "E24363": "1"
              },
              {
                "A25209": "25207",
                "B25209": "Kitl",
                "C25209": "-0.51570761203765869",
                "D25209": "-0.12724208831787109",
                "E25209": "1"
              },
              {
                "A26265": "26263",
                "B26265": "Flt3l",
                "C26265": "-0.84677612781524658",
                "D26265": "-0.11805408447980879",
                "E26265": "1"
              },
              {
                "A28074": "28072",
                "B28074": "Cxcl12",
                "C28074": "-2.5819540023803711",
                "D28074": "-0.27722126245498657",
                "E28074": "0.22241519005934229"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          },
          {
            "sheet": "Table 10 - cTEC",
            "dimension": "A1:E28753",
            "header": [
              {
                "B1": "d7_12:cTEC_n",
                "C1": "d7_12:cTEC_s",
                "D1": "d7_12:cTEC_l",
                "E1": "d7_12:cTEC_p"
              },
              {
                "A2": "0",
                "B2": "Tbata",
                "C2": "11.124302864074711",
                "D2": "4.8570680618286133",
                "E2": "2.7472612368805102E-24"
              }
            ],
            "targeted_rows": [
              {
                "A4": "2",
                "B4": "Ccl25",
                "C4": "10.34247398376465",
                "D4": "4.0765895843505859",
                "E4": "2.9511892989143162E-21"
              },
              {
                "A6": "4",
                "B6": "Prss16",
                "C6": "9.7986307144165039",
                "D6": "3.0924313068389888",
                "E6": "4.6874866614818497E-19"
              },
              {
                "A11": "9",
                "B11": "Psmb11",
                "C11": "7.8139891624450684",
                "D11": "2.4346134662628169",
                "E11": "9.9564354705251938E-12"
              },
              {
                "A52": "50",
                "B52": "Ly75",
                "C52": "5.582770824432373",
                "D52": "1.488738059997559",
                "E52": "9.3233863305752613E-6"
              },
              {
                "A114": "112",
                "B114": "Foxn1",
                "C114": "4.3833942413330078",
                "D114": "1.330366969108582",
                "E114": "2.1814977010770581E-3"
              },
              {
                "A210": "208",
                "B210": "Kitl",
                "C210": "3.6213264465332031",
                "D210": "1.3804794549942021",
                "E210": "3.086852390035371E-2"
              },
              {
                "A257": "255",
                "B257": "Cxcl12",
                "C257": "3.4039609432220459",
                "D257": "0.58627444505691528",
                "E257": "5.8397549415374082E-2"
              },
              {
                "A1034": "1032",
                "B1034": "Dll4",
                "C1034": "2.012134313583374",
                "D1034": "0.78106582164764404",
                "E1034": "1"
              },
              {
                "A1374": "1372",
                "B1374": "Flt3l",
                "C1374": "1.7509521245956421",
                "D1374": "1.3202240467071531",
                "E1374": "1"
              },
              {
                "A1552": "1550",
                "B1552": "Enpep",
                "C1552": "1.6341074705123899",
                "D1552": "0.86625814437866211",
                "E1552": "1"
              },
              {
                "A10577": "10575",
                "B10577": "Il7",
                "C10577": "9.4506740570068359E-3",
                "D10577": "1.514724269509315E-2",
                "E10577": "1"
              },
              {
                "A19067": "19065",
                "B19067": "Fgf10",
                "C19067": "0",
                "D19067": "0",
                "E19067": "1"
              },
              {
                "A23688": "23686",
                "B23688": "Bmp4",
                "C23688": "-6.7013867199420929E-2",
                "D23688": "-0.566436767578125",
                "E23688": "1"
              },
              {
                "A23921": "23919",
                "B23921": "Fezf2",
                "C23921": "-9.7943350672721863E-2",
                "D23921": "0.35481533408164978",
                "E23921": "1"
              },
              {
                "A24011": "24009",
                "B24011": "Fgf21",
                "C24011": "-0.106534868478775",
                "D24011": "-0.71903479099273682",
                "E24011": "1"
              },
              {
                "A25434": "25432",
                "B25434": "Aire",
                "C25434": "-0.16152061522006991",
                "D25434": "-1.7847328186035161",
                "E25434": "1"
              },
              {
                "A26175": "26173",
                "B26175": "Fgf7",
                "C26175": "-0.25259074568748469",
                "D26175": "-24.859489440917969",
                "E26175": "1"
              }
            ],
            "scope": "actual selected original cells, not full gene-sheet reanalysis"
          }
        ],
        "source": {
          "path": "sources/A144_workbook_targeted_results_read.json",
          "sha256": "6b8522b7c60ede1d8071b15b538c67edcef6b9c7b7da08efd52ccf71f491cb37",
          "scope": "targeted cells fromTables7–10; not all129sheets reanalyzed"
        },
        "kind": "published source rows, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR21",
      "type": "source_figure_or_text_result",
      "locator": "Fig6c–e; Discussion",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F05",
          "locator": "Fig6c–e; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR22",
      "type": "source_figure_or_text_result",
      "locator": "Results FOXN1; Fig7a–c",
      "fresh_visual_review": false,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Results FOXN1; Fig7a–c",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    },
    {
      "artifact_id": "A144-R20261012-AR23",
      "type": "source_figure_or_text_result",
      "locator": "Fig7d–h; Discussion",
      "fresh_visual_review": true,
      "raw_data_obtained": false,
      "source_refs": [
        {
          "source_id": "A144-R20261012-F04",
          "locator": "Fig7d–h; Discussion",
          "verification": "fresh_indexed_primary_text_read; not fresh image digitization"
        },
        {
          "source_id": "A144-SUPP-5",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        },
        {
          "source_id": "A144-SUPP-6",
          "locator": "four distributed movie frames",
          "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
        }
      ],
      "visual_review_scope": {
        "reviewed_sources": [
          {
            "source_id": "A144-SUPP-5",
            "locator": "four distributed movie frames",
            "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
          },
          {
            "source_id": "A144-SUPP-6",
            "locator": "four distributed movie frames",
            "verification": "fresh sampled frames; computational simulation or qualitative spatial support only; no extra biological n"
          }
        ],
        "limit": "published artwork or sampledframes, not raw microscopy"
      }
    }
  ],
  "claims": [
    {
      "claim_id": "A144-R20261012-C01",
      "claim": "亚群变化：2月/18月单细胞比较中老龄出现aaTEC1/2及early-prog增加；此设计不定位首次出现年龄。独立年龄流式显示aaTEC在12月已增多。基质各亚群频率/数量变化异质，详见新增主Fig1及ED1/4端点。 采样层级：单细胞集22932个CD45−细胞是细胞数，不是动物n；与流式计数分开。 ED2 FB13240/EC1661/TEC6175，ED3整合297988/上皮205625，均为注释数据细胞数。 细分TEC的年龄流式绝对计数：Fig1g每年龄n10：老龄cTEC↑P=.01，mTEC1/2/3及tuft↓P=.001/.0001/.0001/.0001，DN-TEC↑.003。细分门控与ED1宽门控不能混成同一cTEC结论；Fig1f另为scaled频率变化，不当绝对数。 aaTEC中龄已增加的年龄系列：Fig1j/k 2/12/18月各年龄合并男女总n依次15/10/13，图以符号区分性别，aaTEC1/2在12月已增加。计数和Frequency(10^-5)为不同纵轴，不改作百分比；比较仅2vs12与2vs18，没有12vs18检验。 整体退化及宽门控年龄背景：ED1总细胞数对2月：6月NS、9月P=.03、12月.0004、19月+<.0001；皮质/髓质比对2月：6月NS、9月.004、12月NS、19月+.001。宽门控EC12月↑.002，mTEC对2月在6/9/12/19月+均下降<.0001；cTEC/FB未标比较，不能从无星称NS。不同年龄标签/量化图与代表切片保持各自范围。 基质亚群年龄异质性和阴性：ED4a–c每年龄n10：medFB老龄↑P<.0001；capsFB/intFB NS；aEC/capEC/vEC全NS；PC↑.0007、vSMC↑.003、MEC NS。d独立DN-TEC计数2vs12月.03、2vs18月+.01，2/6/9/12/18月+n14/5/15/5/18，勿借a–c n。",
      "result_ids": [
        "A144-R20261012-O01",
        "A144-R20261012-O02",
        "A144-R20261012-O41",
        "A144-R20261012-O42",
        "A144-R20261012-O45",
        "A144-R20261012-O46"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "年龄相关细胞亚群改变",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O01",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O02",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O41",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O42",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O45",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O46",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C02",
      "claim": "三维组织结构：年轻髓质互连，老年呈孤立岛及髓周高密度TEC带。 Fig2a老年代表图实际标18mo+，caption称24mo male，年龄来源范围不一致，不能强行统一。 体积与细胞估计：Fig2c老龄相对年轻：总体积↓P=.07、皮质体积↓.08、cTEC数量↓.07均未显著；髓质体积↓.002、mTEC数量↓.0008；HD体积↑.009、HD细胞数↑.004。n3/年龄，mean±SEM、unpaired t；不把趋势全称显著下降。",
      "result_ids": [
        "A144-R20261012-O03",
        "A144-R20261012-O04"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "整叶高密度TEC区域",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-FIG2A-AGE",
          "artwork": "18mo+",
          "caption": "24mo male representative",
          "resolution": "retain source-specific representative age discrepancy; quantitative18month branch remains separate"
        },
        {
          "conflict_id": "A144-VIDEO1-AGE",
          "video_labels": "2mo/18mo",
          "video_caption": "female reporter",
          "Fig2b_caption": "24mo old representative",
          "resolution": "separate source specimen/age labels retained, not forcibly matched"
        }
      ],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O03",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O04",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C03",
      "claim": "空间匹配：老年aaTEC签名聚集在髓质相关区域；HD中多K5+、部分K8+、K14−，claudin3可标记。 Workbook Table3当前aaTEC1/2 top20签名各20基因，官网补件描述top30/top10，来源定义差异保留。 边界：转录签名、流式DN-TEC和HD形态的对应为多源推断，非单一共同测量。",
      "result_ids": [
        "A144-R20261012-O05",
        "A144-R20261012-O06"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "空间转录与固定免疫对应",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-TABLE3-SIGNATURE-SIZE",
          "workbook": "tabs top20, aaTEC1/2 signatures contain20genes",
          "web_description": "top30/top10 descriptions",
          "resolution": "source definitions preserved, not silently interchangeable"
        }
      ],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O05",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O06",
          "record_type": "author_interpretation",
          "measurement_status": "author_inference_scope"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C04",
      "claim": "报告谱系：老年GFP+出现EpCAM+ DN与EpCAM−群；claudin3和PDPN分别支持aaTEC1/2标记。 轨迹限定：RNA velocity提示mTEC1/early-prog向aaTEC方向；不是直接逐细胞纵向追踪。 tdTom转录谱系支持：20月Foxn1tdTom报告TEC共1093细胞与18/20月WT7412细胞整合，所有TEC簇包括aaTEC1/2均检测tdTom转录，支持其既往Foxn1谱系来源。细胞数不是鼠n；独立scRNA分支不继承GFP流式。 aaTEC标记表型的流式支持：Fig3b claudin3+比例aaTEC>mTEC P=.03（n4鼠）；3c在GFP+EpCAM−内PDPN+比例PDGFRα−高于α+ P=.03（n4）。2月c明确No data，不能作年轻阴性。3d报告鼠aaTEC1/2老龄计数↑P=.04/.01，2月n6、18月n4，不能借Fig1k C57BL/6 n。 报告体系特异性的独立支持：ED5a11周体系验证近全部TEC GFP仅Foxn1报告鼠，n2–3、两实验；代表门控百分比不作总体均值。此年轻验证支路不借作Fig3d的2/18月生物n。",
      "result_ids": [
        "A144-R20261012-O07",
        "A144-R20261012-O08",
        "A144-R20261012-O27",
        "A144-R20261012-O43",
        "A144-R20261012-O50"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "既有报告体系中的TEC来源",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O07",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O08",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O27",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O43",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O50",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C05",
      "claim": "胸腺细胞分布：aaTEC富集区域缺乏胸腺细胞；人体材料见相似富上皮区域。 人体适用限制：既有人数据可见aaTEC签名；claudin3/PDPN在人组织识别的有效性仍待确认。 Fig3h–k为50岁女性连续H&E/panCK/CD1a切片；ED5人整合115536 CD45−/40144TEC均为细胞数，不是患者n。",
      "result_ids": [
        "A144-R20261012-O09",
        "A144-R20261012-O10"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "HD区及人体参照",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O09",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O10",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C06",
      "claim": "分子背景：年龄效应具有细胞谱系差异，FB中的炎症/衰老相关程序是作者主要背景解释。 Fig4a/ED6b多数群线粒体功能/代谢相关程序降低，FB免疫/抗原呈递增加，蛋白稳态变化主要限上皮；均为转录GSEA推断，不等于实际功能测定。 稳态cTEC基因年龄阴性：稳态cTEC中Foxn1/Dll4/Psmb11/Prss16/Enpep/Ly75未观察到随龄表达变化；作者提示全CD45−单细胞中cTEC捕获少可能限制检测，不当等效证明。 新Table4-cTEC原_p列：Cxcl12 .0965814、Foxn1 .894045、Ccl25/Psmb11/Kitl/Dll4/Il7均1，符合这些目标无显著年龄变化；按Methods为FDR调整检验，不改为原始P。",
      "result_ids": [
        "A144-R20261012-O11",
        "A144-R20261012-O30"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "年龄相关通路背景",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O11",
          "record_type": "reported_observation",
          "measurement_status": "independent_transcriptomic_result_reference; full pathway values not recovered"
        },
        {
          "result_id": "A144-R20261012-O30",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C07",
      "claim": "GSEA：aaTEC1抗原呈递降低；aaTEC2 EMT特征富集。 原Table6对应aaTEC1抗原呈递row8 NES−1.8/FDRq列0，aaTEC2EMT row4 NES2.4/q0；0为作者报告精度，不解释概率为零，与图≤.0001并存。 细胞状态：Cdh1/Vim及8795相关基因比较支持aaTEC2介于上皮和间质之间；支持部分EMT状态，但作者未排除某些aaTEC2完全EMT；不是直接谱系转换实验。 ED7a官方图版纠正：2026-03-13作者纠正：原右图标注Mouse1/2/3实为同一鼠3区域；HTML/PDF已替换为3只不同老年报告鼠。旧版n=1鼠/3区域，新版n=3鼠，仅适用于ED7a；本轮已直接读修正图面，不外推其它结果。 本轮已取得并实读纠正后ED7a原图，右侧UEA1显示Mouse1/2/3；三只不同鼠的身份来自官方纠正声明，非从图片猜测。原版同鼠三区域与新版三鼠范围仅适用a。 拟态细胞年龄比较：ED7b：2月较18月常规mTEC中Tuft及Corneocyte数量更高，各P=.0007；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。 老龄mTEC与DN-TEC比较：ED7c：18月mTEC较DN-TEC的Tuft数量更高P=.001、Corneocyte更高P=.005；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。 Aire/Foxn1转录支持：ED7d展示TEC子群Aire/Foxn1表达分布，作为转录支持图，不是蛋白流式或额外生物重复。 AIRE组织定位支持：ED7e 12月报告鼠AIRE在髓质可见，aaTEC/HD区图示缺乏相当AIRE信号；代表图不作细胞阳性率量化，未报告e生物n。图注比例尺50μm，实际两图30/20μm，保留不一致。 aaTEC功能相关转录表达低下：aaTEC中Dll4/Psmb11/Kitl/Ccl25/Cxcl12/Il7低；Fezf2/Aire、关键NFκB目标及Tnfrsf11a/Ltbr/Cd40缺乏相应表达；AIRE/FEZF2依赖TRA低或无，主要见mTEC2/mTECprol。仅转录支持，不声称已做T细胞功能干预或绝对无功能。",
      "result_ids": [
        "A144-R20261012-O12",
        "A144-R20261012-O13",
        "A144-R20261012-O25",
        "A144-R20261012-O37",
        "A144-R20261012-O38",
        "A144-R20261012-O39",
        "A144-R20261012-O40",
        "A144-R20261012-O44"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "aaTEC功能表达与部分EMT",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-CF04",
          "binding": "explicit_panel_or_metric_scope; historically_recorded_not_freshly_visual_verified",
          "source_conflict": {
            "id": "A144-CF04",
            "detail": "更正后ED7版本保留；本轮不将更正附录旧图当独立实验。"
          }
        },
        {
          "conflict_id": "A144-ED7E-SCALE",
          "caption_scale_um": 50,
          "artwork_scale_um": {
            "medulla": 30,
            "aaTEC": 20
          },
          "resolution": "preserve source discrepancy; no geometry measurement inferred"
        }
      ],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O12",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O13",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O25",
          "record_type": "source_correction",
          "measurement_status": "official correction plus fresh corrected artwork read"
        },
        {
          "result_id": "A144-R20261012-O37",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O38",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O39",
          "record_type": "transcript_expression_visualization",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O40",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O44",
          "record_type": "transcript_expression_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C08",
      "claim": "相互作用推断：CellChat按受体/配体表达比较，作者认为aaTEC可吸引上皮生长信号；不是配体流量实测。 PTN/MDK蛋白量：Fig4j蛋白量单位pg/10^6 cells：PTN 2vs12月P=.04、2vs18月.005；MDK 2vs12月NS、2vs18月.01。2/12/18月雌鼠每组n5，mean±SEM、Kruskal–Wallis+Dunn；不是全胸腺总量，不是流式/CellChat，保留MDK12月阴性。",
      "result_ids": [
        "A144-R20261012-O14",
        "A144-R20261012-O15"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "基线配体受体推断与蛋白支路",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O14",
          "record_type": "author_interpretation",
          "measurement_status": "computational_inference"
        },
        {
          "result_id": "A144-R20261012-O15",
          "record_type": "source_note_or_unresolved_result",
          "measurement_status": "author_reported_protein_assay"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C09",
      "claim": "恢复时间：年轻第28日恢复；老年约第42日才接近损伤前细胞量。 流式aaTEC早期再现：流式支路：老年aaTEC在损伤后快速再现；这里只记录细胞亚群反应，不绑定组织学纤维化/钙化。 损伤早期AUC与老龄指数：Fig5d以0–7日AUC表示早期变化，老龄指数=老年AUC/年轻AUC；每细胞类型报告n10。这里只保留年轻/老年动态支路。 图面y轴实际标Recovery index，而图注/正文用aging index；两称谓并存，不据此假设不同计算。 多数基质亚群早期反应阴性：ED9b多数基质亚群早期反应未见重大年龄差异，aaTEC是例外；不以aaTEC的特殊变化替代整体基质反应。 该正文概述不排除ED9b具体时间点跨龄差异，详见新逐点O；不能把概述作所有基质时点均阴性。 损伤后组织学改变：ED9a组织学显示老年持续纤维化/钙化等改变，年轻无相同持续改变；此比较与aaTEC流式计数、12月右叶透明成像分开，现不外推具体每组n。 损伤各时间点跨龄差异和明确阴性：ED9b每年龄/时间n10，mean±SEM、2wayANOVA+Sidak。day7 aEC/vEC老龄较高P=.005/.002；capEC全时点NS、aEC/vEC其余时点NS。intFB全时点NS；capsFB day1/4/7老龄较高.04/.01/.001；medFB day0/4/7老龄较高<.0001/.009/.0005，day1 NS。mTEC1 day0/1/7老龄较低.01/.0002/.01；mTEC2 day0/1较低<.0001/.002；mTEC3 day0/1较低.0002/<.0001；tuft day0/1/7较低<.0001/.001/.04；cTEC day0老龄较高.01，aaTEC1/2 day0***。未标注的其他点不自动判NS。",
      "result_ids": [
        "A144-R20261012-O16",
        "A144-R20261012-O17",
        "A144-R20261012-O26",
        "A144-R20261012-O31",
        "A144-R20261012-O32",
        "A144-R20261012-O47"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "年轻与老年损伤后恢复",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-FIG5D-INDEX-NAME",
          "type": "source_terminology_difference",
          "caption": "aging index; aged AUC/young AUC",
          "actual_axis_label": "Recovery index",
          "resolution": "keep both labels; no numerical formula difference inferred"
        }
      ],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O16",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O17",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O26",
          "record_type": "reported_observation",
          "measurement_status": "historical_embedded_caption_read"
        },
        {
          "result_id": "A144-R20261012-O31",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O32",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O47",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C10",
      "claim": "绝对体积与数：12月雄鼠既有TBI后28日右叶：叶/髓质/皮质体积下降，图上P=.01/.002/.03；aaTEC体积升高P=.004。mTEC数量下降P=.02，但cTEC数量升高P=.02，aaTEC数量升高P=.004。不能把常规TEC统一说成下降。精确柱均值未数字化。 Video4年龄/时间来源冲突：Video4实际分散帧标18mo untreated/18mo(d21 SL-TBI)，caption却12mo baseline/day28并称associatedFig3e。保持独立代表性来源冲突，不把该影片并入O18 Fig5e/f12月day28量化或借其n。",
      "result_ids": [
        "A144-R20261012-O18",
        "A144-R20261012-O49"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "损伤后老年HD区三维量化",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [
        {
          "conflict_id": "A144-CF03",
          "binding": "explicit_panel_or_metric_scope; historically_recorded_not_freshly_visual_verified",
          "source_conflict": {
            "id": "A144-CF03",
            "detail": "Video4已有字幕18mo/d21与说明12mo/d28冲突，仍保留旧核心，不能由统一流程消除。"
          }
        },
        {
          "conflict_id": "A144-VIDEO4-AGE-TIME",
          "actual_movie": "A18mo untreated/B18mo day21 SL-TBI",
          "official_caption": "12mo baseline/day28; associatedFig3e",
          "resolution": "retain separate representative video labels/caption; not identical toFig5e/f12mo day28 quantitative branch"
        }
      ],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O18",
          "record_type": "reported_observation",
          "measurement_status": "author_plotted_result_fresh_visual_confirmed_without_digitization"
        },
        {
          "result_id": "A144-R20261012-O49",
          "record_type": "source_quality_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C11",
      "claim": "独立数据支路：Fig5g–i以年龄、day0/1/4/7及基质亚群注释同一UMAP。损伤后1/4/7日58,309个CD45−细胞与22,932个day0细胞整合，共81,241；这些是细胞而不是动物n。显示嵌入/标签本身不等于亚群恢复量。 SuppFig1 QC前共93,738细胞，QC后整合81,241；细胞QC排除不等于样本排除，前后分母不混用。 aaTEC组成的损伤后持续性：Fig5j表明aaTEC群在老龄胸腺损伤后仍是突出TEC组分。纵轴是TEC亚群Proportion(%)，不是绝对细胞数；图上比例未数字化，不能凭组成说绝对增加。 年轻组RNA-velocity轨迹：2月组day0/1/4/7的RNA-velocity推断由mTECprol走向常规mTEC2及拟态细胞谱系。箭头表示计算推断，不是同一细胞的实验追踪。 老龄组RNA-velocity轨迹：18月组损伤后轨迹偏向mTEC1/earlyprog→aaTEC1/aaTEC2，而非年轻的常规mTEC2/拟态方向；为年龄分层RNA-velocity推断，不作为已证明谱系转分化。 作者的分化扰动解释：作者据此提出aaTEC可能扰乱老龄胸腺早期分化/再生程序。该项是解释，不是额外消除实验或独立干预结果。 bulk与scRNA表达一致性支持：正式SupplementFig2比较同时间CD45−样本：横轴log10 bulk RNAseq、纵轴log10平均scRNA技术重复表达。day0四bulk生物重复R=.83/.79/.82/.79；day1三例.84/.84/.86；day4三例.83/.85/.84；day7三例.85/.83/.84，全部Pearson P<2.2e−16。scRNA技术重复精确n未在caption给出；基因点不是动物n，相关支持不证明每个稀少亚群采样无偏。",
      "result_ids": [
        "A144-R20261012-O19",
        "A144-R20261012-O33",
        "A144-R20261012-O34",
        "A144-R20261012-O35",
        "A144-R20261012-O36",
        "A144-R20261012-O48"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "损伤后亚群转录时间序列",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O19",
          "record_type": "dataset_metadata_not_independent_biological_result",
          "measurement_status": "primary_text_dataset_and_fresh_figure_annotation"
        },
        {
          "result_id": "A144-R20261012-O33",
          "record_type": "reported_observation",
          "measurement_status": "published_result_and_fresh_visual_confirmed"
        },
        {
          "result_id": "A144-R20261012-O34",
          "record_type": "computational_inference",
          "measurement_status": "RNA_velocity_inference_fresh_figure_seen"
        },
        {
          "result_id": "A144-R20261012-O35",
          "record_type": "computational_inference",
          "measurement_status": "RNA_velocity_inference_fresh_figure_seen"
        },
        {
          "result_id": "A144-R20261012-O36",
          "record_type": "author_interpretation",
          "measurement_status": "author_interpretation_not_causal_validation"
        },
        {
          "result_id": "A144-R20261012-O48",
          "record_type": "computational_association_support",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C12",
      "claim": "再生程序：正文概述损伤后Fgf7/Fgf10/Fgf21/Bmp4及Flt3l/Kitl再生相关程序广泛上调、老龄幅度常较弱，但不能推广为每亚群每时间点均如此。再生相关基因响应依亚群/年龄/时点而异。cTEC Psmb11在老年day4/7相对day1仍显著上升（_l=1.919/2.435，FDR-adjusted _p≈8.25e−7/9.96e−12），但幅度弱于年轻_l=5.494/5.691，不能写老年Psmb11下降。Dll4年轻day4/7显著诱导_p=.01682/.004699，老年两点_p=1。Foxn1两龄day7显著上升，day4年轻_p=.24488、老年.05246均未显著；Ccl25两龄两点显著上升，Cxcl12老day4显著.000159而day7 .05840未显著。年轻intFB Kitl day4反向下降_l−.310/_p.000725，day7上升.686/.002055；老intFB Fgf7 day4/7仍上升.595/.000332及.282/.004990，老medFB Bmp4也上升.499/.02699及.955/2.65e−13。老龄不等于所有因子都不响应；原表完整目标行/坐标另存，数值按报告精度非新重算。 受体配体推断：FGF/BMP相关互作偏向aaTEC；受体表达/CellChat不能单独证明实际竞争性消耗。 pAKT直接信号及FB阴性：KGF响应下cTEC/mTEC/aaTEC出现pAKT反应，FB无对应反应；6只18月雌鼠独立胸腺，mean±SEM、paired t test。与CellChat计算分开。 pAKT读出时点为KGF后5 min。 Fig6e实图纵轴pAKT MFI，配对KGF−/+：cTEC P=.002、mTEC .03、aaTEC1 .03、aaTEC2 .008，FB NS。",
      "result_ids": [
        "A144-R20261012-O20",
        "A144-R20261012-O21",
        "A144-R20261012-O24"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "再生信号与竞争解释",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O20",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O21",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O24",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    },
    {
      "claim_id": "A144-R20261012-C13",
      "claim": "FOXN1蛋白流式：FOXN1蛋白在cTEC/mTEC可检出，在aaTEC1/2不明显；此O仅蛋白流式。 FOXN1计算轨迹支持：计算诱导/抑制FOXN1与分化轨迹相关；不是实际动物干预或蛋白流式读出。 FOXN1转录低表达：aaTEC1/2的Foxn1转录低表达，与蛋白结果为不同支路，不赋蛋白流式P。 既有低功能模型结果：6月既有Foxn1低功能模型较对照提前出现aaTEC；仅记录已发表比较，不继承FOXN1蛋白流式流程或重建模型建立。 ED10b各柱来自不同性别/年龄/模型数据，不能当完全匹配干预的定量对照。",
      "result_ids": [
        "A144-R20261012-O22",
        "A144-R20261012-O23",
        "A144-R20261012-O28",
        "A144-R20261012-O29"
      ],
      "scope": "only the attached results; no common validation across experiments",
      "label": "FOXN1降低与aaTEC关联",
      "claim_semantics": "source-bounded scientific propositions from linked observations, including negative findings and conflicts; not a topic title",
      "applicable_source_conflicts": [],
      "interpretation_limits": [
        {
          "result_id": "A144-R20261012-O22",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text_or_qualitative_image_description"
        },
        {
          "result_id": "A144-R20261012-O23",
          "record_type": "reported_observation",
          "measurement_status": "distinct_in_silico_and_existing_model_evidence_no_joint_validation"
        },
        {
          "result_id": "A144-R20261012-O28",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        },
        {
          "result_id": "A144-R20261012-O29",
          "record_type": "reported_observation",
          "measurement_status": "author_reported_text"
        }
      ]
    }
  ],
  "questions": [
    {
      "question_id": "A144-R20261012-GQ01a",
      "question": "年龄相关细胞亚群改变：实际观察到了什么？",
      "answer": [
        "2月/18月单细胞比较中老龄出现aaTEC1/2及early-prog增加；此设计不定位首次出现年龄。独立年龄流式显示aaTEC在12月已增多。基质各亚群频率/数量变化异质，详见新增主Fig1及ED1/4端点。",
        "单细胞集22932个CD45−细胞是细胞数，不是动物n；与流式计数分开。 ED2 FB13240/EC1661/TEC6175，ED3整合297988/上皮205625，均为注释数据细胞数。",
        "Fig1g每年龄n10：老龄cTEC↑P=.01，mTEC1/2/3及tuft↓P=.001/.0001/.0001/.0001，DN-TEC↑.003。细分门控与ED1宽门控不能混成同一cTEC结论；Fig1f另为scaled频率变化，不当绝对数。",
        "Fig1j/k 2/12/18月各年龄合并男女总n依次15/10/13，图以符号区分性别，aaTEC1/2在12月已增加。计数和Frequency(10^-5)为不同纵轴，不改作百分比；比较仅2vs12与2vs18，没有12vs18检验。",
        "ED1总细胞数对2月：6月NS、9月P=.03、12月.0004、19月+<.0001；皮质/髓质比对2月：6月NS、9月.004、12月NS、19月+.001。宽门控EC12月↑.002，mTEC对2月在6/9/12/19月+均下降<.0001；cTEC/FB未标比较，不能从无星称NS。不同年龄标签/量化图与代表切片保持各自范围。",
        "ED4a–c每年龄n10：medFB老龄↑P<.0001；capsFB/intFB NS；aEC/capEC/vEC全NS；PC↑.0007、vSMC↑.003、MEC NS。d独立DN-TEC计数2vs12月.03、2vs18月+.01，2/6/9/12/18月+n14/5/15/5/18，勿借a–c n。"
      ],
      "result_ids": [
        "A144-R20261012-O01",
        "A144-R20261012-O02",
        "A144-R20261012-O41",
        "A144-R20261012-O42",
        "A144-R20261012-O45",
        "A144-R20261012-O46"
      ],
      "group_ids": [
        "A144-R20261012-G01",
        "A144-R20261012-G02",
        "A144-R20261012-G03",
        "A144-R20261012-G39",
        "A144-R20261012-G46",
        "A144-R20261012-G47",
        "A144-R20261012-G48",
        "A144-R20261012-G51",
        "A144-R20261012-G52"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ01b",
      "question": "年龄相关细胞亚群改变：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P003",
            "scope": "仅直接流式门控计数；scRNA独立来源",
            "sample_class_id": "A144-R20261012-G01"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "仅直接流式门控计数；scRNA独立来源",
            "sample_class_id": "A144-R20261012-G02"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "仅直接流式门控计数；scRNA独立来源",
            "sample_class_id": "A144-R20261012-G03"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
            "sample_class_id": "A144-R20261012-G46"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
            "sample_class_id": "A144-R20261012-G47"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
            "sample_class_id": "A144-R20261012-G48"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
            "sample_class_id": "A144-R20261012-G52"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O01",
        "A144-R20261012-O02",
        "A144-R20261012-O41",
        "A144-R20261012-O42",
        "A144-R20261012-O45",
        "A144-R20261012-O46"
      ],
      "group_ids": [
        "A144-R20261012-G01",
        "A144-R20261012-G02",
        "A144-R20261012-G03",
        "A144-R20261012-G39",
        "A144-R20261012-G46",
        "A144-R20261012-G47",
        "A144-R20261012-G48",
        "A144-R20261012-G51",
        "A144-R20261012-G52"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ02a",
      "question": "整叶高密度TEC区域：实际观察到了什么？",
      "answer": [
        "年轻髓质互连，老年呈孤立岛及髓周高密度TEC带。 Fig2a老年代表图实际标18mo+，caption称24mo male，年龄来源范围不一致，不能强行统一。",
        "Fig2c老龄相对年轻：总体积↓P=.07、皮质体积↓.08、cTEC数量↓.07均未显著；髓质体积↓.002、mTEC数量↓.0008；HD体积↑.009、HD细胞数↑.004。n3/年龄，mean±SEM、unpaired t；不把趋势全称显著下降。"
      ],
      "result_ids": [
        "A144-R20261012-O03",
        "A144-R20261012-O04"
      ],
      "group_ids": [
        "A144-R20261012-G04",
        "A144-R20261012-G05",
        "A144-R20261012-G06"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ02b",
      "question": "整叶高密度TEC区域：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定组织透明/标记",
            "sample_class_id": "A144-R20261012-G04"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应形态成像量化",
            "sample_class_id": "A144-R20261012-G04"
          },
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定组织透明/标记",
            "sample_class_id": "A144-R20261012-G05"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应形态成像量化",
            "sample_class_id": "A144-R20261012-G05"
          },
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定组织透明/标记",
            "sample_class_id": "A144-R20261012-G06"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应形态成像量化",
            "sample_class_id": "A144-R20261012-G06"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O03",
        "A144-R20261012-O04"
      ],
      "group_ids": [
        "A144-R20261012-G04",
        "A144-R20261012-G05",
        "A144-R20261012-G06"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ03a",
      "question": "空间转录与固定免疫对应：实际观察到了什么？",
      "answer": [
        "老年aaTEC签名聚集在髓质相关区域；HD中多K5+、部分K8+、K14−，claudin3可标记。 Workbook Table3当前aaTEC1/2 top20签名各20基因，官网补件描述top30/top10，来源定义差异保留。",
        "转录签名、流式DN-TEC和HD形态的对应为多源推断，非单一共同测量。"
      ],
      "result_ids": [
        "A144-R20261012-O05",
        "A144-R20261012-O06"
      ],
      "group_ids": [
        "A144-R20261012-G07",
        "A144-R20261012-G08"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ03b",
      "question": "空间转录与固定免疫对应：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定免疫支路",
            "sample_class_id": "A144-R20261012-G08"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应图像；Visium独立来源",
            "sample_class_id": "A144-R20261012-G08"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O05",
        "A144-R20261012-O06"
      ],
      "group_ids": [
        "A144-R20261012-G07",
        "A144-R20261012-G08"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ04a",
      "question": "既有报告体系中的TEC来源：实际观察到了什么？",
      "answer": [
        "老年GFP+出现EpCAM+ DN与EpCAM−群；claudin3和PDPN分别支持aaTEC1/2标记。",
        "RNA velocity提示mTEC1/early-prog向aaTEC方向；不是直接逐细胞纵向追踪。",
        "20月Foxn1tdTom报告TEC共1093细胞与18/20月WT7412细胞整合，所有TEC簇包括aaTEC1/2均检测tdTom转录，支持其既往Foxn1谱系来源。细胞数不是鼠n；独立scRNA分支不继承GFP流式。",
        "Fig3b claudin3+比例aaTEC>mTEC P=.03（n4鼠）；3c在GFP+EpCAM−内PDPN+比例PDGFRα−高于α+ P=.03（n4）。2月c明确No data，不能作年轻阴性。3d报告鼠aaTEC1/2老龄计数↑P=.04/.01，2月n6、18月n4，不能借Fig1k C57BL/6 n。",
        "ED5a11周体系验证近全部TEC GFP仅Foxn1报告鼠，n2–3、两实验；代表门控百分比不作总体均值。此年轻验证支路不借作Fig3d的2/18月生物n。"
      ],
      "result_ids": [
        "A144-R20261012-O07",
        "A144-R20261012-O08",
        "A144-R20261012-O27",
        "A144-R20261012-O43",
        "A144-R20261012-O50"
      ],
      "group_ids": [
        "A144-R20261012-G09",
        "A144-R20261012-G10",
        "A144-R20261012-G11",
        "A144-R20261012-G49",
        "A144-R20261012-G57"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ04b",
      "question": "既有报告体系中的TEC来源：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P003",
            "scope": "仅流式GFP、EpCAM/claudin3/PDPN表型",
            "sample_class_id": "A144-R20261012-G09"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
            "sample_class_id": "A144-R20261012-G49"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "only named published reporter-validation flow readout; no20month transcript branch",
            "sample_class_id": "A144-R20261012-G57"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O07",
        "A144-R20261012-O08",
        "A144-R20261012-O27",
        "A144-R20261012-O43",
        "A144-R20261012-O50"
      ],
      "group_ids": [
        "A144-R20261012-G09",
        "A144-R20261012-G10",
        "A144-R20261012-G11",
        "A144-R20261012-G49",
        "A144-R20261012-G57"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ05a",
      "question": "HD区及人体参照：实际观察到了什么？",
      "answer": [
        "aaTEC富集区域缺乏胸腺细胞；人体材料见相似富上皮区域。",
        "既有人数据可见aaTEC签名；claudin3/PDPN在人组织识别的有效性仍待确认。 Fig3h–k为50岁女性连续H&E/panCK/CD1a切片；ED5人整合115536 CD45−/40144TEC均为细胞数，不是患者n。"
      ],
      "result_ids": [
        "A144-R20261012-O09",
        "A144-R20261012-O10"
      ],
      "group_ids": [
        "A144-R20261012-G12",
        "A144-R20261012-G13",
        "A144-R20261012-G14"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ05b",
      "question": "HD区及人体参照：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定组织透明/标记",
            "sample_class_id": "A144-R20261012-G12"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应形态成像量化",
            "sample_class_id": "A144-R20261012-G12"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O09",
        "A144-R20261012-O10"
      ],
      "group_ids": [
        "A144-R20261012-G12",
        "A144-R20261012-G13",
        "A144-R20261012-G14"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ06a",
      "question": "年龄相关通路背景：实际观察到了什么？",
      "answer": [
        "年龄效应具有细胞谱系差异，FB中的炎症/衰老相关程序是作者主要背景解释。 Fig4a/ED6b多数群线粒体功能/代谢相关程序降低，FB免疫/抗原呈递增加，蛋白稳态变化主要限上皮；均为转录GSEA推断，不等于实际功能测定。",
        "稳态cTEC中Foxn1/Dll4/Psmb11/Prss16/Enpep/Ly75未观察到随龄表达变化；作者提示全CD45−单细胞中cTEC捕获少可能限制检测，不当等效证明。 新Table4-cTEC原_p列：Cxcl12 .0965814、Foxn1 .894045、Ccl25/Psmb11/Kitl/Dll4/Il7均1，符合这些目标无显著年龄变化；按Methods为FDR调整检验，不改为原始P。"
      ],
      "result_ids": [
        "A144-R20261012-O11",
        "A144-R20261012-O30"
      ],
      "group_ids": [
        "A144-R20261012-G15",
        "A144-R20261012-G16"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ06b",
      "question": "年龄相关通路背景：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O11",
        "A144-R20261012-O30"
      ],
      "group_ids": [
        "A144-R20261012-G15",
        "A144-R20261012-G16"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ07a",
      "question": "aaTEC功能表达与部分EMT：实际观察到了什么？",
      "answer": [
        "aaTEC1抗原呈递降低；aaTEC2 EMT特征富集。 原Table6对应aaTEC1抗原呈递row8 NES−1.8/FDRq列0，aaTEC2EMT row4 NES2.4/q0；0为作者报告精度，不解释概率为零，与图≤.0001并存。",
        "Cdh1/Vim及8795相关基因比较支持aaTEC2介于上皮和间质之间；支持部分EMT状态，但作者未排除某些aaTEC2完全EMT；不是直接谱系转换实验。",
        "2026-03-13作者纠正：原右图标注Mouse1/2/3实为同一鼠3区域；HTML/PDF已替换为3只不同老年报告鼠。旧版n=1鼠/3区域，新版n=3鼠，仅适用于ED7a；本轮已直接读修正图面，不外推其它结果。 本轮已取得并实读纠正后ED7a原图，右侧UEA1显示Mouse1/2/3；三只不同鼠的身份来自官方纠正声明，非从图片猜测。原版同鼠三区域与新版三鼠范围仅适用a。",
        "ED7b：2月较18月常规mTEC中Tuft及Corneocyte数量更高，各P=.0007；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。",
        "ED7c：18月mTEC较DN-TEC的Tuft数量更高P=.001、Corneocyte更高P=.005；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。",
        "ED7d展示TEC子群Aire/Foxn1表达分布，作为转录支持图，不是蛋白流式或额外生物重复。",
        "ED7e 12月报告鼠AIRE在髓质可见，aaTEC/HD区图示缺乏相当AIRE信号；代表图不作细胞阳性率量化，未报告e生物n。图注比例尺50μm，实际两图30/20μm，保留不一致。",
        "aaTEC中Dll4/Psmb11/Kitl/Ccl25/Cxcl12/Il7低；Fezf2/Aire、关键NFκB目标及Tnfrsf11a/Ltbr/Cd40缺乏相应表达；AIRE/FEZF2依赖TRA低或无，主要见mTEC2/mTECprol。仅转录支持，不声称已做T细胞功能干预或绝对无功能。"
      ],
      "result_ids": [
        "A144-R20261012-O12",
        "A144-R20261012-O13",
        "A144-R20261012-O25",
        "A144-R20261012-O37",
        "A144-R20261012-O38",
        "A144-R20261012-O39",
        "A144-R20261012-O40",
        "A144-R20261012-O44"
      ],
      "group_ids": [
        "A144-R20261012-G17",
        "A144-R20261012-G18",
        "A144-R20261012-G19",
        "A144-R20261012-G36",
        "A144-R20261012-G37",
        "A144-R20261012-G41",
        "A144-R20261012-G42",
        "A144-R20261012-G43",
        "A144-R20261012-G44",
        "A144-R20261012-G45",
        "A144-R20261012-G50"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ07b",
      "question": "aaTEC功能表达与部分EMT：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P003",
            "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging",
            "sample_class_id": "A144-R20261012-G41"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging",
            "sample_class_id": "A144-R20261012-G42"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging",
            "sample_class_id": "A144-R20261012-G43"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O12",
        "A144-R20261012-O13",
        "A144-R20261012-O25",
        "A144-R20261012-O37",
        "A144-R20261012-O38",
        "A144-R20261012-O39",
        "A144-R20261012-O40",
        "A144-R20261012-O44"
      ],
      "group_ids": [
        "A144-R20261012-G17",
        "A144-R20261012-G18",
        "A144-R20261012-G19",
        "A144-R20261012-G36",
        "A144-R20261012-G37",
        "A144-R20261012-G41",
        "A144-R20261012-G42",
        "A144-R20261012-G43",
        "A144-R20261012-G44",
        "A144-R20261012-G45",
        "A144-R20261012-G50"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ08a",
      "question": "基线配体受体推断与蛋白支路：实际观察到了什么？",
      "answer": [
        "CellChat按受体/配体表达比较，作者认为aaTEC可吸引上皮生长信号；不是配体流量实测。",
        "Fig4j蛋白量单位pg/10^6 cells：PTN 2vs12月P=.04、2vs18月.005；MDK 2vs12月NS、2vs18月.01。2/12/18月雌鼠每组n5，mean±SEM、Kruskal–Wallis+Dunn；不是全胸腺总量，不是流式/CellChat，保留MDK12月阴性。"
      ],
      "result_ids": [
        "A144-R20261012-O14",
        "A144-R20261012-O15"
      ],
      "group_ids": [
        "A144-R20261012-G20",
        "A144-R20261012-G21"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ08b",
      "question": "基线配体受体推断与蛋白支路：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O14",
        "A144-R20261012-O15"
      ],
      "group_ids": [
        "A144-R20261012-G20",
        "A144-R20261012-G21"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ09a",
      "question": "年轻与老年损伤后恢复：实际观察到了什么？",
      "answer": [
        "年轻第28日恢复；老年约第42日才接近损伤前细胞量。",
        "流式支路：老年aaTEC在损伤后快速再现；这里只记录细胞亚群反应，不绑定组织学纤维化/钙化。",
        "Fig5d以0–7日AUC表示早期变化，老龄指数=老年AUC/年轻AUC；每细胞类型报告n10。这里只保留年轻/老年动态支路。 图面y轴实际标Recovery index，而图注/正文用aging index；两称谓并存，不据此假设不同计算。",
        "ED9b多数基质亚群早期反应未见重大年龄差异，aaTEC是例外；不以aaTEC的特殊变化替代整体基质反应。 该正文概述不排除ED9b具体时间点跨龄差异，详见新逐点O；不能把概述作所有基质时点均阴性。",
        "ED9a组织学显示老年持续纤维化/钙化等改变，年轻无相同持续改变；此比较与aaTEC流式计数、12月右叶透明成像分开，现不外推具体每组n。",
        "ED9b每年龄/时间n10，mean±SEM、2wayANOVA+Sidak。day7 aEC/vEC老龄较高P=.005/.002；capEC全时点NS、aEC/vEC其余时点NS。intFB全时点NS；capsFB day1/4/7老龄较高.04/.01/.001；medFB day0/4/7老龄较高<.0001/.009/.0005，day1 NS。mTEC1 day0/1/7老龄较低.01/.0002/.01；mTEC2 day0/1较低<.0001/.002；mTEC3 day0/1较低.0002/<.0001；tuft day0/1/7较低<.0001/.001/.04；cTEC day0老龄较高.01，aaTEC1/2 day0***。未标注的其他点不自动判NS。"
      ],
      "result_ids": [
        "A144-R20261012-O16",
        "A144-R20261012-O17",
        "A144-R20261012-O26",
        "A144-R20261012-O31",
        "A144-R20261012-O32",
        "A144-R20261012-O47"
      ],
      "group_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23",
        "A144-R20261012-G40",
        "A144-R20261012-G53"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ09b",
      "question": "年轻与老年损伤后恢复：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P003",
            "scope": "仅已采集数据的细胞计数；不重建损伤操作",
            "sample_class_id": "A144-R20261012-G22"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "仅已采集数据的细胞计数；不重建损伤操作",
            "sample_class_id": "A144-R20261012-G23"
          },
          {
            "protocol_id": "A144-P003",
            "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
            "sample_class_id": "A144-R20261012-G53"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O16",
        "A144-R20261012-O17",
        "A144-R20261012-O26",
        "A144-R20261012-O31",
        "A144-R20261012-O32",
        "A144-R20261012-O47"
      ],
      "group_ids": [
        "A144-R20261012-G22",
        "A144-R20261012-G23",
        "A144-R20261012-G40",
        "A144-R20261012-G53"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ10a",
      "question": "损伤后老年HD区三维量化：实际观察到了什么？",
      "answer": [
        "12月雄鼠既有TBI后28日右叶：叶/髓质/皮质体积下降，图上P=.01/.002/.03；aaTEC体积升高P=.004。mTEC数量下降P=.02，但cTEC数量升高P=.02，aaTEC数量升高P=.004。不能把常规TEC统一说成下降。精确柱均值未数字化。",
        "Video4实际分散帧标18mo untreated/18mo(d21 SL-TBI)，caption却12mo baseline/day28并称associatedFig3e。保持独立代表性来源冲突，不把该影片并入O18 Fig5e/f12月day28量化或借其n。"
      ],
      "result_ids": [
        "A144-R20261012-O18",
        "A144-R20261012-O49"
      ],
      "group_ids": [
        "A144-R20261012-G24",
        "A144-R20261012-G25",
        "A144-R20261012-G56"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ10b",
      "question": "损伤后老年HD区三维量化：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定组织透明/标记",
            "sample_class_id": "A144-R20261012-G24"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应形态成像量化",
            "sample_class_id": "A144-R20261012-G24"
          },
          {
            "protocol_id": "A144-P001",
            "scope": "仅固定组织透明/标记",
            "sample_class_id": "A144-R20261012-G25"
          },
          {
            "protocol_id": "A144-P002",
            "scope": "对应形态成像量化",
            "sample_class_id": "A144-R20261012-G25"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O18",
        "A144-R20261012-O49"
      ],
      "group_ids": [
        "A144-R20261012-G24",
        "A144-R20261012-G25",
        "A144-R20261012-G56"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ11a",
      "question": "损伤后亚群转录时间序列：实际观察到了什么？",
      "answer": [
        "Fig5g–i以年龄、day0/1/4/7及基质亚群注释同一UMAP。损伤后1/4/7日58,309个CD45−细胞与22,932个day0细胞整合，共81,241；这些是细胞而不是动物n。显示嵌入/标签本身不等于亚群恢复量。 SuppFig1 QC前共93,738细胞，QC后整合81,241；细胞QC排除不等于样本排除，前后分母不混用。",
        "Fig5j表明aaTEC群在老龄胸腺损伤后仍是突出TEC组分。纵轴是TEC亚群Proportion(%)，不是绝对细胞数；图上比例未数字化，不能凭组成说绝对增加。",
        "2月组day0/1/4/7的RNA-velocity推断由mTECprol走向常规mTEC2及拟态细胞谱系。箭头表示计算推断，不是同一细胞的实验追踪。",
        "18月组损伤后轨迹偏向mTEC1/earlyprog→aaTEC1/aaTEC2，而非年轻的常规mTEC2/拟态方向；为年龄分层RNA-velocity推断，不作为已证明谱系转分化。",
        "作者据此提出aaTEC可能扰乱老龄胸腺早期分化/再生程序。该项是解释，不是额外消除实验或独立干预结果。",
        "正式SupplementFig2比较同时间CD45−样本：横轴log10 bulk RNAseq、纵轴log10平均scRNA技术重复表达。day0四bulk生物重复R=.83/.79/.82/.79；day1三例.84/.84/.86；day4三例.83/.85/.84；day7三例.85/.83/.84，全部Pearson P<2.2e−16。scRNA技术重复精确n未在caption给出；基因点不是动物n，相关支持不证明每个稀少亚群采样无偏。"
      ],
      "result_ids": [
        "A144-R20261012-O19",
        "A144-R20261012-O33",
        "A144-R20261012-O34",
        "A144-R20261012-O35",
        "A144-R20261012-O36",
        "A144-R20261012-O48"
      ],
      "group_ids": [
        "A144-R20261012-G26",
        "A144-R20261012-G27",
        "A144-R20261012-G54",
        "A144-R20261012-G55"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ11b",
      "question": "损伤后亚群转录时间序列：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O19",
        "A144-R20261012-O33",
        "A144-R20261012-O34",
        "A144-R20261012-O35",
        "A144-R20261012-O36",
        "A144-R20261012-O48"
      ],
      "group_ids": [
        "A144-R20261012-G26",
        "A144-R20261012-G27",
        "A144-R20261012-G54",
        "A144-R20261012-G55"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ12a",
      "question": "再生信号与竞争解释：实际观察到了什么？",
      "answer": [
        "正文概述损伤后Fgf7/Fgf10/Fgf21/Bmp4及Flt3l/Kitl再生相关程序广泛上调、老龄幅度常较弱，但不能推广为每亚群每时间点均如此。再生相关基因响应依亚群/年龄/时点而异。cTEC Psmb11在老年day4/7相对day1仍显著上升（_l=1.919/2.435，FDR-adjusted _p≈8.25e−7/9.96e−12），但幅度弱于年轻_l=5.494/5.691，不能写老年Psmb11下降。Dll4年轻day4/7显著诱导_p=.01682/.004699，老年两点_p=1。Foxn1两龄day7显著上升，day4年轻_p=.24488、老年.05246均未显著；Ccl25两龄两点显著上升，Cxcl12老day4显著.000159而day7 .05840未显著。年轻intFB Kitl day4反向下降_l−.310/_p.000725，day7上升.686/.002055；老intFB Fgf7 day4/7仍上升.595/.000332及.282/.004990，老medFB Bmp4也上升.499/.02699及.955/2.65e−13。老龄不等于所有因子都不响应；原表完整目标行/坐标另存，数值按报告精度非新重算。",
        "FGF/BMP相关互作偏向aaTEC；受体表达/CellChat不能单独证明实际竞争性消耗。",
        "KGF响应下cTEC/mTEC/aaTEC出现pAKT反应，FB无对应反应；6只18月雌鼠独立胸腺，mean±SEM、paired t test。与CellChat计算分开。 pAKT读出时点为KGF后5 min。 Fig6e实图纵轴pAKT MFI，配对KGF−/+：cTEC P=.002、mTEC .03、aaTEC1 .03、aaTEC2 .008，FB NS。"
      ],
      "result_ids": [
        "A144-R20261012-O20",
        "A144-R20261012-O21",
        "A144-R20261012-O24"
      ],
      "group_ids": [
        "A144-R20261012-G29",
        "A144-R20261012-G30",
        "A144-R20261012-G31",
        "A144-R20261012-G35"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ12b",
      "question": "再生信号与竞争解释：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P003",
            "scope": "published pAKT flow endpoint only",
            "sample_class_id": "A144-R20261012-G35"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O20",
        "A144-R20261012-O21",
        "A144-R20261012-O24"
      ],
      "group_ids": [
        "A144-R20261012-G29",
        "A144-R20261012-G30",
        "A144-R20261012-G31",
        "A144-R20261012-G35"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ13a",
      "question": "FOXN1降低与aaTEC关联：实际观察到了什么？",
      "answer": [
        "FOXN1蛋白在cTEC/mTEC可检出，在aaTEC1/2不明显；此O仅蛋白流式。",
        "计算诱导/抑制FOXN1与分化轨迹相关；不是实际动物干预或蛋白流式读出。",
        "aaTEC1/2的Foxn1转录低表达，与蛋白结果为不同支路，不赋蛋白流式P。",
        "6月既有Foxn1低功能模型较对照提前出现aaTEC；仅记录已发表比较，不继承FOXN1蛋白流式流程或重建模型建立。 ED10b各柱来自不同性别/年龄/模型数据，不能当完全匹配干预的定量对照。"
      ],
      "result_ids": [
        "A144-R20261012-O22",
        "A144-R20261012-O23",
        "A144-R20261012-O28",
        "A144-R20261012-O29"
      ],
      "group_ids": [
        "A144-R20261012-G32",
        "A144-R20261012-G33",
        "A144-R20261012-G34",
        "A144-R20261012-G38"
      ]
    },
    {
      "question_id": "A144-R20261012-GQ13b",
      "question": "FOXN1降低与aaTEC关联：哪些方法及限制适用？",
      "answer": {
        "protocol_uses": [
          {
            "protocol_id": "A144-P003",
            "scope": "仅FOXN1蛋白流式，不扩为模型构建",
            "sample_class_id": "A144-R20261012-G34"
          }
        ],
        "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
      },
      "result_ids": [
        "A144-R20261012-O22",
        "A144-R20261012-O23",
        "A144-R20261012-O28",
        "A144-R20261012-O29"
      ],
      "group_ids": [
        "A144-R20261012-G32",
        "A144-R20261012-G33",
        "A144-R20261012-G34",
        "A144-R20261012-G38"
      ]
    }
  ],
  "relations": [
    {
      "from_id": "A144-R20261012-E01",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O01"
    },
    {
      "from_id": "A144-R20261012-G01",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O01"
    },
    {
      "from_id": "A144-R20261012-G02",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O01"
    },
    {
      "from_id": "A144-R20261012-G03",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O01"
    },
    {
      "from_id": "A144-R20261012-E01",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O02"
    },
    {
      "from_id": "A144-R20261012-G39",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O02"
    },
    {
      "from_id": "A144-R20261012-E02",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O03"
    },
    {
      "from_id": "A144-R20261012-G04",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O03"
    },
    {
      "from_id": "A144-R20261012-G05",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O03"
    },
    {
      "from_id": "A144-R20261012-E02",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O04"
    },
    {
      "from_id": "A144-R20261012-G04",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O04"
    },
    {
      "from_id": "A144-R20261012-G06",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O04"
    },
    {
      "from_id": "A144-R20261012-E03",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O05"
    },
    {
      "from_id": "A144-R20261012-G07",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O05"
    },
    {
      "from_id": "A144-R20261012-G08",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O05"
    },
    {
      "from_id": "A144-R20261012-E03",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O06"
    },
    {
      "from_id": "A144-R20261012-G07",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O06"
    },
    {
      "from_id": "A144-R20261012-G08",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O06"
    },
    {
      "from_id": "A144-R20261012-E04",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O07"
    },
    {
      "from_id": "A144-R20261012-G09",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O07"
    },
    {
      "from_id": "A144-R20261012-E04",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O08"
    },
    {
      "from_id": "A144-R20261012-G11",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O08"
    },
    {
      "from_id": "A144-R20261012-E05",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O09"
    },
    {
      "from_id": "A144-R20261012-G12",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O09"
    },
    {
      "from_id": "A144-R20261012-G13",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O09"
    },
    {
      "from_id": "A144-R20261012-G14",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O09"
    },
    {
      "from_id": "A144-R20261012-E05",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O10"
    },
    {
      "from_id": "A144-R20261012-G13",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O10"
    },
    {
      "from_id": "A144-R20261012-G14",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O10"
    },
    {
      "from_id": "A144-R20261012-E06",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O11"
    },
    {
      "from_id": "A144-R20261012-G15",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O11"
    },
    {
      "from_id": "A144-R20261012-G16",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O11"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O12"
    },
    {
      "from_id": "A144-R20261012-G17",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O12"
    },
    {
      "from_id": "A144-R20261012-G18",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O12"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O13"
    },
    {
      "from_id": "A144-R20261012-G18",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O13"
    },
    {
      "from_id": "A144-R20261012-G19",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O13"
    },
    {
      "from_id": "A144-R20261012-E08",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O14"
    },
    {
      "from_id": "A144-R20261012-G20",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O14"
    },
    {
      "from_id": "A144-R20261012-E08",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O15"
    },
    {
      "from_id": "A144-R20261012-G21",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O15"
    },
    {
      "from_id": "A144-R20261012-E09",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O16"
    },
    {
      "from_id": "A144-R20261012-G22",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O16"
    },
    {
      "from_id": "A144-R20261012-G23",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O16"
    },
    {
      "from_id": "A144-R20261012-E09",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O17"
    },
    {
      "from_id": "A144-R20261012-G22",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O17"
    },
    {
      "from_id": "A144-R20261012-G23",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O17"
    },
    {
      "from_id": "A144-R20261012-E10",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O18"
    },
    {
      "from_id": "A144-R20261012-G24",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O18"
    },
    {
      "from_id": "A144-R20261012-G25",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O18"
    },
    {
      "from_id": "A144-R20261012-E11",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O19"
    },
    {
      "from_id": "A144-R20261012-G26",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O19"
    },
    {
      "from_id": "A144-R20261012-G27",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O19"
    },
    {
      "from_id": "A144-R20261012-E12",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O20"
    },
    {
      "from_id": "A144-R20261012-G29",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O20"
    },
    {
      "from_id": "A144-R20261012-G30",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O20"
    },
    {
      "from_id": "A144-R20261012-E12",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O21"
    },
    {
      "from_id": "A144-R20261012-G29",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O21"
    },
    {
      "from_id": "A144-R20261012-G30",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O21"
    },
    {
      "from_id": "A144-R20261012-G31",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O21"
    },
    {
      "from_id": "A144-R20261012-E13",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O22"
    },
    {
      "from_id": "A144-R20261012-G34",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O22"
    },
    {
      "from_id": "A144-R20261012-E13",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O23"
    },
    {
      "from_id": "A144-R20261012-G38",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O23"
    },
    {
      "from_id": "A144-R20261012-E12",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O24"
    },
    {
      "from_id": "A144-R20261012-G35",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O24"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O25"
    },
    {
      "from_id": "A144-R20261012-G36",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O25"
    },
    {
      "from_id": "A144-R20261012-G37",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O25"
    },
    {
      "from_id": "A144-R20261012-E09",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O26"
    },
    {
      "from_id": "A144-R20261012-G22",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O26"
    },
    {
      "from_id": "A144-R20261012-G23",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O26"
    },
    {
      "from_id": "A144-R20261012-E04",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O27"
    },
    {
      "from_id": "A144-R20261012-G10",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O27"
    },
    {
      "from_id": "A144-R20261012-E13",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O28"
    },
    {
      "from_id": "A144-R20261012-G32",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O28"
    },
    {
      "from_id": "A144-R20261012-E13",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O29"
    },
    {
      "from_id": "A144-R20261012-G33",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O29"
    },
    {
      "from_id": "A144-R20261012-E06",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O30"
    },
    {
      "from_id": "A144-R20261012-G15",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O30"
    },
    {
      "from_id": "A144-R20261012-G16",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O30"
    },
    {
      "from_id": "A144-R20261012-E09",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O31"
    },
    {
      "from_id": "A144-R20261012-G22",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O31"
    },
    {
      "from_id": "A144-R20261012-G23",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O31"
    },
    {
      "from_id": "A144-R20261012-E09",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O32"
    },
    {
      "from_id": "A144-R20261012-G40",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O32"
    },
    {
      "from_id": "A144-R20261012-E11",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O33"
    },
    {
      "from_id": "A144-R20261012-G27",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O33"
    },
    {
      "from_id": "A144-R20261012-E11",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O34"
    },
    {
      "from_id": "A144-R20261012-G26",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O34"
    },
    {
      "from_id": "A144-R20261012-E11",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O35"
    },
    {
      "from_id": "A144-R20261012-G27",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O35"
    },
    {
      "from_id": "A144-R20261012-E11",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O36"
    },
    {
      "from_id": "A144-R20261012-G26",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O36"
    },
    {
      "from_id": "A144-R20261012-G27",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O36"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O37"
    },
    {
      "from_id": "A144-R20261012-G41",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O37"
    },
    {
      "from_id": "A144-R20261012-G42",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O37"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O38"
    },
    {
      "from_id": "A144-R20261012-G42",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O38"
    },
    {
      "from_id": "A144-R20261012-G43",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O38"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O39"
    },
    {
      "from_id": "A144-R20261012-G44",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O39"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O40"
    },
    {
      "from_id": "A144-R20261012-G45",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O40"
    },
    {
      "from_id": "A144-R20261012-E01",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O41"
    },
    {
      "from_id": "A144-R20261012-G46",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O41"
    },
    {
      "from_id": "A144-R20261012-G47",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O41"
    },
    {
      "from_id": "A144-R20261012-E01",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O42"
    },
    {
      "from_id": "A144-R20261012-G48",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O42"
    },
    {
      "from_id": "A144-R20261012-E04",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O43"
    },
    {
      "from_id": "A144-R20261012-G49",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O43"
    },
    {
      "from_id": "A144-R20261012-E07",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O44"
    },
    {
      "from_id": "A144-R20261012-G50",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O44"
    },
    {
      "from_id": "A144-R20261012-E01",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O45"
    },
    {
      "from_id": "A144-R20261012-G51",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O45"
    },
    {
      "from_id": "A144-R20261012-E01",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O46"
    },
    {
      "from_id": "A144-R20261012-G52",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O46"
    },
    {
      "from_id": "A144-R20261012-E09",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O47"
    },
    {
      "from_id": "A144-R20261012-G53",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O47"
    },
    {
      "from_id": "A144-R20261012-E11",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O48"
    },
    {
      "from_id": "A144-R20261012-G54",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O48"
    },
    {
      "from_id": "A144-R20261012-G55",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O48"
    },
    {
      "from_id": "A144-R20261012-E10",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O49"
    },
    {
      "from_id": "A144-R20261012-G56",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O49"
    },
    {
      "from_id": "A144-R20261012-E04",
      "relation": "has_observation",
      "to_id": "A144-R20261012-O50"
    },
    {
      "from_id": "A144-R20261012-G57",
      "relation": "observed_in",
      "to_id": "A144-R20261012-O50"
    }
  ],
  "legacy_mapping": {
    "mapping_basis": "Explicit historical references retained verbatim; new objects have new identities. Component correspondence is not a recovery of missing historical E/G/O contents.",
    "evidence_links": [
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A144-E01-G01",
        "group_pointer": "/evidence_records/0/groups/0",
        "observations": [
          {
            "observation_id": "A144-E01-O01",
            "pointer": "/evidence_records/0/observations/0",
            "figure_panels": [
              "pp2–3 Fig1a–f; pp21–22 ED2–3",
              "Tables1–3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp2–3 Fig1a–f; pp21–22 ED2–3"
              },
              {
                "source_id": "F06",
                "location": "Tables1–3"
              }
            ],
            "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
          },
          {
            "observation_id": "A144-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "p3 Fig1g–k; p23 ED4",
              "p4 Table11",
              "pp5–6,9,12: markers, emergence timing and sex"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig1g–k; p23 ED4"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F05",
                "location": "pp5–6,9,12: markers, emergence timing and sex"
              }
            ],
            "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
          }
        ],
        "group_label": "2月稳态",
        "protocol_binding": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A144-E01-G02",
        "group_pointer": "/evidence_records/0/groups/1",
        "observations": [
          {
            "observation_id": "A144-E01-O01",
            "pointer": "/evidence_records/0/observations/0",
            "figure_panels": [
              "pp2–3 Fig1a–f; pp21–22 ED2–3",
              "Tables1–3"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp2–3 Fig1a–f; pp21–22 ED2–3"
              },
              {
                "source_id": "F06",
                "location": "Tables1–3"
              }
            ],
            "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
          },
          {
            "observation_id": "A144-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "p3 Fig1g–k; p23 ED4",
              "p4 Table11",
              "pp5–6,9,12: markers, emergence timing and sex"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig1g–k; p23 ED4"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F05",
                "location": "pp5–6,9,12: markers, emergence timing and sex"
              }
            ],
            "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
          }
        ],
        "group_label": "18月稳态",
        "protocol_binding": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E01",
        "evidence_pointer": "/evidence_records/0",
        "group_id": "A144-E01-G03",
        "group_pointer": "/evidence_records/0/groups/2",
        "observations": [
          {
            "observation_id": "A144-E01-O02",
            "pointer": "/evidence_records/0/observations/1",
            "figure_panels": [
              "p3 Fig1g–k; p23 ED4",
              "p4 Table11",
              "pp5–6,9,12: markers, emergence timing and sex"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p3 Fig1g–k; p23 ED4"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F05",
                "location": "pp5–6,9,12: markers, emergence timing and sex"
              }
            ],
            "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
          }
        ],
        "group_label": "2/12/18月aaTEC计数及生命期DN-TEC",
        "protocol_binding": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A144-E02-G01",
        "group_pointer": "/evidence_records/1/groups/0",
        "observations": [
          {
            "observation_id": "A144-E02-O01",
            "pointer": "/evidence_records/1/observations/0",
            "figure_panels": [
              "p4 Fig2a,b; pp15–16,18",
              "Video1 9个分布抽帧"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2a,b; pp15–16,18"
              },
              {
                "source_id": "F07",
                "location": "Video1 9个分布抽帧"
              }
            ],
            "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
          },
          {
            "observation_id": "A144-E02-O02",
            "pointer": "/evidence_records/1/observations/1",
            "figure_panels": [
              "p4 Fig2c actual panel; pp15–16 image quantification"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2c actual panel; pp15–16 image quantification"
              }
            ],
            "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
          }
        ],
        "group_label": "年轻2月",
        "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E02",
        "evidence_pointer": "/evidence_records/1",
        "group_id": "A144-E02-G02",
        "group_pointer": "/evidence_records/1/groups/1",
        "observations": [
          {
            "observation_id": "A144-E02-O01",
            "pointer": "/evidence_records/1/observations/0",
            "figure_panels": [
              "p4 Fig2a,b; pp15–16,18",
              "Video1 9个分布抽帧"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2a,b; pp15–16,18"
              },
              {
                "source_id": "F07",
                "location": "Video1 9个分布抽帧"
              }
            ],
            "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
          },
          {
            "observation_id": "A144-E02-O02",
            "pointer": "/evidence_records/1/observations/1",
            "figure_panels": [
              "p4 Fig2c actual panel; pp15–16 image quantification"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2c actual panel; pp15–16 image quantification"
              }
            ],
            "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
          }
        ],
        "group_label": "衰老代表图24月、定量18月",
        "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A144-E03-G01",
        "group_pointer": "/evidence_records/2/groups/0",
        "observations": [
          {
            "observation_id": "A144-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "p4 Fig2d–f; p18; ED5",
              "Table 3 - top 20 (visium) C3:W4",
              "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2d–f; p18; ED5"
              },
              {
                "source_id": "F06",
                "location": "Table 3 - top 20 (visium) C3:W4"
              },
              {
                "source_id": "F05",
                "location": "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
              }
            ],
            "scope_guard": "Visium/组学来源；不继承P001鼠透明或P002采样。"
          }
        ],
        "group_label": "2月Visium",
        "protocol_binding": "Visium/组学来源；不继承P001鼠透明或P002采样。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A144-E03-G02",
        "group_pointer": "/evidence_records/2/groups/1",
        "observations": [
          {
            "observation_id": "A144-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "p4 Fig2d–f; p18; ED5",
              "Table 3 - top 20 (visium) C3:W4",
              "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2d–f; p18; ED5"
              },
              {
                "source_id": "F06",
                "location": "Table 3 - top 20 (visium) C3:W4"
              },
              {
                "source_id": "F05",
                "location": "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
              }
            ],
            "scope_guard": "Visium/组学来源；不继承P001鼠透明或P002采样。"
          }
        ],
        "group_label": "18月Visium",
        "protocol_binding": "Visium/组学来源；不继承P001鼠透明或P002采样。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E03",
        "evidence_pointer": "/evidence_records/2",
        "group_id": "A144-E03-G03",
        "group_pointer": "/evidence_records/2/groups/2",
        "observations": [
          {
            "observation_id": "A144-E03-O01",
            "pointer": "/evidence_records/2/observations/0",
            "figure_panels": [
              "p4 Fig2d–f; p18; ED5",
              "Table 3 - top 20 (visium) C3:W4",
              "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p4 Fig2d–f; p18; ED5"
              },
              {
                "source_id": "F06",
                "location": "Table 3 - top 20 (visium) C3:W4"
              },
              {
                "source_id": "F05",
                "location": "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
              }
            ],
            "scope_guard": "P001/P002仅G03的HD区免疫图；Visium及signature为独立范围外来源。"
          }
        ],
        "group_label": "12–18月HD区免疫图",
        "protocol_binding": "P001/P002仅G03的HD区免疫图；Visium及signature为独立范围外来源。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A144-E04-G01",
        "group_pointer": "/evidence_records/3/groups/0",
        "observations": [
          {
            "observation_id": "A144-E04-O01",
            "pointer": "/evidence_records/3/observations/0",
            "figure_panels": [
              "p5 Fig3a–e; ED5a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3a–e; ED5a"
              }
            ],
            "scope_guard": "P001/P002报告鼠影像；无新模型构建操作。"
          }
        ],
        "group_label": "年轻报告小鼠",
        "protocol_binding": "P001/P002报告鼠影像；无新模型构建操作。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A144-E04-G02",
        "group_pointer": "/evidence_records/3/groups/1",
        "observations": [
          {
            "observation_id": "A144-E04-O01",
            "pointer": "/evidence_records/3/observations/0",
            "figure_panels": [
              "p5 Fig3a–e; ED5a"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3a–e; ED5a"
              }
            ],
            "scope_guard": "P001/P002报告鼠影像；无新模型构建操作。"
          }
        ],
        "group_label": "衰老Foxn1nTnG与Foxn1tdTom",
        "protocol_binding": "P001/P002报告鼠影像；无新模型构建操作。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A144-E04-G03",
        "group_pointer": "/evidence_records/3/groups/2",
        "observations": [
          {
            "observation_id": "A144-E04-O02",
            "pointer": "/evidence_records/3/observations/1",
            "figure_panels": [
              "p5 Fig3f,g; pp11–12 Discussion",
              "Video2a分布抽帧",
              "Video2b分布抽帧",
              "pp6–7,9: lineage inference and alternative fate"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3f,g; pp11–12 Discussion"
              },
              {
                "source_id": "F08",
                "location": "Video2a分布抽帧"
              },
              {
                "source_id": "F09",
                "location": "Video2b分布抽帧"
              },
              {
                "source_id": "F05",
                "location": "pp6–7,9: lineage inference and alternative fate"
              }
            ],
            "scope_guard": "RNAvelocity计算推断来源，不当实时显微或P001处理。"
          }
        ],
        "group_label": "2月WT TEC计算轨迹",
        "protocol_binding": "RNAvelocity计算推断来源，不当实时显微或P001处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E04",
        "evidence_pointer": "/evidence_records/3",
        "group_id": "A144-E04-G04",
        "group_pointer": "/evidence_records/3/groups/3",
        "observations": [
          {
            "observation_id": "A144-E04-O02",
            "pointer": "/evidence_records/3/observations/1",
            "figure_panels": [
              "p5 Fig3f,g; pp11–12 Discussion",
              "Video2a分布抽帧",
              "Video2b分布抽帧",
              "pp6–7,9: lineage inference and alternative fate"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3f,g; pp11–12 Discussion"
              },
              {
                "source_id": "F08",
                "location": "Video2a分布抽帧"
              },
              {
                "source_id": "F09",
                "location": "Video2b分布抽帧"
              },
              {
                "source_id": "F05",
                "location": "pp6–7,9: lineage inference and alternative fate"
              }
            ],
            "scope_guard": "RNAvelocity计算推断来源，不当实时显微或P001处理。"
          }
        ],
        "group_label": "18月WT TEC计算轨迹",
        "protocol_binding": "RNAvelocity计算推断来源，不当实时显微或P001处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A144-E05-G01",
        "group_pointer": "/evidence_records/4/groups/0",
        "observations": [
          {
            "observation_id": "A144-E05-O01",
            "pointer": "/evidence_records/4/observations/0",
            "figure_panels": [
              "p5 Fig3h,i; ED5b; p18",
              "Video3 9个分布抽帧"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3h,i; ED5b; p18"
              },
              {
                "source_id": "F10",
                "location": "Video3 9个分布抽帧"
              }
            ],
            "scope_guard": "P001/P002老鼠影像。"
          }
        ],
        "group_label": "衰老鼠aaTEC相关区域",
        "protocol_binding": "P001/P002老鼠影像。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A144-E05-G02",
        "group_pointer": "/evidence_records/4/groups/1",
        "observations": [
          {
            "observation_id": "A144-E05-O02",
            "pointer": "/evidence_records/4/observations/1",
            "figure_panels": [
              "p5 Fig3j,k; ED5d–f",
              "p7 marker catalog not human-specific",
              "p4",
              "Table 3 - top 20 (human TEC) D25:W26"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3j,k; ED5d–f"
              },
              {
                "source_id": "F03",
                "location": "p7 marker catalog not human-specific"
              },
              {
                "source_id": "F04",
                "location": "p4"
              },
              {
                "source_id": "F06",
                "location": "Table 3 - top 20 (human TEC) D25:W26"
              }
            ],
            "scope_guard": "人FFPE独立部分方法来源，参数不足，绝不继承鼠P001/P002。"
          }
        ],
        "group_label": "50岁人胸腺连续切片",
        "protocol_binding": "人FFPE独立部分方法来源，参数不足，绝不继承鼠P001/P002。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E05",
        "evidence_pointer": "/evidence_records/4",
        "group_id": "A144-E05-G03",
        "group_pointer": "/evidence_records/4/groups/2",
        "observations": [
          {
            "observation_id": "A144-E05-O02",
            "pointer": "/evidence_records/4/observations/1",
            "figure_panels": [
              "p5 Fig3j,k; ED5d–f",
              "p7 marker catalog not human-specific",
              "p4",
              "Table 3 - top 20 (human TEC) D25:W26"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p5 Fig3j,k; ED5d–f"
              },
              {
                "source_id": "F03",
                "location": "p7 marker catalog not human-specific"
              },
              {
                "source_id": "F04",
                "location": "p4"
              },
              {
                "source_id": "F06",
                "location": "Table 3 - top 20 (human TEC) D25:W26"
              }
            ],
            "scope_guard": "人公开scRNA数据独立来源。"
          }
        ],
        "group_label": "既有人体TEC转录数据",
        "protocol_binding": "人公开scRNA数据独立来源。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E06",
        "evidence_pointer": "/evidence_records/5",
        "group_id": "A144-E06-G01",
        "group_pointer": "/evidence_records/5/groups/0",
        "observations": [
          {
            "observation_id": "A144-E06-O01",
            "pointer": "/evidence_records/5/observations/0",
            "figure_panels": [
              "pp6–8 Fig4a; p26 ED6",
              "Tables4–5; Table4-cTEC specified rows in QT01"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp6–8 Fig4a; p26 ED6"
              },
              {
                "source_id": "F06",
                "location": "Tables4–5; Table4-cTEC specified rows in QT01"
              }
            ],
            "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
          }
        ],
        "group_label": "2月同亚群",
        "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E06",
        "evidence_pointer": "/evidence_records/5",
        "group_id": "A144-E06-G02",
        "group_pointer": "/evidence_records/5/groups/1",
        "observations": [
          {
            "observation_id": "A144-E06-O01",
            "pointer": "/evidence_records/5/observations/0",
            "figure_panels": [
              "pp6–8 Fig4a; p26 ED6",
              "Tables4–5; Table4-cTEC specified rows in QT01"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp6–8 Fig4a; p26 ED6"
              },
              {
                "source_id": "F06",
                "location": "Tables4–5; Table4-cTEC specified rows in QT01"
              }
            ],
            "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
          }
        ],
        "group_label": "18月同亚群",
        "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G01",
        "group_pointer": "/evidence_records/6/groups/0",
        "observations": [
          {
            "observation_id": "A144-E07-O01",
            "pointer": "/evidence_records/6/observations/0",
            "figure_panels": [
              "p7 Fig4b",
              "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p7 Fig4b"
              },
              {
                "source_id": "F06",
                "location": "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          },
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          }
        ],
        "group_label": "衰老aaTEC1",
        "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G02",
        "group_pointer": "/evidence_records/6/groups/1",
        "observations": [
          {
            "observation_id": "A144-E07-O01",
            "pointer": "/evidence_records/6/observations/0",
            "figure_panels": [
              "p7 Fig4b",
              "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p7 Fig4b"
              },
              {
                "source_id": "F06",
                "location": "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          },
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          }
        ],
        "group_label": "衰老aaTEC2",
        "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G03",
        "group_pointer": "/evidence_records/6/groups/2",
        "observations": [
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          }
        ],
        "group_label": "Cdh1/Vim等pEMT表达比较中的其他TEC与medFB",
        "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G04",
        "group_pointer": "/evidence_records/6/groups/3",
        "observations": [
          {
            "observation_id": "A144-E07-O01",
            "pointer": "/evidence_records/6/observations/0",
            "figure_panels": [
              "p7 Fig4b",
              "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p7 Fig4b"
              },
              {
                "source_id": "F06",
                "location": "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          },
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
          }
        ],
        "group_label": "GSEA及TEC功能表达比较中的其他TEC（不含medFB）",
        "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G05",
        "group_pointer": "/evidence_records/6/groups/4",
        "observations": [
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。"
          }
        ],
        "group_label": "2月Foxn1nTnG mimetic细胞流式",
        "protocol_binding": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G06",
        "group_pointer": "/evidence_records/6/groups/5",
        "observations": [
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。"
          }
        ],
        "group_label": "18月Foxn1nTnG mimetic与DN-TEC流式",
        "protocol_binding": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E07",
        "evidence_pointer": "/evidence_records/6",
        "group_id": "A144-E07-G07",
        "group_pointer": "/evidence_records/6/groups/6",
        "observations": [
          {
            "observation_id": "A144-E07-O02",
            "pointer": "/evidence_records/6/observations/1",
            "figure_panels": [
              "pp7–8 Fig4c–g; pp27–30 ED7–8",
              "p4 Table11",
              "p1; ED7a correction",
              "p2; original figure version only",
              "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
              },
              {
                "source_id": "F03",
                "location": "p4 Table11"
              },
              {
                "source_id": "F12",
                "location": "p1; ED7a correction"
              },
              {
                "source_id": "F13",
                "location": "p2; original figure version only"
              },
              {
                "source_id": "F16",
                "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
              }
            ],
            "scope_guard": "P001/P002仅HD区免疫图。"
          }
        ],
        "group_label": "12月Foxn1nTnG HD区免疫成像",
        "protocol_binding": "P001/P002仅HD区免疫图。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E08",
        "evidence_pointer": "/evidence_records/7",
        "group_id": "A144-E08-G01",
        "group_pointer": "/evidence_records/7/groups/0",
        "observations": [
          {
            "observation_id": "A144-E08-O01",
            "pointer": "/evidence_records/7/observations/0",
            "figure_panels": [
              "pp7–8 Fig4h,i; p29 ED8b; p17"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4h,i; p29 ED8b; p17"
              }
            ],
            "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
          },
          {
            "observation_id": "A144-E08-O02",
            "pointer": "/evidence_records/7/observations/1",
            "figure_panels": [
              "p7 Fig4j actual graphs; p8 legend"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p7 Fig4j actual graphs; p8 legend"
              }
            ],
            "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
          }
        ],
        "group_label": "2月",
        "protocol_binding": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E08",
        "evidence_pointer": "/evidence_records/7",
        "group_id": "A144-E08-G02",
        "group_pointer": "/evidence_records/7/groups/1",
        "observations": [
          {
            "observation_id": "A144-E08-O02",
            "pointer": "/evidence_records/7/observations/1",
            "figure_panels": [
              "p7 Fig4j actual graphs; p8 legend"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p7 Fig4j actual graphs; p8 legend"
              }
            ],
            "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
          }
        ],
        "group_label": "12月",
        "protocol_binding": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E08",
        "evidence_pointer": "/evidence_records/7",
        "group_id": "A144-E08-G03",
        "group_pointer": "/evidence_records/7/groups/2",
        "observations": [
          {
            "observation_id": "A144-E08-O01",
            "pointer": "/evidence_records/7/observations/0",
            "figure_panels": [
              "pp7–8 Fig4h,i; p29 ED8b; p17"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp7–8 Fig4h,i; p29 ED8b; p17"
              }
            ],
            "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
          },
          {
            "observation_id": "A144-E08-O02",
            "pointer": "/evidence_records/7/observations/1",
            "figure_panels": [
              "p7 Fig4j actual graphs; p8 legend"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p7 Fig4j actual graphs; p8 legend"
              }
            ],
            "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
          }
        ],
        "group_label": "18月",
        "protocol_binding": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E09",
        "evidence_pointer": "/evidence_records/8",
        "group_id": "A144-E09-G01",
        "group_pointer": "/evidence_records/8/groups/0",
        "observations": [
          {
            "observation_id": "A144-E09-O01",
            "pointer": "/evidence_records/8/observations/0",
            "figure_panels": [
              "pp8–9 Fig5a,b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp8–9 Fig5a,b"
              }
            ],
            "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
          },
          {
            "observation_id": "A144-E09-O02",
            "pointer": "/evidence_records/8/observations/1",
            "figure_panels": [
              "p9 Fig5c,d; p31 ED9"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p9 Fig5c,d; p31 ED9"
              }
            ],
            "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
          }
        ],
        "group_label": "年轻1–2/2月",
        "protocol_binding": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E09",
        "evidence_pointer": "/evidence_records/8",
        "group_id": "A144-E09-G02",
        "group_pointer": "/evidence_records/8/groups/1",
        "observations": [
          {
            "observation_id": "A144-E09-O01",
            "pointer": "/evidence_records/8/observations/0",
            "figure_panels": [
              "pp8–9 Fig5a,b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp8–9 Fig5a,b"
              }
            ],
            "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
          },
          {
            "observation_id": "A144-E09-O02",
            "pointer": "/evidence_records/8/observations/1",
            "figure_panels": [
              "p9 Fig5c,d; p31 ED9"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p9 Fig5c,d; p31 ED9"
              }
            ],
            "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
          }
        ],
        "group_label": "衰老18/18+月",
        "protocol_binding": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E10",
        "evidence_pointer": "/evidence_records/9",
        "group_id": "A144-E10-G01",
        "group_pointer": "/evidence_records/9/groups/0",
        "observations": [
          {
            "observation_id": "A144-E10-O01",
            "pointer": "/evidence_records/9/observations/0",
            "figure_panels": [
              "p9 Fig5e,f; p16",
              "p11: Fig5e–f age/time clarification",
              "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)",
              "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p9 Fig5e,f; p16"
              },
              {
                "source_id": "F05",
                "location": "p11: Fig5e–f age/time clarification"
              },
              {
                "source_id": "F11",
                "location": "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)"
              },
              {
                "source_id": "F02",
                "location": "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
              }
            ],
            "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
          }
        ],
        "group_label": "12月稳态",
        "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E10",
        "evidence_pointer": "/evidence_records/9",
        "group_id": "A144-E10-G02",
        "group_pointer": "/evidence_records/9/groups/1",
        "observations": [
          {
            "observation_id": "A144-E10-O01",
            "pointer": "/evidence_records/9/observations/0",
            "figure_panels": [
              "p9 Fig5e,f; p16",
              "p11: Fig5e–f age/time clarification",
              "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)",
              "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p9 Fig5e,f; p16"
              },
              {
                "source_id": "F05",
                "location": "p11: Fig5e–f age/time clarification"
              },
              {
                "source_id": "F11",
                "location": "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)"
              },
              {
                "source_id": "F02",
                "location": "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
              }
            ],
            "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
          }
        ],
        "group_label": "12月损伤后28日",
        "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E11",
        "evidence_pointer": "/evidence_records/10",
        "group_id": "A144-E11-G01",
        "group_pointer": "/evidence_records/10/groups/0",
        "observations": [
          {
            "observation_id": "A144-E11-O01",
            "pointer": "/evidence_records/10/observations/0",
            "figure_panels": [
              "pp8–9 Fig5g–k; pp16–18; ED10a",
              "p2 FigS1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp8–9 Fig5g–k; pp16–18; ED10a"
              },
              {
                "source_id": "F03",
                "location": "p2 FigS1"
              }
            ],
            "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
          }
        ],
        "group_label": "2月不同时间",
        "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E11",
        "evidence_pointer": "/evidence_records/10",
        "group_id": "A144-E11-G02",
        "group_pointer": "/evidence_records/10/groups/1",
        "observations": [
          {
            "observation_id": "A144-E11-O01",
            "pointer": "/evidence_records/10/observations/0",
            "figure_panels": [
              "pp8–9 Fig5g–k; pp16–18; ED10a",
              "p2 FigS1"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp8–9 Fig5g–k; pp16–18; ED10a"
              },
              {
                "source_id": "F03",
                "location": "p2 FigS1"
              }
            ],
            "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
          }
        ],
        "group_label": "18月不同时间",
        "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E11",
        "evidence_pointer": "/evidence_records/10",
        "group_id": "A144-E11-G03",
        "group_pointer": "/evidence_records/10/groups/2",
        "observations": [
          {
            "observation_id": "A144-E11-O02",
            "pointer": "/evidence_records/10/observations/1",
            "figure_panels": [
              "p3 FigS2 actual plot",
              "p18 bulk comparison"
            ],
            "source_refs": [
              {
                "source_id": "F03",
                "location": "p3 FigS2 actual plot"
              },
              {
                "source_id": "F01",
                "location": "p18 bulk comparison"
              }
            ],
            "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
          }
        ],
        "group_label": "bulk/scRNA总体表达验证，年龄映射未单列",
        "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E12",
        "evidence_pointer": "/evidence_records/11",
        "group_id": "A144-E12-G01",
        "group_pointer": "/evidence_records/11/groups/0",
        "observations": [
          {
            "observation_id": "A144-E12-O01",
            "pointer": "/evidence_records/11/observations/0",
            "figure_panels": [
              "p10 Fig6a,b",
              "Tables7–10 specific rows in QT02",
              "notebook14 zero-based cells12,14,17,19: field export and contrasts"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p10 Fig6a,b"
              },
              {
                "source_id": "F06",
                "location": "Tables7–10 specific rows in QT02"
              },
              {
                "source_id": "F15",
                "location": "notebook14 zero-based cells12,14,17,19: field export and contrasts"
              }
            ],
            "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
          }
        ],
        "group_label": "2月损伤后4/7日相对1日",
        "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E12",
        "evidence_pointer": "/evidence_records/11",
        "group_id": "A144-E12-G02",
        "group_pointer": "/evidence_records/11/groups/1",
        "observations": [
          {
            "observation_id": "A144-E12-O01",
            "pointer": "/evidence_records/11/observations/0",
            "figure_panels": [
              "p10 Fig6a,b",
              "Tables7–10 specific rows in QT02",
              "notebook14 zero-based cells12,14,17,19: field export and contrasts"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p10 Fig6a,b"
              },
              {
                "source_id": "F06",
                "location": "Tables7–10 specific rows in QT02"
              },
              {
                "source_id": "F15",
                "location": "notebook14 zero-based cells12,14,17,19: field export and contrasts"
              }
            ],
            "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
          }
        ],
        "group_label": "18月损伤后4/7日相对1日",
        "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E12",
        "evidence_pointer": "/evidence_records/11",
        "group_id": "A144-E12-G03",
        "group_pointer": "/evidence_records/11/groups/2",
        "observations": [
          {
            "observation_id": "A144-E12-O02",
            "pointer": "/evidence_records/11/observations/1",
            "figure_panels": [
              "p10 Fig6c–e",
              "p10: growth-factor response versus inferred competition"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p10 Fig6c–e"
              },
              {
                "source_id": "F05",
                "location": "p10: growth-factor response versus inferred competition"
              }
            ],
            "scope_guard": "P003S04/S05 KGF/pAKT直接流式，pairedindividualthymi。"
          }
        ],
        "group_label": "18月各亚群响应前后配对",
        "protocol_binding": "P003S04/S05 KGF/pAKT直接流式，pairedindividualthymi。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E12",
        "evidence_pointer": "/evidence_records/11",
        "group_id": "A144-E12-G04",
        "group_pointer": "/evidence_records/11/groups/3",
        "observations": [
          {
            "observation_id": "A144-E12-O02",
            "pointer": "/evidence_records/11/observations/1",
            "figure_panels": [
              "p10 Fig6c–e",
              "p10: growth-factor response versus inferred competition"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p10 Fig6c–e"
              },
              {
                "source_id": "F05",
                "location": "p10: growth-factor response versus inferred competition"
              }
            ],
            "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
          }
        ],
        "group_label": "2月WT CellChat基线与第7日",
        "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E12",
        "evidence_pointer": "/evidence_records/11",
        "group_id": "A144-E12-G05",
        "group_pointer": "/evidence_records/11/groups/4",
        "observations": [
          {
            "observation_id": "A144-E12-O02",
            "pointer": "/evidence_records/11/observations/1",
            "figure_panels": [
              "p10 Fig6c–e",
              "p10: growth-factor response versus inferred competition"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "p10 Fig6c–e"
              },
              {
                "source_id": "F05",
                "location": "p10: growth-factor response versus inferred competition"
              }
            ],
            "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
          }
        ],
        "group_label": "18月WT CellChat基线与第7日",
        "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E13",
        "evidence_pointer": "/evidence_records/12",
        "group_id": "A144-E13-G01",
        "group_pointer": "/evidence_records/12/groups/0",
        "observations": [
          {
            "observation_id": "A144-E13-O01",
            "pointer": "/evidence_records/12/observations/0",
            "figure_panels": [
              "pp10–12 Fig7; ED10b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp10–12 Fig7; ED10b"
              }
            ],
            "scope_guard": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。"
          }
        ],
        "group_label": "衰老TEC各状态",
        "protocol_binding": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E13",
        "evidence_pointer": "/evidence_records/12",
        "group_id": "A144-E13-G02",
        "group_pointer": "/evidence_records/12/groups/1",
        "observations": [
          {
            "observation_id": "A144-E13-O01",
            "pointer": "/evidence_records/12/observations/0",
            "figure_panels": [
              "pp10–12 Fig7; ED10b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp10–12 Fig7; ED10b"
              }
            ],
            "scope_guard": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。"
          }
        ],
        "group_label": "6月Foxn1低功能与对照",
        "protocol_binding": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      },
      {
        "core_path": "A144_candidate/A144_evidence.json",
        "evidence_id": "A144-E13",
        "evidence_pointer": "/evidence_records/12",
        "group_id": "A144-E13-G03",
        "group_pointer": "/evidence_records/12/groups/2",
        "observations": [
          {
            "observation_id": "A144-E13-O01",
            "pointer": "/evidence_records/12/observations/0",
            "figure_panels": [
              "pp10–12 Fig7; ED10b"
            ],
            "source_refs": [
              {
                "source_id": "F01",
                "location": "pp10–12 Fig7; ED10b"
              }
            ],
            "scope_guard": "P003FOXN1流式；Table12FOXN1稀释未报。"
          }
        ],
        "group_label": "2/18+月Fig7a FOXN1蛋白流式",
        "protocol_binding": "P003FOXN1流式；Table12FOXN1稀释未报。",
        "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
      }
    ],
    "legacy_mapping": [],
    "original_baseline": {
      "selected_core_files": {
        "evidence_json": {
          "path": "A144_candidate/A144_evidence.json",
          "sha256": "658294a58d5b8a55b1b33b21f74d4c6f670999e0f205826299ad1c1e30d01b4c"
        },
        "questions_json": {
          "path": "A144_candidate/A144_questions.json",
          "sha256": "b99393c48ac92ae92e066dc398692b94a9d36e014febff51e5ee91417cf3900d"
        },
        "reading_md": {
          "path": "A144_candidate/A144_reading_zh.md",
          "sha256": "f8d0aa95a2d11a2bf8e9073559ab65b50ef1209daa0cdcdfac614989abe66d08"
        }
      },
      "existing_protocol_index": "none",
      "preserved_status": {
        "state": "held_source_reviewed_candidate_pending_specified_review",
        "not_reperformed": "No new scientific acceptance/delivery/count increment",
        "core_status_fields": {
          "record_id_status": "candidate_not_accepted"
        },
        "local_review_and_scope_records": [
          "A144_candidate/README.md"
        ]
      },
      "originals_modified": false,
      "acceptance_or_count_changed": false,
      "runtime_integration": false,
      "upload_or_publication": false
    }
  },
  "historical_review_preserved": {
    "current_review": {
      "paper_id": "A144",
      "selected_source": "review_recent_corrections_recovered_20261010/A144/protocol_records.recovered.json",
      "current_review_artifacts": [
        "audit/review_recent_corrections_recovered_20261010/A144/recovery_review.json",
        "audit/review_recent_corrections_recovered_20261010/A144/REVIEW.md"
      ],
      "status": "candidate_current_scopes_must_be_read_not_full_pass",
      "historical_changes_file": "changes.json is inherited history; current corrections and limits are in audit/",
      "source_path_map": "support/source_path_map.json",
      "unmapped_references": "No map entry means unresolved, not automatically false or absent scientific content.",
      "publication_approved": false
    },
    "review_scope": "本轮组织透明/标记/成像/左右叶形态估计及直接流式读出已按源整理：MethodsPDF15–16，Table11全部23门控、Table12全部41材料行、Table13全部IF材料，原表4–7页目视；Fig5/6直接读出定义补核。3记录14步。组学实验/软件是独立支持来源，未扩为本轮透明流程；来源仍有未报值，不称可执行SOP。",
    "review_status": {
      "content": "source_checked_declared_tissue_and_direct_flow_scope_saved;unreported_gaps_retained",
      "independent_audit": "notperformed_for_currentrevision",
      "integration": "pending",
      "specified_Pro": "unchanged_hold",
      "actual_execution": "notperformed"
    },
    "source_path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A144/protocol_records.json",
    "source_sha256": "445426dfa923b29c36fc8a7561b8f9d699be9bb327ba3e46be99981e10aaea29"
  },
  "cohorts": [],
  "limitations": [
    "主Fig1–7、ED1–10、补Fig1–2及Tables11–13/报告摘要实际核；官方当前补PDF没有所引SuppFig3c。",
    "129sheet目录/表头及关键结果目标行实际核，未重分析全部原始转录组；关键细胞/时间条件与FDR列定义保留。",
    "五影片20分散帧已核但未逐帧；Video1/4年龄时间与caption、Fig2a年龄、ED7e比例尺、签名20与描述30/10等来源差异分开保留。",
    "作者未报IF稀释、仪器????未猜；计算轨迹/CellChat及转录功能推断不当作直接因果或谱系追踪。"
  ],
  "inherited_scientific_boundaries": {
    "source_conflicts": [
      {
        "id": "A144-CF01",
        "detail": "Liberase62.5µm/mL与DNase20µg/µL按原印保留；不得猜校正单位。"
      },
      {
        "id": "A144-CF02",
        "detail": "正文称下列给IF稀释，Table13只有身份/供应商/目录，IF稀释实际未列；Table12流式稀释不能搬来。"
      },
      {
        "id": "A144-CF03",
        "detail": "Video4已有字幕18mo/d21与说明12mo/d28冲突，仍保留旧核心，不能由统一流程消除。"
      },
      {
        "id": "A144-CF04",
        "detail": "更正后ED7版本保留；本轮不将更正附录旧图当独立实验。"
      },
      {
        "id": "A144-CF05",
        "detail": "Table12全部原页复核：MHCII BV421/BV711同cat107631，L1CAM Cat=AAYQ0223061/Lot=FAB5674P，PDPN二抗行Clone=Alexa647/Fluorochrome=Anti-IgG，A31573在Table12列APC而Table13列AF647；不以厂家常識改表。"
      }
    ],
    "remaining_unreviewed": [
      "已读主文Sec16/Sec17测序制备与Sec19–Sec27组学/QC/轨迹等为本轮透明和直接影像/流式读出以外的方法来源，不扩展完整软件/组学重建；不得将其E/G/O说成由本3记录完成。",
      "人胸腺FFPE来源已明，专属脱蜡/修复/染色执行未充分；不继承鼠厚片透明。",
      "Fig4j PTN/MK蛋白定量在已读Methods/ReportingSummary未取得完整检测流程；图注只支持蛋白量比较，不能发明ELISA试剂/步骤。",
      "引用73/74细胞分离和76透明法未展开；全影片/大源工作簿/作者notebooks不在本轮重新全读或执行范围，旧源版本与Prohold保留。"
    ],
    "missing_content_register": [
      {
        "record_id": "A144-P001",
        "missing": [
          "免疫荧光稀释、孵育时长/温度、normalserum种属、洗液体积/温度、clear与match精确时长未报。"
        ]
      },
      {
        "record_id": "A144-P002",
        "missing": [
          "数值分割参数、图像质量排除、左右叶匹配和density抽样规则未完整报告。"
        ]
      },
      {
        "record_id": "A144-P003",
        "missing": [
          "分离液单位疑点、消化时程、厂家MACS具体流程与每图完整荧光组合/补偿/数字门阈值未报。",
          "FOXN1 Table12稀释为空；Table13 IF稀释也缺；流式稀释不迁移到wholemount。",
          "Table12少数列/标注疑点保留：MHCII两荧光同cat107631、L1CAM Cat#/Lot#角色可疑、PDPN二抗行列名位置及A31573流式APC/IF-AF647名称差异。"
        ]
      }
    ],
    "observation_conditions": [
      "半透明/全透明为分别清除/匹配终点，无精确天数；处理和衰老/损伤后取材时间分开。",
      "左叶density×右叶volume是估计来源，不改成wholeorgan核直接计数。"
    ],
    "review_status": {
      "content": "source_checked_declared_tissue_and_direct_flow_scope_saved;unreported_gaps_retained",
      "independent_audit": "notperformed_for_currentrevision",
      "integration": "pending",
      "specified_Pro": "unchanged_hold",
      "actual_execution": "notperformed"
    }
  },
  "coverage_dimensions": {
    "new_source_scoped_graph": "all accessible published scientific Results/main/supplement sources mapped to O/claim/Q with true source gaps explicit",
    "old_core_identity": "not_recovered",
    "fresh_visual_review": true,
    "specified_Pro_gate": "unchanged",
    "parent_review": "final_increment_pending_independent_delta",
    "full_paper_status": "scientific reconstruction completed subject to explicit source gaps/author omissions; formal release unchanged",
    "historical_components_with_new_scoped_results": [
      "A144-E01",
      "A144-E02",
      "A144-E03",
      "A144-E04",
      "A144-E05",
      "A144-E06",
      "A144-E07",
      "A144-E08",
      "A144-E09",
      "A144-E10",
      "A144-E11",
      "A144-E12",
      "A144-E13"
    ],
    "historical_components_not_represented_by_new_result": [],
    "unrepresented_components_disposition": "retained as historical references; not silently counted as restored observations",
    "coverage_file": "source_to_object_coverage.json",
    "fresh_visual_scope": [
      "Main Figure5, actual asset viewed; explicit new metric review focused d/f/g/h/i/j/k"
    ],
    "fresh_visual_review_note": "Not a full-paper visual review; exact plotted values only if printed, no point digitization.",
    "actual_full_main_artwork_read": "All main figures A142 1–7, A143 1–8, A144 1–7 and Extended Data1–10 actual artwork independently viewed. Includes both corrected and original ED7. Supplements beyond extended figures remain source-unit-specific open scope.",
    "complete_supplement_scope": "Main1–7/ED1–10 andSuppFig1–2 all read;Tables11–13 and reporting all pages;129workbook directory/headers and targeted outcome rows read;5movies20frames sampled. ReferencedSuppFig3c absent in obtained currentPDF."
  },
  "sample_count_semantics": {
    "condition_class_nodes_are_not_n": true,
    "no_cross_experiment_common_validation": true
  },
  "change_log": [
    "New E/G/O/question graph built from currently read source excerpts, preserving stable P and historical boundaries.",
    "Figure descriptions are separated from metric definitions; exact author numbers are not digitized estimates.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12.",
    "Independent-review corrections: result-specific P/G bindings, negative/support findings, exact reported n and source statistics; 2026-10-12."
  ],
  "inherited_scientific_boundaries_note": "All historical this_round and verified wording belongs to the cited author-draft version, not to 2026-10-12. Original source files may remain unavailable; preserved history is not a new read.",
  "research_questions": [
    {
      "question_id": "A144-R20261012-SQ01",
      "question": "这篇论文的样本、直接结果与方法证据分别支持什么，哪些范围仍不可确认？",
      "subquestion_ids": [
        "A144-R20261012-GQ01a",
        "A144-R20261012-GQ01b",
        "A144-R20261012-GQ02a",
        "A144-R20261012-GQ02b",
        "A144-R20261012-GQ03a",
        "A144-R20261012-GQ03b",
        "A144-R20261012-GQ04a",
        "A144-R20261012-GQ04b",
        "A144-R20261012-GQ05a",
        "A144-R20261012-GQ05b",
        "A144-R20261012-GQ06a",
        "A144-R20261012-GQ06b",
        "A144-R20261012-GQ07a",
        "A144-R20261012-GQ07b",
        "A144-R20261012-GQ08a",
        "A144-R20261012-GQ08b",
        "A144-R20261012-GQ09a",
        "A144-R20261012-GQ09b",
        "A144-R20261012-GQ10a",
        "A144-R20261012-GQ10b",
        "A144-R20261012-GQ11a",
        "A144-R20261012-GQ11b",
        "A144-R20261012-GQ12a",
        "A144-R20261012-GQ12b",
        "A144-R20261012-GQ13a",
        "A144-R20261012-GQ13b"
      ],
      "evidence_scope": "partial_new_reconstruction; see coverage ledger"
    }
  ],
  "source_correction_register": [
    {
      "doi": "10.1038/s41590-026-02489-4",
      "published": "2026-03-13",
      "scope": "ED7a right panel only",
      "affected_new_O": [
        "A144-R20261012-O25"
      ],
      "affected_new_G": [
        "A144-R20261012-G36",
        "A144-R20261012-G37"
      ],
      "unaffected_results": "No other panel or result changed by this notice",
      "fresh_corrected_figure_read": false
    }
  ],
  "unbound_method_conflicts": [
    {
      "id": "A144-CF01",
      "detail": "Liberase62.5µm/mL与DNase20µg/µL按原印保留；不得猜校正单位。"
    },
    {
      "id": "A144-CF02",
      "detail": "正文称下列给IF稀释，Table13只有身份/供应商/目录，IF稀释实际未列；Table12流式稀释不能搬来。"
    },
    {
      "id": "A144-CF05",
      "detail": "Table12全部原页复核：MHCII BV421/BV711同cat107631，L1CAM Cat=AAYQ0223061/Lot=FAB5674P，PDPN二抗行Clone=Alexa647/Fluorochrome=Anti-IgG，A31573在Table12列APC而Table13列AF647；不以厂家常識改表。"
    }
  ],
  "new_source_conflicts": [
    {
      "conflict_id": "A144-FIG5D-INDEX-NAME",
      "type": "source_terminology_difference",
      "caption": "aging index; aged AUC/young AUC",
      "actual_axis_label": "Recovery index",
      "resolution": "keep both labels; no numerical formula difference inferred"
    },
    {
      "conflict_id": "A144-ED7E-SCALE",
      "caption_scale_um": 50,
      "artwork_scale_um": {
        "medulla": 30,
        "aaTEC": 20
      },
      "resolution": "preserve source discrepancy; no geometry measurement inferred"
    },
    {
      "conflict_id": "A144-FIG2A-AGE",
      "artwork": "18mo+",
      "caption": "24mo male representative",
      "resolution": "retain source-specific representative age discrepancy; quantitative18month branch remains separate"
    },
    {
      "conflict_id": "A144-VIDEO4-AGE-TIME",
      "actual_movie": "A18mo untreated/B18mo day21 SL-TBI",
      "official_caption": "12mo baseline/day28; associatedFig3e",
      "resolution": "retain separate representative video labels/caption; not identical toFig5e/f12mo day28 quantitative branch"
    },
    {
      "conflict_id": "A144-TABLE3-SIGNATURE-SIZE",
      "workbook": "tabs top20, aaTEC1/2 signatures contain20genes",
      "web_description": "top30/top10 descriptions",
      "resolution": "source definitions preserved, not silently interchangeable"
    }
  ],
  "supplement_method_source_register": {
    "Table11": "panel-specific flow phenotypes; ED1 broad gate distinct fromFig1 detailed/aaTEC andED4/ED7; no new n",
    "Table12": "flow/sorting antibodies with reported dilutions",
    "Table13": "IF antibody list has no dilution column; author omission retained",
    "reporting_summary": "6pages read:1human50yearfemale; no sample exclusion vs cellQC separate; generally unblinded, age/sex-balanced then cage allocation; p6instrument???? remains unfilled, p1 instrument names separate",
    "source_refs": [
      "A144-SUPP-1",
      "A144-SUPP-2",
      "A144-SUPP-READ"
    ],
    "protocol_bodies_modified": false
  },
  "superseded_early_reconstruction_scope": {
    "status": "partial_new_source_reconstruction_pending_full_result_panel_coverage",
    "limitations": [
      "Fig2a/b代表图24月与Fig2c定量18月分别保存；影片1说明18月雌鼠不合并为24月雄鼠。",
      "HD体积与数量为左右叶相关形态估计，不等同直接全叶逐细胞计数。",
      "FOXN1/table12稀释空值、原液单位与抗体表疑点继承并待核。",
      "没有aaTEC直接消除/阻断实验，不能把CellChat竞争解释当充分因果验证。"
    ],
    "coverage_dimensions": {
      "new_source_scoped_graph": "materialized_new_objects; full-paper result coverage still needs explicit reconciliation",
      "old_core_identity": "not_recovered",
      "fresh_visual_review": false,
      "specified_Pro_gate": "unchanged",
      "parent_review": "pending",
      "full_paper_status": "PARTIAL: no complete figure/table coverage claim",
      "historical_components_with_new_scoped_results": [
        "A144-E01",
        "A144-E02",
        "A144-E03",
        "A144-E04",
        "A144-E05",
        "A144-E06",
        "A144-E07",
        "A144-E08",
        "A144-E09",
        "A144-E10",
        "A144-E11",
        "A144-E12",
        "A144-E13"
      ],
      "historical_components_not_represented_by_new_result": [],
      "unrepresented_components_disposition": "retained as historical references; not silently counted as restored observations",
      "coverage_file": "source_to_object_coverage.json",
      "fresh_visual_scope": [
        "Main Figure5, actual asset viewed; explicit new metric review focused d/f/g/h/i/j/k"
      ],
      "fresh_visual_review_note": "Not a full-paper visual review; exact plotted values only if printed, no point digitization.",
      "actual_full_main_artwork_read": "All main figures A142 1–7, A143 1–8, A144 1–7 and Extended Data1–10 actual artwork independently viewed. Includes both corrected and original ED7. Supplements beyond extended figures remain source-unit-specific open scope.",
      "complete_supplement_scope": "Main1–7/ED1–10 andSuppFig1–2 all read;Tables11–13 and reporting all pages;129workbook directory/headers and targeted outcome rows read;5movies20frames sampled. ReferencedSuppFig3c absent in obtained currentPDF."
    },
    "disposition": "early reconstruction snapshot superseded by current_scientific_scope"
  },
  "current_scientific_scope": {
    "status": "PUBLISHED_SCIENTIFIC_SCOPE_COMPLETE_PENDING_FINAL_DELTA",
    "precedence": "current scope and remaining_scientific_scope.json supersede early snapshots; final independent receipt takes precedence over pre-delta wording",
    "formal_gate_change": false,
    "old_core_identity_recovered": false
  },
  "preserved_protocol_source": {
    "path": "ninety_paper_review_delivery_20261010/author_drafts/recent/A144/protocol_records.json",
    "sha256": "445426dfa923b29c36fc8a7561b8f9d699be9bb327ba3e46be99981e10aaea29",
    "binding": "core.protocols[].record unchanged"
  }
}
```

## 完整当前P对象（角色与限制原样保留）

```json

{
  "schema_version": "source_scoped_protocol_records-1.0",
  "paper_id": "A144",
  "title": "Age-related epithelial defects limit thymic function and regeneration",
  "doi": "10.1038/s41590-024-01915-9",
  "baseline": {
    "selected_core_files": {
      "evidence_json": {
        "path": "A144_candidate/A144_evidence.json",
        "sha256": "658294a58d5b8a55b1b33b21f74d4c6f670999e0f205826299ad1c1e30d01b4c"
      },
      "questions_json": {
        "path": "A144_candidate/A144_questions.json",
        "sha256": "b99393c48ac92ae92e066dc398692b94a9d36e014febff51e5ee91417cf3900d"
      },
      "reading_md": {
        "path": "A144_candidate/A144_reading_zh.md",
        "sha256": "f8d0aa95a2d11a2bf8e9073559ab65b50ef1209daa0cdcdfac614989abe66d08"
      }
    },
    "existing_protocol_index": "none",
    "preserved_status": {
      "state": "held_source_reviewed_candidate_pending_specified_review",
      "not_reperformed": "No new scientific acceptance/delivery/count increment",
      "core_status_fields": {
        "record_id_status": "candidate_not_accepted"
      },
      "local_review_and_scope_records": [
        "A144_candidate/README.md"
      ]
    },
    "originals_modified": false,
    "acceptance_or_count_changed": false,
    "runtime_integration": false,
    "upload_or_publication": false
  },
  "review_scope": "本轮组织透明/标记/成像/左右叶形态估计及直接流式读出已按源整理：MethodsPDF15–16，Table11全部23门控、Table12全部41材料行、Table13全部IF材料，原表4–7页目视；Fig5/6直接读出定义补核。3记录14步。组学实验/软件是独立支持来源，未扩为本轮透明流程；来源仍有未报值，不称可执行SOP。",
  "protocol_records": [
    {
      "record_id": "A144-P001",
      "record_type": "reported_clearing_workflow_with_unreported_antibody_incubations",
      "title": {
        "value": "小鼠胸腺整叶/厚片透明和免疫荧光",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec15"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "整理常规胸腺透明/标记、形态量化及流式直接步骤；转录组算法另列本轮未合并范围。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec15"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "论文既有报告鼠及年龄/损伤队列；整叶用于光片，固定后200µm片用于共聚焦",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec15"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "待固定胸腺组织",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec15"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "EasyIndex中全透明组织",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec15"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "PFA、PBS、acrylamide/azo-initiator、N2、SDS/sodiumsulfite、BSA/TritonX/normalserum、EasyIndex",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec15"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "value": "Table13免疫荧光材料，未给稀释；与流式Table12分开",
          "source_refs": [
            {
              "source_id": "F03",
              "locator": "41590_2024_1915_MOESM1_ESM.pdf p7"
            }
          ],
          "check_status": "verified_against_primary_supplement"
        }
      ],
      "sections": [
        {
          "title": "固定与厚片分支",
          "steps": [
            {
              "step_id": "A144-P001-S01",
              "display_order": 1,
              "action": {
                "value": "PBS/PFA灌流后取胸腺后固定，共聚焦分支制片。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "perfusion": {
                  "value": "PBS→4%PFA",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "postfix": {
                  "value": "4%PFA，4h，4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "confocal_sections": {
                  "value": "LeicaVT1000S，200µm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "whole_lobe": {
                  "value": "光片保留wholelobe",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "人FFPE不是此流程的适用样本；组织取得后操作不重新编谱系模型构建/损伤执行。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "水凝胶",
          "steps": [
            {
              "step_id": "A144-P001-S02",
              "display_order": 2,
              "action": {
                "value": "浸单体液，氮气除氧后聚合。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "monomer": {
                  "value": "4%acrylamide+0.25%(w/v)azo-initiator inPBS；4°Covernight",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "deoxygenation": {
                  "value": "vacuumtube，nitrogenbubble15min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "polymerization": {
                  "value": "37°C，3h，gentlerotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "azo-initiator原文未写具体VA型号，不能按其他文章改成VA044。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "透明与去SDS",
          "steps": [
            {
              "step_id": "A144-P001-S03",
              "display_order": 3,
              "action": {
                "value": "清除至半透明，再按所列顺序每轮一小时洗。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "clear": {
                  "value": "8%SDS+50mMsodiumsulfite inPBS；37°C，untilsemitransparent",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "wash1": {
                  "value": "1%SDS+0.5%TritonX/PBS，1×1h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "wash2": {
                  "value": "1%BSA+0.5%TritonX/PBS，2×1h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "wash3": {
                  "value": "4%normalserum+1%BSA+0.3%TritonX/PBS，2×1h",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "agitation": {
                  "value": "washrotation",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "清除精确时长及洗涤温度未报；不是全部5洗都继承37°C。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "免疫荧光",
          "steps": [
            {
              "step_id": "A144-P001-S04",
              "display_order": 4,
              "action": {
                "value": "在blockingbuffer中配抗体并染色，随后PBS/Triton洗。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "primaries": {
                  "value": "panCK Z0622；K5 poly19055；K8/18 TROMA1；K14 EPR17350；AIRE5H12；DCLK1LS-C100746；UEA1B-1065。",
                  "source_refs": [
                    {
                      "source_id": "F03",
                      "locator": "41590_2024_1915_MOESM1_ESM.pdf p7"
                    }
                  ],
                  "check_status": "verified_against_primary_supplement"
                },
                "secondaries": {
                  "value": "AF647donkeyantiRabbit A31573；AF647goatantiRat A-21247；AF647streptavidinS21374。",
                  "source_refs": [
                    {
                      "source_id": "F03",
                      "locator": "41590_2024_1915_MOESM1_ESM.pdf p7"
                    }
                  ],
                  "check_status": "verified_against_primary_supplement"
                },
                "diluent": {
                  "value": "4%normalserum+1%BSA+0.3%TritonX/PBS",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "afterwash": {
                  "value": "PBS+0.3%TritonX",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "Table13只有身份/供应商/目录，无稀释列；正文“dilutions indicated below”未实际提供。染色时长/温度/重复/体积也未报；不把Table12流式稀释搬来。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "匹配",
          "steps": [
            {
              "step_id": "A144-P001-S05",
              "display_order": 5,
              "action": {
                "value": "置EasyIndex至全透明后成像。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "medium": {
                  "value": "EasyIndex，RI1.46",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "condition": {
                  "value": "RT，untilfullytransparent",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec15"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "时长/体积/逐样本总处理周期未报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec15"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [],
      "reported_precedence": [
        "固定→共聚焦片或整叶分支→monomer/聚合→清除/5轮洗→染色/末洗→EasyIndex；没有来源支持的完整抗体时间表。"
      ],
      "missing_information": [
        "免疫荧光稀释、孵育时长/温度、normalserum种属、洗液体积/温度、clear与match精确时长未报。"
      ],
      "review_status": "source_checked_declared_tissue_and_direct_flow_scope;independent_review_pending"
    },
    {
      "record_id": "A144-P002",
      "record_type": "reported_imaging_and_cross_lobe_estimation",
      "title": {
        "value": "左右叶分工的胸腺采集、区域体积和TEC数量估计",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar1"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar2"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar4"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar5"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar6"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "整理常规胸腺透明/标记、形态量化及流式直接步骤；转录组算法另列本轮未合并范围。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar1"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar2"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar4"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar5"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar6"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "左叶共聚焦厚片用于density；右叶wholelobe光片用于volume；既有报告信号按源图分配",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar1"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar2"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar4"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar5"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar6"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "已处理切片与wholelobe",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar1"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar2"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar4"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar5"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar6"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "区域体积/TEC密度及右叶数量推算",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar1"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar2"
          },
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#FPar4"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar5"
          },
          {
            "source_id": "F01",
            "locator": "PDFp16 XML#FPar6"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "LSM880/Z.1、Imaris9.7.1、ImageJ2.3.0/1.53f",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar1"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar2"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar3"
            },
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#FPar4"
            }
          ],
          "check_status": "verified_against_primary_source"
        }
      ],
      "sections": [
        {
          "title": "分别采集",
          "steps": [
            {
              "step_id": "A144-P002-S01",
              "display_order": 1,
              "action": {
                "value": "按组织尺度使用对应设备/采样并处理显示。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar1"
                  },
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar2"
                  },
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar3"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "confocal": {
                  "value": "ZeissLSM880，PlanApochromat25×/0.8multi-immersion；voxelXY0.22µm/Z2µm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar1"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar2"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "lightsheet": {
                  "value": "ZeissZ.1，ECPlanNeofluar5×/0.16；XY0.915µm/Z约4.9µm；dual-side按maximumintensityfuse",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar1"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar2"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "display": {
                  "value": "Imaris9.7.1；tissuesectionROI显示10µmZprojection",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar1"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar2"
                    },
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar3"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "10µm是显示投影厚度，不是物理200µm片或2µm采集步长；激光/曝光未报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar1"
                  },
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar2"
                  },
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar3"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "区域体积",
          "steps": [
            {
              "step_id": "A144-P002-S02",
              "display_order": 2,
              "action": {
                "value": "从各信号构建表面并求皮质差值。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar4"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "total": {
                  "value": "右整叶tdTomatochannel生成lobesurface",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "medulla": {
                  "value": "GFP高密度及Krt14+，GFP+K14合并",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "HD_TEC": {
                  "value": "压紧GFP+TEC，仅GFPchannel",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "pipeline": {
                  "value": "ImageJ2.3.0/1.53f；2Dmedian→3DGaussian→2Dminmax按强度阈值binarization→extractsurface",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "cortex": {
                  "value": "total−medulla−HDvolume",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#FPar4"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "滤波核/阈值值及区域重叠处理未报；不同核报告鼠和tdTomato分配按队列，不把全部marker当单一样本。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#FPar4"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "TEC核及density",
          "steps": [
            {
              "step_id": "A144-P002-S03",
              "display_order": 3,
              "action": {
                "value": "在共聚焦厚片中Spot识别核，再依据带符号距离分类并求密度。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp16 XML#FPar5"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "detection": {
                  "value": "Imarisspot；先filtertotalTECspots",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "medullary_HD": {
                  "value": "到指定surface最短距离≤0µm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "subcapsular": {
                  "value": "到sectionedge最短距离≥−25µm（保留原不等号/符号）",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "cTEC": {
                  "value": "remaining spots",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "density": {
                  "value": "对应subsetnumber/regionvolume",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar5"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "负值符号约定/交叠优先级未充分给出，不改成无符号25µm或把切片边缘当整个器官表面。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp16 XML#FPar5"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "右叶TEC数",
          "steps": [
            {
              "step_id": "A144-P002-S04",
              "display_order": 4,
              "action": {
                "value": "以左叶厚片平均density乘右叶光片volume，得到右叶各subset核数。",
                "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp16 XML#FPar6"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "formula": {
                  "value": "meanleftlobeconfocaldensity × rightlobelightsheetvolume",
                  "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "role": {
                  "value": "跨叶推算，不是右叶逐个核直接计数",
                  "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp16 XML#FPar6"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "每个动物两叶对应/片层抽样、估计不确定性未全列。",
                "source_raw": "Quantification of TECs The number of nuclei in the various TEC subsets in the right lobe was calculated by multiplying the mean cell densities ascertained by confocal analysis of the slices from the left lobe by the volumes determined by light-sheet imaging of the right lobe.",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp16 XML#FPar6"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [],
      "reported_precedence": [
        "各叶采集→右体积/左密度独立测量→乘积估计；步骤展示不改变左右叶来源。"
      ],
      "missing_information": [
        "数值分割参数、图像质量排除、左右叶匹配和density抽样规则未完整报告。"
      ],
      "review_status": "source_checked_declared_tissue_and_direct_flow_scope;independent_review_pending"
    },
    {
      "record_id": "A144-P003",
      "record_type": "reported_flow_procedure_with_source_complete_material_and_gate_tables;unreported_conditions_retained",
      "title": {
        "value": "分离细胞、流式及KGF-pAKT独立测量",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec14"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "purpose": {
        "value": "整理常规胸腺透明/标记、形态量化及流式直接步骤；转录组算法另列本轮未合并范围。",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec14"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "applicability": {
        "value": "新鲜胸腺细胞悬液；不使用P001固定透明组织",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec14"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "start_state": {
        "value": "胸腺组织",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec14"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "end_state": {
        "value": "分选细胞或流式读出",
        "source_refs": [
          {
            "source_id": "F01",
            "locator": "PDFp15 XML#Sec14"
          }
        ],
        "check_status": "verified_against_primary_source"
      },
      "materials": [
        {
          "value": "RPMI、两种消化液、filters、CD45microbeads/LScolumns、ACK、BSA、FACS/FlowJo",
          "source_refs": [
            {
              "source_id": "F01",
              "locator": "PDFp15 XML#Sec14"
            }
          ],
          "check_status": "verified_against_primary_source"
        },
        {
          "material": {
            "value": "CD45",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=30-F11; Fluorochrome=PerCP-Cy5.5; Vendor=Biolegend; Cat#=103132; Lot#=B363634; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD45",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=30-F11; Fluorochrome=PE-CF594; Vendor=BD; Cat#=562420; Lot#=0013784; Dilution=1/300",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD45",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=30-F11; Fluorochrome=BUV615; Vendor=BD; Cat#=751170; Lot#=not reported; Dilution=1/300",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD31",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=390; Fluorochrome=PerCP-Cy5.5; Vendor=Biolegend; Cat#=102420; Lot#=B247171; Dilution=1/1300",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "TER119",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=TER-119; Fluorochrome=PerCP-Cy5.5; Vendor=Biolegend; Cat#=116228; Lot#=B356105; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "TER119",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=TER-119; Fluorochrome=BUV563; Vendor=BD; Cat#=741257; Lot#=2265032; Dilution=1/500",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "TER119",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=TER-119; Fluorochrome=PE-Cy5.5; Vendor=Invitrogen; Cat#=35-5921-82; Lot#=not reported; Dilution=1/650",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "MHCII",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=M5/114.15.2; Fluorochrome=BV421; Vendor=Biolegend; Cat#=107631; Lot#=B360795; Dilution=1/300",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "MHCII",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=M5/114.15.2; Fluorochrome=BV711; Vendor=Biolegend; Cat#=107631; Lot#=B377900; Dilution=1/400",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "MHCII",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=M5/114.15.2; Fluorochrome=APC-e780; Vendor=Invitrogen; Cat#=47-5321-82; Lot#=not reported; Dilution=1/2000",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "EpCAM",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=G8.8; Fluorochrome=APC-Cy7; Vendor=Biolegend; Cat#=118218; Lot#=B393333; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "EpCAM",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=G8.8; Fluorochrome=PerCP-e710; Vendor=Invitrogen; Cat#=46-5791-82; Lot#=4278076; Dilution=1/400",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "Ly51",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=6C3; Fluorochrome=PE-Cy7; Vendor=Biolegend; Cat#=108313; Lot#=B215053; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "Ly51",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=6C3; Fluorochrome=PE; Vendor=Invitrogen; Cat#=12-5891-83; Lot#=4300066; Dilution=1/1000",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "Ly51",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=6C3; Fluorochrome=Alexa647; Vendor=Biolegend; Cat#=108312; Lot#=B222435; Dilution=1/400",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDGFRa",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=APA5; Fluorochrome=BUV737; Vendor=BD; Cat#=741789; Lot#=3228775; Dilution=1/200",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDGFRa",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=APA5; Fluorochrome=Alexa594; Vendor=Invitrogen; Cat#=14-1401-82; Lot#=not reported; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDGFRa",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=APA5; Fluorochrome=BV750; Vendor=BD; Cat#=747220; Lot#=not reported; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDGFRb",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=APB5; Fluorochrome=SB600; Vendor=Invitrogen; Cat#=63-1402-80; Lot#=not reported; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD104",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=346-11A; Fluorochrome=PE-Cy7; Vendor=Biolegend; Cat#=123615; Lot#=B343426; Dilution=1/200",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD104",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=346-11A; Fluorochrome=BV711; Vendor=BD; Cat#=743082; Lot#=not reported; Dilution=1/150",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "L1CAM",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=555; Fluorochrome=PE; Vendor=RD system; Cat#=AAYQ0223061; Lot#=FAB5674P; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "Ly6D",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=49-H4; Fluorochrome=eFluor450; Vendor=eBio; Cat#=48-597480; Lot#=2020836; Dilution=1/200",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDPN",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=8.1.1; Fluorochrome=APC-Fire750; Vendor=Biolegend; Cat#=127425; Lot#=B313124; Dilution=1/200",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDPN",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=8.1.1; Fluorochrome=BUV805; Vendor=BD custom; Cat#=624287; Lot#=not reported; Dilution=1/650",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDPN",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=8.1.1; Fluorochrome=Purified; Vendor=Biolegend; Cat#=127402; Lot#=B219285; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "PDPN-associated secondary row",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Alexa647 in Clone column; Fluorochrome=Anti-IgG in Fluorochrome column; Vendor=Invitrogen; Cat#=A-21451; Lot#=2527971; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD26",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=H194-112; Fluorochrome=BUV737; Vendor=BD; Cat#=741729; Lot#=not reported; Dilution=1/20",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD62P",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=RB40.34; Fluorochrome=BV480; Vendor=BD; Cat#=746249; Lot#=not reported; Dilution=1/300",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD309",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Avas12a; Fluorochrome=BUV661; Vendor=BD; Cat#=741571; Lot#=not reported; Dilution=1/50",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "CD9",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=KMC8; Fluorochrome=BUV563; Vendor=BD; Cat#=741270; Lot#=not reported; Dilution=1/50",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "Claudin-3",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Polyclonal; Fluorochrome=Purified; Vendor=Invitrogen; Cat#=34-1700; Lot#=Y1376567; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "Anti-Rabbit",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Secondary; Fluorochrome=APC; Vendor=Invitrogen; Cat#=A31573; Lot#=1786284; Dilution=1/400",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "UEA1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Lectin; Fluorochrome=Fitc; Vendor=VectorLabs; Cat#=FL-1061; Lot#=ZC0426; Dilution=1/1000",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "UEA1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Lectin; Fluorochrome=Biotin; Vendor=VectorLabs; Cat#=B1065; Lot#=ZD0810; Dilution=1/200",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "UEA1-associated streptavidin row",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Lectin merged table cell; Fluorochrome=Strep-BV605; Vendor=Biolegend; Cat#=405229; Lot#=B387251; Dilution=1/1000",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "pAKT",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=Polyclonal; Fluorochrome=Pac Blue; Vendor=Cell Signaling; Cat#=68035S; Lot#=1; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "FOXN1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=2/41; Fluorochrome=Alexa647; Vendor=Gift; Cat#=N/A; Lot#=N/A; Dilution=not reported",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "DCLK1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=aa690-720; Fluorochrome=BV421; Vendor=Lsbio; Cat#=LSC100746; Lot#=134142; Dilution=1/1000",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "GP2",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=2F11-C3; Fluorochrome=Alexa594; Vendor=MBL; Cat#=D278-3; Lot#=010; Dilution=1/100",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        },
        {
          "material": {
            "value": "GFP",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "reported_specification": {
            "value": "Clone=GFP-1020; Fluorochrome=Dylight488; Vendor=Aves; Cat#=GFP-1020; Lot#=GFP3717982; Dilution=1/1000",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p6; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "table_role": "Table12实际原列抄录；不同荧光为可用材料分支，不能任意合成一个全标cocktail。"
        }
      ],
      "sections": [
        {
          "title": "分离",
          "steps": [
            {
              "step_id": "A144-P003-S01",
              "display_order": 1,
              "action": {
                "value": "机械碎化和所列酶液消化，分轮收上清并过滤离心。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "pieces": {
                  "value": "1–2mm",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "bufferA": {
                  "value": "RPMI+10%FCS+62.5µm mL−1 liberaseTM+0.4mg/mL DNaseI（µm/mL原印）",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "bufferB": {
                  "value": "RPMI+25mMHEPES+20µg/µL DNase1+1mg/mL collagenase/dispase",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "collect": {
                  "value": "incubations间取上清，100µmfilter；400g5min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "temperature": {
                  "value": "本节allsteps4°C unlessindicated",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "两种buffer为替代；消化轮次/时长缺失，异常单位不改；4°C是原文总括，消化实际特例未报。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "测序用分选",
          "steps": [
            {
              "step_id": "A144-P003-S02",
              "display_order": 2,
              "action": {
                "value": "CD45去除后红细胞裂解、表面染色并分选，重新悬液。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "CD45": {
                  "value": "antiMouseCD45microbeads，MACSLScolumn，manufacturerprotocol未读",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "RBC": {
                  "value": "ACKlysis，参数未报",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "stain": {
                  "value": "antibodycocktail15min4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "sort": {
                  "value": "BDAriaII，100µmnozzle；RPMI+2%BSA收集",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "resuspend": {
                  "value": "400g5min→PBS+0.04%BSA",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                }
              },
              "notes": {
                "value": "完整panel随目的变化；Table11/12作为材料/门控来源而非自动统一成一个cocktail。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "流式及门控",
          "steps": [
            {
              "step_id": "A144-P003-S03",
              "display_order": 3,
              "action": {
                "value": "按源表中subsets/panels读取表面/细胞内信号。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "platform": {
                  "value": "FortessaX50或SymphonyA6；FACSDiva；FlowJo",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "source_panels": {
                  "value": "完整23项Table11门控定义见本记录cases；材料与稀释见materials中Table12的41条逐行原列记录。",
                  "source_refs": [
                    {
                      "source_id": "F03",
                      "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
                    }
                  ],
                  "check_status": "verified_against_original_table_text_and_image"
                },
                "panel_boundary": {
                  "value": "Table11按figure指定门控；Table12列材料变体，但未给每个图完整荧光组合/串色补偿。不能将全部41条同时混合作单一cocktail。",
                  "source_refs": [
                    {
                      "source_id": "F03",
                      "locator": "41590_2024_1915_MOESM1_ESM.pdf p5; original table visually checked"
                    }
                  ],
                  "check_status": "verified_against_original_table_text_and_image"
                }
              },
              "notes": {
                "value": "该记录是partial，不把已存在Table12数值说成原文未报；其余门控/稀释保持source-reference待细化。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "KGF/pAKT子实验",
          "steps": [
            {
              "step_id": "A144-P003-S04",
              "display_order": 4,
              "action": {
                "value": "CD45去除细胞接受短KGF刺激，固定通透并同时染胞内/外抗原。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "verified_against_primary_source"
              },
              "parameters": {
                "KGF": {
                  "value": "recombinantmouseKGF100ng/mL，5min",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "fix": {
                  "value": "1.6%PFA，37°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "perm": {
                  "value": "90%methanol，4°C",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "wash": {
                  "value": "彻底去methanol后intracellular/extracellular同时染",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "PDFp15 XML#Sec14"
                    }
                  ],
                  "check_status": "verified_against_primary_source"
                },
                "pAKT_material": {
                  "value": "Table12 pAKT polyclonalPacificBlue，CellSignaling68035S，lot1，1/100。",
                  "source_refs": [
                    {
                      "source_id": "F03",
                      "locator": "41590_2024_1915_MOESM1_ESM.pdf p6"
                    }
                  ],
                  "check_status": "verified_against_primary_supplement"
                }
              },
              "notes": {
                "value": "固定/甲醇时长和刺激温度未特例给出，保留总括4°C来源及缺项，不补常用37°C刺激。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "PDFp15 XML#Sec14"
                  }
                ],
                "check_status": "source_scope_limited"
              },
              "legacy_P_or_row": null
            }
          ]
        },
        {
          "title": "直接流式读出",
          "steps": [
            {
              "step_id": "A144-P003-S05",
              "display_order": 5,
              "action": {
                "value": "按各图的细胞群和时间定义输出计数、恢复指数或pAKT配对MFI。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "Fig5a–d caption PDFp9"
                  }
                ],
                "check_status": "verified_against_original_figure_caption"
              },
              "parameters": {
                "Fig5b": {
                  "value": "对应时间总cellularity/同龄steady-statecellularity；细胞计数仪/完整计数方法未给。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "Fig5b caption"
                    }
                  ],
                  "check_status": "verified_against_original_figure_caption"
                },
                "Fig5d": {
                  "value": "前7天各群体恢复曲线算AUC；agingindex=agedAUC/youngAUC。具体积分算法未给。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "Fig5d caption"
                    }
                  ],
                  "check_status": "verified_against_original_figure_caption"
                },
                "Fig6e": {
                  "value": "KGF前后pAKT MFI配对，n6thymuses/individualmice，two-tailedpairedt-test；MFI的mean/median展开未给。",
                  "source_refs": [
                    {
                      "source_id": "F01",
                      "locator": "Fig6e originalimage andcaption"
                    }
                  ],
                  "check_status": "verified_against_original_figure_caption"
                }
              },
              "notes": {
                "value": "基线归一与AUC比值是不同读出；pAKT流式不赋RNA表达量或wholemount IF参数。",
                "source_refs": [
                  {
                    "source_id": "F01",
                    "locator": "Fig6e caption"
                  }
                ],
                "check_status": "verified_against_original_figure_caption"
              },
              "legacy_P_or_row": null
            }
          ]
        }
      ],
      "cases": [
        {
          "case_id": "gate_EC",
          "description": {
            "value": "EC: Live TER119− CD45− CD31+ PDGFRa−；Table11 figure scope=ExtFig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_Fibroblast",
          "description": {
            "value": "Fibroblast: Live TER119− CD45− CD31− PDGFRa+；Table11 figure scope=ExtFig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_mTEC",
          "description": {
            "value": "mTEC: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo；Table11 figure scope=ExtFig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_cTEC",
          "description": {
            "value": "cTEC: Live TER119− CD45− EpCAM+ MHCII+ UEA1lo Ly51hi；Table11 figure scope=ExtFig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_mTEC1",
          "description": {
            "value": "mTEC1: Live TER119− CD45− EpCAM+ MHCIIlo UEA1hi Ly51lo L1CAM− CD104+；Table11 figure scope=Fig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_mTEC2",
          "description": {
            "value": "mTEC2: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo L1CAM− CD104− Ly6D−；Table11 figure scope=Fig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_mTEC3",
          "description": {
            "value": "mTEC3: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo L1CAM− CD104− Ly6D+；Table11 figure scope=Fig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_TECtuft",
          "description": {
            "value": "TECtuft: Live TER119− CD45− EpCAM+ MHCII+ UEA1hi Ly51lo L1CAM+；Table11 figure scope=Fig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_DN-TEC",
          "description": {
            "value": "DN-TEC: Live TER119− CD45− EpCAM+ MHCII+ UEA1− Ly51−；Table11 figure scope=Fig1",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_aaTEC1",
          "description": {
            "value": "aaTEC1: Live TER119− CD45− PDGFRa− CD31− EpCAM+ MHCII+ UEA1− Ly51− Claudin-3+；Table11 figure scope=Fig1j/ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_aaTEC2",
          "description": {
            "value": "aaTEC2: Live TER119− CD45− EpCAM− MHCII+ PDPN+ PDGFRa−；Table11 figure scope=Fig1j/ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_capFB",
          "description": {
            "value": "capFB: Live TER119− CD45− CD31− PDGFRa+ CD26+ PDPN+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_medFB",
          "description": {
            "value": "medFB: Live TER119− CD45− CD31− PDGFRa+ CD26− PDPN+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_intFB",
          "description": {
            "value": "intFB: Live TER119− CD45− CD31− PDGFRa+ PDPN−；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_aEC",
          "description": {
            "value": "aEC: Live TER119− CD45− CD31+ PDGFRa− CD309− CD62P−；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_capEC",
          "description": {
            "value": "capEC: Live TER119− CD45− CD31+ PDGFRa− CD309+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_vEC",
          "description": {
            "value": "vEC: Live TER119− CD45− CD31+ PDGFRa− CD309− CD62P+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_Pericyte",
          "description": {
            "value": "Pericyte: Live TER119− CD45− CD31− PDGFRb+ Ly51+ CD9+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_vSMC",
          "description": {
            "value": "vSMC: Live TER119− CD45− CD31− PDGFRb+ Ly51− CD9+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_Mesothelial",
          "description": {
            "value": "Mesothelial: Live TER119− CD45− CD31− PDGFRb− CD9+ PDPN+；Table11 figure scope=ED4",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_Tuft_Cell",
          "description": {
            "value": "Tuft Cell: Live TER119− CD45− EpCAM+ UEA1hi Ly51lo GFP+ DCLK1+ Ly6Dlo/−；Table11 figure scope=ED7 Foxn1nTnG",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_Corneocyte",
          "description": {
            "value": "Corneocyte: Live TER119− CD45− EpCAM+ UEA1hi Ly51lo GFP+ DCLK1− Ly6D+；Table11 figure scope=ED7 Foxn1nTnG",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        },
        {
          "case_id": "gate_M_cell",
          "description": {
            "value": "M cell: Live TER119− CD45− EpCAM+ UEA1hi Ly51lo GFP+ GP2+ Ly6Dlo/−；Table11 figure scope=ED7 Foxn1nTnG",
            "source_refs": [
              {
                "source_id": "F03",
                "locator": "41590_2024_1915_MOESM1_ESM.pdf p4; original table visually checked"
              }
            ],
            "check_status": "verified_against_original_table_text_and_image"
          },
          "role": "marker-defined endpoint gate，未提供数字阈值/补偿/死细胞染料，不视为完整gate execution file"
        }
      ],
      "reported_precedence": [
        "组织分离→CD45去除/ACK/分选链用于测序；KGF-pAKT为另一读出支路，不将固定甲醇加入活细胞RNA分选。"
      ],
      "missing_information": [
        "分离液单位疑点、消化时程、厂家MACS具体流程与每图完整荧光组合/补偿/数字门阈值未报。",
        "FOXN1 Table12稀释为空；Table13 IF稀释也缺；流式稀释不迁移到wholemount。",
        "Table12少数列/标注疑点保留：MHCII两荧光同cat107631、L1CAM Cat#/Lot#角色可疑、PDPN二抗行列名位置及A31573流式APC/IF-AF647名称差异。"
      ],
      "review_status": "source_checked_declared_tissue_and_direct_flow_scope;independent_review_pending"
    }
  ],
  "legacy_mapping": [],
  "source_conflicts": [
    {
      "id": "A144-CF01",
      "detail": "Liberase62.5µm/mL与DNase20µg/µL按原印保留；不得猜校正单位。"
    },
    {
      "id": "A144-CF02",
      "detail": "正文称下列给IF稀释，Table13只有身份/供应商/目录，IF稀释实际未列；Table12流式稀释不能搬来。"
    },
    {
      "id": "A144-CF03",
      "detail": "Video4已有字幕18mo/d21与说明12mo/d28冲突，仍保留旧核心，不能由统一流程消除。"
    },
    {
      "id": "A144-CF04",
      "detail": "更正后ED7版本保留；本轮不将更正附录旧图当独立实验。"
    },
    {
      "id": "A144-CF05",
      "detail": "Table12全部原页复核：MHCII BV421/BV711同cat107631，L1CAM Cat=AAYQ0223061/Lot=FAB5674P，PDPN二抗行Clone=Alexa647/Fluorochrome=Anti-IgG，A31573在Table12列APC而Table13列AF647；不以厂家常識改表。"
    }
  ],
  "remaining_unreviewed": [
    "已读主文Sec16/Sec17测序制备与Sec19–Sec27组学/QC/轨迹等为本轮透明和直接影像/流式读出以外的方法来源，不扩展完整软件/组学重建；不得将其E/G/O说成由本3记录完成。",
    "人胸腺FFPE来源已明，专属脱蜡/修复/染色执行未充分；不继承鼠厚片透明。",
    "Fig4j PTN/MK蛋白定量在已读Methods/ReportingSummary未取得完整检测流程；图注只支持蛋白量比较，不能发明ELISA试剂/步骤。",
    "引用73/74细胞分离和76透明法未展开；全影片/大源工作簿/作者notebooks不在本轮重新全读或执行范围，旧源版本与Prohold保留。"
  ],
  "missing_content_register": [
    {
      "record_id": "A144-P001",
      "missing": [
        "免疫荧光稀释、孵育时长/温度、normalserum种属、洗液体积/温度、clear与match精确时长未报。"
      ]
    },
    {
      "record_id": "A144-P002",
      "missing": [
        "数值分割参数、图像质量排除、左右叶匹配和density抽样规则未完整报告。"
      ]
    },
    {
      "record_id": "A144-P003",
      "missing": [
        "分离液单位疑点、消化时程、厂家MACS具体流程与每图完整荧光组合/补偿/数字门阈值未报。",
        "FOXN1 Table12稀释为空；Table13 IF稀释也缺；流式稀释不迁移到wholemount。",
        "Table12少数列/标注疑点保留：MHCII两荧光同cat107631、L1CAM Cat#/Lot#角色可疑、PDPN二抗行列名位置及A31573流式APC/IF-AF647名称差异。"
      ]
    }
  ],
  "observation_conditions": [
    "半透明/全透明为分别清除/匹配终点，无精确天数；处理和衰老/损伤后取材时间分开。",
    "左叶density×右叶volume是估计来源，不改成wholeorgan核直接计数。"
  ],
  "evidence_links": [
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A144-E01-G01",
      "group_pointer": "/evidence_records/0/groups/0",
      "observations": [
        {
          "observation_id": "A144-E01-O01",
          "pointer": "/evidence_records/0/observations/0",
          "figure_panels": [
            "pp2–3 Fig1a–f; pp21–22 ED2–3",
            "Tables1–3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp2–3 Fig1a–f; pp21–22 ED2–3"
            },
            {
              "source_id": "F06",
              "location": "Tables1–3"
            }
          ],
          "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
        },
        {
          "observation_id": "A144-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "p3 Fig1g–k; p23 ED4",
            "p4 Table11",
            "pp5–6,9,12: markers, emergence timing and sex"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig1g–k; p23 ED4"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F05",
              "location": "pp5–6,9,12: markers, emergence timing and sex"
            }
          ],
          "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
        }
      ],
      "group_label": "2月稳态",
      "protocol_binding": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A144-E01-G02",
      "group_pointer": "/evidence_records/0/groups/1",
      "observations": [
        {
          "observation_id": "A144-E01-O01",
          "pointer": "/evidence_records/0/observations/0",
          "figure_panels": [
            "pp2–3 Fig1a–f; pp21–22 ED2–3",
            "Tables1–3"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp2–3 Fig1a–f; pp21–22 ED2–3"
            },
            {
              "source_id": "F06",
              "location": "Tables1–3"
            }
          ],
          "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
        },
        {
          "observation_id": "A144-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "p3 Fig1g–k; p23 ED4",
            "p4 Table11",
            "pp5–6,9,12: markers, emergence timing and sex"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig1g–k; p23 ED4"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F05",
              "location": "pp5–6,9,12: markers, emergence timing and sex"
            }
          ],
          "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
        }
      ],
      "group_label": "18月稳态",
      "protocol_binding": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E01",
      "evidence_pointer": "/evidence_records/0",
      "group_id": "A144-E01-G03",
      "group_pointer": "/evidence_records/0/groups/2",
      "observations": [
        {
          "observation_id": "A144-E01-O02",
          "pointer": "/evidence_records/0/observations/1",
          "figure_panels": [
            "p3 Fig1g–k; p23 ED4",
            "p4 Table11",
            "pp5–6,9,12: markers, emergence timing and sex"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p3 Fig1g–k; p23 ED4"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F05",
              "location": "pp5–6,9,12: markers, emergence timing and sex"
            }
          ],
          "scope_guard": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。"
        }
      ],
      "group_label": "2/12/18月aaTEC计数及生命期DN-TEC",
      "protocol_binding": "O01组学范围外来源；O02才是P003/Table11流式子群门控/计数。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A144-E02-G01",
      "group_pointer": "/evidence_records/1/groups/0",
      "observations": [
        {
          "observation_id": "A144-E02-O01",
          "pointer": "/evidence_records/1/observations/0",
          "figure_panels": [
            "p4 Fig2a,b; pp15–16,18",
            "Video1 9个分布抽帧"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2a,b; pp15–16,18"
            },
            {
              "source_id": "F07",
              "location": "Video1 9个分布抽帧"
            }
          ],
          "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
        },
        {
          "observation_id": "A144-E02-O02",
          "pointer": "/evidence_records/1/observations/1",
          "figure_panels": [
            "p4 Fig2c actual panel; pp15–16 image quantification"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2c actual panel; pp15–16 image quantification"
            }
          ],
          "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
        }
      ],
      "group_label": "年轻2月",
      "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E02",
      "evidence_pointer": "/evidence_records/1",
      "group_id": "A144-E02-G02",
      "group_pointer": "/evidence_records/1/groups/1",
      "observations": [
        {
          "observation_id": "A144-E02-O01",
          "pointer": "/evidence_records/1/observations/0",
          "figure_panels": [
            "p4 Fig2a,b; pp15–16,18",
            "Video1 9个分布抽帧"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2a,b; pp15–16,18"
            },
            {
              "source_id": "F07",
              "location": "Video1 9个分布抽帧"
            }
          ],
          "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
        },
        {
          "observation_id": "A144-E02-O02",
          "pointer": "/evidence_records/1/observations/1",
          "figure_panels": [
            "p4 Fig2c actual panel; pp15–16 image quantification"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2c actual panel; pp15–16 image quantification"
            }
          ],
          "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
        }
      ],
      "group_label": "衰老代表图24月、定量18月",
      "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A144-E03-G01",
      "group_pointer": "/evidence_records/2/groups/0",
      "observations": [
        {
          "observation_id": "A144-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "p4 Fig2d–f; p18; ED5",
            "Table 3 - top 20 (visium) C3:W4",
            "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2d–f; p18; ED5"
            },
            {
              "source_id": "F06",
              "location": "Table 3 - top 20 (visium) C3:W4"
            },
            {
              "source_id": "F05",
              "location": "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
            }
          ],
          "scope_guard": "Visium/组学来源；不继承P001鼠透明或P002采样。"
        }
      ],
      "group_label": "2月Visium",
      "protocol_binding": "Visium/组学来源；不继承P001鼠透明或P002采样。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A144-E03-G02",
      "group_pointer": "/evidence_records/2/groups/1",
      "observations": [
        {
          "observation_id": "A144-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "p4 Fig2d–f; p18; ED5",
            "Table 3 - top 20 (visium) C3:W4",
            "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2d–f; p18; ED5"
            },
            {
              "source_id": "F06",
              "location": "Table 3 - top 20 (visium) C3:W4"
            },
            {
              "source_id": "F05",
              "location": "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
            }
          ],
          "scope_guard": "Visium/组学来源；不继承P001鼠透明或P002采样。"
        }
      ],
      "group_label": "18月Visium",
      "protocol_binding": "Visium/组学来源；不继承P001鼠透明或P002采样。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E03",
      "evidence_pointer": "/evidence_records/2",
      "group_id": "A144-E03-G03",
      "group_pointer": "/evidence_records/2/groups/2",
      "observations": [
        {
          "observation_id": "A144-E03-O01",
          "pointer": "/evidence_records/2/observations/0",
          "figure_panels": [
            "p4 Fig2d–f; p18; ED5",
            "Table 3 - top 20 (visium) C3:W4",
            "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p4 Fig2d–f; p18; ED5"
            },
            {
              "source_id": "F06",
              "location": "Table 3 - top 20 (visium) C3:W4"
            },
            {
              "source_id": "F05",
              "location": "pp5,9,11: marker validation and failed aaTEC2 imaging discrimination"
            }
          ],
          "scope_guard": "P001/P002仅G03的HD区免疫图；Visium及signature为独立范围外来源。"
        }
      ],
      "group_label": "12–18月HD区免疫图",
      "protocol_binding": "P001/P002仅G03的HD区免疫图；Visium及signature为独立范围外来源。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A144-E04-G01",
      "group_pointer": "/evidence_records/3/groups/0",
      "observations": [
        {
          "observation_id": "A144-E04-O01",
          "pointer": "/evidence_records/3/observations/0",
          "figure_panels": [
            "p5 Fig3a–e; ED5a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3a–e; ED5a"
            }
          ],
          "scope_guard": "P001/P002报告鼠影像；无新模型构建操作。"
        }
      ],
      "group_label": "年轻报告小鼠",
      "protocol_binding": "P001/P002报告鼠影像；无新模型构建操作。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A144-E04-G02",
      "group_pointer": "/evidence_records/3/groups/1",
      "observations": [
        {
          "observation_id": "A144-E04-O01",
          "pointer": "/evidence_records/3/observations/0",
          "figure_panels": [
            "p5 Fig3a–e; ED5a"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3a–e; ED5a"
            }
          ],
          "scope_guard": "P001/P002报告鼠影像；无新模型构建操作。"
        }
      ],
      "group_label": "衰老Foxn1nTnG与Foxn1tdTom",
      "protocol_binding": "P001/P002报告鼠影像；无新模型构建操作。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A144-E04-G03",
      "group_pointer": "/evidence_records/3/groups/2",
      "observations": [
        {
          "observation_id": "A144-E04-O02",
          "pointer": "/evidence_records/3/observations/1",
          "figure_panels": [
            "p5 Fig3f,g; pp11–12 Discussion",
            "Video2a分布抽帧",
            "Video2b分布抽帧",
            "pp6–7,9: lineage inference and alternative fate"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3f,g; pp11–12 Discussion"
            },
            {
              "source_id": "F08",
              "location": "Video2a分布抽帧"
            },
            {
              "source_id": "F09",
              "location": "Video2b分布抽帧"
            },
            {
              "source_id": "F05",
              "location": "pp6–7,9: lineage inference and alternative fate"
            }
          ],
          "scope_guard": "RNAvelocity计算推断来源，不当实时显微或P001处理。"
        }
      ],
      "group_label": "2月WT TEC计算轨迹",
      "protocol_binding": "RNAvelocity计算推断来源，不当实时显微或P001处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E04",
      "evidence_pointer": "/evidence_records/3",
      "group_id": "A144-E04-G04",
      "group_pointer": "/evidence_records/3/groups/3",
      "observations": [
        {
          "observation_id": "A144-E04-O02",
          "pointer": "/evidence_records/3/observations/1",
          "figure_panels": [
            "p5 Fig3f,g; pp11–12 Discussion",
            "Video2a分布抽帧",
            "Video2b分布抽帧",
            "pp6–7,9: lineage inference and alternative fate"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3f,g; pp11–12 Discussion"
            },
            {
              "source_id": "F08",
              "location": "Video2a分布抽帧"
            },
            {
              "source_id": "F09",
              "location": "Video2b分布抽帧"
            },
            {
              "source_id": "F05",
              "location": "pp6–7,9: lineage inference and alternative fate"
            }
          ],
          "scope_guard": "RNAvelocity计算推断来源，不当实时显微或P001处理。"
        }
      ],
      "group_label": "18月WT TEC计算轨迹",
      "protocol_binding": "RNAvelocity计算推断来源，不当实时显微或P001处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A144-E05-G01",
      "group_pointer": "/evidence_records/4/groups/0",
      "observations": [
        {
          "observation_id": "A144-E05-O01",
          "pointer": "/evidence_records/4/observations/0",
          "figure_panels": [
            "p5 Fig3h,i; ED5b; p18",
            "Video3 9个分布抽帧"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3h,i; ED5b; p18"
            },
            {
              "source_id": "F10",
              "location": "Video3 9个分布抽帧"
            }
          ],
          "scope_guard": "P001/P002老鼠影像。"
        }
      ],
      "group_label": "衰老鼠aaTEC相关区域",
      "protocol_binding": "P001/P002老鼠影像。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A144-E05-G02",
      "group_pointer": "/evidence_records/4/groups/1",
      "observations": [
        {
          "observation_id": "A144-E05-O02",
          "pointer": "/evidence_records/4/observations/1",
          "figure_panels": [
            "p5 Fig3j,k; ED5d–f",
            "p7 marker catalog not human-specific",
            "p4",
            "Table 3 - top 20 (human TEC) D25:W26"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3j,k; ED5d–f"
            },
            {
              "source_id": "F03",
              "location": "p7 marker catalog not human-specific"
            },
            {
              "source_id": "F04",
              "location": "p4"
            },
            {
              "source_id": "F06",
              "location": "Table 3 - top 20 (human TEC) D25:W26"
            }
          ],
          "scope_guard": "人FFPE独立部分方法来源，参数不足，绝不继承鼠P001/P002。"
        }
      ],
      "group_label": "50岁人胸腺连续切片",
      "protocol_binding": "人FFPE独立部分方法来源，参数不足，绝不继承鼠P001/P002。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E05",
      "evidence_pointer": "/evidence_records/4",
      "group_id": "A144-E05-G03",
      "group_pointer": "/evidence_records/4/groups/2",
      "observations": [
        {
          "observation_id": "A144-E05-O02",
          "pointer": "/evidence_records/4/observations/1",
          "figure_panels": [
            "p5 Fig3j,k; ED5d–f",
            "p7 marker catalog not human-specific",
            "p4",
            "Table 3 - top 20 (human TEC) D25:W26"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p5 Fig3j,k; ED5d–f"
            },
            {
              "source_id": "F03",
              "location": "p7 marker catalog not human-specific"
            },
            {
              "source_id": "F04",
              "location": "p4"
            },
            {
              "source_id": "F06",
              "location": "Table 3 - top 20 (human TEC) D25:W26"
            }
          ],
          "scope_guard": "人公开scRNA数据独立来源。"
        }
      ],
      "group_label": "既有人体TEC转录数据",
      "protocol_binding": "人公开scRNA数据独立来源。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E06",
      "evidence_pointer": "/evidence_records/5",
      "group_id": "A144-E06-G01",
      "group_pointer": "/evidence_records/5/groups/0",
      "observations": [
        {
          "observation_id": "A144-E06-O01",
          "pointer": "/evidence_records/5/observations/0",
          "figure_panels": [
            "pp6–8 Fig4a; p26 ED6",
            "Tables4–5; Table4-cTEC specified rows in QT01"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp6–8 Fig4a; p26 ED6"
            },
            {
              "source_id": "F06",
              "location": "Tables4–5; Table4-cTEC specified rows in QT01"
            }
          ],
          "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
        }
      ],
      "group_label": "2月同亚群",
      "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E06",
      "evidence_pointer": "/evidence_records/5",
      "group_id": "A144-E06-G02",
      "group_pointer": "/evidence_records/5/groups/1",
      "observations": [
        {
          "observation_id": "A144-E06-O01",
          "pointer": "/evidence_records/5/observations/0",
          "figure_panels": [
            "pp6–8 Fig4a; p26 ED6",
            "Tables4–5; Table4-cTEC specified rows in QT01"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp6–8 Fig4a; p26 ED6"
            },
            {
              "source_id": "F06",
              "location": "Tables4–5; Table4-cTEC specified rows in QT01"
            }
          ],
          "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
        }
      ],
      "group_label": "18月同亚群",
      "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G01",
      "group_pointer": "/evidence_records/6/groups/0",
      "observations": [
        {
          "observation_id": "A144-E07-O01",
          "pointer": "/evidence_records/6/observations/0",
          "figure_panels": [
            "p7 Fig4b",
            "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p7 Fig4b"
            },
            {
              "source_id": "F06",
              "location": "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        },
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        }
      ],
      "group_label": "衰老aaTEC1",
      "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G02",
      "group_pointer": "/evidence_records/6/groups/1",
      "observations": [
        {
          "observation_id": "A144-E07-O01",
          "pointer": "/evidence_records/6/observations/0",
          "figure_panels": [
            "p7 Fig4b",
            "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p7 Fig4b"
            },
            {
              "source_id": "F06",
              "location": "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        },
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        }
      ],
      "group_label": "衰老aaTEC2",
      "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G03",
      "group_pointer": "/evidence_records/6/groups/2",
      "observations": [
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        }
      ],
      "group_label": "Cdh1/Vim等pEMT表达比较中的其他TEC与medFB",
      "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G04",
      "group_pointer": "/evidence_records/6/groups/3",
      "observations": [
        {
          "observation_id": "A144-E07-O01",
          "pointer": "/evidence_records/6/observations/0",
          "figure_panels": [
            "p7 Fig4b",
            "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p7 Fig4b"
            },
            {
              "source_id": "F06",
              "location": "6-GOBP_AP&P_OF_PEPTIDE_ANTIGEN!B7:B11, B20:B87, F68:F87; Table 6 - HALLMARK_EMT!B7:B11, B20:B212, F20:F128"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        },
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "组学/基因表达来源，不继承流式门控或IF处理。"
        }
      ],
      "group_label": "GSEA及TEC功能表达比较中的其他TEC（不含medFB）",
      "protocol_binding": "组学/基因表达来源，不继承流式门控或IF处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G05",
      "group_pointer": "/evidence_records/6/groups/4",
      "observations": [
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。"
        }
      ],
      "group_label": "2月Foxn1nTnG mimetic细胞流式",
      "protocol_binding": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G06",
      "group_pointer": "/evidence_records/6/groups/5",
      "observations": [
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。"
        }
      ],
      "group_label": "18月Foxn1nTnG mimetic与DN-TEC流式",
      "protocol_binding": "P003/Table11mimeticgates/Table12流式材料；更正后ED7范围。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E07",
      "evidence_pointer": "/evidence_records/6",
      "group_id": "A144-E07-G07",
      "group_pointer": "/evidence_records/6/groups/6",
      "observations": [
        {
          "observation_id": "A144-E07-O02",
          "pointer": "/evidence_records/6/observations/1",
          "figure_panels": [
            "pp7–8 Fig4c–g; pp27–30 ED7–8",
            "p4 Table11",
            "p1; ED7a correction",
            "p2; original figure version only",
            "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4c–g; pp27–30 ED7–8"
            },
            {
              "source_id": "F03",
              "location": "p4 Table11"
            },
            {
              "source_id": "F12",
              "location": "p1; ED7a correction"
            },
            {
              "source_id": "F13",
              "location": "p2; original figure version only"
            },
            {
              "source_id": "F16",
              "location": "zero-based cells12–32; MAGIC-processed heatmap/scatter and cached output"
            }
          ],
          "scope_guard": "P001/P002仅HD区免疫图。"
        }
      ],
      "group_label": "12月Foxn1nTnG HD区免疫成像",
      "protocol_binding": "P001/P002仅HD区免疫图。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E08",
      "evidence_pointer": "/evidence_records/7",
      "group_id": "A144-E08-G01",
      "group_pointer": "/evidence_records/7/groups/0",
      "observations": [
        {
          "observation_id": "A144-E08-O01",
          "pointer": "/evidence_records/7/observations/0",
          "figure_panels": [
            "pp7–8 Fig4h,i; p29 ED8b; p17"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4h,i; p29 ED8b; p17"
            }
          ],
          "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
        },
        {
          "observation_id": "A144-E08-O02",
          "pointer": "/evidence_records/7/observations/1",
          "figure_panels": [
            "p7 Fig4j actual graphs; p8 legend"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p7 Fig4j actual graphs; p8 legend"
            }
          ],
          "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
        }
      ],
      "group_label": "2月",
      "protocol_binding": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E08",
      "evidence_pointer": "/evidence_records/7",
      "group_id": "A144-E08-G02",
      "group_pointer": "/evidence_records/7/groups/1",
      "observations": [
        {
          "observation_id": "A144-E08-O02",
          "pointer": "/evidence_records/7/observations/1",
          "figure_panels": [
            "p7 Fig4j actual graphs; p8 legend"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p7 Fig4j actual graphs; p8 legend"
            }
          ],
          "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
        }
      ],
      "group_label": "12月",
      "protocol_binding": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E08",
      "evidence_pointer": "/evidence_records/7",
      "group_id": "A144-E08-G03",
      "group_pointer": "/evidence_records/7/groups/2",
      "observations": [
        {
          "observation_id": "A144-E08-O01",
          "pointer": "/evidence_records/7/observations/0",
          "figure_panels": [
            "pp7–8 Fig4h,i; p29 ED8b; p17"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp7–8 Fig4h,i; p29 ED8b; p17"
            }
          ],
          "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
        },
        {
          "observation_id": "A144-E08-O02",
          "pointer": "/evidence_records/7/observations/1",
          "figure_panels": [
            "p7 Fig4j actual graphs; p8 legend"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p7 Fig4j actual graphs; p8 legend"
            }
          ],
          "scope_guard": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。"
        }
      ],
      "group_label": "18月",
      "protocol_binding": "O01CellChat独立来源；O02蛋白量PTN/MK检测流程未报，不被P003pAKT覆盖。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E09",
      "evidence_pointer": "/evidence_records/8",
      "group_id": "A144-E09-G01",
      "group_pointer": "/evidence_records/8/groups/0",
      "observations": [
        {
          "observation_id": "A144-E09-O01",
          "pointer": "/evidence_records/8/observations/0",
          "figure_panels": [
            "pp8–9 Fig5a,b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp8–9 Fig5a,b"
            }
          ],
          "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
        },
        {
          "observation_id": "A144-E09-O02",
          "pointer": "/evidence_records/8/observations/1",
          "figure_panels": [
            "p9 Fig5c,d; p31 ED9"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p9 Fig5c,d; p31 ED9"
            }
          ],
          "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
        }
      ],
      "group_label": "年轻1–2/2月",
      "protocol_binding": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E09",
      "evidence_pointer": "/evidence_records/8",
      "group_id": "A144-E09-G02",
      "group_pointer": "/evidence_records/8/groups/1",
      "observations": [
        {
          "observation_id": "A144-E09-O01",
          "pointer": "/evidence_records/8/observations/0",
          "figure_panels": [
            "pp8–9 Fig5a,b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp8–9 Fig5a,b"
            }
          ],
          "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
        },
        {
          "observation_id": "A144-E09-O02",
          "pointer": "/evidence_records/8/observations/1",
          "figure_panels": [
            "p9 Fig5c,d; p31 ED9"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p9 Fig5c,d; p31 ED9"
            }
          ],
          "scope_guard": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。"
        }
      ],
      "group_label": "衰老18/18+月",
      "protocol_binding": "P003flowpopulation/AUC读出；totalcellularity计数方法部分未报。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E10",
      "evidence_pointer": "/evidence_records/9",
      "group_id": "A144-E10-G01",
      "group_pointer": "/evidence_records/9/groups/0",
      "observations": [
        {
          "observation_id": "A144-E10-O01",
          "pointer": "/evidence_records/9/observations/0",
          "figure_panels": [
            "p9 Fig5e,f; p16",
            "p11: Fig5e–f age/time clarification",
            "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)",
            "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p9 Fig5e,f; p16"
            },
            {
              "source_id": "F05",
              "location": "p11: Fig5e–f age/time clarification"
            },
            {
              "source_id": "F11",
              "location": "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)"
            },
            {
              "source_id": "F02",
              "location": "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
            }
          ],
          "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
        }
      ],
      "group_label": "12月稳态",
      "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E10",
      "evidence_pointer": "/evidence_records/9",
      "group_id": "A144-E10-G02",
      "group_pointer": "/evidence_records/9/groups/1",
      "observations": [
        {
          "observation_id": "A144-E10-O01",
          "pointer": "/evidence_records/9/observations/0",
          "figure_panels": [
            "p9 Fig5e,f; p16",
            "p11: Fig5e–f age/time clarification",
            "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)",
            "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p9 Fig5e,f; p16"
            },
            {
              "source_id": "F05",
              "location": "p11: Fig5e–f age/time clarification"
            },
            {
              "source_id": "F11",
              "location": "Video4 sampled frames: 4.17s (18mo untreated), 20.85s (18mo d21)"
            },
            {
              "source_id": "F02",
              "location": "Supplementary Video4 description: 12mo/28d and residual Fig3e reference"
            }
          ],
          "scope_guard": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。"
        }
      ],
      "group_label": "12月损伤后28日",
      "protocol_binding": "P001/P002鼠wholelobe/section及左右叶估计；年龄/时间按本G/O，不改变Video4冲突。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E11",
      "evidence_pointer": "/evidence_records/10",
      "group_id": "A144-E11-G01",
      "group_pointer": "/evidence_records/10/groups/0",
      "observations": [
        {
          "observation_id": "A144-E11-O01",
          "pointer": "/evidence_records/10/observations/0",
          "figure_panels": [
            "pp8–9 Fig5g–k; pp16–18; ED10a",
            "p2 FigS1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp8–9 Fig5g–k; pp16–18; ED10a"
            },
            {
              "source_id": "F03",
              "location": "p2 FigS1"
            }
          ],
          "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
        }
      ],
      "group_label": "2月不同时间",
      "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E11",
      "evidence_pointer": "/evidence_records/10",
      "group_id": "A144-E11-G02",
      "group_pointer": "/evidence_records/10/groups/1",
      "observations": [
        {
          "observation_id": "A144-E11-O01",
          "pointer": "/evidence_records/10/observations/0",
          "figure_panels": [
            "pp8–9 Fig5g–k; pp16–18; ED10a",
            "p2 FigS1"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp8–9 Fig5g–k; pp16–18; ED10a"
            },
            {
              "source_id": "F03",
              "location": "p2 FigS1"
            }
          ],
          "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
        }
      ],
      "group_label": "18月不同时间",
      "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E11",
      "evidence_pointer": "/evidence_records/10",
      "group_id": "A144-E11-G03",
      "group_pointer": "/evidence_records/10/groups/2",
      "observations": [
        {
          "observation_id": "A144-E11-O02",
          "pointer": "/evidence_records/10/observations/1",
          "figure_panels": [
            "p3 FigS2 actual plot",
            "p18 bulk comparison"
          ],
          "source_refs": [
            {
              "source_id": "F03",
              "location": "p3 FigS2 actual plot"
            },
            {
              "source_id": "F01",
              "location": "p18 bulk comparison"
            }
          ],
          "scope_guard": "独立组学或bulk验证来源；本轮不扩完整分析协议。"
        }
      ],
      "group_label": "bulk/scRNA总体表达验证，年龄映射未单列",
      "protocol_binding": "独立组学或bulk验证来源；本轮不扩完整分析协议。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E12",
      "evidence_pointer": "/evidence_records/11",
      "group_id": "A144-E12-G01",
      "group_pointer": "/evidence_records/11/groups/0",
      "observations": [
        {
          "observation_id": "A144-E12-O01",
          "pointer": "/evidence_records/11/observations/0",
          "figure_panels": [
            "p10 Fig6a,b",
            "Tables7–10 specific rows in QT02",
            "notebook14 zero-based cells12,14,17,19: field export and contrasts"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p10 Fig6a,b"
            },
            {
              "source_id": "F06",
              "location": "Tables7–10 specific rows in QT02"
            },
            {
              "source_id": "F15",
              "location": "notebook14 zero-based cells12,14,17,19: field export and contrasts"
            }
          ],
          "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
        }
      ],
      "group_label": "2月损伤后4/7日相对1日",
      "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E12",
      "evidence_pointer": "/evidence_records/11",
      "group_id": "A144-E12-G02",
      "group_pointer": "/evidence_records/11/groups/1",
      "observations": [
        {
          "observation_id": "A144-E12-O01",
          "pointer": "/evidence_records/11/observations/0",
          "figure_panels": [
            "p10 Fig6a,b",
            "Tables7–10 specific rows in QT02",
            "notebook14 zero-based cells12,14,17,19: field export and contrasts"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p10 Fig6a,b"
            },
            {
              "source_id": "F06",
              "location": "Tables7–10 specific rows in QT02"
            },
            {
              "source_id": "F15",
              "location": "notebook14 zero-based cells12,14,17,19: field export and contrasts"
            }
          ],
          "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
        }
      ],
      "group_label": "18月损伤后4/7日相对1日",
      "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E12",
      "evidence_pointer": "/evidence_records/11",
      "group_id": "A144-E12-G03",
      "group_pointer": "/evidence_records/11/groups/2",
      "observations": [
        {
          "observation_id": "A144-E12-O02",
          "pointer": "/evidence_records/11/observations/1",
          "figure_panels": [
            "p10 Fig6c–e",
            "p10: growth-factor response versus inferred competition"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p10 Fig6c–e"
            },
            {
              "source_id": "F05",
              "location": "p10: growth-factor response versus inferred competition"
            }
          ],
          "scope_guard": "P003S04/S05 KGF/pAKT直接流式，pairedindividualthymi。"
        }
      ],
      "group_label": "18月各亚群响应前后配对",
      "protocol_binding": "P003S04/S05 KGF/pAKT直接流式，pairedindividualthymi。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E12",
      "evidence_pointer": "/evidence_records/11",
      "group_id": "A144-E12-G04",
      "group_pointer": "/evidence_records/11/groups/3",
      "observations": [
        {
          "observation_id": "A144-E12-O02",
          "pointer": "/evidence_records/11/observations/1",
          "figure_panels": [
            "p10 Fig6c–e",
            "p10: growth-factor response versus inferred competition"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p10 Fig6c–e"
            },
            {
              "source_id": "F05",
              "location": "p10: growth-factor response versus inferred competition"
            }
          ],
          "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
        }
      ],
      "group_label": "2月WT CellChat基线与第7日",
      "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E12",
      "evidence_pointer": "/evidence_records/11",
      "group_id": "A144-E12-G05",
      "group_pointer": "/evidence_records/11/groups/4",
      "observations": [
        {
          "observation_id": "A144-E12-O02",
          "pointer": "/evidence_records/11/observations/1",
          "figure_panels": [
            "p10 Fig6c–e",
            "p10: growth-factor response versus inferred competition"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "p10 Fig6c–e"
            },
            {
              "source_id": "F05",
              "location": "p10: growth-factor response versus inferred competition"
            }
          ],
          "scope_guard": "差异表达/CellChat独立来源，不赋pAKT处理。"
        }
      ],
      "group_label": "18月WT CellChat基线与第7日",
      "protocol_binding": "差异表达/CellChat独立来源，不赋pAKT处理。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E13",
      "evidence_pointer": "/evidence_records/12",
      "group_id": "A144-E13-G01",
      "group_pointer": "/evidence_records/12/groups/0",
      "observations": [
        {
          "observation_id": "A144-E13-O01",
          "pointer": "/evidence_records/12/observations/0",
          "figure_panels": [
            "pp10–12 Fig7; ED10b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp10–12 Fig7; ED10b"
            }
          ],
          "scope_guard": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。"
        }
      ],
      "group_label": "衰老TEC各状态",
      "protocol_binding": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E13",
      "evidence_pointer": "/evidence_records/12",
      "group_id": "A144-E13-G02",
      "group_pointer": "/evidence_records/12/groups/1",
      "observations": [
        {
          "observation_id": "A144-E13-O01",
          "pointer": "/evidence_records/12/observations/0",
          "figure_panels": [
            "pp10–12 Fig7; ED10b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp10–12 Fig7; ED10b"
            }
          ],
          "scope_guard": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。"
        }
      ],
      "group_label": "6月Foxn1低功能与对照",
      "protocol_binding": "FOXN1表达/计算/既有突变测序来源，不由本影像流程覆盖。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    },
    {
      "core_path": "A144_candidate/A144_evidence.json",
      "evidence_id": "A144-E13",
      "evidence_pointer": "/evidence_records/12",
      "group_id": "A144-E13-G03",
      "group_pointer": "/evidence_records/12/groups/2",
      "observations": [
        {
          "observation_id": "A144-E13-O01",
          "pointer": "/evidence_records/12/observations/0",
          "figure_panels": [
            "pp10–12 Fig7; ED10b"
          ],
          "source_refs": [
            {
              "source_id": "F01",
              "location": "pp10–12 Fig7; ED10b"
            }
          ],
          "scope_guard": "P003FOXN1流式；Table12FOXN1稀释未报。"
        }
      ],
      "group_label": "2/18+月Fig7a FOXN1蛋白流式",
      "protocol_binding": "P003FOXN1流式；Table12FOXN1稀释未报。",
      "binding_basis": "每O的既有sample/signal/原始source保留；不同模态只部分方法关联，不声明paper-widecomplete。"
    }
  ],
  "sources": [
    {
      "source_id": "F01",
      "path": "candidate_research_next_20261007b/PMC11362016/originals/PMC11362016.1.pdf",
      "sha256": "5c2b75371a1dbd25250b6124b195b2c4480371ce96908c5d6b60668bea310a17",
      "this_round_read": "Methods15–16source;selectedvisual"
    },
    {
      "source_id": "F02",
      "path": "candidate_research_next_20261007b/PMC11362016/originals/PMC11362016.1.xml",
      "sha256": "04f41f5c67206b19da669f6ffe69f18751ef192687957c79263c5763d9b2252d",
      "this_round_read": "Sec13–17/FPar1–6text"
    },
    {
      "source_id": "F03",
      "path": "candidate_research_next_20261007b/PMC11362016/originals/41590_2024_1915_MOESM1_ESM.pdf",
      "sha256": "0646ac1b2f9dab5e621b74ecfb53a90a6813e8220587e165cb0a604260978da3",
      "this_round_read": "Table11all23gates;Table12all41materialrows;Table13allIF;PDFpp4–7visual"
    }
  ],
  "review_status": {
    "content": "source_checked_declared_tissue_and_direct_flow_scope_saved;unreported_gaps_retained",
    "independent_audit": "notperformed_for_currentrevision",
    "integration": "pending",
    "specified_Pro": "unchanged_hold",
    "actual_execution": "notperformed"
  },
  "source_field_check_count": 206,
  "out_of_scope_source_references": [
    {
      "scope": "RNA-seq/Visium/library and independent computational analyses",
      "source": "F01 Sec16–27",
      "relationship": "supporting_experiments_separate_from_tissue_and_direct_flow_protocols",
      "not_claimed_reconstructed": true
    }
  ]
}
```

## 当前问题对象（非expert gold）

```json

[
  {
    "question_id": "A144-R20261012-GQ01a",
    "question": "年龄相关细胞亚群改变：实际观察到了什么？",
    "answer": [
      "2月/18月单细胞比较中老龄出现aaTEC1/2及early-prog增加；此设计不定位首次出现年龄。独立年龄流式显示aaTEC在12月已增多。基质各亚群频率/数量变化异质，详见新增主Fig1及ED1/4端点。",
      "单细胞集22932个CD45−细胞是细胞数，不是动物n；与流式计数分开。 ED2 FB13240/EC1661/TEC6175，ED3整合297988/上皮205625，均为注释数据细胞数。",
      "Fig1g每年龄n10：老龄cTEC↑P=.01，mTEC1/2/3及tuft↓P=.001/.0001/.0001/.0001，DN-TEC↑.003。细分门控与ED1宽门控不能混成同一cTEC结论；Fig1f另为scaled频率变化，不当绝对数。",
      "Fig1j/k 2/12/18月各年龄合并男女总n依次15/10/13，图以符号区分性别，aaTEC1/2在12月已增加。计数和Frequency(10^-5)为不同纵轴，不改作百分比；比较仅2vs12与2vs18，没有12vs18检验。",
      "ED1总细胞数对2月：6月NS、9月P=.03、12月.0004、19月+<.0001；皮质/髓质比对2月：6月NS、9月.004、12月NS、19月+.001。宽门控EC12月↑.002，mTEC对2月在6/9/12/19月+均下降<.0001；cTEC/FB未标比较，不能从无星称NS。不同年龄标签/量化图与代表切片保持各自范围。",
      "ED4a–c每年龄n10：medFB老龄↑P<.0001；capsFB/intFB NS；aEC/capEC/vEC全NS；PC↑.0007、vSMC↑.003、MEC NS。d独立DN-TEC计数2vs12月.03、2vs18月+.01，2/6/9/12/18月+n14/5/15/5/18，勿借a–c n。"
    ],
    "result_ids": [
      "A144-R20261012-O01",
      "A144-R20261012-O02",
      "A144-R20261012-O41",
      "A144-R20261012-O42",
      "A144-R20261012-O45",
      "A144-R20261012-O46"
    ],
    "group_ids": [
      "A144-R20261012-G01",
      "A144-R20261012-G02",
      "A144-R20261012-G03",
      "A144-R20261012-G39",
      "A144-R20261012-G46",
      "A144-R20261012-G47",
      "A144-R20261012-G48",
      "A144-R20261012-G51",
      "A144-R20261012-G52"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ01b",
    "question": "年龄相关细胞亚群改变：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅直接流式门控计数；scRNA独立来源",
          "sample_class_id": "A144-R20261012-G01"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "仅直接流式门控计数；scRNA独立来源",
          "sample_class_id": "A144-R20261012-G02"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "仅直接流式门控计数；scRNA独立来源",
          "sample_class_id": "A144-R20261012-G03"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
          "sample_class_id": "A144-R20261012-G46"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
          "sample_class_id": "A144-R20261012-G47"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
          "sample_class_id": "A144-R20261012-G48"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
          "sample_class_id": "A144-R20261012-G52"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O01",
      "A144-R20261012-O02",
      "A144-R20261012-O41",
      "A144-R20261012-O42",
      "A144-R20261012-O45",
      "A144-R20261012-O46"
    ],
    "group_ids": [
      "A144-R20261012-G01",
      "A144-R20261012-G02",
      "A144-R20261012-G03",
      "A144-R20261012-G39",
      "A144-R20261012-G46",
      "A144-R20261012-G47",
      "A144-R20261012-G48",
      "A144-R20261012-G51",
      "A144-R20261012-G52"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ02a",
    "question": "整叶高密度TEC区域：实际观察到了什么？",
    "answer": [
      "年轻髓质互连，老年呈孤立岛及髓周高密度TEC带。 Fig2a老年代表图实际标18mo+，caption称24mo male，年龄来源范围不一致，不能强行统一。",
      "Fig2c老龄相对年轻：总体积↓P=.07、皮质体积↓.08、cTEC数量↓.07均未显著；髓质体积↓.002、mTEC数量↓.0008；HD体积↑.009、HD细胞数↑.004。n3/年龄，mean±SEM、unpaired t；不把趋势全称显著下降。"
    ],
    "result_ids": [
      "A144-R20261012-O03",
      "A144-R20261012-O04"
    ],
    "group_ids": [
      "A144-R20261012-G04",
      "A144-R20261012-G05",
      "A144-R20261012-G06"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ02b",
    "question": "整叶高密度TEC区域：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记",
          "sample_class_id": "A144-R20261012-G04"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化",
          "sample_class_id": "A144-R20261012-G04"
        },
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记",
          "sample_class_id": "A144-R20261012-G05"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化",
          "sample_class_id": "A144-R20261012-G05"
        },
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记",
          "sample_class_id": "A144-R20261012-G06"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化",
          "sample_class_id": "A144-R20261012-G06"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O03",
      "A144-R20261012-O04"
    ],
    "group_ids": [
      "A144-R20261012-G04",
      "A144-R20261012-G05",
      "A144-R20261012-G06"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ03a",
    "question": "空间转录与固定免疫对应：实际观察到了什么？",
    "answer": [
      "老年aaTEC签名聚集在髓质相关区域；HD中多K5+、部分K8+、K14−，claudin3可标记。 Workbook Table3当前aaTEC1/2 top20签名各20基因，官网补件描述top30/top10，来源定义差异保留。",
      "转录签名、流式DN-TEC和HD形态的对应为多源推断，非单一共同测量。"
    ],
    "result_ids": [
      "A144-R20261012-O05",
      "A144-R20261012-O06"
    ],
    "group_ids": [
      "A144-R20261012-G07",
      "A144-R20261012-G08"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ03b",
    "question": "空间转录与固定免疫对应：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定免疫支路",
          "sample_class_id": "A144-R20261012-G08"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应图像；Visium独立来源",
          "sample_class_id": "A144-R20261012-G08"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O05",
      "A144-R20261012-O06"
    ],
    "group_ids": [
      "A144-R20261012-G07",
      "A144-R20261012-G08"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ04a",
    "question": "既有报告体系中的TEC来源：实际观察到了什么？",
    "answer": [
      "老年GFP+出现EpCAM+ DN与EpCAM−群；claudin3和PDPN分别支持aaTEC1/2标记。",
      "RNA velocity提示mTEC1/early-prog向aaTEC方向；不是直接逐细胞纵向追踪。",
      "20月Foxn1tdTom报告TEC共1093细胞与18/20月WT7412细胞整合，所有TEC簇包括aaTEC1/2均检测tdTom转录，支持其既往Foxn1谱系来源。细胞数不是鼠n；独立scRNA分支不继承GFP流式。",
      "Fig3b claudin3+比例aaTEC>mTEC P=.03（n4鼠）；3c在GFP+EpCAM−内PDPN+比例PDGFRα−高于α+ P=.03（n4）。2月c明确No data，不能作年轻阴性。3d报告鼠aaTEC1/2老龄计数↑P=.04/.01，2月n6、18月n4，不能借Fig1k C57BL/6 n。",
      "ED5a11周体系验证近全部TEC GFP仅Foxn1报告鼠，n2–3、两实验；代表门控百分比不作总体均值。此年轻验证支路不借作Fig3d的2/18月生物n。"
    ],
    "result_ids": [
      "A144-R20261012-O07",
      "A144-R20261012-O08",
      "A144-R20261012-O27",
      "A144-R20261012-O43",
      "A144-R20261012-O50"
    ],
    "group_ids": [
      "A144-R20261012-G09",
      "A144-R20261012-G10",
      "A144-R20261012-G11",
      "A144-R20261012-G49",
      "A144-R20261012-G57"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ04b",
    "question": "既有报告体系中的TEC来源：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅流式GFP、EpCAM/claudin3/PDPN表型",
          "sample_class_id": "A144-R20261012-G09"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
          "sample_class_id": "A144-R20261012-G49"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "only named published reporter-validation flow readout; no20month transcript branch",
          "sample_class_id": "A144-R20261012-G57"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O07",
      "A144-R20261012-O08",
      "A144-R20261012-O27",
      "A144-R20261012-O43",
      "A144-R20261012-O50"
    ],
    "group_ids": [
      "A144-R20261012-G09",
      "A144-R20261012-G10",
      "A144-R20261012-G11",
      "A144-R20261012-G49",
      "A144-R20261012-G57"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ05a",
    "question": "HD区及人体参照：实际观察到了什么？",
    "answer": [
      "aaTEC富集区域缺乏胸腺细胞；人体材料见相似富上皮区域。",
      "既有人数据可见aaTEC签名；claudin3/PDPN在人组织识别的有效性仍待确认。 Fig3h–k为50岁女性连续H&E/panCK/CD1a切片；ED5人整合115536 CD45−/40144TEC均为细胞数，不是患者n。"
    ],
    "result_ids": [
      "A144-R20261012-O09",
      "A144-R20261012-O10"
    ],
    "group_ids": [
      "A144-R20261012-G12",
      "A144-R20261012-G13",
      "A144-R20261012-G14"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ05b",
    "question": "HD区及人体参照：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记",
          "sample_class_id": "A144-R20261012-G12"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化",
          "sample_class_id": "A144-R20261012-G12"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O09",
      "A144-R20261012-O10"
    ],
    "group_ids": [
      "A144-R20261012-G12",
      "A144-R20261012-G13",
      "A144-R20261012-G14"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ06a",
    "question": "年龄相关通路背景：实际观察到了什么？",
    "answer": [
      "年龄效应具有细胞谱系差异，FB中的炎症/衰老相关程序是作者主要背景解释。 Fig4a/ED6b多数群线粒体功能/代谢相关程序降低，FB免疫/抗原呈递增加，蛋白稳态变化主要限上皮；均为转录GSEA推断，不等于实际功能测定。",
      "稳态cTEC中Foxn1/Dll4/Psmb11/Prss16/Enpep/Ly75未观察到随龄表达变化；作者提示全CD45−单细胞中cTEC捕获少可能限制检测，不当等效证明。 新Table4-cTEC原_p列：Cxcl12 .0965814、Foxn1 .894045、Ccl25/Psmb11/Kitl/Dll4/Il7均1，符合这些目标无显著年龄变化；按Methods为FDR调整检验，不改为原始P。"
    ],
    "result_ids": [
      "A144-R20261012-O11",
      "A144-R20261012-O30"
    ],
    "group_ids": [
      "A144-R20261012-G15",
      "A144-R20261012-G16"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ06b",
    "question": "年龄相关通路背景：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O11",
      "A144-R20261012-O30"
    ],
    "group_ids": [
      "A144-R20261012-G15",
      "A144-R20261012-G16"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ07a",
    "question": "aaTEC功能表达与部分EMT：实际观察到了什么？",
    "answer": [
      "aaTEC1抗原呈递降低；aaTEC2 EMT特征富集。 原Table6对应aaTEC1抗原呈递row8 NES−1.8/FDRq列0，aaTEC2EMT row4 NES2.4/q0；0为作者报告精度，不解释概率为零，与图≤.0001并存。",
      "Cdh1/Vim及8795相关基因比较支持aaTEC2介于上皮和间质之间；支持部分EMT状态，但作者未排除某些aaTEC2完全EMT；不是直接谱系转换实验。",
      "2026-03-13作者纠正：原右图标注Mouse1/2/3实为同一鼠3区域；HTML/PDF已替换为3只不同老年报告鼠。旧版n=1鼠/3区域，新版n=3鼠，仅适用于ED7a；本轮已直接读修正图面，不外推其它结果。 本轮已取得并实读纠正后ED7a原图，右侧UEA1显示Mouse1/2/3；三只不同鼠的身份来自官方纠正声明，非从图片猜测。原版同鼠三区域与新版三鼠范围仅适用a。",
      "ED7b：2月较18月常规mTEC中Tuft及Corneocyte数量更高，各P=.0007；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。",
      "ED7c：18月mTEC较DN-TEC的Tuft数量更高P=.001、Corneocyte更高P=.005；M-cell NS。 纵轴细胞数×10³；mean±SEM，个体生物重复，双侧Mann–Whitney；不借用a纠正后的n3。",
      "ED7d展示TEC子群Aire/Foxn1表达分布，作为转录支持图，不是蛋白流式或额外生物重复。",
      "ED7e 12月报告鼠AIRE在髓质可见，aaTEC/HD区图示缺乏相当AIRE信号；代表图不作细胞阳性率量化，未报告e生物n。图注比例尺50μm，实际两图30/20μm，保留不一致。",
      "aaTEC中Dll4/Psmb11/Kitl/Ccl25/Cxcl12/Il7低；Fezf2/Aire、关键NFκB目标及Tnfrsf11a/Ltbr/Cd40缺乏相应表达；AIRE/FEZF2依赖TRA低或无，主要见mTEC2/mTECprol。仅转录支持，不声称已做T细胞功能干预或绝对无功能。"
    ],
    "result_ids": [
      "A144-R20261012-O12",
      "A144-R20261012-O13",
      "A144-R20261012-O25",
      "A144-R20261012-O37",
      "A144-R20261012-O38",
      "A144-R20261012-O39",
      "A144-R20261012-O40",
      "A144-R20261012-O44"
    ],
    "group_ids": [
      "A144-R20261012-G17",
      "A144-R20261012-G18",
      "A144-R20261012-G19",
      "A144-R20261012-G36",
      "A144-R20261012-G37",
      "A144-R20261012-G41",
      "A144-R20261012-G42",
      "A144-R20261012-G43",
      "A144-R20261012-G44",
      "A144-R20261012-G45",
      "A144-R20261012-G50"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ07b",
    "question": "aaTEC功能表达与部分EMT：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging",
          "sample_class_id": "A144-R20261012-G41"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging",
          "sample_class_id": "A144-R20261012-G42"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "only published mimetic-cell flow-cytometry readout; not transcript or imaging",
          "sample_class_id": "A144-R20261012-G43"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O12",
      "A144-R20261012-O13",
      "A144-R20261012-O25",
      "A144-R20261012-O37",
      "A144-R20261012-O38",
      "A144-R20261012-O39",
      "A144-R20261012-O40",
      "A144-R20261012-O44"
    ],
    "group_ids": [
      "A144-R20261012-G17",
      "A144-R20261012-G18",
      "A144-R20261012-G19",
      "A144-R20261012-G36",
      "A144-R20261012-G37",
      "A144-R20261012-G41",
      "A144-R20261012-G42",
      "A144-R20261012-G43",
      "A144-R20261012-G44",
      "A144-R20261012-G45",
      "A144-R20261012-G50"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ08a",
    "question": "基线配体受体推断与蛋白支路：实际观察到了什么？",
    "answer": [
      "CellChat按受体/配体表达比较，作者认为aaTEC可吸引上皮生长信号；不是配体流量实测。",
      "Fig4j蛋白量单位pg/10^6 cells：PTN 2vs12月P=.04、2vs18月.005；MDK 2vs12月NS、2vs18月.01。2/12/18月雌鼠每组n5，mean±SEM、Kruskal–Wallis+Dunn；不是全胸腺总量，不是流式/CellChat，保留MDK12月阴性。"
    ],
    "result_ids": [
      "A144-R20261012-O14",
      "A144-R20261012-O15"
    ],
    "group_ids": [
      "A144-R20261012-G20",
      "A144-R20261012-G21"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ08b",
    "question": "基线配体受体推断与蛋白支路：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O14",
      "A144-R20261012-O15"
    ],
    "group_ids": [
      "A144-R20261012-G20",
      "A144-R20261012-G21"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ09a",
    "question": "年轻与老年损伤后恢复：实际观察到了什么？",
    "answer": [
      "年轻第28日恢复；老年约第42日才接近损伤前细胞量。",
      "流式支路：老年aaTEC在损伤后快速再现；这里只记录细胞亚群反应，不绑定组织学纤维化/钙化。",
      "Fig5d以0–7日AUC表示早期变化，老龄指数=老年AUC/年轻AUC；每细胞类型报告n10。这里只保留年轻/老年动态支路。 图面y轴实际标Recovery index，而图注/正文用aging index；两称谓并存，不据此假设不同计算。",
      "ED9b多数基质亚群早期反应未见重大年龄差异，aaTEC是例外；不以aaTEC的特殊变化替代整体基质反应。 该正文概述不排除ED9b具体时间点跨龄差异，详见新逐点O；不能把概述作所有基质时点均阴性。",
      "ED9a组织学显示老年持续纤维化/钙化等改变，年轻无相同持续改变；此比较与aaTEC流式计数、12月右叶透明成像分开，现不外推具体每组n。",
      "ED9b每年龄/时间n10，mean±SEM、2wayANOVA+Sidak。day7 aEC/vEC老龄较高P=.005/.002；capEC全时点NS、aEC/vEC其余时点NS。intFB全时点NS；capsFB day1/4/7老龄较高.04/.01/.001；medFB day0/4/7老龄较高<.0001/.009/.0005，day1 NS。mTEC1 day0/1/7老龄较低.01/.0002/.01；mTEC2 day0/1较低<.0001/.002；mTEC3 day0/1较低.0002/<.0001；tuft day0/1/7较低<.0001/.001/.04；cTEC day0老龄较高.01，aaTEC1/2 day0***。未标注的其他点不自动判NS。"
    ],
    "result_ids": [
      "A144-R20261012-O16",
      "A144-R20261012-O17",
      "A144-R20261012-O26",
      "A144-R20261012-O31",
      "A144-R20261012-O32",
      "A144-R20261012-O47"
    ],
    "group_ids": [
      "A144-R20261012-G22",
      "A144-R20261012-G23",
      "A144-R20261012-G40",
      "A144-R20261012-G53"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ09b",
    "question": "年轻与老年损伤后恢复：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅已采集数据的细胞计数；不重建损伤操作",
          "sample_class_id": "A144-R20261012-G22"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "仅已采集数据的细胞计数；不重建损伤操作",
          "sample_class_id": "A144-R20261012-G23"
        },
        {
          "protocol_id": "A144-P003",
          "scope": "published fixed flow readout only for named source comparison; not scRNA or imaging",
          "sample_class_id": "A144-R20261012-G53"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O16",
      "A144-R20261012-O17",
      "A144-R20261012-O26",
      "A144-R20261012-O31",
      "A144-R20261012-O32",
      "A144-R20261012-O47"
    ],
    "group_ids": [
      "A144-R20261012-G22",
      "A144-R20261012-G23",
      "A144-R20261012-G40",
      "A144-R20261012-G53"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ10a",
    "question": "损伤后老年HD区三维量化：实际观察到了什么？",
    "answer": [
      "12月雄鼠既有TBI后28日右叶：叶/髓质/皮质体积下降，图上P=.01/.002/.03；aaTEC体积升高P=.004。mTEC数量下降P=.02，但cTEC数量升高P=.02，aaTEC数量升高P=.004。不能把常规TEC统一说成下降。精确柱均值未数字化。",
      "Video4实际分散帧标18mo untreated/18mo(d21 SL-TBI)，caption却12mo baseline/day28并称associatedFig3e。保持独立代表性来源冲突，不把该影片并入O18 Fig5e/f12月day28量化或借其n。"
    ],
    "result_ids": [
      "A144-R20261012-O18",
      "A144-R20261012-O49"
    ],
    "group_ids": [
      "A144-R20261012-G24",
      "A144-R20261012-G25",
      "A144-R20261012-G56"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ10b",
    "question": "损伤后老年HD区三维量化：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记",
          "sample_class_id": "A144-R20261012-G24"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化",
          "sample_class_id": "A144-R20261012-G24"
        },
        {
          "protocol_id": "A144-P001",
          "scope": "仅固定组织透明/标记",
          "sample_class_id": "A144-R20261012-G25"
        },
        {
          "protocol_id": "A144-P002",
          "scope": "对应形态成像量化",
          "sample_class_id": "A144-R20261012-G25"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O18",
      "A144-R20261012-O49"
    ],
    "group_ids": [
      "A144-R20261012-G24",
      "A144-R20261012-G25",
      "A144-R20261012-G56"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ11a",
    "question": "损伤后亚群转录时间序列：实际观察到了什么？",
    "answer": [
      "Fig5g–i以年龄、day0/1/4/7及基质亚群注释同一UMAP。损伤后1/4/7日58,309个CD45−细胞与22,932个day0细胞整合，共81,241；这些是细胞而不是动物n。显示嵌入/标签本身不等于亚群恢复量。 SuppFig1 QC前共93,738细胞，QC后整合81,241；细胞QC排除不等于样本排除，前后分母不混用。",
      "Fig5j表明aaTEC群在老龄胸腺损伤后仍是突出TEC组分。纵轴是TEC亚群Proportion(%)，不是绝对细胞数；图上比例未数字化，不能凭组成说绝对增加。",
      "2月组day0/1/4/7的RNA-velocity推断由mTECprol走向常规mTEC2及拟态细胞谱系。箭头表示计算推断，不是同一细胞的实验追踪。",
      "18月组损伤后轨迹偏向mTEC1/earlyprog→aaTEC1/aaTEC2，而非年轻的常规mTEC2/拟态方向；为年龄分层RNA-velocity推断，不作为已证明谱系转分化。",
      "作者据此提出aaTEC可能扰乱老龄胸腺早期分化/再生程序。该项是解释，不是额外消除实验或独立干预结果。",
      "正式SupplementFig2比较同时间CD45−样本：横轴log10 bulk RNAseq、纵轴log10平均scRNA技术重复表达。day0四bulk生物重复R=.83/.79/.82/.79；day1三例.84/.84/.86；day4三例.83/.85/.84；day7三例.85/.83/.84，全部Pearson P<2.2e−16。scRNA技术重复精确n未在caption给出；基因点不是动物n，相关支持不证明每个稀少亚群采样无偏。"
    ],
    "result_ids": [
      "A144-R20261012-O19",
      "A144-R20261012-O33",
      "A144-R20261012-O34",
      "A144-R20261012-O35",
      "A144-R20261012-O36",
      "A144-R20261012-O48"
    ],
    "group_ids": [
      "A144-R20261012-G26",
      "A144-R20261012-G27",
      "A144-R20261012-G54",
      "A144-R20261012-G55"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ11b",
    "question": "损伤后亚群转录时间序列：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O19",
      "A144-R20261012-O33",
      "A144-R20261012-O34",
      "A144-R20261012-O35",
      "A144-R20261012-O36",
      "A144-R20261012-O48"
    ],
    "group_ids": [
      "A144-R20261012-G26",
      "A144-R20261012-G27",
      "A144-R20261012-G54",
      "A144-R20261012-G55"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ12a",
    "question": "再生信号与竞争解释：实际观察到了什么？",
    "answer": [
      "正文概述损伤后Fgf7/Fgf10/Fgf21/Bmp4及Flt3l/Kitl再生相关程序广泛上调、老龄幅度常较弱，但不能推广为每亚群每时间点均如此。再生相关基因响应依亚群/年龄/时点而异。cTEC Psmb11在老年day4/7相对day1仍显著上升（_l=1.919/2.435，FDR-adjusted _p≈8.25e−7/9.96e−12），但幅度弱于年轻_l=5.494/5.691，不能写老年Psmb11下降。Dll4年轻day4/7显著诱导_p=.01682/.004699，老年两点_p=1。Foxn1两龄day7显著上升，day4年轻_p=.24488、老年.05246均未显著；Ccl25两龄两点显著上升，Cxcl12老day4显著.000159而day7 .05840未显著。年轻intFB Kitl day4反向下降_l−.310/_p.000725，day7上升.686/.002055；老intFB Fgf7 day4/7仍上升.595/.000332及.282/.004990，老medFB Bmp4也上升.499/.02699及.955/2.65e−13。老龄不等于所有因子都不响应；原表完整目标行/坐标另存，数值按报告精度非新重算。",
      "FGF/BMP相关互作偏向aaTEC；受体表达/CellChat不能单独证明实际竞争性消耗。",
      "KGF响应下cTEC/mTEC/aaTEC出现pAKT反应，FB无对应反应；6只18月雌鼠独立胸腺，mean±SEM、paired t test。与CellChat计算分开。 pAKT读出时点为KGF后5 min。 Fig6e实图纵轴pAKT MFI，配对KGF−/+：cTEC P=.002、mTEC .03、aaTEC1 .03、aaTEC2 .008，FB NS。"
    ],
    "result_ids": [
      "A144-R20261012-O20",
      "A144-R20261012-O21",
      "A144-R20261012-O24"
    ],
    "group_ids": [
      "A144-R20261012-G29",
      "A144-R20261012-G30",
      "A144-R20261012-G31",
      "A144-R20261012-G35"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ12b",
    "question": "再生信号与竞争解释：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "published pAKT flow endpoint only",
          "sample_class_id": "A144-R20261012-G35"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O20",
      "A144-R20261012-O21",
      "A144-R20261012-O24"
    ],
    "group_ids": [
      "A144-R20261012-G29",
      "A144-R20261012-G30",
      "A144-R20261012-G31",
      "A144-R20261012-G35"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ13a",
    "question": "FOXN1降低与aaTEC关联：实际观察到了什么？",
    "answer": [
      "FOXN1蛋白在cTEC/mTEC可检出，在aaTEC1/2不明显；此O仅蛋白流式。",
      "计算诱导/抑制FOXN1与分化轨迹相关；不是实际动物干预或蛋白流式读出。",
      "aaTEC1/2的Foxn1转录低表达，与蛋白结果为不同支路，不赋蛋白流式P。",
      "6月既有Foxn1低功能模型较对照提前出现aaTEC；仅记录已发表比较，不继承FOXN1蛋白流式流程或重建模型建立。 ED10b各柱来自不同性别/年龄/模型数据，不能当完全匹配干预的定量对照。"
    ],
    "result_ids": [
      "A144-R20261012-O22",
      "A144-R20261012-O23",
      "A144-R20261012-O28",
      "A144-R20261012-O29"
    ],
    "group_ids": [
      "A144-R20261012-G32",
      "A144-R20261012-G33",
      "A144-R20261012-G34",
      "A144-R20261012-G38"
    ]
  },
  {
    "question_id": "A144-R20261012-GQ13b",
    "question": "FOXN1降低与aaTEC关联：哪些方法及限制适用？",
    "answer": {
      "protocol_uses": [
        {
          "protocol_id": "A144-P003",
          "scope": "仅FOXN1蛋白流式，不扩为模型构建",
          "sample_class_id": "A144-R20261012-G34"
        }
      ],
      "limitations": "Apply methods only to explicitly linked group/panel/endpoint. Published artwork inspected as source_refs specify; real missing source units/author omissions remain in current scope. No raw image stack, full movie playback, unprinted point values or causal validation inferred."
    },
    "result_ids": [
      "A144-R20261012-O22",
      "A144-R20261012-O23",
      "A144-R20261012-O28",
      "A144-R20261012-O29"
    ],
    "group_ids": [
      "A144-R20261012-G32",
      "A144-R20261012-G33",
      "A144-R20261012-G34",
      "A144-R20261012-G38"
    ]
  }
]

```
