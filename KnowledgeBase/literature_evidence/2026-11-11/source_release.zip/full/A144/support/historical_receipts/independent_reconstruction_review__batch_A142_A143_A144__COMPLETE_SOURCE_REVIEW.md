# A142–A144 independent scientific review: final source-bounded receipt

The accessible published result evidence has been reviewed against Results, captions and actual artwork, then traced into the reconstructed O/G/claim/Q objects. Final author corrections pass the scientific delta review. This is not historical-core restoration, protocol validation, publication approval, a complete SOP, or raw-data reanalysis.

## Coverage

| Paper | Actual source review | Final reconstructed objects |
|---|---|---|
| A142 | All 7 main figures personally viewed. Root and independent supplement reviewer read S1–S8, all 30 rows across Tables S1–S3, and 18 sampled frames across 6 movies; final root receipt incorporated separately. | 19 O / 14 G / 8 claims / 16 Q |
| A143 | All 8 main figures; all S1–S3 panels; all 515 published gene-table rows across 2 sheets; 6 sampled frames from complete, CRC-verified Videos 2 and 5. | 20 O / 27 G / 9 claims / 18 Q |
| A144 | All 7 main figures and ED1–10; current and original ED7; supplementary Figures 1–2 and Tables 11–13; all 6 reporting-summary pages; 20 sampled frames across all 5 video files. Published 129-sheet workbook: complete inventory/headers, full Table1/3 contents, headline GSEA statistics and targeted manuscript-linked genes across Table4/7–10 subsets. | 50 O / 57 G / 13 claims / 26 Q |

For A144, Table2/5 schema and selected context rows were read; the review does not claim scientific adjudication of every genome-wide row or fresh sequencing analysis. Full published workbooks remain retained. Video review uses distributed actual frames, not complete frame-by-frame replay.

## Important scientific repairs verified

- A142 patient/block/gland levels are separate; pooled 69/37 gland denominators, location fractions, correlation negatives and closed-gland height are restored. The Results 37±11% versus Discussion 32% disagreement and local source-number/footnote conflicts remain explicit. Supplement-derived evidence and original P branches follow the root's final independent receipt.
- A143 whole-gland volume ratios, section area/DAPI and fluorescence-density/DAPI are distinct. VIP P=.0732 remains nonsignificant; the SD/SEM diagnostic does not replace the source. AP-1 inhibition is not JunB-specific causation; FluoroGold is an independent qualitative branch. Extract donor/recipient and panel-specific PBS comparisons are preserved.
- A143 supplementary Slit2 FDR=.0962003 is nonsignificant despite the main-text P=.004. Ntn1 and Junb FDR results are distinct. All-gene, finite-fold-change and plotted gene counts remain separate; finite significant counts match the volcano plot numerically without inventing an undocumented filtering rule. Main-text counts remain partly unreconciled.
- A144 Fig2 nonsignificant declines are retained; fine-gated cTEC age increases are not merged with broad-gate trends. Age/time/sex/model sample sizes are panel-specific. PTN/MDK protein, FOXN1 protein, transcript expression, CellChat and differentiation inference are separate branches. MDK middle-age and pAKT fibroblast negatives are retained.
- A144 ED7a correction is version-bound: original panels represented one aged mouse's three regions, corrected panels three aged mice. ED7b/c sample sizes are independent. Figure/caption age, scale-bar and index-name discrepancies remain explicit.
- A144 regeneration is not uniformly absent in old animals. Psmb11 still increases during old recovery but less than in young; Foxn1, Cxcl12 and Dll4 significance is time-specific. Retained old Fgf7/Bmp4 responses and the young intFB Kitl reversal are included. Partial EMT is supported without excluding some complete EMT, as the authors state.
- Actual supplementary Figure2 supplies the formerly unverified bulk/scRNA correlation branch. Video4's actual 18-month/day21 labels remain separate from its 12-month/day28 caption and Fig5 quantification. ED5a's 11-week reporter validation is now a separate O50/G57 rather than borrowing older-cohort n.
- Claims now contain supported scientific propositions, marker/metric identifiers, comparison order, negative findings and source conflicts. All final O records have claim and Q coverage. Method P applicability is limited to actual branches; original P records remain unchanged.

## Remaining source limits

1. A143 Videos 1, 3, 4, 6, 7 and 8 were not obtained as complete valid files after an official API 503 and interrupted transfers. Individual valid entries were CRC-checked; the partial ZIP is not represented as complete. Their captions link to already reviewed Fig1 conditions; no new visual conclusions are invented.
2. A144's article references Supplementary Figure3c, but the current official seven-page supplement contains only Figures1–2 and Tables11–13. The missing citation target is not reconstructed by guesswork.
3. Unreported biological n, tracer counts, original point values, raw image stacks and unresolved source discrepancies remain explicit. No statistical nonsignificance is treated as equivalence.

## Frozen receipts

See `complete_final_review_manifest.json` for exact reviewed hashes, all 93 registered source-file hash checks, all 9 original-P preservation checks, and O→claim/Q coverage. These structural checks are supporting integrity checks, not the scientific review itself.

Detailed scientific records: `remaining_artwork_read_report.json`, `A143_supplement_read_report.json`, `A143_supplement_table_full_read.json`, `A144_supplement_read_report.json`, `A144_workbook_targeted_results_read.json`, and `root_supplement_check/A142_final_scientific_delta_receipt.json`. Earlier review reports are retained as historical snapshots and superseded by this receipt.
