"""Dedicated read-only workbook representation resolver v1.
No ordinary-file fallback, source ZIP reads, network or formula evaluation.
Install alongside typed_projection.py; ROOT is the portable release directory.
"""
from pathlib import Path, PurePosixPath
import hashlib,json,re
import typed_projection as projection
ROOT=Path(__file__).resolve().parent
class WorkbookReferenceHold(ValueError): pass
def require(ok,reason):
    if not ok: raise WorkbookReferenceHold(reason)
def digest(data): return hashlib.sha256(data).hexdigest()
def canon(data): return json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def _read(root,name):
    require(isinstance(name,str) and name and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,'UNSAFE_PATH')
    path=root/name; require(path.resolve().is_relative_to(root.resolve()),'PATH_ESCAPES_ROOT')
    require(path.is_file(),'MISSING_FILE')
    return path.read_bytes()
def _json(root,name):
    try: return json.loads(_read(root,name))
    except (json.JSONDecodeError,UnicodeError): raise WorkbookReferenceHold('INVALID_JSON')
def _unique(rows,key):
    keys=[r[key] for r in rows]; require(len(keys)==len(set(keys)),'DUPLICATE_'+key.upper())
    return dict(zip(keys,rows))
def _context(paper_id,allow_candidate):
    root=ROOT.resolve(); require(paper_id not in projection.RESTRICTED,'STRUCTURE_ONLY_PAPER')
    require(re.fullmatch(r'[A-Za-z0-9_-]+',paper_id) is not None,'INVALID_PAPER_ID')
    idx=_json(root,'active_index.json'); rows=[r for r in idx['records'] if r['paper_id']==paper_id]
    require(len(rows)==1,'PAPER_NOT_UNIQUELY_SELECTED'); row=rows[0]
    require(row.get('default_eligible') is True or allow_candidate is True,'CANDIDATE_REQUIRES_EXPLICIT_OPT_IN')
    selectionpath='full/'+paper_id+'/version_selection.json'; require(row['version_selection']==selectionpath,'NONCANONICAL_SELECTION')
    sums=_json(root,'SHA256SUMS.json')
    for path in ['active_index.json',selectionpath,'source_file_manifest.json','supporting_file_manifest.json']:
        require(sums.get(path)==digest(_read(root,path)),'ROOT_MANIFEST_HASH_MISMATCH')
    sel=_json(root,selectionpath); require(sel['paper_id']==paper_id and sel.get('default_eligible')==row.get('default_eligible'),'SELECTION_IDENTITY')
    for field in ['active_scientific_files','required_supporting_files']:
        require(sel[field]==row[field],'INDEX_SELECTION_CLOSURE_MISMATCH')
    science=_unique(sel['active_scientific_files'],'path'); support=_unique(sel['required_supporting_files'],'path')
    require(not (science.keys() & support.keys()),'SCIENCE_SUPPORT_ROLE_OVERLAP')
    manifests=_unique(_json(root,'source_file_manifest.json')+_json(root,'supporting_file_manifest.json'),'path')
    # Every selected mandatory companion must exist and match, not only the requested workbook.
    for path,f in {**science,**support}.items():
        require(path.startswith('full/'+paper_id+'/'),'CROSS_PAPER_SELECTED_FILE')
        actual=digest(_read(root,path)); require(path in manifests,'SELECTED_FILE_NOT_MANIFESTED')
        require(manifests[path]['sha256']==actual and f['sha256']==actual and sums.get(path)==actual,'SELECTED_FILE_HASH_MISMATCH')
        require(manifests[path].get('paper_id')==paper_id,'MANIFEST_PAPER_MISMATCH')
    bindings=sel.get('workbook_representation_bindings',[])
    require(row.get('workbook_representation_bindings_sha256')==digest(canon(bindings)),'BINDINGS_DIGEST_MISMATCH')
    _unique(bindings,'binding_id'); aliases=[]
    for b in bindings:
        require(b['paper_id']==paper_id,'BINDING_PAPER_MISMATCH')
        require(b['original_sha256'] not in projection.RESTRICTED_HASHES,'STRUCTURE_ONLY_SOURCE_HASH')
        require(b['original_member'] in b['original_aliases'],'ORIGINAL_MEMBER_ALIAS_REQUIRED')
        for alias in b['original_aliases']:
            require(isinstance(alias,str) and '/' in alias and alias.endswith('.xlsx'),'EXPLICIT_FULL_ALIAS_REQUIRED')
        aliases+=b['original_aliases']
    require(len(aliases)==len(set(aliases)),'AMBIGUOUS_WORKBOOK_ALIAS')
    return root,row,sel,science,support,manifests,bindings

def guard_ordinary_reference(paper_id,reference,allow_candidate=False):
    """Call BEFORE old ordinary resolver; raises only for a registered workbook alias.
    No existing resolver is modified by this module. Context integrity always applies.
    """
    *_,bindings=_context(paper_id,allow_candidate)
    if any(reference in b['original_aliases'] for b in bindings):
        raise WorkbookReferenceHold('WORKBOOK_ALIAS_REQUIRES_DEDICATED_API')
    return False

def _load_projection(ctx,b):
    root,row,sel,science,support,manifests,bindings=ctx; path=b['portable_path']
    role=b['source_role']; require(role in ('science','mandatoryhistoricalsupport'),'UNKNOWN_SOURCE_ROLE')
    if role=='science': require(path in science and path not in support,'SCIENCE_ROLE_MISMATCH')
    else: require(path in support and path not in science,'HISTORICAL_SUPPORT_PROMOTED_OR_MISSING')
    require(path.startswith('full/'+b['paper_id']+'/'),'CROSS_PAPER_TARGET')
    raw=_read(root,path); require(digest(raw)==b['portable_sha256'],'PORTABLE_HASH_MISMATCH')
    m=manifests[path]
    require(m.get('source_sha256')==b['original_sha256'] and m.get('source_role')==role,'ORIGINAL_IDENTITY_OR_ROLE_CHAIN_MISMATCH')
    require(m.get('original_member')==b['original_member'],'ORIGINAL_MEMBER_CHAIN_MISMATCH')
    d=json.loads(raw)
    require(d['source']['source_id']==b['paper_id'] and d['source']['sha256']==b['original_sha256'],'PROJECTION_SOURCE_IDENTITY')
    require(d['claim']==b['projection_claim'],'PROJECTION_CLAIM_MISMATCH')
    require(d['claim']=='semantic-lossless-original-for-supported-profile' and not d.get('transforms'),'DERIVED_PROJECTION_REQUIRES_SEPARATE_VERIFIER')
    require(d['original_zip_byte_reconstruction_claim'] is False,'FALSE_ORIGINAL_BYTE_CLAIM')
    try:
        for part in d['parts'].values(): require(projection.encode(projection.decode(part))==part,'INVALID_TYPED_FEATURE')
        identities=projection.validate_dependencies(d['parts'])
    except (projection.Hold,KeyError,ValueError,TypeError): raise WorkbookReferenceHold('INVALID_PROJECTION_FEATURE_OR_DEPENDENCY')
    require(identities==d['sheet_identities']==b['sheet_identities'],'SHEET_IDENTITY_MISMATCH')
    proofs=_unique(d['proof'],'part'); sourceparts=_unique(d['source_parts'],'part')
    require(set(proofs)==set(sourceparts)==set(d['parts']),'PROJECTION_PART_CLOSURE')
    for name,part in d['parts'].items():
        actual=digest(canon(projection.semantic(projection.decode(part))))
        q=proofs[name]; require(q.get('equal') is True and actual==q['projected_semantic_sha256']==q['source_semantic_sha256'],'SEMANTIC_PROOF_MISMATCH')
    for name,part in d['parts'].items():
        if part['kind']!='worksheet': continue
        cells=[x for x in projection.walk(part) if x['kind']=='c']; _unique(cells,'coordinate')
        rows=[x for x in projection.walk(part) if x['kind']=='row']; ids=[x['attributes']['r'] for x in rows]; require(len(ids)==len(set(ids)),'DUPLICATE_ROW')
        for rowdata in rows:
            for c in rowdata['features']: require(str(projection.coordinate(c['coordinate'])[1])==rowdata['attributes']['r'],'CELL_ROW_IDENTITY')
        indexes=[s for s in d['sparse_sheet_index'] if s['part']==name]
        require(len(indexes)==1 and indexes[0]['stored_rows']==[int(i) for i in ids] and indexes[0]['stored_cells']==[c['coordinate'] for c in cells],'SPARSE_INDEX_MISMATCH')
    return d

def _merge_status(part,ref):
    col,row=projection.coordinate(ref); hits=[]
    for node in projection.walk(part):
        if node['kind']!='mergeCell': continue
        span=node['attributes']['ref']; a,b=projection.cell_range(span)
        if a[0]<=col<=b[0] and a[1]<=row<=b[1]: hits.append({'range':span,'anchor':span.split(':')[0],'position':'anchor' if (col,row)==a else 'non-anchor','value_redirected':False})
    require(len(hits)<=1,'OVERLAPPING_MERGES')
    return hits[0] if hits else {'position':'not-merged','value_redirected':False}
def _storage(part,ref):
    matches=[n for n in projection.walk(part) if n['kind']=='c' and n['coordinate']==ref]
    require(len(matches)<=1,'DUPLICATE_CELL'); result={'coordinate':ref,'merge':_merge_status(part,ref)}
    if not matches: result['storage']='absent'; return result
    c=matches[0]; children={x['kind']:x for x in c['features']}; result.update({'storage':c['presence'],'cell_type':c['valueType'],'style_index':c['attributes'].get('s')})
    if 'f' in children:
        result['formula_present']=True; result['cache_presence']='present' if 'v' in children else 'absent'
    elif c['valueType'] in ('str','inlineStr'):
        texts=[n['text'] for n in projection.walk(c) if n['kind'] in ('v','t')]
        if texts and all(t=='' for t in texts): result['storage']='empty-text'
    return result

def resolve_workbook_reference(paper_id,original_reference,original_sha256,*,sheet=None,coordinate=None,range_ref=None,view=None,allow_candidate=False):
    """Return typed-workbook location metadata, never a cell value or calculated result.
    sheet is the exact full sheet identity object registered in the binding.
    """
    ctx=_context(paper_id,allow_candidate); bindings=ctx[-1]
    found=[b for b in bindings if original_reference in b['original_aliases']]
    require(len(found)==1,'UNREGISTERED_OR_AMBIGUOUS_WORKBOOK_ALIAS'); b=found[0]
    require(original_sha256==b['original_sha256'],'ORIGINAL_SHA_MISMATCH'); d=_load_projection(ctx,b)
    out={'kind':'typed-workbook-representation','portable_path':b['portable_path'],'portable_sha256':b['portable_sha256'],'original_sha256':original_sha256,'original_member':b['original_member'],'source_role':b['source_role'],'projection_claim':d['claim'],'formula_evaluated':False,'original_xlsx_delivered':False}
    if view=='workbook':
        require(sheet is None and coordinate is None and range_ref is None,'AMBIGUOUS_WORKBOOK_VIEW')
        out.update({'view':'workbook','sheet_identities':d['sheet_identities']}); return out
    require(isinstance(sheet,dict) and sheet in d['sheet_identities'],'EXACT_SHEET_IDENTITY_REQUIRED')
    require(view in (None,'cell','range','sheet'),'UNKNOWN_VIEW'); part=d['parts'][sheet['part']]; out['sheet_identity']=sheet
    if view=='sheet':
        require(coordinate is None and range_ref is None,'AMBIGUOUS_SHEET_VIEW'); out['view']='sheet'; return out
    require((coordinate is not None) != (range_ref is not None),'EXACT_CELL_OR_RANGE_REQUIRED')
    try:
        if coordinate is not None:
            require(view in (None,'cell'),'VIEW_ADDRESS_MISMATCH'); projection.coordinate(coordinate)
            out.update({'view':'cell',**_storage(part,coordinate)})
        else:
            require(view in (None,'range'),'VIEW_ADDRESS_MISMATCH'); a,bounds=projection.cell_range(range_ref)
            area=(bounds[0]-a[0]+1)*(bounds[1]-a[1]+1); require(area<=10000,'RANGE_QUERY_LIMIT')
            def letters(n):
                result=''
                while n: n,r=divmod(n-1,26); result=chr(65+r)+result
                return result
            statuses=[_storage(part,letters(c)+str(r)) for r in range(a[1],bounds[1]+1) for c in range(a[0],bounds[0]+1)]
            out.update({'view':'range','range':range_ref,'cells':statuses})
    except projection.Hold as e: raise WorkbookReferenceHold(str(e))
    return out
