"""Fail-closed, local-only OOXML semantic projection. No workbook writer/network API.

Metadata uses explicit, finite feature records, not arbitrary XML/opaque payloads.
XML spelling, namespace prefixes, attribute ordering, and insignificant inter-element
whitespace are not semantic claims. No formula calculation or scientific inference.
"""
import argparse, copy, hashlib, io, json, posixpath, re, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P='http://schemas.openxmlformats.org/package/2006/relationships'
C='http://schemas.openxmlformats.org/package/2006/content-types'
X='http://www.w3.org/XML/1998/namespace'
RESTRICTED={'A109','A117','R004'}
RESTRICTED_HASHES={'7c90f5f469647ad044d0a692a05515515c03069a84ead2f4ca69dfdaab461e95', 'e64283b21088b77c9ed1ce5be0533d4fc9520425fc242cd47bf39ca576a38e5c', 'ceabadc42600cf15454389d6b82eac624aab57e706e411787ec417d82dff23d3'}
class Hold(Exception): pass
def require(ok, code):
    if not ok: raise Hold(code)
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
# Each entry is a finite typed feature definition (attributes, child feature kinds).
G={}
def grammar(name,attrs='',children='',ns=S,text=False):
    G[(ns,name)]={'attributes':attrs.split(),'children':children.split(),'text':text}
grammar('workbook','','fileVersion workbookPr bookViews sheets definedNames calcPr')
grammar('fileVersion','appName lastEdited lowestEdited rupBuild codeName')
grammar('workbookPr','date1904 showObjects filterPrivacy codeName defaultThemeVersion saveExternalLinkValues updateLinks')
grammar('bookViews','','workbookView'); grammar('workbookView','visibility minimized showHorizontalScroll showVerticalScroll showSheetTabs xWindow yWindow windowWidth windowHeight tabRatio firstSheet activeTab autoFilterDateGrouping')
grammar('sheets','','sheet'); grammar('sheet','name sheetId state rel:id')
grammar('definedNames','','definedName'); grammar('definedName','name comment customMenu description help statusBar localSheetId hidden function vbProcedure xlm functionGroupId shortcutKey publishToServer workbookParameter',text=True)
grammar('calcPr','calcId calcMode fullCalcOnLoad refMode iterate iterateCount iterateDelta fullPrecision calcCompleted calcOnSave concurrentCalc concurrentManualCount forceFullCalc')
grammar('worksheet','','sheetPr dimension sheetViews sheetFormatPr cols sheetData autoFilter mergeCells hyperlinks printOptions pageMargins pageSetup headerFooter tableParts')
grammar('sheetPr','syncHorizontal syncVertical syncRef transitionEvaluation transitionEntry published codeName filterMode enableFormatConditionsCalculation','tabColor outlinePr pageSetUpPr')
grammar('outlinePr','applyStyles summaryBelow summaryRight showOutlineSymbols'); grammar('pageSetUpPr','autoPageBreaks fitToPage'); grammar('dimension','ref')
grammar('sheetViews','','sheetView'); grammar('sheetView','windowProtection showFormulas showGridLines showRowColHeaders showZeros rightToLeft tabSelected showRuler showOutlineSymbols defaultGridColor showWhiteSpace view topLeftCell colorId zoomScale zoomScaleNormal zoomScaleSheetLayoutView zoomScalePageLayoutView workbookViewId','pane selection')
grammar('pane','xSplit ySplit topLeftCell activePane state'); grammar('selection','pane activeCell activeCellId sqref')
grammar('sheetFormatPr','baseColWidth defaultColWidth defaultRowHeight customHeight zeroHeight thickTop thickBottom outlineLevelRow outlineLevelCol')
grammar('cols','','col'); grammar('col','min max width style hidden bestFit customWidth phonetic outlineLevel collapsed')
grammar('sheetData','','row'); grammar('row','r spans s customFormat ht hidden customHeight outlineLevel collapsed thickTop thickBot ph','c')
grammar('c','r s t cm vm ph','f v is'); grammar('f','t aca ref dt2D dtr del1 del2 r1 r2 ca si bx',text=True); grammar('v',text=True)
grammar('is','','t r rPh phoneticPr'); grammar('sst','count uniqueCount','si'); grammar('si','','t r rPh phoneticPr')
grammar('t','xml:space',text=True); grammar('r','','rPr t'); grammar('rPh','sb eb','t'); grammar('phoneticPr','fontId type alignment')
grammar('mergeCells','count','mergeCell'); grammar('mergeCell','ref')
grammar('hyperlinks','','hyperlink'); grammar('hyperlink','ref rel:id location tooltip display')
grammar('printOptions','horizontalCentered verticalCentered headings gridLines gridLinesSet'); grammar('pageMargins','left right top bottom header footer')
grammar('pageSetup','paperSize scale firstPageNumber fitToWidth fitToHeight pageOrder orientation usePrinterDefaults blackAndWhite draft cellComments useFirstPageNumber errors horizontalDpi verticalDpi copies rel:id')
grammar('headerFooter','differentOddEven differentFirst scaleWithDoc alignWithMargins','oddHeader oddFooter evenHeader evenFooter firstHeader firstFooter')
for n in 'oddHeader oddFooter evenHeader evenFooter firstHeader firstFooter'.split(): grammar(n,text=True)
grammar('tableParts','count','tablePart'); grammar('tablePart','rel:id')
grammar('table','id name displayName ref headerRowCount insertRow insertRowShift totalsRowCount totalsRowShown published headerRowDxfId dataDxfId totalsRowDxfId headerRowBorderDxfId tableBorderDxfId totalsRowBorderDxfId headerRowCellStyle dataCellStyle totalsRowCellStyle connectionId','autoFilter tableColumns tableStyleInfo')
grammar('tableColumns','count','tableColumn'); grammar('tableColumn','id uniqueName name totalsRowFunction totalsRowLabel queryTableFieldId headerRowDxfId dataDxfId totalsRowDxfId headerRowCellStyle dataCellStyle totalsRowCellStyle','calculatedColumnFormula totalsRowFormula')
for n in ['calculatedColumnFormula','totalsRowFormula']: grammar(n,'array',text=True)
grammar('tableStyleInfo','name showFirstColumn showLastColumn showRowStripes showColumnStripes')
grammar('autoFilter','ref','filterColumn'); grammar('filterColumn','colId hiddenButton showButton','filters customFilters top10 dynamicFilter colorFilter iconFilter')
grammar('filters','blank calendarType','filter dateGroupItem'); grammar('filter','val'); grammar('dateGroupItem','year month day hour minute second dateTimeGrouping'); grammar('customFilters','and','customFilter'); grammar('customFilter','operator val'); grammar('top10','top percent val filterVal'); grammar('dynamicFilter','type val maxVal'); grammar('colorFilter','dxfId cellColor'); grammar('iconFilter','iconSet iconId')
grammar('styleSheet','','numFmts fonts fills borders cellStyleXfs cellXfs cellStyles dxfs tableStyles colors')
for n,ch in [('numFmts','numFmt'),('fonts','font'),('fills','fill'),('borders','border'),('cellStyleXfs','xf'),('cellXfs','xf'),('cellStyles','cellStyle'),('dxfs','dxf')]: grammar(n,'count',ch)
grammar('numFmt','numFmtId formatCode'); grammar('font','','name charset family b i strike outline shadow condense extend color sz u vertAlign scheme'); grammar('rPr','','rFont charset family b i strike outline shadow condense extend color sz u vertAlign scheme')
for n in 'name rFont charset family b i strike outline shadow condense extend sz u vertAlign scheme'.split(): grammar(n,'val')
for n in 'color fgColor bgColor tabColor'.split(): grammar(n,'auto indexed rgb theme tint')
grammar('fill','','patternFill gradientFill'); grammar('patternFill','patternType','fgColor bgColor'); grammar('gradientFill','type degree left right top bottom','stop'); grammar('stop','position','color')
grammar('border','diagonalUp diagonalDown outline','left right top bottom diagonal vertical horizontal start end')
for n in 'left right top bottom diagonal vertical horizontal start end'.split(): grammar(n,'style','color')
grammar('xf','numFmtId fontId fillId borderId xfId quotePrefix pivotButton applyNumberFormat applyFont applyFill applyBorder applyAlignment applyProtection','alignment protection')
grammar('alignment','horizontal vertical textRotation wrapText shrinkToFit indent relativeIndent justifyLastLine readingOrder'); grammar('protection','locked hidden')
grammar('cellStyle','name xfId builtinId iLevel hidden customBuiltin'); grammar('dxf','','font numFmt fill alignment border protection'); grammar('tableStyles','count defaultTableStyle defaultPivotStyle','tableStyle'); grammar('tableStyle','name pivot table count','tableStyleElement'); grammar('tableStyleElement','type size dxfId'); grammar('colors','','indexedColors mruColors'); grammar('indexedColors','','rgbColor'); grammar('mruColors','','color'); grammar('rgbColor','rgb')
grammar('comments','','authors commentList'); grammar('authors','','author'); grammar('author',text=True); grammar('commentList','','comment'); grammar('comment','ref authorId guid shapeId','text'); grammar('text','','t r rPh phoneticPr')
grammar('Relationships','','Relationship',P); grammar('Relationship','Id Type Target TargetMode',ns=P)
grammar('Types','','Default Override',C); grammar('Default','Extension ContentType',ns=C); grammar('Override','PartName ContentType',ns=C)


A='http://schemas.openxmlformats.org/drawingml/2006/main'
def theme(name,attrs='',children=''): grammar(name,attrs,children,A)
theme('theme','name','themeElements objectDefaults extraClrSchemeLst')
theme('themeElements','','clrScheme fontScheme fmtScheme'); theme('clrScheme','name','dk1 lt1 dk2 lt2 accent1 accent2 accent3 accent4 accent5 accent6 hlink folHlink')
for n in 'dk1 lt1 dk2 lt2 accent1 accent2 accent3 accent4 accent5 accent6 hlink folHlink'.split(): theme(n,'','srgbClr sysClr')
mods='tint shade comp inv gray alpha alphaOff alphaMod hue hueOff hueMod sat satOff satMod lum lumOff lumMod red redOff redMod green greenOff greenMod blue blueOff blueMod gamma invGamma'
for n,attrs in [('srgbClr','val'),('sysClr','val lastClr'),('schemeClr','val'),('prstClr','val'),('scrgbClr','r g b'),('hslClr','hue sat lum')]: theme(n,attrs,mods)
for n in mods.split(): theme(n,'val')
theme('fontScheme','name','majorFont minorFont')
for n in ('majorFont','minorFont'): theme(n,'','latin ea cs font')
for n in ('latin','ea','cs'): theme(n,'typeface panose pitchFamily charset')
theme('font','script typeface'); theme('fmtScheme','name','fillStyleLst lnStyleLst effectStyleLst bgFillStyleLst')
for n in ('fillStyleLst','bgFillStyleLst'): theme(n,'','solidFill gradFill noFill pattFill')
theme('solidFill','','srgbClr schemeClr sysClr scrgbClr hslClr prstClr'); theme('noFill'); theme('gradFill','flip rotWithShape','gsLst lin path tileRect'); theme('gsLst','','gs'); theme('gs','pos','srgbClr schemeClr sysClr'); theme('lin','ang scaled'); theme('path','path','fillToRect'); theme('fillToRect','l t r b'); theme('tileRect','l t r b'); theme('pattFill','prst','fgClr bgClr')
for n in ('fgClr','bgClr'): theme(n,'','srgbClr schemeClr sysClr')
theme('lnStyleLst','','ln'); theme('ln','w cap cmpd algn','solidFill noFill prstDash custDash round bevel miter headEnd tailEnd'); theme('prstDash','val'); theme('custDash','','ds'); theme('ds','d sp'); theme('round'); theme('bevel'); theme('miter','lim')
for n in ('headEnd','tailEnd'): theme(n,'type w len')
theme('effectStyleLst','','effectStyle'); theme('effectStyle','','effectLst'); theme('effectLst','','outerShdw innerShdw glow softEdge blur reflection')
theme('outerShdw','blurRad dist dir sx sy kx ky algn rotWithShape','srgbClr schemeClr sysClr'); theme('innerShdw','blurRad dist dir','srgbClr schemeClr sysClr'); theme('glow','rad','srgbClr schemeClr sysClr'); theme('softEdge','rad'); theme('blur','rad grow'); theme('reflection','blurRad stA stPos endA endPos dist dir fadeDir sx sy kx ky algn rotWithShape')
# Empty default containers only. Shape defaults and extension lists remain HOLD.
theme('objectDefaults'); theme('extraClrSchemeLst')

def split(q):
    if q.startswith('{'): return q[1:].split('}',1)
    return '',q
def attr_key(q):
    ns,n=split(q)
    require(ns in ('',R,X),'UNSUPPORTED_ATTRIBUTE_NAMESPACE')
    return ('rel:' if ns==R else 'xml:' if ns==X else '')+n
def attr_xml(q):
    return '{'+R+'}'+q[4:] if q.startswith('rel:') else '{'+X+'}'+q[4:] if q.startswith('xml:') else q

def encode(e):
    ns,n=split(e.tag); require((ns,n) in G,'UNSUPPORTED_FEATURE:'+n)
    g=G[(ns,n)]; a={attr_key(k):v for k,v in e.attrib.items()}
    require(set(a)<=set(g['attributes']),'UNSUPPORTED_ATTRIBUTE:'+n)
    record={'kind':n,'namespace':ns,'attributes':a}
    if g['text']:
        require(not len(e),'TEXT_WITH_CHILDREN:'+n); record['text']=e.text or ''
    else:
        require(not e.text or not e.text.strip(),'UNSUPPORTED_MIXED_TEXT:'+n)
        kids=[]
        for c in e:
            require(split(c.tag)[0]==ns and split(c.tag)[1] in g['children'],'UNSUPPORTED_CHILD:'+n)
            require(not c.tail or not c.tail.strip(),'UNSUPPORTED_TAIL:'+n)
            kids.append(encode(c))
        record['features']=kids
    if n=='c':
        record['coordinate']=a.get('r'); require(re.fullmatch(r'[A-Z]{1,3}[1-9][0-9]*',record['coordinate'] or ''),'CELL_COORDINATE')
        typ=a.get('t','n'); require(typ in ('n','s','str','inlineStr','b','e','d'),'CELL_TYPE')
        record['valueType']=typ
        names=[c['kind'] for c in record['features']]
        require(len(names)==len(set(names)),'DUPLICATE_CELL_SUBFIELD')
        record['presence']='formula' if 'f' in names else 'inline-text' if 'is' in names else 'stored-value' if 'v' in names else 'explicit-blank'
    return record

def decode(d):
    e=ET.Element('{'+d['namespace']+'}'+d['kind'],{attr_xml(k):v for k,v in d['attributes'].items()})
    if 'text' in d: e.text=d['text']
    else:
        for c in d['features']: e.append(decode(c))
    return e

def semantic(e):
    # Independent source comparator; does not call encode/decode.
    ns,n=split(e.tag)
    return [e.tag, sorted(e.attrib.items()), (e.text or '') if (ns,n) in G and G[(ns,n)]['text'] else None,[semantic(c) for c in e]]
def walk(d):
    yield d
    for c in d.get('features',[]): yield from walk(c)
def read_xml(b):
    require(b'<!DOCTYPE' not in b.upper() and b'<!ENTITY' not in b.upper(),'DTD_OR_ENTITY')
    # Comments/PI are not silently discarded, even though Excel normally ignores them.
    require(b'<!--' not in b and not re.search(br'<\?(?!xml\s)',b),'COMMENTS_OR_PI_UNSUPPORTED')
    try: return ET.fromstring(b)
    except ET.ParseError: raise Hold('MALFORMED_XML')

PARTS=[(r'xl/theme/[^/]+\.xml',A,'theme'),(r'\[Content_Types\]\.xml',C,'Types'),(r'(?:.*/)?_rels/[^/]*\.rels',P,'Relationships'),(r'xl/workbook\.xml',S,'workbook'),(r'xl/styles\.xml',S,'styleSheet'),(r'xl/sharedStrings\.xml',S,'sst'),(r'xl/worksheets/[^/]+\.xml',S,'worksheet'),(r'xl/tables/[^/]+\.xml',S,'table'),(r'xl/comments[^/]*\.xml',S,'comments')]


def coordinate(ref):
    m=re.fullmatch(r'([A-Z]{1,3})([1-9][0-9]*)',ref or '')
    require(m is not None,'INVALID_COORDINATE')
    col=0
    for ch in m[1]: col=col*26+ord(ch)-64
    row=int(m[2]); require(col<=16384 and row<=1048576,'COORDINATE_OUT_OF_BOUNDS')
    return col,row

def cell_range(ref):
    bits=ref.split(':'); require(len(bits)<=2,'AMBIGUOUS_RANGE')
    a=coordinate(bits[0]); b=coordinate(bits[-1]); require(a[0]<=b[0] and a[1]<=b[1],'REVERSED_RANGE')
    return a,b

def resolve_relationship(name,rel):
    base='' if name=='_rels/.rels' else name.rsplit('/_rels/',1)[0]
    target=rel['attributes']['Target']
    return target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(base,target))

def validate_dependencies(parts):
    linked=set(); expected_types={'officeDocument':'workbook','worksheet':'worksheet','styles':'styleSheet','sharedStrings':'sst','theme':'theme','table':'table','comments':'comments'}
    for part,d in parts.items():
        if d['kind']!='Relationships': continue
        for rel in d['features']:
            a=rel['attributes']; typ=a['Type']
            require(typ.startswith(R+'/'),'UNKNOWN_RELATIONSHIP_TYPE')
            short=typ[len(R)+1:]
            require(short in expected_types or short=='hyperlink','UNKNOWN_RELATIONSHIP_TYPE')
            if a.get('TargetMode')=='External':
                require(short=='hyperlink','EXTERNAL_NON_HYPERLINK_UNSUPPORTED'); continue
            target=resolve_relationship(part,rel); linked.add(target)
            require(short in expected_types and parts[target]['kind']==expected_types[short],'RELATIONSHIP_TARGET_KIND')
    require(all(name in linked for name,d in parts.items() if d['kind'] not in ('Types','Relationships')),'UNBOUND_SEMANTIC_PART')
    wb=parts['xl/workbook.xml']; relationships={r['attributes']['Id']:r for r in parts['xl/_rels/workbook.xml.rels']['features']}
    names=[]; ids=[]; targets=[]; sheets=[]
    for sh in [n for n in walk(wb) if n['kind']=='sheet']:
        a=sh['attributes']; require(all(k in a for k in ('name','sheetId','rel:id')),'SHEET_IDENTITY_MISSING')
        names.append(a['name'].casefold()); ids.append(a['sheetId']); rel=relationships.get(a['rel:id'])
        require(rel is not None and rel['attributes'].get('Type')==R+'/worksheet' and rel['attributes'].get('TargetMode','Internal')=='Internal','SHEET_RELATIONSHIP')
        target=resolve_relationship('xl/_rels/workbook.xml.rels',rel); require(target in parts and parts[target]['kind']=='worksheet','SHEET_TARGET')
        targets.append(target); sheets.append({'order':len(sheets),'name':a['name'],'sheet_id':a['sheetId'],'relationship_id':a['rel:id'],'part':target,'visibility':a.get('state','visible')})
    require(len(names)==len(set(names)) and len(ids)==len(set(ids)) and len(targets)==len(set(targets)),'DUPLICATE_SHEET_IDENTITY')
    require(set(targets)=={k for k,v in parts.items() if v['kind']=='worksheet'},'UNBOUND_WORKSHEET')
    styles=parts.get('xl/styles.xml'); xfs=[]
    if styles:
        xfs=next((n['features'] for n in styles['features'] if n['kind']=='cellXfs'),[])
        lookup={n['kind']:n['features'] for n in styles['features'] if 'features' in n}
        fmtids={n['attributes']['numFmtId'] for n in lookup.get('numFmts',[])}
        for xf in lookup.get('cellXfs',[])+lookup.get('cellStyleXfs',[]):
            for attr,container in [('fontId','fonts'),('fillId','fills'),('borderId','borders')]:
                if attr in xf['attributes']: require(0<=int(xf['attributes'][attr])<len(lookup.get(container,[])),'STYLE_DEPENDENCY')
            fmt=xf['attributes'].get('numFmtId','0'); require(int(fmt)<164 or fmt in fmtids,'NUMBER_FORMAT_DEPENDENCY')
        for xf in lookup.get('cellXfs',[]):
            if 'xfId' in xf['attributes']:
                require(0<=int(xf['attributes']['xfId'])<len(lookup.get('cellStyleXfs',[])),'CELL_XF_BASE_STYLE_DEPENDENCY')
        for style in lookup.get('cellStyles',[]):
            require('xfId' in style['attributes'] and 0<=int(style['attributes']['xfId'])<len(lookup.get('cellStyleXfs',[])),'CELLSTYLE_XFID_DEPENDENCY')
    shared=parts.get('xl/sharedStrings.xml'); sharedcount=len(shared['features']) if shared else 0
    for name,d in parts.items():
        authors=next((x['features'] for x in d.get('features',[]) if x['kind']=='authors'),[]) if d['kind']=='comments' else []
        for n in walk(d):
            a=n['attributes']; kind=n['kind']
            if kind=='c':
                coordinate(n['coordinate'])
                if 's' in a: require(0<=int(a['s'])<len(xfs),'CELL_STYLE_DEPENDENCY')
                if a.get('t')=='s':
                    vals=[x['text'] for x in n['features'] if x['kind']=='v']; require(len(vals)==1 and vals[0].isdigit() and int(vals[0])<sharedcount,'SHARED_STRING_DEPENDENCY')
            if kind=='f': require(a.get('t','normal')=='normal','FORMULA_SHARED_ARRAY_DATATABLE_UNSUPPORTED')
            if kind in ('dimension','mergeCell','table','autoFilter','hyperlink') and 'ref' in a: cell_range(a['ref'])
            if kind=='row':
                require(1<=int(a['r'])<=1048576,'ROW_OUT_OF_BOUNDS')
                if 's' in a: require(0<=int(a['s'])<len(xfs),'ROW_STYLE_DEPENDENCY')
            if kind=='col':
                require(1<=int(a['min'])<=int(a['max'])<=16384,'COLUMN_OUT_OF_BOUNDS')
                if 'style' in a: require(0<=int(a['style'])<len(xfs),'COLUMN_STYLE_DEPENDENCY')
            if kind=='comment':
                coordinate(a.get('ref',''))
                require('authorId' in a and 0<=int(a['authorId'])<len(authors),'COMMENT_AUTHOR_DEPENDENCY')
            if 'count' in a and kind in ('mergeCells','tableParts','tableColumns','numFmts','fonts','fills','borders','cellStyleXfs','cellXfs','cellStyles','dxfs'):
                require(int(a['count'])==len(n['features']),'DECLARED_COUNT_MISMATCH')
            if 'rel:id' in a and kind!='sheet':
                relpart=posixpath.dirname(name)+'/_rels/'+posixpath.basename(name)+'.rels'
                require(relpart in parts,'MISSING_RELATIONSHIP_PART')
                candidates=[r for r in parts[relpart]['features'] if r['attributes']['Id']==a['rel:id']]; require(len(candidates)==1,'RELATIONSHIP_ID_UNRESOLVED')
                if kind=='tablePart': require(candidates[0]['attributes']['Type']==R+'/table' and parts[resolve_relationship(relpart,candidates[0])]['kind']=='table','TABLE_DEPENDENCY')
    return sheets

def project(blob, source_id, expected_sha, gate, transforms=None):
    require(source_id not in RESTRICTED,'STRUCTURE_ONLY_ID_PAYLOAD_EXPORT_FORBIDDEN')
    require(sha(blob) not in RESTRICTED_HASHES,'STRUCTURE_ONLY_SOURCE_HASH_FORBIDDEN')
    require(sha(blob)==expected_sha,'SOURCE_IDENTITY_MISMATCH')
    require(gate.get('source_id')==source_id and gate.get('sha256')==expected_sha and gate.get('content_approved') is True,'CONTENT_GATE_REQUIRED')
    require(gate.get('mode') in ('synthetic','reviewed-source'),'INVALID_GATE_MODE')
    require(gate.get('review_reference'),'REVIEW_REFERENCE_REQUIRED')
    parts={}; roots={}; inventory=[]
    try:
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            infos=z.infolist(); names=[i.filename for i in infos]
            require(len(names)==len(set(names)),'DUPLICATE_PART')
            require(len(names)<=1000 and sum(i.file_size for i in infos)<=100_000_000,'PACKAGE_LIMIT')
            for i in infos:
                require(not i.flag_bits&1,'ENCRYPTED_PART')
                require(not i.filename.startswith('/') and '..' not in i.filename.split('/'),'UNSAFE_PART_PATH')
                patterns=[p for p in PARTS if re.fullmatch(p[0],i.filename)]
                require(len(patterns)==1,'UNSUPPORTED_PART:'+i.filename)
                raw=z.read(i); root=read_xml(raw)
                require(split(root.tag)==[patterns[0][1],patterns[0][2]],'PART_ROOT_MISMATCH')
                roots[i.filename]=root; parts[i.filename]=encode(root)
                inventory.append({'part':i.filename,'sha256':sha(raw),'bytes':len(raw)})
    except (zipfile.BadZipFile,RuntimeError): raise Hold('INVALID_ZIP')
    require(all(p in parts for p in ['[Content_Types].xml','_rels/.rels','xl/workbook.xml','xl/_rels/workbook.xml.rels']),'REQUIRED_PART_MISSING')
    for name,root in roots.items():
        if split(root.tag)[0]==P:
            ids=[]
            for rel in root:
                ids.append(rel.attrib['Id'])
                # Preserve an external URL but NEVER fetch it. External workbook links are unsupported parts.
                if rel.attrib.get('TargetMode')=='External': continue
                require(rel.attrib.get('TargetMode','Internal')=='Internal','RELATION_MODE')
                base='' if name=='_rels/.rels' else name.rsplit('/_rels/',1)[0]
                target=posixpath.normpath(posixpath.join(base,rel.attrib['Target']))
                if rel.attrib['Target'].startswith('/'): target=rel.attrib['Target'].lstrip('/')
                require(target in parts,'DANGLING_RELATIONSHIP')
            require(len(ids)==len(set(ids)),'DUPLICATE_RELATIONSHIP')
    sheet_identities=validate_dependencies(parts)
    cells=[]; sheets=[]
    for name,d in parts.items():
        if d['kind']!='worksheet': continue
        rows=[x for x in walk(d) if x['kind']=='row']; rowids=[r['attributes'].get('r') for r in rows]
        require(None not in rowids and len(rowids)==len(set(rowids)),'ROW_COORDINATE')
        coords=[]
        for row in rows:
            for c in row['features']:
                require(re.search(r'\d+$',c['coordinate']).group()==row['attributes']['r'],'CELL_ROW_MISMATCH')
                coords.append(c['coordinate']); cells.append({'part':name,'coordinate':c['coordinate'],'cell':c})
        require(len(coords)==len(set(coords)),'DUPLICATE_CELL')
        sheets.append({'part':name,'stored_rows':[int(r) for r in rowids],'stored_cells':coords})
    proof=[]
    for name,d in parts.items():
        original=semantic(roots[name]); rebuilt=semantic(decode(d))
        require(original==rebuilt,'SEMANTIC_ROUNDTRIP_FAILED')
        require(encode(decode(d))==d,'TYPED_JSON_ROUNDTRIP_FAILED')
        proof.append({'part':name,'source_semantic_sha256':sha(canonical(original)),'projected_semantic_sha256':sha(canonical(rebuilt)),'equal':True})
    result={'schema':'typed-ooxml-local.v1','source':{'source_id':source_id,'sha256':expected_sha,'bytes':len(blob),'review_reference':gate['review_reference']},'claim':'semantic-lossless-original-for-supported-profile','original_zip_byte_reconstruction_claim':False,'source_parts':inventory,'parts':parts,'sheet_identities':sheet_identities,'sparse_sheet_index':sheets,'proof':proof,'transforms':[]}
    for change in transforms or []:
        require(change.get('approval_reference'),'TRANSFORM_APPROVAL_REQUIRED')
        require(set(change)=={'part','coordinate','subfield','sourcevalue_sha256','replacement','approval_reference'},'TRANSFORM_FIELDS')
        matches=[c['cell'] for c in cells if c['part']==change['part'] and c['coordinate']==change['coordinate']]
        require(len(matches)==1,'TRANSFORM_CELL_TARGET')
        require(change['subfield'] in ('v.text','f.text','is.t.text'),'TRANSFORM_SUBFIELD_UNSUPPORTED')
        n=matches[0]
        for k in change['subfield'].split('.')[:-1]:
            m=[x for x in n['features'] if x['kind']==k]; require(len(m)==1,'TRANSFORM_SUBFIELD_TARGET'); n=m[0]
        require(isinstance(change['replacement'],str),'TRANSFORM_REPLACEMENT_TYPE')
        require(sha(n['text'].encode())==change['sourcevalue_sha256'],'TRANSFORM_SOURCEVALUE_MISMATCH')
        n['text']=change['replacement']; result['transforms'].append(change)
    if transforms:
        result['claim']='reviewed-scope-derived-not-semantic-lossless-original'
        result['proof_scope']='proof covers original projection BEFORE exact listed transformations only'
    return result

def validate(blob, projection, gate, approved_transforms=None):
    """Replay from original bytes; untrusted projection cannot authorize its transforms."""
    expected=project(blob,gate['source_id'],gate['sha256'],gate,approved_transforms)
    require(canonical(expected)==canonical(projection),'PROJECTION_REPLAY_MISMATCH')
    return {'status':'PASS_SUPPORTED_PROFILE_REPLAY','projection_sha256':sha(canonical(projection))}

def main():
    p=argparse.ArgumentParser(); p.add_argument('input'); p.add_argument('--id',required=True); p.add_argument('--sha256',required=True); p.add_argument('--gate',required=True); p.add_argument('--output',required=True); p.add_argument('--transforms'); a=p.parse_args()
    try:
        # Reject restricted IDs before opening input or gate.
        require(a.id not in RESTRICTED,'STRUCTURE_ONLY_ID_PAYLOAD_EXPORT_FORBIDDEN')
        inp=Path(a.input); out=Path(a.output); require(inp.resolve()!=out.resolve(),'OUTPUT_OVERWRITES_SOURCE')
        require(not out.exists(),'OUTPUT_EXISTS')
        blob=inp.read_bytes(); result=project(blob,a.id,a.sha256,json.loads(Path(a.gate).read_text()),json.loads(Path(a.transforms).read_text()) if a.transforms else None)
        require(sha(inp.read_bytes())==a.sha256,'SOURCE_MUTATED_DURING_READ')
        out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'status':'PASS_SUPPORTED_SEMANTIC_PROFILE','output':str(out),'source_sha256':a.sha256}))
    except (Hold,KeyError,ValueError,OSError) as e:
        print(json.dumps({'status':'HOLD','reason':str(e) if isinstance(e,Hold) else type(e).__name__})); return 2
    return 0
if __name__=='__main__': raise SystemExit(main())
