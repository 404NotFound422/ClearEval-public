# Partial evidence

No partial scientific records are included. Their frozen status remains in the224-paper catalog, with default eligibility disabled.
