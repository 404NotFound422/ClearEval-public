#!/usr/bin/env python3
"""Offline candidate gate checks. Does not authorize publication or ingestion."""
from pathlib import Path
import json,hashlib,collections,copy,sys,functools
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
@functools.lru_cache(maxsize=None)
def read(n):return json.loads((ROOT/n).read_text())
def check_sets(cat,idx,m):
 assert len(cat)==224 and len({r['paper_id'] for r in cat})==224
 core=[r for r in cat if r.get('core_selected')];assert len(core)==200
 assert collections.Counter('method' if r['primary_category']=='method_development' else r['primary_category'] for r in core)=={'method':75,'application':75,'review':50}
 assert collections.Counter(r['coverage_status'] for r in cat)=={'full':139,'partial':54,'not_finally_accepted':31}
 old=set(m['previous_release_ids']);new=set(m['batch2_candidate_ids'])|set(m['batch3_candidate_ids'])|set(m['batch4_candidate_ids'])|set(m['batch5_candidate_ids'])|set(m['batch6_candidate_ids'])|set(m['batch7_candidate_ids'])|set(m['batch8_candidate_ids'])|set(m['batch9_candidate_ids'])|set(m['batch10_candidate_ids'])|set(m['batch11_candidate_ids']);assert len(old)==9 and len(new)==110 and not old&new
 assert set(idx['default_eligible_ids'])==old and set(idx['candidate_full_ids'])==new
 assert {r['paper_id'] for r in idx['records']}==old|new
 for r in cat:assert r['default_eligible']==(r['paper_id'] in old)
 for r in idx['records']:
  assert r['coverage_status']=='full';assert r['default_eligible']==(r['paper_id'] in old)
  if r['paper_id'] in new:assert r['release_status']=='candidate_pending_gates'
 return old,new
def get_pointer(value, pointer):
 for token in pointer.lstrip('/').split('/'):
  token=token.replace('~1','/').replace('~0','~');value=value[int(token)] if isinstance(value,list) else value[token]
 return value
def check_reference_evidence(selection):
 aliases=selection['active_reference_aliases']
 allowed={f['path'] for f in selection['active_scientific_files']+selection.get('required_supporting_files',[])}
 for e in selection.get('active_reference_resolution_evidence',[]):
  assert e['source_file'] in allowed,'Reference evidence source not selected'
  observed=get_pointer(read(e['source_file']),e['json_pointer']);ref=e['reference']
  if 'reference_extraction' in e:
   rule=e['reference_extraction'];assert observed==e['source_value'] and isinstance(observed,str)
   assert rule['rule']=='semicolon_delimited_component' and rule['delimiter']==';'
   start=rule['start_character_offset'];end=rule['end_character_offset_exclusive'];assert observed[start:end]==ref
   assert observed.split(';')[rule['component_index']]==ref
   assert (start==0 or observed[start-1]==';') and (end==len(observed) or observed[end]==';')
  else:assert observed==ref,'Reference pointer value does not equal claimed reference'
  assert ref in aliases and aliases[ref]==e['resolved_release_path'],'Required reference alias missing or wrong'
  assert e['resolved_release_path'] in allowed,'Reference target outside selected closure'
 return True
def check_alias_binding_proofs(selection, manifests):
 aliases=selection['active_reference_aliases']
 assert not {e['reference'] for e in selection.get('external_or_historical_references',[])} & set(aliases),'Active/external reference classification conflict'
 allowed={f['path'] for f in selection['active_scientific_files']+selection.get('required_supporting_files',[])}
 for b in selection.get('verified_alias_binding_proofs',[]):
  target=b['target'];h=b['hash_value'];assert b['source_file'] in allowed and target in allowed
  assert aliases.get(b['reference'])==target,'Proof alias missing or target changed'
  assert target.split('/')[1]==selection['paper_id'],'Cross-paper proof forbidden'
  source=read(b['source_file'])
  if 'hash_pointer' in b:assert get_pointer(source,b['hash_pointer'])==h,'Hash pointer mismatch'
  for ptr in b.get('source_hash_occurrence_pointers',[]):assert get_pointer(source,ptr)==h,'Source hash occurrence mismatch'
  f=manifests[target];bound={f.get(k) for k in ('source_sha256','accepted_original_sha256','baseline_delivered_sha256','sha256')}
  n=b.get('newline_equivalence')
  if n:
   data=(ROOT/target).read_bytes();assert sha(data)==n['current_sha256'],'LF proof input changed'
   assert n['equivalent_original_sha256']==h and n['parsed_json_equal'] is True
   if n['operation']=='append_one_terminal_LF':equiv=data+b'\n'
   elif n['operation']=='remove_terminal_LF_only':equiv=data.rstrip(b'\n')
   else:raise AssertionError('Unknown newline equivalence')
   assert sha(equiv)==h and json.loads(data)==json.loads(equiv),'Invalid LF proof'
  else:assert h in bound,'Alias hash is not bound to selected source'
 return True
def check_semantic_projection(projection):
 assert projection['caption_count']==15 and len(projection['captions'])==15
 count=0
 for c in projection['captions']:
  obj=read(c['input']['path'])
  try:get_pointer(obj,c['input']['json_pointer'])
  except (KeyError,IndexError):pass
  else:raise AssertionError('Original complete caption remains')
  replacement=get_pointer(obj,c['replacement_pointer'])
  assert replacement['nonverbatim'] is True and replacement['source_caption_sha256']==c['input']['value_sha256']
  assert replacement['source_caption_pointer']==c['input']['json_pointer']
  assert sha(json.dumps(replacement,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==c['replacement_value_sha256']
  for panel in c['panel_fact_coverage']:
   for fact in panel['facts'].values():
    mapping=fact['original_to_proposed_mapping'];assert mapping['original_caption_value_sha256']==c['input']['value_sha256']
    assert get_pointer(obj,mapping['proposed_field_pointer'])==fact['value'],'Semantic fact changed or omitted'
    for ptr in fact.get('existing_coverage_pointers',[]):
     value=get_pointer(read(ptr['path']),ptr['json_pointer']);assert isinstance(value,str) and sha(value.encode())==ptr['value_sha256']
    count+=1
 assert count==projection['fact_count']==336
 for f in projection['files']:assert sha((ROOT/f['path']).read_bytes())==f['v3_sha256'] and f['all_other_fields_equal']
 return True
def check_semantic_source_reference(groups,ref,expected_hash):
 assert ref['file']=='source_payload_semantic_groups.json' and ref['semantic_group_id'] in groups,'Semantic group is missing'
 assert groups[ref['semantic_group_id']]['source_value_sha256']==expected_hash==ref['source_value_sha256'],'Semantic source identity mismatch'
 return True
def check_batch4_semantics():
 proof=read('batch4_semantic_support_verification.json');sm={f['path']:f for f in read('supporting_file_manifest.json')}
 for f in proof['required_generated_support']:
  assert f['path'] in sm and sha((ROOT/f['path']).read_bytes())==f['sha256']
  assert sha(json.dumps(read(f['path']),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==f['canonical_content_sha256']
  s=read('full/'+f['paper_id']+'/version_selection.json');assert f['path'] in {x['path'] for x in s['required_supporting_files']}
 groups=read('full/A107/support/source_payload_semantic_groups.json')['groups'];assert len(groups)==24
 projections=read('batch4_scientific_projection_test_results.json')['records'];assert len(projections)==71
 refs=0;raw=0
 for r in projections:
  path=r['path'];assert sha((ROOT/path).read_bytes())==r['derived_sha256']
  if path.endswith('.json'):obj=read(path);blocks=None
  else:
   import re
   blocks=[json.loads(m.group(1)) for m in re.finditer(r'```json\s*\n(.*?)\n```',(ROOT/path).read_text(),re.S)];obj=None
  for a in r['changes']:
   if a.get('op') not in ['remove_field','replace_string','replace_text_with_semantic_reference']:continue
   value=blocks[a['markdown_json_block_index']] if 'markdown_json_block_index' in a else obj
   ptr=a['json_pointer']
   if a['op']=='replace_string':assert get_pointer(value,ptr)==a['replacement'];continue
   try:get_pointer(value,ptr)
   except (KeyError,IndexError):pass
   else:raise AssertionError('Source payload or internal field removal missing')
   if a['op']=='replace_text_with_semantic_reference':
    ref=get_pointer(value,ptr.rsplit('/',1)[0]+'/semantic_source_ref');assert ref==a['reference']
    check_semantic_source_reference(groups,ref,a['value_sha256']);refs+=1
   elif r['paper_id']!='A107' and a['op']=='remove_field':raw+=1
 assert refs==218 and raw==1257
 s=read('full/A107/version_selection.json');assert 'closed_changes/new_fixed_brain_evidence.json' not in s['active_reference_aliases']
 assert all(not f['path'].endswith('/closed_changes/new_fixed_brain_evidence.json') for f in s['active_scientific_files']+s['required_supporting_files'])
 for f in read('first_three_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior49 per-paper bytes changed'
 return True
def check_semantic_addendum_identity(value, expected_canonical_sha256):
 assert sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==expected_canonical_sha256,'Approved semantic addendum changed'
 return True

def check_subdocument_projections(selection, manifests):
 for p in selection.get('subdocument_alias_projections',[]):
  assert selection['paper_id']=='R016' and p['reference']=='evidence_layer.json'
  assert p['source_pointer_prefix']=='/current_evidence_view' and p['target_pointer_prefix']==''
  target=p['target'];assert selection['active_reference_aliases'].get(p['reference'])==target
  assert manifests[target]['baseline_delivered_sha256']==p['accepted_root_baseline_sha256']
  current=sha(json.dumps(read(target),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
  assert current==p['target_canonical_sha256']==p['original_subtree_canonical_sha256'],'Subdocument equivalence was not preserved'
 return True

def check_batch5_semantics_and_projection():
 for support_proof in read('batch5_semantic_support_verification.json')['required_support']:
  assert sha((ROOT/support_proof['path']).read_bytes())==support_proof['sha256']
  check_semantic_addendum_identity(read(support_proof['path']),support_proof['canonical_sha256'])
 proof=read('batch5_scientific_projection_test_results.json');assert len(proof['records'])==115
 fm=read('source_file_manifest.json');sm=read('supporting_file_manifest.json');manifests={f['path']:f for f in fm+sm}
 for f in read('first_four_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior53 per-paper bytes changed'
 for r in proof['records']:
  assert sha((ROOT/r['path']).read_bytes())==r['derived_sha256'] and r['all_unlisted_structured_fields_unchanged']
  if r['path'].endswith('.json'):
   for a in r['changes']:
    if a.get('operation')=='inherited_source_payload_omission' or a.get('op')=='remove_field':
     try:get_pointer(read(r['path']),a['json_pointer'])
     except (KeyError,IndexError):pass
     else:raise AssertionError('Required source-payload omission not applied')
 for pid,expected in [('A124',(2,7)),('A125',(5,10))]:
  path='full/'+pid+'/support/source_payload_semantic_addenda.json';support=read(path);selection=read('full/'+pid+'/version_selection.json')
  assert path in {f['path'] for f in selection['required_supporting_files']}
  assert len(support['current_required_addenda'])==expected[0]
  assert sum(bool(g['mandatory_nonverbatim_addendum']) for g in support['inherited_source_groups'])==expected[1]
  ids={a['id'] for a in support['current_required_addenda']}
  sourcefiles=[f for f in fm+sm if f.get('paper_id')==pid and 'baseline_delivered_sha256' in f]
  for g in support['current_source_groups']:
   assert set(g['mandatory_addendum_ids'])<=ids
   for occurrence in g['occurrences']:
    matches=[f for f in sourcefiles if f['baseline_delivered_sha256']==occurrence['source_file_sha256']]
    assert len(matches)==1,'Source occurrence lacks a unique selected baseline'
    obj=read(matches[0]['path']);ptr=occurrence['json_pointer']
    if g['classification']=='verbatim_source_copy_payload':
     try:get_pointer(obj,ptr)
     except (KeyError,IndexError):pass
     else:raise AssertionError('Reviewed copied source text still present')
    else:assert sha(get_pointer(obj,ptr).encode())==g['value_sha256'],'Authored scientific summary was changed or removed'
 closure=read('batch5_R016_inherited_object_closure.json');target=read(closure['selected_target'])
 retained={k:target[k] for k in closure['retained_original_keys']}
 assert sha(json.dumps(retained,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==closure['retained_object_canonical_sha256']
 author=get_pointer(target,closure['author_demonstration_target_pointer'])
 assert sha(json.dumps(author,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==closure['author_demonstration_canonical_sha256']
 assert closure['omitted_original_container_key']=='protocol_table'
 assert len(read(closure['protocol_container_supersession_basis']['accepted_mapping_checks']))==35
 check_subdocument_projections(read('full/R016/version_selection.json'),manifests)
 return True

def check_accepted_successor_bindings(proof=None,selection=None):
 proof=read('batch5_A124_accepted_successor_bindings.json') if proof is None else proof;selection=read('full/A124/version_selection.json') if selection is None else selection;fm={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')};assert len(proof['bindings'])==2
 total=0;corrections=0
 for b in proof['bindings']:
  source=read(b['source_file']);assert get_pointer(source,b['reference_pointer'])==b['reference']
  assert get_pointer(source,b['old_source_hash_pointer'])==b['old_source_sha256']
  assert selection['active_reference_aliases'][b['reference']]==b['target']
  assert fm[b['target']]['accepted_original_sha256']==b['accepted_current_source_sha256']
  assert fm[b['current_acceptance_file']]['accepted_original_sha256']==b['current_acceptance_original_sha256']
  target=read(b['target']);succ=next(x for x in selection['accepted_successor_aliases'] if x['reference']==b['reference'])
  assert succ['target']==b['target'] and succ['old_source_sha256']==b['old_source_sha256']
  assert succ['pointer_mapping']=={r['old_pointer']:r['current_pointer'] for r in b['scientific_leaf_mappings']}
  assert succ['historical_metadata_relocations']==b['historical_metadata_relocations']
  for row in b['scientific_leaf_mappings']:
   value=get_pointer(target,row['current_pointer']);assert sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==row['current_canonical_value_sha256']
   assert row['exact_value_equal']==(row['old_canonical_value_sha256']==row['current_canonical_value_sha256']);total+=1;corrections+=not row['exact_value_equal']
  for row in b['historical_metadata_relocations']:
   value=get_pointer(target,row['current_pointer']);assert sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==row['canonical_value_sha256']
 assert total==982 and corrections==3
 return True

def check_required_original_member_aliases(selection, manifests):
 aliases=selection['active_reference_aliases']
 for selected in selection['active_scientific_files']+selection.get('required_supporting_files',[]):
  path=selected['path'];member=manifests[path]['source_member']
  assert isinstance(member,str) and aliases.get(member)==path,'Required selected original-member alias missing or wrong'
 return True

def check_batch6_projection_and_prior_bytes():
 proof=read('batch6_scientific_projection_test_results.json');m=read('release_manifest.json');files={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')};new=set(m['batch6_candidate_ids'])
 expected={p for p,f in files.items() if f.get('paper_id',p.split('/')[1]) in new and not f.get('source_member_kind','').startswith('generated')}
 assert {r['path'] for r in proof['records']}==expected,'New original-member projection closure incomplete'
 for r in proof['records']:
  f=files[r['path']];assert r['original_sha256']==f['source_sha256'] and r['baseline_sha256']==f['baseline_delivered_sha256'] and r['derived_sha256']==f['sha256']==sha((ROOT/r['path']).read_bytes())
  assert r['all_unlisted_structured_fields_unchanged'] is True
 for f in read('first_five_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior63 per-paper bytes changed'

def check_batch7_projection_and_prior_bytes():
 proof=read('batch7_scientific_projection_test_results.json');m=read('release_manifest.json');files={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')};new=set(m['batch7_candidate_ids'])
 expected={p for p,f in files.items() if f.get('paper_id',p.split('/')[1]) in new and not f.get('source_member_kind','').startswith('generated')}
 assert {r['path'] for r in proof['records']}==expected,'New original-member projection closure incomplete'
 for r in proof['records']:
  f=files[r['path']];assert r['original_sha256']==f['source_sha256'] and r['baseline_sha256']==f['baseline_delivered_sha256'] and r['derived_sha256']==f['sha256']==sha((ROOT/r['path']).read_bytes())
  assert r['all_unlisted_structured_fields_unchanged'] is True
 for f in read('first_six_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior75 per-paper bytes changed'

def check_batch7_semantic_support(pid,selection=None,semantic_object=None):
 s=selection or read('full/'+pid+'/version_selection.json');path='full/'+pid+'/support/mandatory_semantic_preservation.json'
 expected={'A121':('f1d2d6eadafb58adba16697683e50955ac3735e11564f21e2383fb457dfe0063',7),'A152':('af5441fed18411e06f9388b492a6e8e8b0627f0f08b412c1ebfc9d46272da365',4)}
 h,n=expected[pid];assert path in {f['path'] for f in s['required_supporting_files']},'Mandatory semantic support missing';assert sha((ROOT/path).read_bytes())==h,'Reviewed semantic preservation changed'
 d=semantic_object if semantic_object is not None else read(path);assert len(d['mandatory_addenda'])==n;ids={a['addendum_id'] for a in d['mandatory_addenda']};groups={g['group_id'] for g in d['source_groups']}
 for a in d['mandatory_addenda']:
  assert sha(json.dumps(a['facts'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==a.get('facts_value_sha256',a.get('canonical_facts_sha256')),'Semantic facts hash mismatch'
  assert set(a.get('source_group_ids',a.get('source_groups',[])))<=groups
 for g in d['source_groups']:assert set(g['mandatory_addendum_ids'])<=ids
 allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']}
 def bindings(o):
  if isinstance(o,dict):
   for k,v in o.items():
    if k=='portable_source_file_bindings':
     assert set(v)<=allowed and all((ROOT/x).is_file() for x in v),'Semantic source binding missing'
    else:bindings(v)
  elif isinstance(o,list):
   for v in o:bindings(v)
 bindings(d)
 assert d['not_new_primary_source_review'] is True

def check_batch7_a152_protocol(selection=None):
 s=selection or read('full/A152/version_selection.json');path='full/A152/support/protocol_records.complete.json'
 entries={f['path']:f for f in s['required_supporting_files']};assert path in entries,'A152 original protocol companion missing'
 f=entries[path];assert f['accepted_original_sha256']=='43f08eeee6b068aaab00d2c14f56c416587c96c37478dc623746c2418f750ec5'
 assert s['active_reference_aliases']['protocol_records.json']==path
 assert path not in {f['path'] for f in s['active_scientific_files']},'Companion incorrectly promoted to root'

def check_batch7_runtime_pointers(pid,selection=None):
 s=selection or read('full/'+pid+'/version_selection.json');bindings=s.get('required_runtime_pointer_bindings',[])
 assert len(bindings)=={'A152':35,'A121':4}[pid],'Required runtime pointer binding count changed'
 allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']}
 for b in bindings:
  assert b['source_file'] in allowed and b['target'] in {f['path'] for f in s['required_supporting_files']}
  sv=get_pointer(read(b['source_file']),b['source_json_pointer']);tv=get_pointer(read(b['target']),b['target_json_pointer'])
  assert sha(json.dumps(sv,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==b['current_source_value_canonical_sha256']
  assert sha(json.dumps(tv,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==b['target_current_value_canonical_sha256']

def check_batch7_supplemental_proofs(selection,manifests):
 s=selection;allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']}
 def chain(c):
  assert c['path'] in allowed;f=manifests[c['path']]
  assert c['original_sha256']==f.get('source_sha256') and c['baseline_sha256']==f.get('baseline_delivered_sha256') and c['current_sha256']==f['sha256']
 def nested(o):
  if isinstance(o,dict):
   if {'path','original_sha256','baseline_sha256','current_sha256'}<=set(o):chain(o)
   for v in o.values():nested(v)
  elif isinstance(o,list):
   for v in o:nested(v)
 keys=['supplemental_reference_binding_proofs','historical_reference_disposition_proofs','supplemental_hash_scoped_manifest_bindings','metadata_only_accepted_final_binding','required_runtime_pointer_bindings','mandatory_semantic_support_source_bindings']
 for k in keys:nested(s.get(k,[]))
 for k in keys[:2]:
  for b in s.get(k,[]):
   assert b['source_file'] in allowed;value=get_pointer(read(b['source_file']),b['source_json_pointer']);assert isinstance(value,str) and sha(value.encode())==b['reference_value_sha256_utf8']
   if k=='supplemental_reference_binding_proofs':assert s['active_reference_aliases'][value]==b['target']
   else:assert any(e['source_file']==b['source_file'] and e['json_pointer']==b['source_json_pointer'] and e['reference']==value and e['automatic_loading'] is False for e in s['external_or_historical_references'])
 for b in s.get('supplemental_hash_scoped_manifest_bindings',[]):
  assert get_pointer(read(b['source_file']),b['source_json_pointer'])==b['declared_target_sha256']
  assert b['declared_target_sha256'] in [b['target_hash_chain']['original_sha256'],b['target_hash_chain']['baseline_sha256']] and b['global_alias_created'] is False
 for b in s.get('mandatory_semantic_support_source_bindings',[]):
  assert b['source_file'] in allowed and b['source_current_sha256']==manifests[b['source_file']]['sha256']
  assert b['target'] in get_pointer(read(b['source_file']),b['source_json_pointer'])
  assert b['source_identity_sha256'] in [b['target_hash_chain']['original_sha256'],b['target_hash_chain']['baseline_sha256']]
 meta=s.get('metadata_only_accepted_final_binding')
 if meta:assert meta['is_raw_byte_alias'] is False and meta['source_receipt_hashes_not_rewritten'] is True

def check_batch8_projection_and_prior_bytes():
 proof=read('batch8_scientific_projection_test_results.json');m=read('release_manifest.json');files={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')};new=set(m['batch8_candidate_ids'])
 expected={p for p,f in files.items() if f.get('paper_id',p.split('/')[1]) in new and not f.get('source_member_kind','').startswith('generated')}
 assert {r['path'] for r in proof['records']}==expected,'New original-member projection closure incomplete'
 for r in proof['records']:
  f=files[r['path']];assert r['original_sha256']==f['source_sha256'] and r['baseline_sha256']==f['baseline_delivered_sha256'] and r['derived_sha256']==f['sha256']==sha((ROOT/r['path']).read_bytes())
  assert r['all_unlisted_structured_fields_unchanged'] is True
 for f in read('first_seven_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior87 per-paper bytes changed'

def check_batch8_a145_semantics(selection=None,semantic_object=None):
 s=selection or read('full/A145/version_selection.json');path='full/A145/support/mandatory_semantic_preservation.json';allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']};manifests={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')}
 assert path in {f['path'] for f in s['required_supporting_files']},'A145 mandatory semantic support missing'
 assert sha((ROOT/path).read_bytes())=='29ccec8739715df9bb5231bdae539f97b32f832b905b18e34534e6b9b1e693ad'
 d=semantic_object if semantic_object is not None else read(path)
 assert len(d['mandatory_addenda'])==5 and len(d['historical_omission_coverage'])==30
 assert sha(json.dumps(d['mandatory_addenda'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())=='283c37bd25c5df330d33d5ae8021f3b93dcb551df4d8dacdb2cd370eb118090b'
 assert [r for r in d['historical_omission_coverage'] if r['decision']=='preserve']==d['mandatory_addenda']
 assert d['historical_payload_restored'] is False and d['current_baseline_fields_deleted']==0 and d['not_new_primary_source_review'] is True
 byhash={}
 for b in d['source_bindings']:
  assert b['portable_path'] in allowed;f=manifests[b['portable_path']]
  assert b['accepted_original_sha256']==f['source_sha256'] and b['baseline_delivered_sha256']==f['baseline_delivered_sha256'];byhash[b['accepted_original_sha256']]=b['portable_path']
 for row in d['historical_omission_coverage']:
  for c in row['current_scientific_coverage']:get_pointer(read(byhash[c['original_sha256']]),c['pointer'])

def check_batch8_m1357_snapshot(selection=None):
 s=selection or read('full/M_N1357/version_selection.json');path='full/M_N1357/support/R2_revised_record.json';support={f['path']:f for f in s['required_supporting_files']}
 assert path in support,'Signed accepted snapshot missing';f=support[path]
 assert f['accepted_original_sha256']==f['source_sha256']==f['baseline_delivered_sha256']=='362a22ff0b2f7999d1de4bdeaf9c0697c799cb0e8b9fac9a512f2a3842368db9'
 assert f['baseline_source_kind']=='existing_local_signed_acceptance_snapshot' and f['original_archive_name'] is None
 assert path not in {f['path'] for f in s['active_scientific_files']},'Old snapshot promoted to current root'

def check_batch8_occurrence_bindings(selection,manifests):
 s=selection;pid=s['paper_id'];rows=s.get('occurrence_scoped_reference_bindings',[])
 expected={('full/M_N1254/support/最终验收依据.json','/accepted_record')} if pid=='M_N1254' else set()
 assert {(b['source_file'],b['json_pointer']) for b in rows}==expected and len(rows)==len(expected),'Required contextual mapping missing or ambiguous'
 allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']};support={f['path'] for f in s['required_supporting_files']};science={f['path'] for f in s['active_scientific_files']}
 for b in rows:
  key=(b['source_file'],b['json_pointer']);assert b['source_file'] in allowed and b['target'] in support and b['target'] not in science
  assert b['source_file'].startswith('full/'+pid+'/') and b['target'].startswith('full/'+pid+'/')
  assert b['automatic_loading'] is False and b['global_alias_unchanged'] is True and b['role']=='nonactive_acceptance_snapshot'
  assert key not in {(e['source_file'],e['json_pointer']) for e in s['active_reference_resolution_evidence']+s['external_or_historical_references']},'Contextual reference has two interpretations'
  assert b['declared_target_hash_pointer']=='/accepted_sha256' and b['target']=='full/M_N1254/support/review/accepted_R1_1_record.json'
  for path,c in [(b['source_file'],b['source_hash_chain']),(b['target'],b['target_hash_chain'])]:
   f=manifests[path];assert c['path']==path and c['original_sha256']==f['source_sha256'] and c['baseline_sha256']==f['baseline_delivered_sha256'] and c['current_sha256']==f['sha256']==sha((ROOT/path).read_bytes())
  value=get_pointer(read(b['source_file']),b['json_pointer']);assert value==b['reference'] and sha(value.encode())==b['source_value_sha256']
  declared=get_pointer(read(b['source_file']),b['declared_target_hash_pointer']);assert declared==b['declared_target_hash_value'] and declared in [b['target_hash_chain']['original_sha256'],b['target_hash_chain']['baseline_sha256']]
  assert s['active_reference_aliases'][b['reference']] in science,'Global current-root alias was changed'

def check_batch8_additional_bindings(s,manifests):
 pid=s['paper_id'];allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']};support={f['path'] for f in s['required_supporting_files']}
 def chain(c):
  p=c['path'];assert p in allowed and p.startswith('full/'+pid+'/');f=manifests[p]
  assert c['original_sha256']==f.get('source_sha256') and c['baseline_sha256']==f.get('baseline_delivered_sha256') and c['current_sha256']==f['sha256']==sha((ROOT/p).read_bytes())
 def ptr(p,q):return get_pointer(read(p),q) if q else read(p)
 def canonical(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
 ordinary={(e['source_file'],e['json_pointer']) for e in s['active_reference_resolution_evidence']+s['external_or_historical_references']}
 rows=s.get('occurrence_scoped_historical_reference_dispositions',[])
 names=['record_R2.json','R2_figures.csv','R2_sample_groups.csv','R2_results.csv','R2_review_rounds.csv','R2_structure_check.json','R2_README_zh.md','R2_reading_log.csv']
 expected={('full/A145/support/package/package_mapping.json','/mapping_from_workspace/history~1'+n) for n in names} if pid=='A145' else set()
 assert len(rows)==len(expected) and {(b['source_file'],b['json_pointer']) for b in rows}==expected
 for b in rows:
  assert (b['source_file'],b['json_pointer']) not in ordinary
  for k in ['source_hash_chain','declared_target_hash_source_chain','rejected_current_alias_target_hash_chain']:chain(b[k])
  assert b['source_file']==b['source_hash_chain']['path'] and b['declared_target_hash_source_file']==b['declared_target_hash_source_chain']['path']
  value=ptr(b['source_file'],b['json_pointer']);assert value==b['reference'] and sha(value.encode())==b['source_value_sha256']
  assert ptr(b['declared_target_hash_source_file'],b['declared_target_hash_pointer'])==b['declared_target_hash_value']
  assert ptr(b['declared_target_hash_source_file'],b['historical_member_name_pointer'])==b['historical_member_name']==b['json_pointer'].split('/')[-1].replace('~1','/')
  assert b['historical_original_member']=='package/'+b['historical_member_name'] and b['automatic_loading'] is False and b['global_alias_unchanged'] is True
  assert b['role']=='excluded_historical_native_mapping_not_current_filename_alias'
  assert s['active_reference_aliases'][value]==b['rejected_current_alias_target']==b['rejected_current_alias_target_hash_chain']['path']
  assert b['declared_target_hash_value'] not in [b['rejected_current_alias_target_hash_chain'][k] for k in ['original_sha256','baseline_sha256','current_sha256']]
 rows=s.get('source_metadata_reference_bindings',[]);expected={'/source_bindings/'+str(i)+'/'+k for i in range(2) for k in ['original_member','portable_path']} if pid=='A145' else set()
 assert len(rows)==len(expected) and {b['source_json_pointer'] for b in rows}==expected
 for b in rows:
  chain(b['source_hash_chain']);chain(b['target_hash_chain']);assert b['source_file']==b['source_hash_chain']['path'] and b['target']==b['target_hash_chain']['path']
  assert (b['source_file'],b['source_json_pointer']) not in ordinary
  value=ptr(b['source_file'],b['source_json_pointer']);assert value==b['reference'] and sha(value.encode())==b['reference_value_sha256_utf8']
  parent=ptr(b['source_file'],b['source_json_pointer'].rsplit('/',1)[0]);assert parent['portable_path']==b['target'] and parent['accepted_original_sha256']==b['target_hash_chain']['original_sha256']
  assert b['role']=='source_version_identity_metadata_not_runtime_reference' and b['original_deleted_pointer_not_asserted_current'] is True
 rows=s.get('required_runtime_pointer_bindings',[]);assert len(rows)=={'REV_38159104':4,'A159':2,'M_N0280':1}.get(pid,0)
 expected_runtime={'REV_38159104': [('full/REV_38159104/evidence/record.json', '/base_record', 'full/REV_38159104/support/REV_38159104/record_R1v2.json', ''), ('full/REV_38159104/evidence/record.json', '/required_correction_overlays/clause_binding_overlay.json/content', 'full/REV_38159104/support/REV_38159104/review_independent/clause_binding_overlay.json', ''), ('full/REV_38159104/evidence/record.json', '/required_correction_overlays/figure2_annotation_overlay.json/content', 'full/REV_38159104/support/REV_38159104/review_independent/figure2_annotation_overlay.json', ''), ('full/REV_38159104/evidence/record.json', '/required_correction_overlays/table3_modality_binding_overlay.json/content', 'full/REV_38159104/support/REV_38159104/review_independent/table3_modality_binding_overlay.json', '')], 'A159': [('full/A159/evidence/record.json', '/statistics', 'full/A159/support/package/statistics.json', ''), ('full/A159/evidence/record.json', '/time_accounting', 'full/A159/support/package/time_accounting.json', '')], 'M_N0280': [('full/M_N0280/evidence/record.json', '/flow_structure', 'full/M_N0280/support/flow_structure.json', '')]}
 assert {(b['source_file'],b['source_json_pointer'],b['target'],b['target_json_pointer']) for b in rows}==set(expected_runtime.get(pid,[]))
 for b in rows:
  chain(b['source_hash_chain']);chain(b['target_hash_chain']);assert b['source_file']==b['source_hash_chain']['path'] and b['target']==b['target_hash_chain']['path'] and b['target'] in support
  a=ptr(b['source_file'],b['source_json_pointer']);v=ptr(b['target'],b['target_json_pointer'])
  assert canonical(a)==b['current_source_value_canonical_sha256'] and canonical(v)==b['target_current_value_canonical_sha256'] and a==v
  assert b['target_is_explicit_required_support'] is True

def check_complete_hash_inventory(sums):
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT))!='SHA256SUMS.json'}
 assert set(sums)==actual,'Unmanifested/missing file including nested hash manifests'


def check_batch9_projection_and_prior_bytes():
 proof=read('batch9_scientific_projection_test_results.json');m=read('release_manifest.json');files={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')};new=set(m['batch9_candidate_ids'])
 expected={p for p,f in files.items() if f.get('paper_id',p.split('/')[1]) in new and not f.get('source_member_kind','').startswith('generated')}
 assert {r['path'] for r in proof['records']}==expected and len(proof['records'])==len(expected),'New original-member projection closure incomplete'
 for r in proof['records']:
  f=files[r['path']];assert r['original_sha256']==f['source_sha256'] and r['baseline_sha256']==f['baseline_delivered_sha256'] and r['derived_sha256']==f['sha256']==sha((ROOT/r['path']).read_bytes())
  assert r['all_unlisted_structured_fields_unchanged'] is True
 for f in read('first_eight_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior99 per-paper bytes changed'


def check_batch9_remaining_gaps():
 d=read('remaining_release_gaps.json');selected={r['paper_id'] for r in read('active_index.json')['records']};full={r['paper_id'] for r in read('catalog/catalog_224.json') if r['coverage_status']=='full'}
 assert len(d['rows'])==d['remaining_full_identity_count']==20 and {r['paper_id'] for r in d['rows']}==full-selected
 assert d['candidate_identity_count']==119 and all(r['science_status']=='full' and r['default_eligible'] is False and r['historical_full_status_changed'] is False for r in d['rows'])
 assert collections.Counter(r['dependency_class'] for r in d['rows'])=={'lossless_workbook_projection_pending':14,'missing_original_reference_identity_hold':2,'isolated_scope_or_privacy_pending':4}
# Suggested portable validator extension. No candidate writes.
# EXPECTED_BATCH9_REFERENCE_PROOFS is inserted below from the applied frozen proof sets.
EXPECTED_BATCH9_REFERENCE_PROOFS = {'A108': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': 'f187ca083ef06b87ab5aa4ee0601f27d585d292cb67db2fea25a98da709cb745', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': 'd1088f5091e78bd94e0e4bf1df8f78a33e17208cfd89d8d356d7e7ad33d98290', 'count': 10}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': 'bb6dd1eba2d74a23827b719d2a71e94498c70de283428c612ccc9dfef0bcf331', 'count': 47}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '98dd922685c56b13e6630db4ecab38feb3b806097ff0227f204cd492f9761938', 'count': 4}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'A111': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '2a536fb2138d6e7323e602b2f7e869f1118b65325811cd4c3d8452ecb4fe20e8', 'count': 5}, 'historical_reference_disposition_proofs': {'canonical_sha256': '3925241b06006b6df7d0ec375ff81edfbefab4b606c2c95dabc47e75e84f9dc2', 'count': 33}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '2626a1d6e93fe5595ad97b78c047219cb0789aa527f5805e231180754544391f', 'count': 63}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': 'ef362072497c4f653c5f876ce845dc769c58c670c77f9af78f7c5b585a2ab4d6', 'count': 22}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'A141': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': 'dad05865bbbfb299ae28368bcd6450228325275cd63c2c8ed5569f3690ac9726', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': '66ffc6063be24596092182c4aaf32b260ed64250d1937d62380f3e0c07deac6d', 'count': 13}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '912a8417470456e36ee662463930a7b59ab3144b0e1b2373a96eb0f1838e139b', 'count': 63}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'A146': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '6db85cc518d08667dd9c67338950ecbd2a4bedeaf54098527492faa4584de2f8', 'count': 13}, 'historical_reference_disposition_proofs': {'canonical_sha256': '4c6eae57b838f5ebb2559812938bc130b2eb9b8205d6f6625194fff998fe2238', 'count': 90}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': 'dafe9849b12410ddfdfa354074fae3413a278a9a688f8d163d53f8069d398579', 'count': 44}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '853ba8e76f7b5d9d207c2527b23b3fdca589aa1ccb1d6c5872888fdc0633fb6e', 'count': 13}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'M008': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '6f15b792b5e550d2bb111e8b3b0f4581881032f50ff712a9a070c0fefe1008f4', 'count': 12}, 'historical_reference_disposition_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '53908ad4a2c6eb66cbb556f734a19ae6ee354481d90cfa0501eab447d35ff164', 'count': 33}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'M043': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '3c01ee7879f7aefeb34d8be7c06a29858ede5320490e60ff3bbac215aeea8e00', 'count': 3}, 'historical_reference_disposition_proofs': {'canonical_sha256': 'db45154353ceb686ccacca950e49ef239fd8ae18ffa4be53f097c6410c0188dd', 'count': 6}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': 'fb7d36bd65669372f238708612a3174e4f14d430d79babe48a4398a27211573e', 'count': 27}, 'metadata_only_accepted_final_binding': {'canonical_sha256': 'db6b6a0e4cfeef23f03d0cbf1a09e60d8c29782f8353edd22f155e12e3260d53', 'count': 1}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'M_N0097': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'historical_reference_disposition_proofs': {'canonical_sha256': 'cceafa32f6383d3b247195392864dd693c44145cc5e470ebd80606a767f180e7', 'count': 2}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '694488423b4f7be37089662c41f845d4c50a6581ead7041067f46ddaf2188780', 'count': 17}, 'metadata_only_accepted_final_binding': {'canonical_sha256': 'c87c5915814cd37fbbec84768b0b186520c7750c98a320a647cc202b57b981d2', 'count': 1}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'REV_28082099': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'historical_reference_disposition_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': 'eda0f9a1a376cdbd9b1747bcc17d04751dbab7f980e9405a58a81537244ab41c', 'count': 43}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '60f0faee6dcb080de3c29135bf416338f5e79ee45d8dafbb450f68d9187a5614', 'count': 1}}}, 'REV_31945400': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '7235b621e375b534367e366e5edf44129aa7adf6b8e7b7d03eaac61fa00226d2', 'count': 2}, 'historical_reference_disposition_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '0ae23965064bab337e0ec5f5b52c2cd59f770357f20adab0123eabf2c0442069', 'count': 11}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '128096904770342888b37fe96c337b7c0f9c2ed2a35c442978b48b6e78efc023', 'count': 11}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '064d99235c0c209d15650c2e58b172ba216dcb448823843dcb36af7e3250f1ee', 'count': 1}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'REV_33981285': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '6c2fec021f876207a5158242111a373eb656b452a43b48e9228f3887fcd6dcff', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': 'db478b08da0eccfc10e20979717f318dc504a672a935052bc5c2afaa84ef48d0', 'count': 2}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '41b3bd0c8140f91063dac33d235f24c3ab7d0731e3538434d508bdcb5608a6d3', 'count': 31}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'REV_33981974': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '0a699e52eb593985e35c5a9f24a79c8abfdff8e80ae2027acb9ce78fa7a0c2a6', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': '231ffe0e57cb58f2b23ff1e09ead703bcede28bf81f7c43f96ebf07e73518e82', 'count': 2}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '8323d8ed57769adb9bf437b76d71091ad91d19d95de5713b6f99bb8338171bd9', 'count': 24}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}, 'REV_40692613': {'spec_sha256': '261f1e041e1114901782c1a2d5a13bd74e97a87dcb0ade75a2c781e3669978ae', 'dispositions_sha256': 'f5bea5899420d196285b5d777f2d820bc01baf914a65cf44a805b30535116003', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': 'af01f5a9220889128d222572cfc7658a3b53755b13c203c920c1646be5b4f167', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': '7dc3fa9389e0bbd286c10bb4df778da11597d61f140c1d4739fdf9ffcf2762e6', 'count': 5}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '74f282b489a5fbbb2d486be02d116c140a05515fc0f8f714af922a4da60b6cbf', 'count': 37}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'composite_frozen_base_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'signed_scientific_compound_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}}}}

def check_batch9_exact_reference_proofs(s, manifests):
 import hashlib, json
 pid=s['paper_id']; expected=EXPECTED_BATCH9_REFERENCE_PROOFS[pid]
 def canonical(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 def point(path,q):
  o=read(path)
  for t in q[1:].split('/') if q else []:
   t=t.replace('~1','/').replace('~0','~');o=o[int(t)] if isinstance(o,list) else o[t]
  return o
 def valuehash(value):return hashlib.sha256(value.encode()).hexdigest()
 allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']};support={f['path'] for f in s['required_supporting_files']};science={f['path'] for f in s['active_scientific_files']}
 def chain(c):
  p=c['path'];assert p in allowed and p.startswith('full/'+pid+'/');f=manifests[p]
  assert c['original_sha256']==f.get('source_sha256') and c['baseline_sha256']==f.get('baseline_delivered_sha256') and c['current_sha256']==f['sha256']==hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
 def nested(o):
  if isinstance(o,dict):
   if {'path','original_sha256','baseline_sha256','current_sha256'}<=set(o):chain(o)
   for v in o.values():nested(v)
  elif isinstance(o,list):
   for v in o:nested(v)
 for key,record in expected['proof_fields'].items():
  actual=s.get(key);assert canonical(actual)==record['canonical_sha256'],(pid,key,'Proof set missing or altered')
  if isinstance(actual,list):assert len(actual)==record['count']
  nested(actual)
 marker=s['reference_closure_supplement'];assert marker['spec_sha256']==expected['spec_sha256'] and marker['dispositions_sha256']==expected['dispositions_sha256']
 ordinary={(e['source_file'],e['json_pointer']) for e in s['active_reference_resolution_evidence']+s['external_or_historical_references']}
 for b in s.get('required_runtime_pointer_bindings',[]):
  assert b['source_file']==b['source_hash_chain']['path'] and b['target']==b['target_hash_chain']['path'] and b['target'] in support
  sv=point(b['source_file'],b['source_json_pointer']);tv=point(b['target'],b['target_json_pointer'])
  assert sv==tv and canonical(sv)==b['current_source_value_canonical_sha256']==b['target_current_value_canonical_sha256']
  assert b['source_and_target_pointers_resolve'] is True and b['target_is_explicit_required_support'] is True
  assert point(b['source_file'],b['declared_original_hash_pointer'])==b['declared_original_hash_value']==b['target_hash_chain']['original_sha256']
  assert b['original_structured_values_equal'] is True and b['not_raw_byte_alias'] is True
 for b in s.get('occurrence_scoped_historical_reference_dispositions',[]):
  assert (b['source_file'],b['json_pointer']) not in ordinary
  ref=point(b['source_file'],b['json_pointer']);assert ref==b['reference'] and valuehash(ref)==b['source_value_sha256']
  assert b['automatic_loading'] is False and b['global_alias_unchanged'] is True
  assert b['role']=='historical_source_occurrence_not_current_filename_alias'
  assert s['active_reference_aliases'][ref]==b['rejected_current_alias_target']==b['rejected_current_alias_target_hash_chain']['path']
  assert b['declared_target_hash_value'] not in [b['rejected_current_alias_target_hash_chain'][k] for k in ['original_sha256','baseline_sha256','current_sha256']]
  if b['declared_target_hash_pointer']:
   assert point(b['source_file'],b['declared_target_hash_pointer'])==b['declared_target_hash_value']
  else:
   assert b['proof'] is not None
   details=b['proof']['proof']
   if 'source_revision_context' in details:
    parent=point(b['source_file'],b['json_pointer'].rsplit('/',1)[0])
    if 'version' in parent:assert parent['version']==details['source_revision_context']
  # External frozen-original proof is attested by the pinned canonical proof set.
  # It is not falsely represented as a published historical file.
 meta=s.get('metadata_only_accepted_final_binding')
 if meta:
  assert meta['signed_acceptance'] in support and meta['normalization_declaration_source'] in support and meta['final_record'] in science
  assert point(meta['signed_acceptance'],meta['signed_accepted_hash_pointer'])==meta['signed_accepted_hash_value']==meta['accepted_snapshot_original_sha256']
  assert point(meta['normalization_declaration_source'],meta['normalization_declaration_pointer'])==meta['excluded_top_level_fields']
  assert point(meta['normalization_declaration_source'],meta['declared_final_hash_pointer'])==meta['declared_final_hash_value']==meta['final_record_original_sha256']==meta['final_record_hash_chain']['original_sha256']
  assert meta['accepted_normalized_canonical_sha256']==meta['final_normalized_canonical_sha256']
  assert set(meta['actual_changed_top_level_keys'])<=set(meta['excluded_top_level_fields'])
  assert meta['is_raw_byte_alias'] is False and meta['creates_additional_runtime_root'] is False and meta['source_receipt_hashes_not_rewritten'] is True
  if 'accepted_snapshot_hash_chain' in meta:
   assert meta['accepted_snapshot'] in support and meta['accepted_snapshot_hash_chain']['original_sha256']==meta['accepted_snapshot_original_sha256']
  else:
   ident=meta['accepted_snapshot_external_original_identity'];assert ident['sha256']==meta['accepted_snapshot_original_sha256'] and ident['automatic_loading'] is False
  if pid=='M043':
   assert point(meta['signed_acceptance'],'/scientific_content_sha256')==meta['accepted_normalized_canonical_sha256']
   assert point(meta['signed_acceptance'],'/scientific_hash_rule/excluded_top_level')==meta['excluded_top_level_fields']
 b=s.get('composite_frozen_base_binding')
 if b:
  assert b['source_file'] in science and b['source_file']==b['source_hash_chain']['path']
  assert canonical(point(b['source_file'],b['source_json_pointer']))==b['current_value_canonical_sha256']
  assert point(b['source_file'],b['declared_original_hash_pointer'])==b['declared_original_hash_value']==b['original_frozen_record_identity']['sha256']
  assert b['original_embedded_values_equal'] is True and b['original_frozen_record_identity']['automatic_loading'] is False
  assert b['additional_runtime_root_created'] is False and b['historical_file_imported'] is False and b['reviewed_overlays_remain_mandatory'] is True
  # Original equality is pinned source-review evidence. Only the current embedded
  # object is re-read here; original historical archive bytes are not packaged.
 compound=s.get('signed_scientific_compound_binding')
 if compound:
  assert compound['count']==len(compound['members'])==10 and compound['metadata_root_is_not_scientific_companion_substitute'] is True
  assert compound['original_acceptance_and_binding_maps_equal'] is True
  targets=set(); receipt_maps=[]; binding_maps=[]
  for b in compound['members']:
   assert b['target'] in support and b['target'] not in science and b['target']==b['target_hash_chain']['path']
   assert b['signed_acceptance'] in support and b['binding_file'] in support
   assert point(b['signed_acceptance'],b['signed_hash_pointer'])==point(b['binding_file'],b['binding_hash_pointer'])==b['declared_sha256']==b['target_hash_chain']['original_sha256']
   assert b['mandatory_scientific_companion'] is True and b['not_standalone_runtime_root'] is True;targets.add(b['target'])
   receipt_maps.append(point(b['signed_acceptance'],b['signed_hash_pointer'].rsplit('/',1)[0]));binding_maps.append(point(b['binding_file'],b['binding_hash_pointer'].rsplit('/',1)[0]))
  assert len(targets)==10 and all(a==receipt_maps[0]==binding_maps[0] and len(a)==10 for a in receipt_maps+binding_maps)


def check_batch10_projection_and_prior_bytes():
 proof=read('batch10_scientific_projection_test_results.json');m=read('release_manifest.json');files={f['path']:f for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')};new=set(m['batch10_candidate_ids'])
 expected={p for p,f in files.items() if f.get('paper_id',p.split('/')[1]) in new and not f.get('source_member_kind','').startswith('generated')}
 assert {r['path'] for r in proof['records']}==expected and len(proof['records'])==len(expected),'New original-member projection closure incomplete'
 for r in proof['records']:
  f=files[r['path']];assert r['original_sha256']==f['source_sha256'] and r['baseline_sha256']==f['baseline_delivered_sha256'] and r['derived_sha256']==f['sha256']==sha((ROOT/r['path']).read_bytes())
  assert r['all_unlisted_structured_fields_unchanged'] is True
 for f in read('first_nine_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior111 per-paper bytes changed'


def check_batch10_snapshot_contexts(s):
 from resolve_reference import resolve_batch10_reference_occurrence
 rows=s.get('occurrence_scoped_reference_bindings',[]);assert len(rows)=={'R006':1,'R023':1}.get(s['paper_id'],0)
 ordinary={(e['source_file'],e['json_pointer']) for e in s['active_reference_resolution_evidence']+s['external_or_historical_references']}
 for b in rows:
  assert (b['source_file'],b['json_pointer']) not in ordinary
  assert resolve_batch10_reference_occurrence(s['paper_id'],b['source_file'],b['json_pointer'],reference=b['reference'],allow_candidate=True)==b['target']
  assert s['active_reference_aliases'][b['reference']]==b['rejected_current_alias_target'] and b['target']!=b['rejected_current_alias_target']
# Exact batch10 proofs; v4 removes transitional duplicate historical/runtime classification.
EXPECTED_BATCH10_REFERENCE_PROOFS = {'M029': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': 'cd991a2d4180f22a77841ce3a09847c52f8c51b4e8af7e2417382e14d3103f7c', 'count': 6}, 'historical_reference_disposition_proofs': {'canonical_sha256': 'dad3bfdc01db8996aba6c6f5fdd2e73282279fdb75aff399db8cf137ec3972c4', 'count': 4}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '4d0cd7f888e37322789ecc71ef0de77d961d1936b00070b13452ef9509bbf7b6', 'count': 45}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'resolved_reference_context_audit': {'canonical_sha256': 'e16c6d35573649fad9098ade9ad997a2792c7e4c017ec67ff77ca8a17622c89c', 'count': 65}, 'signed_current_companion_bindings': {'canonical_sha256': '2fa13c2a2736ac2c7a5005a87df908b04748db529282d7a077c3f6a9eaab6eed', 'count': 1}, 'embedded_source_component_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}}}, 'M_N0022': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': 'e7738a2ef1609517f98b8ce884263126f1c5d051bc1a0cb744d66ff367188cc2', 'count': 11}, 'historical_reference_disposition_proofs': {'canonical_sha256': '9100019298a28735c95e17076e3effc048c58d5a34b31469fe5c57bd414cca07', 'count': 2}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '218fbd39b5a9c993d7417fd4fae11d405dee2eaefabbcc7f2e10a5a8b8c2a12a', 'count': 1}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'resolved_reference_context_audit': {'canonical_sha256': '36386ffdcda09b9e6e44f52e1e5fa08274e13d08e7638a7da060219609392855', 'count': 55}, 'signed_current_companion_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'embedded_source_component_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}}}, 'R006': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '15becac0a511e490d7994ee0c940af198eaa6b8b13cc3fe1d003aca75afe545d', 'count': 2}, 'historical_reference_disposition_proofs': {'canonical_sha256': '5c1fff667d60d06f9fe0aa94a56f2819d9fe2f942f4d9bd3470ab41ab0e6859b', 'count': 28}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': 'b7fcc85cb214c3303919b6cac318bf54d90e54e134b180cd68d0a9cd9bec40e0', 'count': 42}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '8549c402d1b9c74a09720fd380c4c55fb3cd88399bf0685e99bd3985c22ce4e6', 'count': 1}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': 'c62840e598d13d0efff156ca3d7168e3c587fb1cff4463f30be1286cf7f8b5a7', 'count': 1}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '34e490743539b573b299ee42419e469ebef6a4b7d145295b97a5eb3801c98f5f', 'count': 2}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'resolved_reference_context_audit': {'canonical_sha256': '0aa4db95ac1eb06edd5a739480e9fb2066779bc0610719eecbd515ce5736a919', 'count': 81}, 'signed_current_companion_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'embedded_source_component_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}}}, 'R009': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'historical_reference_disposition_proofs': {'canonical_sha256': '6940085b245596eebaade4e9f4763a61c1af3f9c2f47978509d7fb42dc11a90a', 'count': 44}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '49f912df90ab9212604d6015faade1b515b0a3b3e8392d665292736dd94e9c2d', 'count': 9}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': 'c04e6af97686238b8190990ffcc41e27e87a8b3cc9d2b295fb0fa23a3b1554b6', 'count': 3}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'resolved_reference_context_audit': {'canonical_sha256': '3354ab2577e4942ed0eebaa367c46ada81366f545c7982c8ef9b7bc670d8294f', 'count': 41}, 'signed_current_companion_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'embedded_source_component_bindings': {'canonical_sha256': '50a93390b1a58dc9fed5f39a4f5b94e2b1019d18dbfed007fb02764372488515', 'count': 2}}}, 'R017': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'historical_reference_disposition_proofs': {'canonical_sha256': 'ded868ee90102de68c811836c04f26f04333ba00ed1a1ea8ea9550653d84d44d', 'count': 52}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': 'b77626158fee5765234dc39d05cf533cd88052e9096776a5d1dc23e3445b3ab1', 'count': 2}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '2a677ea99454f26914948ece376f7ee222df437fca91ccadd55c6f05822839bb', 'count': 1}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '11dddbfb5dd8e82a962190be637c496891b8f395e72f0fac09c49fed4d908f6b', 'count': 5}, 'resolved_reference_context_audit': {'canonical_sha256': 'cf36abeffe24487e9e3110439c94a6940db49844e920f7a8d2ad608278b76535', 'count': 8}, 'signed_current_companion_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'embedded_source_component_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}}}, 'R022': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': 'caf1e5d39f2e8b5ae9eeac786a7fe45e19d33a6ee639651e67a29bb2a96f01d4', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': '0fcc2ca244bb85f329a4542fd14550bb0d5060e966f9f41c7d919db6e330e512', 'count': 41}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': 'c329f6f1e7e8977d7f38494cde18744a39370cf3c445b9eb4a3d78391cf99cd8', 'count': 45}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'resolved_reference_context_audit': {'canonical_sha256': '4d28ca62e1d5d157bb8e52f14709d9f55dfbbf01257672e9c6965eb17c33742c', 'count': 126}, 'signed_current_companion_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'embedded_source_component_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}}}, 'R023': {'spec_sha256': '4a6dd272ae0f3f6d50a778b2726dbd3d34099504b06e67ee656fb2dd65fa02f9', 'dispositions_sha256': '96c6b7a8d16354b909184b0cad6e89b425dcbb26fe8fbade5d57b9dc750bb42c', 'proof_fields': {'supplemental_reference_binding_proofs': {'canonical_sha256': '8437f4e774b92362eb1951ba25bef6bd277e6ff9cb21f3d97fa1d0dfefe0fa82', 'count': 1}, 'historical_reference_disposition_proofs': {'canonical_sha256': '85860c32a3f97ce5b73cbce0dd2380cc03051347c67e3c4b2fcd45ba9b9ec934', 'count': 2}, 'supplemental_hash_scoped_manifest_bindings': {'canonical_sha256': '60f11e178fef2dd52b28c9b8264f86c98754bdea661ea8f60c22ed7bd8cabb32', 'count': 33}, 'metadata_only_accepted_final_binding': {'canonical_sha256': '74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b', 'count': 0}, 'required_runtime_pointer_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_reference_bindings': {'canonical_sha256': 'dcc0d4a42444205cd62eb6363816bf99396de225003e878857207230fe55ce19', 'count': 1}, 'occurrence_scoped_historical_reference_dispositions': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'occurrence_scoped_subdocument_projections': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'mandatory_local_companion_identity_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'resolved_reference_context_audit': {'canonical_sha256': 'a62daeda8516c69d41717f7ba4e45f0a5120b8e770711a829e4bdf739b7bd954', 'count': 111}, 'signed_current_companion_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}, 'embedded_source_component_bindings': {'canonical_sha256': '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945', 'count': 0}}}}

def check_batch10_exact_reference_proofs(s, manifests):
 import hashlib, json
 pid=s['paper_id']; expected=EXPECTED_BATCH10_REFERENCE_PROOFS[pid]
 def canonical(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 def point(path,q):
  o=read(path)
  for t in q[1:].split('/') if q else []:
   t=t.replace('~1','/').replace('~0','~');o=o[int(t)] if isinstance(o,list) else o[t]
  return o
 def valuehash(value):return hashlib.sha256(value.encode()).hexdigest()
 allowed={f['path'] for f in s['active_scientific_files']+s['required_supporting_files']};support={f['path'] for f in s['required_supporting_files']};science={f['path'] for f in s['active_scientific_files']}
 def chain(c):
  p=c['path'];assert p in allowed and p.startswith('full/'+pid+'/');f=manifests[p]
  assert c['original_sha256']==f.get('source_sha256') and c['baseline_sha256']==f.get('baseline_delivered_sha256') and c['current_sha256']==f['sha256']==hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
 def nested(o):
  if isinstance(o,dict):
   if {'path','original_sha256','baseline_sha256','current_sha256'}<=set(o):chain(o)
   for v in o.values():nested(v)
  elif isinstance(o,list):
   for v in o:nested(v)
 for key,record in expected['proof_fields'].items():
  actual=s.get(key);assert canonical(actual)==record['canonical_sha256'],(pid,key,'Proof set missing or altered')
  if isinstance(actual,list):assert len(actual)==record['count']
  nested(actual)
 marker=s['reference_closure_supplement'];assert marker['spec_sha256']==expected['spec_sha256'] and marker['dispositions_sha256']==expected['dispositions_sha256']
 ordinary={(e['source_file'],e['json_pointer']) for e in s['active_reference_resolution_evidence']+s['external_or_historical_references']}
 for b in s.get('required_runtime_pointer_bindings',[]):
  assert b['source_file']==b['source_hash_chain']['path'] and b['target']==b['target_hash_chain']['path'] and b['target'] in support
  sv=point(b['source_file'],b['source_json_pointer']);tv=point(b['target'],b['target_json_pointer'])
  assert canonical(sv)==b['current_source_value_canonical_sha256'] and canonical(tv)==b['target_current_value_canonical_sha256']
  if b['binding_kind']=='equal_structured_values':assert sv==tv
  elif b['binding_kind']=='explicit_file_fragment_reference':assert sv=='inherited_status.json#'+b['target_json_pointer'] and b['target_json_pointer']=='/inherited_remaining_unreviewed'
  else:raise AssertionError('Unknown runtime binding kind')
  assert b['source_and_target_pointers_resolve'] is True and b['target_is_explicit_required_support'] is True
 for b in s.get('occurrence_scoped_reference_bindings',[]):
  assert (b['source_file'],b['json_pointer']) not in ordinary
  assert b['source_file']==b['source_hash_chain']['path'] and b['target']==b['target_hash_chain']['path']
  assert b['target'] in support and b['target'] not in science
  ref=point(b['source_file'],b['json_pointer']);assert ref==b['reference'] and valuehash(ref)==b['source_value_sha256']
  assert point(b['source_file'],b['declared_target_hash_pointer'])==b['declared_target_hash_value']
  assert b['declared_target_hash_value'] in [b['target_hash_chain']['original_sha256'],b['target_hash_chain']['baseline_sha256']]
  assert b['automatic_loading'] is False and b['global_alias_unchanged'] is True and s['active_reference_aliases'][ref]==b['rejected_current_alias_target']!=b['target']
  assert b['role']==('nonactive_finalization_review_support' if pid=='R023' else 'nonactive_acceptance_snapshot')
 for b in s.get('occurrence_scoped_historical_reference_dispositions',[]):
  assert (b['source_file'],b['json_pointer']) not in ordinary
  ref=point(b['source_file'],b['json_pointer']);assert ref==b['reference'] and valuehash(ref)==b['source_value_sha256']
  assert b['automatic_loading'] is False and b['global_alias_unchanged'] is True
  assert b['role']=='historical_source_occurrence_not_current_filename_alias'
  assert s['active_reference_aliases'][ref]==b['rejected_current_alias_target']==b['rejected_current_alias_target_hash_chain']['path']
  assert b['declared_target_hash_value'] not in [b['rejected_current_alias_target_hash_chain'][k] for k in ['original_sha256','baseline_sha256','current_sha256']]
  if b['declared_target_hash_pointer']:
   assert point(b['source_file'],b['declared_target_hash_pointer'])==b['declared_target_hash_value']
  else:
   assert b['proof'] is not None
   details=b['proof']['proof']
   if 'source_revision_context' in details:
    parent=point(b['source_file'],b['json_pointer'].rsplit('/',1)[0])
    if 'version' in parent:assert parent['version']==details['source_revision_context']
  # External frozen-original proof is attested by the pinned canonical proof set.
  # It is not falsely represented as a published historical file.
 meta=s.get('metadata_only_accepted_final_binding')
 if meta:
  assert meta['signed_acceptance'] in support and meta['normalization_declaration_source'] in support and meta['final_record'] in science
  assert point(meta['signed_acceptance'],meta['signed_accepted_hash_pointer'])==meta['signed_accepted_hash_value']==meta['accepted_snapshot_original_sha256']
  assert point(meta['normalization_declaration_source'],meta['normalization_declaration_pointer'])==meta.get('normalization_declaration_value',meta['excluded_top_level_fields'])
  assert point(meta['normalization_declaration_source'],meta['declared_final_hash_pointer'])==meta['declared_final_hash_value']==meta['final_record_original_sha256']==meta['final_record_hash_chain']['original_sha256']
  assert meta['accepted_normalized_canonical_sha256']==meta['final_normalized_canonical_sha256']
  assert set(meta['actual_changed_top_level_keys'])<=set(meta['excluded_top_level_fields'])
  assert meta['is_raw_byte_alias'] is False and meta['creates_additional_runtime_root'] is False and meta['source_receipt_hashes_not_rewritten'] is True
  if 'accepted_snapshot_hash_chain' in meta:
   assert meta['accepted_snapshot'] in support and meta['accepted_snapshot_hash_chain']['original_sha256']==meta['accepted_snapshot_original_sha256']
  else:
   ident=meta['accepted_snapshot_external_original_identity'];assert ident['sha256']==meta['accepted_snapshot_original_sha256'] and ident['automatic_loading'] is False
  if pid=='M_N0022':assert point(meta['signed_acceptance'],meta['signed_projection_keys_pointer'])==meta['signed_projection_keys']
  if pid=='M_N0022':assert point(meta['signed_acceptance'],meta['signed_projection_hash_pointer'])==meta['signed_projection_canonical_sha256']
 for b in s.get('supplemental_reference_binding_proofs',[]):
  ref=point(b['source_file'],b['source_json_pointer']);assert valuehash(ref)==b['reference_value_sha256_utf8']
  assert s['active_reference_aliases'][ref]==b['target'] and b['target'] in allowed
 for b in s.get('historical_reference_disposition_proofs',[]):
  value=point(b['source_file'],b['source_json_pointer']);assert valuehash(value)==b['reference_value_sha256_utf8']
  assert any(e['source_file']==b['source_file'] and e['json_pointer']==b['source_json_pointer'] and e['reference']==value and e['automatic_loading'] is False for e in s['external_or_historical_references'])
 for b in s.get('supplemental_hash_scoped_manifest_bindings',[]):
  assert point(b['source_file'],b['source_json_pointer'])==b['declared_target_sha256']
  assert b['declared_target_sha256'] in [b['target_hash_chain']['original_sha256'],b['target_hash_chain']['baseline_sha256']]
 for b in s.get('resolved_reference_context_audit',[]):
  assert point(b['source_file'],b['json_pointer'])==b['reference']
  for h in b['declared_hash_checks']:
   if h['json_pointer'] is not None:assert point(b['source_file'],h['json_pointer'])==h['declared_sha256']
 for b in s.get('occurrence_scoped_subdocument_projections',[]):
  assert pid=='R017' and b['target'] in science and b['source_file'] in support
  assert point(b['source_file'],b['source_reference_pointer'])==b['reference']=='evidence_layer.json'
  assert point(b['source_file'],b['source_pointer_declaration'])==b['source_pointer_prefix']=='/current_evidence_view'
  assert b['original_ancestor_identity']['sha256']=='ed8bdb42a655d198219826559a4658f281bc4a927b5210561a8e21fe02caaf78'
  assert b['reference'] not in s['active_reference_aliases']
  assert canonical(point(b['target'],''))==b['target_current_value_canonical_sha256']
  assert b['target_pointer_prefix']=='' and b['global_alias_created'] is False and b['historical_ancestor_automatic_loading'] is False
  assert b['exact_original_subtree_deep_equal'] is True and b['not_raw_byte_alias'] is True and b['arbitrary_same_name_pointer_stripping_forbidden'] is True
  assert (b['source_file'],b['source_reference_pointer']) not in ordinary
 companions=s.get('mandatory_local_companion_identity_bindings',[])
 assert len(companions)==(5 if pid=='R017' else 0)
 for b in companions:
  assert b['target'] in support and b['target'] not in science and b['must_load_as_required_support'] is True and b['standalone_runtime_root'] is False
  assert b['original_sha256']==b['target_hash_chain']['original_sha256']==b['manifest_identity']['row']['sha256']
  assert b['original_bytes']==b['manifest_identity']['row']['bytes'];point(b['target'],'')
 for b in s.get('signed_current_companion_bindings',[]):
  assert b['target'] in support and b['target'] not in science and b['signed_acceptance'] in support
  assert point(b['signed_acceptance'],b['signed_file_pointer'])==b['signed_file_value']
  assert point(b['signed_acceptance'],b['signed_hash_pointer'])==b['declared_original_sha256']==b['target_hash_chain']['original_sha256']
  assert b['mandatory_current_companion'] is True and b['not_standalone_root'] is True
 for b in s.get('embedded_source_component_bindings',[]):
  assert b['source_file'] in science and canonical(point(b['source_file'],b['source_json_pointer']))==b['current_component_canonical_sha256']
  assert b['standalone_original_file_required'] is False and b['raw_byte_alias_claim'] is False
 return True

def check_batch11_workbook_and_companions():
 import workbook_reference_resolver as w
 w.ROOT=ROOT
 sel=read('full/A103/version_selection.json');ctx=w._context('A103',True);assert len(ctx[-1])==1
 b=ctx[-1][0];w._load_projection(ctx,b)
 assert b['original_sha256']=='25f32b99dfc4ea0f1cdf42bd0c0d0380b80bb78e6f8df1c400c752ef7f619147'
 assert b['portable_sha256']=='ec125c1739dd8818d520b67c6e7a8ce5971ed653f49fdec8c563f889d56e9423'
 assert len(sel['active_scientific_files'])==4 and len(sel['required_supporting_files'])==18
 required=sel['required_A103_antecedent_bindings'];assert len(required)==8
 support={f['path']:f for f in sel['required_supporting_files']}
 for r in required:
  assert r['path'] in support and sha((ROOT/r['path']).read_bytes())==r['sha256']==support[r['path']]['sha256']
  assert r['source_sha256']==support[r['path']]['source_sha256']
  assert r['original_member'] in sel['active_reference_aliases'] and sel['active_reference_aliases'][r['original_member']]==r['path']
 accept=read(sel['acceptance'])
 for ref in accept['audit_records']:
  assert ref in sel['active_reference_aliases']
  assert sel['active_reference_aliases'][ref] in {r['path']for r in required}
 assert sel['active_reference_aliases']['sources/diameter_data_check.json']=='full/A103/support/package/historical_exact_scientific_snapshot/source_checks/diameter_data_check.json'
 root=read('full/A103/evidence/A103_evidence.json');ref=root['quality_status']['structural_check'];assert sel['active_reference_aliases'][ref] in {r['path']for r in required}
 for f in read('first_ten_batches_immutable_files.json')['files']:
  assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior118 scientific/support bytes changed'
 records=read('batch11_scientific_projection_test_results.json')['records']
 assert {r['path']for r in records}=={f['path']for f in read('source_file_manifest.json')+read('supporting_file_manifest.json')if f.get('paper_id',f['path'].split('/')[1])=='A103'}
 assert all(r['all_unlisted_structured_fields_unchanged']for r in records)
 return True

def main():
 cat=read('catalog/catalog_224.json');idx=read('active_index.json');m=read('release_manifest.json');old,new=check_sets(cat,idx,m)
 assert len(read('catalog/historical117_crosswalk.json'))==117 and len(read('catalog/historical96_complete_crosswalk.json'))==96
 sums=read('SHA256SUMS.json');check_complete_hash_inventory(sums)
 for n,h in sums.items():
  p=ROOT/n;assert not Path(n).is_absolute() and '..' not in Path(n).parts
  assert p.suffix in {'.json','.md','.py','.csv','.txt'} and sha(p.read_bytes())==h,'Forbidden format or hash mismatch: '+n
  assert not any(x in p.read_text() for x in ('/'+'workspace'+'/scratch/','/'+'workspace'+'/shared/','/'+'home'+'/agent/')),'Local absolute path leaked'
 fm=read('source_file_manifest.json');sm=read('supporting_file_manifest.json');assert len(fm)==456 and len(sm)==1709
 for f in fm+sm:assert sha((ROOT/f['path']).read_bytes())==f['sha256']
 allpaths={f['path'] for f in fm+sm};seen=[];seen_support=[]
 from resolve_reference import resolve_reference
 for r in idx['records']:
  s=read(r['version_selection']);assert s['paper_id']==r['paper_id'] and s['default_eligible']==r['default_eligible'];assert s['active_scientific_files']==r['active_scientific_files']
  science={f['path'] for f in s['active_scientific_files']};support={f['path'] for f in s.get('required_supporting_files',[])};assert s['acceptance'] in science|support
  assert set(s.get('acceptance_files',[s['acceptance']]))<=science|support
  assert set(s['original_member_to_release_path'].values())==science
  assert set(s['active_reference_aliases'].values())<=science|support
  assert science|support<=allpaths
  assert s.get('required_supporting_files',[])==r.get('required_supporting_files',[])
  check_reference_evidence(s);check_alias_binding_proofs(s,{f['path']:f for f in fm+sm});seen_support+=list(support)
  if r['paper_id'] in m['batch7_candidate_ids']+m['batch8_candidate_ids']+m['batch9_candidate_ids']+m['batch10_candidate_ids']:check_batch7_supplemental_proofs(s,{f['path']:f for f in fm+sm})
  if r['paper_id'] in m['batch10_candidate_ids']:check_batch10_exact_reference_proofs(s,{f['path']:f for f in fm+sm});check_batch10_snapshot_contexts(s)
  if r['paper_id'] in m['batch9_candidate_ids']:check_batch9_exact_reference_proofs(s,{f['path']:f for f in fm+sm})
  if r['paper_id'] in m['batch8_candidate_ids']:check_batch8_occurrence_bindings(s,{f['path']:f for f in fm+sm});check_batch8_additional_bindings(s,{f['path']:f for f in fm+sm})
  if r['paper_id'] in m['batch5_candidate_ids']+m['batch6_candidate_ids']+m['batch7_candidate_ids']+m['batch8_candidate_ids']+m['batch9_candidate_ids']+m['batch10_candidate_ids']:check_required_original_member_aliases(s,{f['path']:f for f in fm+sm})
  workbook_aliases={a for b in s.get('workbook_representation_bindings',[]) for a in b['original_aliases']}
  for ref,target in s['active_reference_aliases'].items():
   if ref in workbook_aliases:
    try:resolve_reference(r['paper_id'],ref,allow_candidate=True)
    except ValueError as exc:assert str(exc)=='WORKBOOK_ALIAS_REQUIRES_DEDICATED_API'
    else:raise AssertionError('Original XLSX alias silently treated as JSON bytes')
   else:assert resolve_reference(r['paper_id'],ref,allow_candidate=True)==target
  for n in s['active_version_and_scope'].get('historical_nonactive_members',[]):assert n not in s['original_member_to_release_path']
  seen+=list(science)
 assert len(seen)==len(set(seen))==456
 assert len(seen_support)==len(set(seen_support))==1709 and set(seen_support)=={f['path'] for f in sm},'Required support closure incomplete'
 for f in read('first_release_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'First-release per-paper bytes changed'
 for f in read('first_two_batches_immutable_files.json')['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],'Prior29 per-paper bytes changed'
 proof=read('batch2_scientific_projection_test_results.json');assert proof['result']=='PASS' and len(proof['records'])==122
 assert all(r['scientific_structure_and_values_preserved'] for r in proof['records'])
 third=read('batch3_scientific_projection_test_results.json');assert len(third['records'])==131 and all(x['scientific_projection_preserved'] for x in third['records'])
 for t in read('transformation_manifest.json')['batch3_transforms']:
  if t['path'].endswith('.json'):
   obj=read(t['path'])
   for change in t['changes']:
    if change['operation'] in ['inherited_original_source_payload_omission','proposed_explicit_long_original_source_payload_omission','reviewed_long_original_source_payload_omission']:
     try:get_pointer(obj,change['json_pointer'])
     except (KeyError,IndexError):pass
     else:raise AssertionError('Omitted source payload remains in candidate')
 check_semantic_projection(read('batch3_caption_semantic_projection_v3.json'))
 check_batch4_semantics()
 check_batch5_semantics_and_projection()
 check_batch6_projection_and_prior_bytes()
 check_batch7_projection_and_prior_bytes()
 check_batch8_projection_and_prior_bytes()
 check_batch9_projection_and_prior_bytes()
 check_batch10_projection_and_prior_bytes()
 check_batch11_workbook_and_companions()
 check_batch9_remaining_gaps()
 check_batch8_a145_semantics()
 check_batch8_m1357_snapshot()
 check_batch7_semantic_support("A121")
 check_batch7_semantic_support("A152")
 check_batch7_a152_protocol()
 check_batch7_runtime_pointers("A152")
 check_batch7_runtime_pointers("A121")
 check_accepted_successor_bindings()
 tests=[]
 for name,mut in [('partial_or_candidate_not_default_eligible',lambda c,i,m:next(r for r in c if r['paper_id'] in new).update(default_eligible=True)),('unpublished_not_eligible',lambda c,i,m:i['default_eligible_ids'].append('NOT_PUBLISHED')),('core_membership_immutable',lambda c,i,m:next(r for r in c if r['core_selected']).update(core_selected=False))]:
  c,i,mm=copy.deepcopy((cat,idx,m));mut(c,i,mm)
  try:check_sets(c,i,mm)
  except AssertionError:tests.append({'test':name,'passed':True})
  else:raise AssertionError('Negative test failed')
 broken=copy.deepcopy(read('full/APP233/version_selection.json'))
 del broken['active_reference_aliases']['private_sources/video_samples.json']
 try:check_reference_evidence(broken)
 except AssertionError:tests.append({'test':'required_support_alias_deletion_rejected','passed':True})
 else:raise AssertionError('Required alias deletion was not rejected')
 broken=copy.deepcopy(read('full/APP233/version_selection.json'))
 item=next(e for e in broken['active_reference_resolution_evidence'] if 'reference_extraction' in e)
 item['reference_extraction']['start_character_offset']+=1
 try:check_reference_evidence(broken)
 except AssertionError:tests.append({'test':'composite_locator_wrong_token_offset_rejected','passed':True})
 else:raise AssertionError('Wrong token offset was not rejected')
 for mode in ['active_external_conflict','forged_alias_hash','forged_hash_pointer','forged_newline_proof']:
  paper='M_N0050' if mode=='forged_hash_pointer' else ('A136' if mode=='forged_newline_proof' else 'A153')
  broken=copy.deepcopy(read('full/'+paper+'/version_selection.json'))
  b=broken['verified_alias_binding_proofs'][0]
  if mode=='active_external_conflict':broken['external_or_historical_references'].append({'reference':b['reference']})
  elif mode=='forged_alias_hash':b['hash_value']='0'*64
  elif mode=='forged_hash_pointer':b['hash_pointer']='/nonexistent_sha256'
  else:b['newline_equivalence']['equivalent_original_sha256']='0'*64
  try:check_alias_binding_proofs(broken,{f['path']:f for f in fm+sm})
  except (AssertionError,KeyError):tests.append({'test':mode+'_rejected','passed':True})
  else:raise AssertionError('Invalid proof was not rejected')
 broken=copy.deepcopy(read('batch3_caption_semantic_projection_v3.json'))
 broken['captions'][0]['panel_fact_coverage'][0]['facts'][next(iter(broken['captions'][0]['panel_fact_coverage'][0]['facts']))]['value']='FORGED_SEMANTIC_VALUE'
 try:check_semantic_projection(broken)
 except AssertionError:tests.append({'test':'semantic_caption_fact_tamper_rejected','passed':True})
 else:raise AssertionError('Semantic fact forgery accepted')
 groups=read('full/A107/support/source_payload_semantic_groups.json')['groups'];gid=next(iter(groups));h=groups[gid]['source_value_sha256'];ref={'file':'source_payload_semantic_groups.json','semantic_group_id':gid,'source_value_sha256':h}
 for name,g,rr in [('missing_semantic_group_rejected',{k:v for k,v in groups.items() if k!=gid},ref),('semantic_source_identity_mismatch_rejected',groups,{**ref,'source_value_sha256':'0'*64})]:
  try:check_semantic_source_reference(g,rr,h)
  except AssertionError:tests.append({'test':name,'passed':True})
  else:raise AssertionError('Invalid semantic dependency accepted')
 for paper,ref in [('APP219','record_R1.json'),('APP232','paper_completion/APP232/independent_review/independent_review_receipt_v1_superseded.json'),('A106','record.json'),('A133','evidence_current.json')]:
  try:resolve_reference(paper,ref)
  except KeyError:pass
  else:raise AssertionError('History/unpublished/candidate resolved by default')
 for mode in ['wrong_subdocument_prefix','wrong_subdocument_hash']:
  broken=copy.deepcopy(read('full/R016/version_selection.json'));p=broken['subdocument_alias_projections'][0]
  if mode=='wrong_subdocument_prefix':p['source_pointer_prefix']='/historical_evidence'
  else:p['original_subtree_canonical_sha256']='0'*64
  try:check_subdocument_projections(broken,{f['path']:f for f in fm+sm})
  except AssertionError:tests.append({'test':mode+'_rejected','passed':True})
  else:raise AssertionError('Invalid subtree mapping accepted')
 approved=read('batch5_semantic_support_verification.json')['required_support'][0];broken=copy.deepcopy(read(approved['path']));broken['current_required_addenda'][0]['content']={'forged':'science'}
 try:check_semantic_addendum_identity(broken,approved['canonical_sha256'])
 except AssertionError:tests.append({'test':'batch5_semantic_fact_tamper_rejected','passed':True})
 else:raise AssertionError('Changed semantic facts accepted')
 from resolve_reference import resolve_json_pointer
 assert resolve_json_pointer('R016','evidence_layer.json','/current_evidence_view',True)==('full/R016/evidence/record.json','')
 assert resolve_json_pointer('A124','A124_candidate/A124_evidence.json','/scope',True)==('full/A124/evidence/record.json','/historical_scope_declaration/scope')
 assert resolve_json_pointer('A124','A124_candidate/A124_evidence.json','/record_id',True)==('full/A124/evidence/record.json','/record_id')
 try:resolve_json_pointer('A124','A124_candidate/A124_evidence.json','/unverified_container',True)
 except ValueError:tests.append({'test':'unverified_old_version_pointer_rejected','passed':True})
 else:raise AssertionError('Unverified old-version pointer accepted')
 for mode in ['old_source_hash','current_leaf_hash','pointer_map']:
  proof=copy.deepcopy(read('batch5_A124_accepted_successor_bindings.json'));selection=copy.deepcopy(read('full/A124/version_selection.json'))
  if mode=='old_source_hash':proof['bindings'][0]['old_source_sha256']='0'*64
  elif mode=='current_leaf_hash':proof['bindings'][0]['scientific_leaf_mappings'][0]['current_canonical_value_sha256']='0'*64
  else:selection['accepted_successor_aliases'][0]['pointer_mapping']['/record_id']='/wrong'
  try:check_accepted_successor_bindings(proof,selection)
  except AssertionError:tests.append({'test':'forged_successor_'+mode+'_rejected','passed':True})
  else:raise AssertionError('Forged accepted successor proof passed')
 for pointer in ['/current_evidence_views','/historical_evidence']:
  try:resolve_json_pointer('R016','evidence_layer.json',pointer,True)
  except ValueError:tests.append({'test':'unproven_pointer_'+pointer+'_rejected','passed':True})
  else:raise AssertionError('Unproven pointer prefix accepted')
 broken=copy.deepcopy(read('full/A158/version_selection.json'));del broken['active_reference_aliases']['当前验收依据.json']
 try:check_required_original_member_aliases(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'required_original_member_alias_deletion_rejected','passed':True})
 else:raise AssertionError('Required legacy-to-portable alias deletion accepted')
 broken=copy.deepcopy(read('full/'+m['batch6_candidate_ids'][0]+'/version_selection.json'));required=broken['required_supporting_files'][0];del broken['active_reference_aliases'][required['source_member']]
 try:check_required_original_member_aliases(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'batch6_required_original_alias_missing_rejected','passed':True})
 else:raise AssertionError('New required alias deletion accepted')

 broken=copy.deepcopy(read('full/A152/version_selection.json'));broken['supplemental_hash_scoped_manifest_bindings'][0]['target_hash_chain']['original_sha256']='0'*64
 try:check_batch7_supplemental_proofs(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'batch7_supplemental_hash_chain_tamper_rejected','passed':True})
 else:raise AssertionError('Forged supplemental hash chain accepted')
 for pid in ['A152','A121']:
  broken=copy.deepcopy(read('full/'+pid+'/version_selection.json'));broken['required_runtime_pointer_bindings'][0]['target_json_pointer']='/not_present'
  try:check_batch7_runtime_pointers(pid,broken)
  except (AssertionError,KeyError,IndexError):tests.append({'test':pid+'_required_pointer_tamper_rejected','passed':True})
  else:raise AssertionError('Broken runtime pointer accepted')
 broken=copy.deepcopy(read('full/A152/version_selection.json'));broken['required_supporting_files']=[f for f in broken['required_supporting_files'] if not f['path'].endswith('/protocol_records.complete.json')]
 try:check_batch7_a152_protocol(broken)
 except AssertionError:tests.append({'test':'A152_required_complete_protocol_missing_rejected','passed':True})
 else:raise AssertionError('Missing complete protocol accepted')
 for mode in ['fact','binding']:
  broken=copy.deepcopy(read('full/A152/support/mandatory_semantic_preservation.json'))
  if mode=='fact':broken['mandatory_addenda'][0]['facts']={'tampered':True}
  else:broken['source_groups'][0]['occurrences'][0]['portable_source_file_bindings']=['full/A152/support/absent.json']
  try:check_batch7_semantic_support('A152',semantic_object=broken)
  except AssertionError:tests.append({'test':'A152_semantic_'+mode+'_tamper_rejected','passed':True})
  else:raise AssertionError('Semantic tampering accepted')
 for pid in ['A121','A152']:
  broken=copy.deepcopy(read('full/'+pid+'/version_selection.json'));broken['required_supporting_files']=[f for f in broken['required_supporting_files'] if not f['path'].endswith('/mandatory_semantic_preservation.json')]
  try:check_batch7_semantic_support(pid,broken)
  except AssertionError:tests.append({'test':pid+'_mandatory_semantic_support_missing_rejected','passed':True})
  else:raise AssertionError('Missing semantic support accepted')
 broken=copy.deepcopy(read('full/'+m['batch7_candidate_ids'][0]+'/version_selection.json'));required=broken['required_supporting_files'][0];del broken['active_reference_aliases'][required['source_member']]
 try:check_required_original_member_aliases(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'batch7_required_original_alias_missing_rejected','passed':True})
 else:raise AssertionError('New required alias deletion accepted')
 for field,pid in [('occurrence_scoped_historical_reference_dispositions','A145'),('source_metadata_reference_bindings','A145'),('required_runtime_pointer_bindings','A159')]:
  for mode in ['missing','tampered']:
   broken=copy.deepcopy(read('full/'+pid+'/version_selection.json'))
   if mode=='missing':broken[field].pop()
   elif field=='occurrence_scoped_historical_reference_dispositions':broken[field][0]['declared_target_hash_value']='0'*64
   elif field=='source_metadata_reference_bindings':broken[field][0]['reference']='wrong'
   else:broken[field][0]['target_json_pointer']='/unknown'
   try:check_batch8_additional_bindings(broken,{f['path']:f for f in fm+sm})
   except (AssertionError,KeyError):tests.append({'test':field+'_'+mode+'_rejected','passed':True})
   else:raise AssertionError('Invalid scoped provenance or runtime binding accepted')
 from resolve_reference import resolve_reference_occurrence
 contextual=read('full/M_N1254/version_selection.json');binding=contextual['occurrence_scoped_reference_bindings'][0]
 assert resolve_reference_occurrence('M_N1254',binding['source_file'],binding['json_pointer'],allow_candidate=True)==binding['target']
 for mode in ['missing','wrong_reference','wrong_declared_hash','wrong_hash_pointer','cross_paper_target','current_root_target','duplicate']:
  broken=copy.deepcopy(contextual);b=broken['occurrence_scoped_reference_bindings'][0]
  if mode=='missing':broken['occurrence_scoped_reference_bindings']=[]
  elif mode=='wrong_reference':b['reference']='wrong.json'
  elif mode=='wrong_declared_hash':b['declared_target_hash_value']='0'*64
  elif mode=='wrong_hash_pointer':b['declared_target_hash_pointer']='/sha256'
  elif mode=='cross_paper_target':b['target']='full/A106/evidence/record.json'
  elif mode=='current_root_target':b['target']=broken['active_scientific_files'][0]['path']
  else:broken['occurrence_scoped_reference_bindings'].append(copy.deepcopy(b))
  try:check_batch8_occurrence_bindings(broken,{f['path']:f for f in fm+sm})
  except (AssertionError,KeyError):tests.append({'test':'contextual_'+mode+'_rejected','passed':True})
  else:raise AssertionError('Invalid contextual binding accepted')
 for mode in ['default_disabled','unknown_pointer','wrong_reference']:
  args={'allow_candidate':mode!='default_disabled'}
  if mode=='wrong_reference':args['reference']='wrong.json'
  ptr='/unknown' if mode=='unknown_pointer' else binding['json_pointer']
  try:resolve_reference_occurrence('M_N1254',binding['source_file'],ptr,**args)
  except (KeyError,ValueError):tests.append({'test':'context_resolver_'+mode+'_rejected','passed':True})
  else:raise AssertionError('Context resolver unsafe fallback')
 for mode in ['missing','wrong_original','promoted']:
  broken=copy.deepcopy(read('full/M_N1357/version_selection.json'));path='full/M_N1357/support/R2_revised_record.json'
  if mode=='missing':broken['required_supporting_files']=[f for f in broken['required_supporting_files'] if f['path']!=path]
  elif mode=='wrong_original':next(f for f in broken['required_supporting_files'] if f['path']==path)['accepted_original_sha256']='0'*64
  else:broken['active_scientific_files'].append({'path':path})
  try:check_batch8_m1357_snapshot(broken)
  except AssertionError:tests.append({'test':'M_N1357_snapshot_'+mode+'_rejected','passed':True})
  else:raise AssertionError('Invalid accepted snapshot accepted')
 broken=copy.deepcopy(read('full/A145/version_selection.json'));broken['required_supporting_files']=[f for f in broken['required_supporting_files'] if not f['path'].endswith('/mandatory_semantic_preservation.json')]
 try:check_batch8_a145_semantics(broken)
 except AssertionError:tests.append({'test':'A145_mandatory_semantic_support_missing_rejected','passed':True})
 else:raise AssertionError('Missing A145 support accepted')
 broken=copy.deepcopy(read('full/A145/support/mandatory_semantic_preservation.json'));broken['mandatory_addenda'][0]['safe_nonverbatim_preservation']='tampered'
 try:check_batch8_a145_semantics(semantic_object=broken)
 except AssertionError:tests.append({'test':'A145_mandatory_semantic_fact_tamper_rejected','passed':True})
 else:raise AssertionError('Changed A145 fact accepted')
 broken=copy.deepcopy(read('full/'+m['batch8_candidate_ids'][0]+'/version_selection.json'));required=broken['required_supporting_files'][0];del broken['active_reference_aliases'][required['source_member']]
 try:check_required_original_member_aliases(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'batch8_required_original_alias_missing_rejected','passed':True})
 else:raise AssertionError('New required alias deletion accepted')
 broken=copy.deepcopy(sums);del broken['full/A128/support/package/SHA256SUMS.json']
 try:check_complete_hash_inventory(broken)
 except AssertionError:tests.append({'test':'nested_hash_manifest_omission_rejected','passed':True})
 else:raise AssertionError('Missing nested checksum file was accepted')
 for pid,key in [('REV_31945400','required_runtime_pointer_bindings'),('REV_31945400','composite_frozen_base_binding'),('REV_28082099','signed_scientific_compound_binding'),('M043','metadata_only_accepted_final_binding'),('M_N0097','metadata_only_accepted_final_binding'),('A108','occurrence_scoped_historical_reference_dispositions'),('A111','occurrence_scoped_historical_reference_dispositions'),('A146','occurrence_scoped_historical_reference_dispositions')]:
  broken=copy.deepcopy(read('full/'+pid+'/version_selection.json'));del broken[key]
  try:check_batch9_exact_reference_proofs(broken,{f['path']:f for f in fm+sm})
  except (AssertionError,KeyError):tests.append({'test':'batch9_'+pid+'_'+key+'_missing_rejected','passed':True})
  else:raise AssertionError('Mandatory exact proof set deletion accepted')
 broken=copy.deepcopy(read('full/'+m['batch9_candidate_ids'][0]+'/version_selection.json'));required=broken['required_supporting_files'][0];del broken['active_reference_aliases'][required['source_member']]
 try:check_required_original_member_aliases(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'batch9_required_original_alias_missing_rejected','passed':True})
 else:raise AssertionError('New required alias deletion accepted')
 from resolve_reference import resolve_batch10_subdocument_reference, resolve_batch10_support_fragment
 rs=read('full/R017/version_selection.json');b=rs['occurrence_scoped_subdocument_projections'][0]
 args=['R017',b['source_file'],b['source_reference_pointer'],b['reference'],b['original_ancestor_identity']['sha256'],'/current_evidence_view']
 assert resolve_batch10_subdocument_reference(*args,allow_candidate=True)==(b['target'],'')
 for mode in ['default_disabled','cross_paper','wrong_context','wrong_reference','wrong_ancestor','empty_fragment','near_prefix','history_branch']:
  bad=list(args)
  if mode=='cross_paper':bad[0]='R006'
  elif mode=='wrong_context':bad[2]='/unknown'
  elif mode=='wrong_reference':bad[3]='wrong.json'
  elif mode=='wrong_ancestor':bad[4]='0'*64
  elif mode=='empty_fragment':bad[5]=''
  elif mode=='near_prefix':bad[5]='/current_evidence_viewX'
  elif mode=='history_branch':bad[5]='/historical'
  try:resolve_batch10_subdocument_reference(*bad,allow_candidate=mode!='default_disabled')
  except (AssertionError,KeyError,ValueError):tests.append({'test':'batch10_subtree_'+mode+'_rejected','passed':True})
  else:raise AssertionError('Unsafe subtree fallback accepted')
 from resolve_reference import resolve_batch10_reference_occurrence
 for pid in ['R006','R023']:
  context=read('full/'+pid+'/version_selection.json')['occurrence_scoped_reference_bindings'][0]
  for mode in ['default_disabled','wrong_context','wrong_reference','cross_paper']:
   args=[pid,context['source_file'],context['json_pointer']];ref=context['reference']
   if mode=='wrong_context':args[2]='/unknown'
   elif mode=='wrong_reference':ref='wrong.json'
   elif mode=='cross_paper':args[0]='R017'
   try:resolve_batch10_reference_occurrence(*args,reference=ref,allow_candidate=mode!='default_disabled')
   except (AssertionError,KeyError,ValueError):tests.append({'test':'batch10_'+pid+'_'+mode+'_rejected','passed':True})
   else:raise AssertionError('Unsafe nonactive support context accepted')
 fragment=next(x for x in rs['required_runtime_pointer_bindings'] if x['binding_kind']=='explicit_file_fragment_reference')
 assert resolve_batch10_support_fragment('R017',fragment['source_file'],fragment['source_json_pointer'],allow_candidate=True)==(fragment['target'],fragment['target_json_pointer'])
 try:resolve_batch10_support_fragment('R017',fragment['source_file'],fragment['source_json_pointer'],reference='inherited_status.json#/wrong',allow_candidate=True)
 except (AssertionError,KeyError,ValueError):tests.append({'test':'batch10_wrong_support_fragment_rejected','passed':True})
 else:raise AssertionError('Wrong support fragment accepted')
 for pid,key in [('R017','occurrence_scoped_subdocument_projections'),('R017','required_runtime_pointer_bindings'),('R017','mandatory_local_companion_identity_bindings'),('M_N0022','metadata_only_accepted_final_binding'),('R006','metadata_only_accepted_final_binding'),('R006','occurrence_scoped_reference_bindings'),('R023','occurrence_scoped_reference_bindings')]:
  broken=copy.deepcopy(read('full/'+pid+'/version_selection.json'));del broken[key]
  try:check_batch10_exact_reference_proofs(broken,{f['path']:f for f in fm+sm})
  except (AssertionError,KeyError):tests.append({'test':'batch10_'+pid+'_'+key+'_missing_rejected','passed':True})
  else:raise AssertionError('Mandatory proof deletion accepted')
 broken=copy.deepcopy(rs);broken['required_supporting_files']=[f for f in broken['required_supporting_files'] if f['path']!=fragment['target']]
 try:check_batch10_exact_reference_proofs(broken,{f['path']:f for f in fm+sm})
 except (AssertionError,KeyError):tests.append({'test':'batch10_fifth_companion_missing_rejected','passed':True})
 else:raise AssertionError('Missing fifth companion accepted')
 broken=copy.deepcopy(read('full/'+m['batch10_candidate_ids'][0]+'/version_selection.json'));required=broken['required_supporting_files'][0];del broken['active_reference_aliases'][required['source_member']]
 try:check_required_original_member_aliases(broken,{f['path']:f for f in fm+sm})
 except AssertionError:tests.append({'test':'batch10_required_original_alias_missing_rejected','passed':True})
 else:raise AssertionError('New required alias deletion accepted')
 return {'result':'PASS','reviewed_first_bundle_full':9,'reviewed_batch2_full':20,'proposed_batch3_full':20,'candidate_total_full':119,'proposed_batch11_full':1,'proposed_batch10_full':7,'proposed_batch9_full':12,'proposed_batch8_full':12,'proposed_batch7_full':12,'proposed_batch6_full':12,'proposed_batch5_full':10,'proposed_batch4_full':4,'catalog':224,'science_files':456,'support_files':1709,'first_nine_batches_per_paper_files_unchanged':True,'negative_tests':tests,'scope':'Local candidate consistency, exact reference closure and preserved projection evidence. Not publication authorization, new source review or full repository CI.'}
if __name__=='__main__':
 try:print(json.dumps(main(),indent=2))
 except Exception as e:print(json.dumps({'result':'FAIL','error':str(e)}));sys.exit(1)
